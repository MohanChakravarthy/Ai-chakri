#!/usr/bin/env python3
"""
dev_repos.py - sets up the development repo(s) next to the QA repo, the same way every time.

Part of the QA AI skills. Used by qa-knowledge-setup. It only clones, fetches and fast-forwards
the development repos with the team's normal git sign-in; it never edits, builds, installs, commits
or pushes anything in them. Run it from the QA repo folder (or pass --qa-repo).

Layout (the QA repo is never moved). Testers do not need to know which repo is front end or back end:
every repo goes flat into dev/, and extract_dev.py works out from the code what each one is.
  <parent>/<qa repo>/                     unchanged
  <parent>/dev/<repo name>/               one folder per development repo
  <parent>/<qa repo>.code-workspace       backup: QA repo and dev, for anyone who wants to open it

Commands (all print JSON):
  branches <link> [<link> ...]            per repo: branch from the link (if it names one), default
                                          branch, suggestions and all branches; at most --max (10) links
  clone --url <link> [--branch <name>]    clone into dev/<repo name>, or update an existing clone
  finish                                  dev-config.md, backup workspace file, extract command
  show                                    add the dev folder to the editor window that is open now
                                          (VS Code, Devin Desktop/Windsurf, Cursor), if possible
  check                                   re-clone missing repos, count new commits (for refresh)
  pull                                    fast-forward every repo to its branch, update dev-config.md
  --self-test

Python 3.8+, standard library only; needs git on PATH.
"""
import argparse, json, os, re, shutil, stat, subprocess, sys, tempfile, datetime
from urllib.parse import unquote

MAX_LINKS = 10            # links taken per round; the rest are asked for in the next round
CRED_RE = re.compile(r"^[a-z][a-z0-9+.-]*://[^/@\s]+@", re.I)


class Fail(Exception):
    pass


def remove_tree(path):
    """Delete a folder that holds a git clone. On Windows git marks its own object files read-only,
    so the read-only flag is cleared and the delete retried for each file that refuses."""
    def retry(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
            func(p)
        except OSError:
            pass
    if not os.path.exists(path):
        return
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=retry)
    else:
        shutil.rmtree(path, onerror=retry)


def git(*args, cwd=None, timeout=600):
    try:
        r = subprocess.run(["git"] + list(args), cwd=cwd, capture_output=True, text=True, timeout=timeout,
                           env=dict(os.environ, GIT_TERMINAL_PROMPT="0"))
    except FileNotFoundError:
        raise Fail("git is not installed or not on PATH")
    except subprocess.TimeoutExpired:
        raise Fail("git took too long: " + " ".join(args[:2]))
    if r.returncode != 0:
        msg = (r.stderr or r.stdout).strip().splitlines()
        raise Fail(clean(msg[-1] if msg else "git " + args[0] + " failed"))
    return r.stdout.strip()


def clean(text):
    """Remove any user name or token from text that is shown or stored."""
    return re.sub(r"([a-z][a-z0-9+.-]*://)[^/@\s]+@", r"\1", str(text), flags=re.I)


def check_url(url):
    url = url.strip()
    if CRED_RE.match(url):
        raise Fail("The URL contains a user name, password or token. Paste the plain URL; git uses your normal sign-in.")
    if not re.match(r"^([a-z][a-z0-9+.-]*://|git@|[\w.-]+@[\w.-]+:)", url, re.I) and not os.path.isdir(url):
        raise Fail("This does not look like a git repo URL: " + url)
    return url


def split_url(text):
    """A pasted repo link -> (clone URL, branch text or None). Understands the branch page links of
    GitHub (/tree/<branch>), GitLab (/-/tree/<branch>), Bitbucket Cloud (/src/<branch>), Bitbucket
    Server (/projects/P/repos/r/browse?at=refs/heads/<branch>), Azure DevOps (?version=GB<branch>),
    and '<url>#<branch>' or '<url> <branch>'. The branch text may still hold a folder path after the
    branch; branches() trims it against the real branch list."""
    s = text.strip().strip("<>\"'")
    if " " in s:
        s, _, b = s.partition(" ")
        return split_url(s)[0], b.strip() or None
    if "#" in s and not s.endswith("#"):
        s, _, b = s.partition("#")
        return split_url(s)[0], unquote(b)
    m = re.match(r"^(https?://[^?#]+?)/-/(?:tree|blob|commits?)/([^?#]+)", s)                       # GitLab
    if m:
        return m.group(1), unquote(m.group(2)).strip("/")
    m = re.match(r"^(https?://[^/]+)(/.*?)?/projects/([^/]+)/repos/([^/?#]+)[^?#]*(?:\?(.*))?$", s, re.I)  # Bitbucket Server
    if m:
        branch = None
        at = re.search(r"(?:^|&)at=([^&]+)", m.group(5) or "")
        if at:
            branch = re.sub(r"^refs/heads/", "", unquote(at.group(1)))
        return f"{m.group(1)}{m.group(2) or ''}/scm/{m.group(3).lower()}/{m.group(4)}.git", branch
    m = re.match(r"^(https?://bitbucket\.org/[^/]+/[^/?#]+)/(?:src|branch)/([^?#]+)", s)               # Bitbucket Cloud
    if m:
        return m.group(1), unquote(m.group(2)).strip("/")
    m = re.match(r"^(https?://[^?#]+/_git/[^/?#]+)(?:\?(.*))?$", s)                                    # Azure DevOps
    if m:
        v = re.search(r"(?:^|&)version=GB([^&]+)", m.group(2) or "")
        return m.group(1), unquote(v.group(1)) if v else None
    m = re.match(r"^(https?://[^/]+/[^/]+/[^/?#]+?)(?:\.git)?/(?:tree|blob|commits?)/([^?#]+)", s)     # GitHub
    if m:
        return m.group(1), unquote(m.group(2)).strip("/")
    if s.startswith("http"):
        s = re.sub(r"[?#].*$", "", s).rstrip("/")
    return s, None


def pick_branch(hint, heads):
    """The longest leading part of hint that is a real branch ('feature/x/src/app' -> 'feature/x')."""
    if not hint:
        return None
    parts = hint.strip("/").split("/")
    for i in range(len(parts), 0, -1):
        cand = "/".join(parts[:i])
        if cand in heads:
            return cand
    return None


def repo_name(url):
    name = re.split(r"[/:\\]", url.rstrip("/\\"))[-1]
    return re.sub(r"\.git$", "", name) or "repo"


def same_url(a, b):
    n = lambda u: re.sub(r"(\.git)?/?$", "", clean(u or "").strip().lower())
    return n(a) == n(b)


def paths(qa_repo):
    qa = os.path.abspath(qa_repo)
    parent = os.path.dirname(qa)
    return qa, parent, os.path.join(parent, "dev")


def kdir(qa):
    """The knowledge folder: <QA repo>/qa-ai-skills/knowledge, or <QA repo>/knowledge in a repo set up before."""
    home = os.path.join(qa, "qa-ai-skills")
    return os.path.join(home if os.path.isdir(home) else qa, "knowledge")


def owner_of(url):
    parts = [p for p in re.split(r"[/:\\]", re.sub(r"\.git$", "", url.rstrip("/\\"))) if p]   # also Windows paths
    return parts[-2] if len(parts) >= 2 else "other"


def folder_for(dev, url):
    """dev/<repo name>; if that folder holds a different repo already, dev/<repo name>-<owner>."""
    name = repo_name(url)
    first = os.path.join(dev, name)
    if os.path.isdir(os.path.join(first, ".git")):
        try:
            if not same_url(git("config", "--get", "remote.origin.url", cwd=first), url):
                return os.path.join(dev, f"{name}-{re.sub(r'[^A-Za-z0-9_.-]', '-', owner_of(url))}")
        except Fail:
            pass
    return first


def rel(path, start):
    return os.path.relpath(path, start).replace(os.sep, "/")


def head(folder):
    return {"commit": git("rev-parse", "HEAD", cwd=folder),
            "commit_date": git("log", "-1", "--format=%cs", cwd=folder),
            "branch": git("rev-parse", "--abbrev-ref", "HEAD", cwd=folder)}


# ------------------------------------------------------------------------------------- commands
def version_key(name):
    return [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", name)]


def cmd_branches(text, qa_repo=None):
    url, hint = split_url(text)
    url = check_url(url)
    if qa_repo and not hint:                # added before: its branch is known, nothing to ask and nothing to list
        known = next((r for r in read_config(qa_repo) if same_url(r["url"], url) and r.get("branch")), None)
        if known:
            return {"url": url, "name": repo_name(url), "branch_from_url": known["branch"], "already_added": True,
                    "folder": known["folder"], "default_branch": None, "suggested": [known["branch"]], "all": [known["branch"]], "count": 1}
    heads = [l.split("refs/heads/", 1)[1] for l in git("ls-remote", "--heads", url, timeout=120).splitlines() if "refs/heads/" in l]
    default = None
    try:
        m = re.search(r"ref: refs/heads/(\S+)\s+HEAD", git("ls-remote", "--symref", url, "HEAD", timeout=120))
        default = m.group(1) if m else None
    except Fail:
        pass
    suggested = []
    for b in [default, "develop", "development", "main", "master"]:
        if b and b in heads and b not in suggested:
            suggested.append(b)
    releases = sorted((b for b in heads if re.match(r"^(release|releases|rel)[/_-]", b)), key=version_key, reverse=True)
    if releases and releases[0] not in suggested:
        suggested.append(releases[0])
    branch = pick_branch(hint, heads)
    res = {"url": url, "name": repo_name(url), "branch_from_url": branch, "default_branch": default,
           "suggested": suggested[:4], "all": sorted(heads, key=str.lower), "count": len(heads)}
    if hint and not branch:
        res["branch_not_found"] = hint      # ask for this repo's branch, and say the one in the link was not found
    return res


def cmd_clone(qa_repo, url, branch=None, record=True):
    url, hint = split_url(url)
    url = check_url(url)
    if not branch and hint:
        heads = [l.split("refs/heads/", 1)[1] for l in git("ls-remote", "--heads", url, timeout=120).splitlines() if "refs/heads/" in l]
        branch = pick_branch(hint, heads)
        if not branch:
            raise Fail(f"The branch in the link ({hint}) does not exist in {repo_name(url)}")
    if not branch:
        raise Fail("No branch given: add --branch, or paste the branch's own link")
    qa, parent, dev = paths(qa_repo)
    migrate_layout(qa_repo)
    folder = folder_for(dev, url)
    if os.path.abspath(folder).startswith(qa + os.sep):
        raise Fail("The development repo must not go inside the QA repo")
    action = "cloned"
    if os.path.isdir(folder) and os.listdir(folder):
        if not os.path.isdir(os.path.join(folder, ".git")):
            raise Fail(f"{rel(folder, parent)} already exists and is not a git clone; I did not touch it")
        remote = git("config", "--get", "remote.origin.url", cwd=folder)
        if not same_url(remote, url):
            raise Fail(f"{rel(folder, parent)} is a clone of a different repo ({clean(remote)}); I did not touch it")
        if git("status", "--porcelain", cwd=folder):
            raise Fail(f"{rel(folder, parent)} has local changes; I did not touch it")
        before = head(folder)["commit"]
        try:                                  # commits made in this copy (not from the server): measured BEFORE fetching
            own = git("rev-list", "--count", f"refs/remotes/origin/{branch}..HEAD", cwd=folder).strip() not in ("", "0")
        except Fail:
            own = False
        git("fetch", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}", cwd=folder, timeout=600)
        try:
            git("checkout", branch, cwd=folder)
        except Fail:
            git("checkout", "-b", branch, "--track", f"origin/{branch}", cwd=folder)
        try:
            git("merge", "--ff-only", f"origin/{branch}", cwd=folder)
        except Fail:
            # the branch was rewritten on the server (force push). This is a read-only copy: when it holds no
            # commits of its own, it simply takes the server's version; otherwise it is left alone.
            if own:
                raise Fail(f"{rel(folder, parent)} has commits of its own; I did not touch it")
            git("reset", "--hard", f"origin/{branch}", cwd=folder)
        after = head(folder)["commit"]
        new = 0
        if before and after and before != after:
            try:
                new = int(git("rev-list", "--count", f"{before}..{after}", cwd=folder).strip() or 0)
            except (Fail, ValueError):
                new = 1
        action = "updated" if before != after else "up to date"
    else:
        os.makedirs(os.path.dirname(folder), exist_ok=True)
        git("clone", "--branch", branch, "--single-branch", url, folder, timeout=1800)
    info = head(folder)
    sel_path = os.path.join(kdir(qa), ".tmp", "dev-selection.json")     # the repos chosen in this run
    extra = {"new_commits": new} if action != "cloned" else {}
    if not record:
        return dict({"action": action, "url": clean(url), "branch": branch, "folder": rel(folder, qa),
                     "commit": info["commit"], "commit_date": info["commit_date"]}, **extra)
    os.makedirs(os.path.dirname(sel_path), exist_ok=True)
    try:
        sel = json.load(open(sel_path, encoding="utf-8"))
    except Exception:
        sel = []
    sel = [s for s in sel if s != rel(folder, qa)] + [rel(folder, qa)]
    json.dump(sel, open(sel_path, "w", encoding="utf-8"))
    return dict({"action": action, "url": clean(url), "branch": branch, "folder": rel(folder, qa),
                 "commit": info["commit"], "commit_date": info["commit_date"]}, **extra)


def migrate_layout(qa_repo):
    """Move clones from the older layout (dev/frontend/<repo>, dev/backend/<repo>) to dev/<repo>.
    Only clean clones are moved, and only when dev/<repo> is free; returns the moves made."""
    qa, parent, dev = paths(qa_repo)
    moved = []
    for group in ("frontend", "backend"):
        g = os.path.join(dev, group)
        if not os.path.isdir(g) or os.path.isdir(os.path.join(g, ".git")):
            continue
        for sub in sorted(os.listdir(g)):
            src = os.path.join(g, sub)
            if not os.path.isdir(os.path.join(src, ".git")):
                continue
            dst = os.path.join(dev, sub)
            if os.path.exists(dst):
                dst = os.path.join(dev, f"{sub}-{group}")
            if os.path.exists(dst):
                continue
            try:
                if git("status", "--porcelain", cwd=src):
                    continue
            except Fail:
                continue
            os.rename(src, dst)
            moved.append({"from": rel(src, qa), "to": rel(dst, qa)})
        try:
            if not os.listdir(g):
                os.rmdir(g)
        except OSError:
            pass
    if moved:                                           # keep dev-config.md pointing at the new folders
        cfg = os.path.join(kdir(qa), "dev-config.md")
        if os.path.isfile(cfg):
            text = open(cfg, encoding="utf-8").read()
            for m in moved:
                text = text.replace(f"| {m['from']} |", f"| {m['to']} |")
            open(cfg, "w", encoding="utf-8").write(text)
    return moved


def find_clones(qa_repo):
    """Development clones under <parent>/dev (dev/<repo>; the older dev/frontend|backend/<repo> too)."""
    qa, parent, dev = paths(qa_repo)
    found = []
    if not os.path.isdir(dev):
        return found
    for entry in sorted(os.listdir(dev), key=str.lower):
        p = os.path.join(dev, entry)
        if os.path.isdir(os.path.join(p, ".git")):
            found.append(p)
        elif entry in ("frontend", "backend") and os.path.isdir(p):
            found += [os.path.join(p, s) for s in sorted(os.listdir(p), key=str.lower) if os.path.isdir(os.path.join(p, s, ".git"))]
    return found


def write_workspace(qa_repo, clones):
    """Backup workspace file next to the QA repo: the QA repo first, then dev."""
    qa, parent, dev = paths(qa_repo)
    ws_path = os.path.join(parent, os.path.basename(qa) + ".code-workspace")
    data = {}
    if os.path.isfile(ws_path):
        try:
            txt = open(ws_path, encoding="utf-8").read()
            txt = re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", txt, flags=re.S)
            data = json.loads(re.sub(r",\s*([}\]])", r"\1", txt))
        except Exception:
            raise Fail(f"{os.path.basename(ws_path)} exists but is not valid JSON; I did not change it")
    folders = data.get("folders") or []
    qa_name = os.path.basename(qa)
    have = [f.get("path", "").replace("\\", "/").rstrip("/") for f in folders]
    qa_entry = [f for f, h in zip(folders, have) if h == qa_name] or [{"path": qa_name}]
    # one "dev" folder, which shows frontend/ and backend/ with the repos inside them; entries an
    # older version added for each repo (dev/frontend/<repo>) are folded into it
    rest = [f for f, h in zip(folders, have) if h != qa_name and h != "dev" and not h.startswith("dev/")]
    dev_entry = [f for f, h in zip(folders, have) if h == "dev"] or [{"path": "dev"}]
    data["folders"] = qa_entry + (dev_entry if clones else []) + rest    # QA repo first, then dev, then anything people added
    settings = data.setdefault("settings", {})
    ro = settings.setdefault("files.readonlyInclude", {})
    ro[dev.replace("\\", "/") + "/**"] = True
    settings.setdefault("git.repositoryScanMaxDepth", 2)                 # Source Control finds dev/frontend/<repo>
    with open(ws_path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
    json.load(open(ws_path, encoding="utf-8"))                           # read back once
    return ws_path


def read_config(qa_repo):
    """Rows of knowledge/dev-config.md (also the older format with a Role column)."""
    p = os.path.join(kdir(os.path.abspath(qa_repo)), "dev-config.md")
    rows, header = [], None
    if not os.path.isfile(p):
        return rows
    for line in open(p, encoding="utf-8"):
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        low = [c.lower() for c in cells]
        if "url" in low and "branch" in low:
            header = low
            continue
        if header is None or set("".join(cells)) <= set("-: "):
            continue
        r = dict(zip(header, cells))
        if r.get("url") and r.get("folder"):
            rows.append({"url": r["url"], "branch": r.get("branch", ""), "commit": r.get("commit", ""),
                         "commit_date": r.get("commit date", ""), "folder": r["folder"], "built": r.get("built", "")})
    return rows


def write_config(qa_repo, rows, ws_path):
    qa = os.path.abspath(qa_repo)
    os.makedirs(kdir(qa), exist_ok=True)
    lines = ["# Development repos (read-only)", "",
             "Written by `dev_repos.py`. The skills only read these repos: nothing is changed, built or committed there.",
             "Which repo is front end or back end is worked out from the code (see `dev/index.md` in the knowledge folder).", "",
             "| Repo | URL | Branch | Commit | Commit date | Folder | Built |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {os.path.basename(r['folder'])} | {clean(r['url'])} | {r['branch']} | {r['commit'][:12]} | {r['commit_date']} | {r['folder']} | {r['built']} |")
    lines += ["", f"Backup workspace file: {rel(ws_path, qa)}", ""]
    with open(os.path.join(kdir(qa), "dev-config.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


def extract_command(qa, rows):
    args = []
    for r in rows:
        args += ["--repo", r["folder"]]
    k = os.path.relpath(kdir(qa), qa).replace("\\", "/")
    script = os.path.relpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "extract_dev.py"), qa).replace("\\", "/")
    return f"python {script} " + " ".join(args) + f" --qa-extract {k}/.extract --out {k}/.extract/dev"


def cmd_finish(qa_repo):
    qa, parent, dev = paths(qa_repo)
    moved = migrate_layout(qa_repo)
    clones = find_clones(qa_repo)
    sel_path = os.path.join(kdir(qa), ".tmp", "dev-selection.json")
    # the repos recorded before plus the ones cloned in this run (links can come in several rounds);
    # a repo is dropped only when its folder is deleted
    try:
        chosen = set(json.load(open(sel_path, encoding="utf-8")))
    except Exception:
        chosen = set()
    chosen |= {r["folder"] for r in read_config(qa_repo)}
    if chosen:
        clones = [c for c in clones if rel(c, qa) in chosen]
    if not clones:
        raise Fail("No development clone found in " + rel(dev, parent) + "; run the clone command first")
    today = datetime.date.today().isoformat()
    rows = []
    for folder in clones:
        info = head(folder)
        f = rel(folder, qa)
        rows.append({"url": clean(git("config", "--get", "remote.origin.url", cwd=folder)),
                     "branch": info["branch"], "commit": info["commit"], "commit_date": info["commit_date"],
                     "folder": f, "built": today})
    ws = write_workspace(qa_repo, clones)
    write_config(qa_repo, rows, ws)
    if os.path.isfile(sel_path):
        os.remove(sel_path)
    return {"backup_workspace": rel(ws, qa), "dev_config": rel(os.path.join(kdir(qa), "dev-config.md"), qa), "repos": rows,
            "moved_from_older_layout": moved, "extract_command": extract_command(qa, rows)}


def cmd_check(qa_repo):
    """For refresh: re-clone any missing repo from dev-config.md, then count new commits."""
    qa, parent, dev = paths(qa_repo)
    moved = migrate_layout(qa_repo)
    rows = read_config(qa_repo)
    if not rows:
        return {"configured": False, "repos": []}
    out = []
    for r in rows:
        folder = os.path.normpath(os.path.join(qa, r["folder"]))
        item = {"repo": os.path.basename(r["folder"]), "branch": r["branch"], "folder": r["folder"], "recorded_commit": r["commit"]}
        try:
            if not os.path.isdir(os.path.join(folder, ".git")):
                cmd_clone(qa_repo, r["url"], r["branch"], record=False)
                item["recloned"] = True
            git("fetch", "origin", f"+refs/heads/{r['branch']}:refs/remotes/origin/{r['branch']}", cwd=folder, timeout=600)
            item["new_commits"] = int(git("rev-list", "--count", f"HEAD..origin/{r['branch']}", cwd=folder) or 0)
            item["current_commit"] = git("rev-parse", "HEAD", cwd=folder)
            item["knowledge_is_older"] = not item["current_commit"].startswith(r["commit"])
        except Fail as e:
            item["error"] = str(e)
        out.append(item)
    ws = os.path.join(parent, os.path.basename(qa) + ".code-workspace")
    if not os.path.isfile(ws) and find_clones(qa_repo):
        write_workspace(qa_repo, find_clones(qa_repo))
    return {"configured": True, "repos": out, "moved_from_older_layout": moved}


def cmd_pull(qa_repo):
    qa = os.path.abspath(qa_repo)
    done = []
    for r in read_config(qa_repo):
        folder = os.path.normpath(os.path.join(qa, r["folder"]))
        if git("status", "--porcelain", cwd=folder):
            raise Fail(f"{r['folder']} has local changes; I did not pull")
        git("fetch", "origin", f"+refs/heads/{r['branch']}:refs/remotes/origin/{r['branch']}", cwd=folder, timeout=600)
        git("merge", "--ff-only", f"origin/{r['branch']}", cwd=folder)
        done.append(r["folder"])
    res = cmd_finish(qa_repo)
    res["pulled"] = done
    return res


EDITORS = [  # (words in the editor's environment, command names to try)
    (("devin",), ["devin-desktop", "windsurf", "surf"]),
    (("windsurf", "codeium"), ["windsurf", "devin-desktop", "surf"]),
    (("cursor",), ["cursor"]),
    (("insiders",), ["code-insiders"]),
    (("code-server", "openvscode"), ["code-server", "openvscode-server", "code"]),
    (("vscode", "visual studio code", "microsoft vs code", "code.exe", "/code"), ["code"]),
]


def editor_cli(env=None):
    """The command line of the editor this terminal runs in (VS Code, Devin Desktop/Windsurf, Cursor,
    code-server), found from the variables those editors set in their terminals."""
    env = os.environ if env is None else env
    keys = ("VSCODE_GIT_ASKPASS_NODE", "GIT_ASKPASS", "VSCODE_GIT_ASKPASS_MAIN", "TERM_PROGRAM", "VSCODE_IPC_HOOK_CLI",
            "__CFBundleIdentifier", "VSCODE_CWD", "VSCODE_CLI", "WINDSURF_CLI", "DEVIN_DESKTOP", "CURSOR_TRACE_ID")
    hints = " ".join(env.get(k, "") for k in keys).lower()
    if not hints.strip():
        return None, None
    names = []
    for words, cmds in EDITORS:
        if any(w in hints for w in words):
            names += [c for c in cmds if c not in names]
    if not names and (env.get("TERM_PROGRAM", "").lower() == "vscode" or "vscode" in hints):
        names = ["code"]
    app = env.get("VSCODE_GIT_ASKPASS_NODE", "")
    app_dirs = []
    if app:
        d = os.path.dirname(app)
        app_dirs = [os.path.join(d, "bin"), os.path.join(d, "resources", "app", "bin"),
                    os.path.join(os.path.dirname(d), "Resources", "app", "bin")]
    path = env.get("PATH", os.environ.get("PATH", ""))
    for n in names:
        found = shutil.which(n, path=path)
        if not found:
            for d in app_dirs:
                for ext in ("", ".cmd", ".exe"):
                    if os.path.isfile(os.path.join(d, n + ext)):
                        found = os.path.join(d, n + ext)
                        break
                if found:
                    break
        if found:
            return n, found
    return (names[0] if names else None), None


def cmd_show(qa_repo, env=None, run=True):
    """Add the dev folder to the editor window that is open now. Run it as the very last step:
    a window with a single folder becomes a workspace and the editor may reload it."""
    qa, parent, dev = paths(qa_repo)
    if not os.path.isdir(dev):
        raise Fail("There is no dev folder yet; clone the repos first")
    name, cli = editor_cli(env)
    ws = os.path.join(parent, os.path.basename(qa) + ".code-workspace")
    backup = {"backup_workspace": rel(ws, qa) if os.path.isfile(ws) else None}
    if not cli:
        return dict(backup, added=False, editor=name,
                    note="No editor command found in this terminal" + (f" ({name} is not installed in PATH)" if name else "") +
                         ". Use File > Add Folder to Workspace and pick the dev folder, or open the backup workspace file.")
    cmd = [cli, "--add", dev]
    if os.name == "nt" and cli.lower().endswith((".cmd", ".bat")):
        cmd = ["cmd", "/c"] + cmd
    if not run:
        return dict(backup, added=None, editor=name, command=cmd)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except Exception as e:
        return dict(backup, added=False, editor=name, note=f"The editor command did not run: {e}")
    if r.returncode != 0:
        return dict(backup, added=False, editor=name, note=clean((r.stderr or r.stdout or "").strip()[:300]))
    return dict(backup, added=True, editor=name, command=" ".join(cmd),
                note="The dev folder was added to the open window (a window with one folder may reload once).")


# ------------------------------------------------------------------------------------- self-test
def self_test():
    tmp = tempfile.mkdtemp(prefix="dev_repos_selftest_")
    ok = {}
    try:
        def sh(*a, cwd):
            git(*a, cwd=cwd)
        def make_remote(name, files, branches):
            src = os.path.join(tmp, "src_" + name)
            os.makedirs(src)
            sh("init", "-q", "-b", "develop", cwd=src)
            sh("config", "user.email", "t@t", cwd=src); sh("config", "user.name", "t", cwd=src)
            for f, c in files.items():
                os.makedirs(os.path.dirname(os.path.join(src, f)) or src, exist_ok=True)
                open(os.path.join(src, f), "w").write(c)
            sh("add", "-A", cwd=src); sh("commit", "-qm", "init", cwd=src)
            for b in branches:
                sh("branch", b, cwd=src)
            bare = os.path.join(tmp, "remotes", name + ".git")
            os.makedirs(os.path.dirname(bare), exist_ok=True)
            git("clone", "-q", "--bare", src, bare)
            git("symbolic-ref", "HEAD", "refs/heads/develop", cwd=bare)
            return src, bare
        fe_src, fe = make_remote("web-app", {"src/App.jsx": "x"}, ["main", "release/1.9", "release/1.10", "feature/a"])
        be_src, be = make_remote("api", {"pom.xml": "<project/>"}, ["main"])
        qa = os.path.join(tmp, "work", "qa-automation")
        os.makedirs(os.path.join(qa, "tests"))
        open(os.path.join(qa, "tests", "a.robot"), "w").write("*** Test Cases ***\n")
        fe_url = "file://" + fe.replace(os.sep, "/") if os.name != "nt" else fe

        b = cmd_branches(fe_url)
        ok["branches listed with the default first"] = b["default_branch"] == "develop" and b["suggested"][0] == "develop" \
            and "release/1.10" in b["suggested"] and b["count"] == 5
        ok["all branches listed, not only the suggested ones"] = b["all"] == ["develop", "feature/a", "main", "release/1.10", "release/1.9"]
        bu = cmd_branches(fe_url + "#release/1.10")
        ok["branch taken from the link (no need to ask)"] = bu["branch_from_url"] == "release/1.10" and "branch_not_found" not in bu
        bx = cmd_branches(fe_url + "#release/9.9")
        ok["branch in the link that does not exist is reported"] = bx["branch_from_url"] is None and bx["branch_not_found"] == "release/9.9"
        ok["GitHub, GitLab, Bitbucket and Azure branch links understood"] = [split_url(u) for u in (
            "https://github.com/acme/web-app/tree/feature/kyc/src",
            "https://gitlab.com/g/sub/api/-/tree/release/2.1",
            "https://bitbucket.bank.com/projects/KYC/repos/web-app/browse?at=refs%2Fheads%2Fdevelop",
            "https://dev.azure.com/org/Proj/_git/api?path=/&version=GBrelease%2F3.0")] == [
            ("https://github.com/acme/web-app", "feature/kyc/src"), ("https://gitlab.com/g/sub/api", "release/2.1"),
            ("https://bitbucket.bank.com/scm/kyc/web-app.git", "develop"), ("https://dev.azure.com/org/Proj/_git/api", "release/3.0")] \
            and pick_branch("feature/kyc/src", ["main", "feature/kyc"]) == "feature/kyc"
        try:
            check_url("https://user:secret@git.example.com/team/web-app.git")
            ok["URL with a token refused"] = False
        except Fail:
            ok["URL with a token refused"] = True
        c1 = cmd_clone(qa, fe_url + "#develop")           # branch from the link, no --branch
        c2 = cmd_clone(qa, be, "main")
        parent = os.path.dirname(qa)
        ok["every repo cloned flat to dev/<repo name>, no front end or back end folders"] = \
            os.path.isdir(os.path.join(parent, "dev", "web-app", "src")) and c1["folder"] == "../dev/web-app" and \
            c2["folder"] == "../dev/api" and sorted(os.listdir(os.path.join(parent, "dev"))) == ["api", "web-app"]
        ok["cloned on the chosen branch"] = git("rev-parse", "--abbrev-ref", "HEAD", cwd=os.path.join(parent, "dev", "api")) == "main"
        ok["QA repo unchanged (only knowledge/ written)"] = sorted(os.listdir(qa)) == ["knowledge", "tests"] and \
            os.listdir(os.path.join(qa, "tests")) == ["a.robot"]
        f = cmd_finish(qa)
        ws = json.load(open(os.path.join(parent, "qa-automation.code-workspace")))
        ok["backup workspace: QA repo, then the dev folder"] = [x["path"] for x in ws["folders"]] == ["qa-automation", "dev"]
        ok["workspace marks the development folders read-only"] = any(k.endswith("/dev/**") for k in ws["settings"]["files.readonlyInclude"])
        again = cmd_branches(be, qa)
        same = cmd_clone(qa, be, "main")
        ok["the same repo given again: no branch question, no new clone, just 'up to date'"] = again.get("already_added") and \
            again["branch_from_url"] == "main" and same["action"] == "up to date" and same["new_commits"] == 0
        open(os.path.join(be_src, "new.txt"), "w").write("1")
        sh("checkout", "-q", "main", cwd=be_src); sh("add", "-A", cwd=be_src); sh("commit", "-qm", "c2", cwd=be_src)
        git("push", "-q", be, "main", cwd=be_src)
        upd = cmd_clone(qa, be, "main")
        sh("reset", "-q", "--hard", "HEAD~1", cwd=be_src); open(os.path.join(be_src, "other.txt"), "w").write("2")
        sh("add", "-A", cwd=be_src); sh("commit", "-qm", "rewritten", cwd=be_src)
        git("push", "-q", "-f", be, "main", cwd=be_src)
        fp = cmd_clone(qa, be, "main")
        ok["a repo added before is only updated to the latest (also after a force push on the server)"] = \
            upd["action"] == "updated" and upd["new_commits"] == 1 and fp["action"] == "updated" and \
            os.path.isfile(os.path.join(parent, "dev", "api", "other.txt")) and not os.path.isfile(os.path.join(parent, "dev", "api", "new.txt"))
        cfg = read_config(qa)
        ok["dev-config.md written and read back, with no front end or back end role"] = \
            {(os.path.basename(r["folder"]), r["branch"]) for r in cfg} == {("web-app", "develop"), ("api", "main")} and \
            "Role" not in open(os.path.join(qa, "knowledge", "dev-config.md")).read()
        ok["extract command passes every repo, to be recognised from its code"] = \
            "--repo ../dev/api --repo ../dev/web-app" in f["extract_command"] and "--frontend" not in f["extract_command"]
        qa_new = os.path.join(tmp, "work4", "qa"); os.makedirs(os.path.join(qa_new, "qa-ai-skills"))
        cmd_clone(qa_new, be, "main"); f_new = cmd_finish(qa_new)
        ok["with the qa-ai-skills folder, dev-config.md goes inside it"] = os.path.isfile(os.path.join(qa_new, "qa-ai-skills", "knowledge", "dev-config.md")) and \
            not os.path.exists(os.path.join(qa_new, "knowledge")) and "--qa-extract qa-ai-skills/knowledge/.extract" in f_new["extract_command"]
        # a second repo with the same name from another owner gets its own folder
        _, be2 = make_remote("api2", {"app.py": "x"}, [])
        other = os.path.join(tmp, "team-b", "api.git"); os.makedirs(os.path.dirname(other)); shutil.move(be2, other)
        c3 = cmd_clone(qa, other, "develop")
        ok["same repo name from another owner: dev/<name>-<owner>"] = c3["folder"] == "../dev/api-team-b"
        f5 = cmd_finish(qa)
        ok["links in a later round are added to the earlier repos"] = sorted(r["folder"] for r in f5["repos"]) == ["../dev/api", "../dev/api-team-b", "../dev/web-app"]
        remove_tree(os.path.join(parent, "dev", "api-team-b"))
        ok["a repo is dropped when its folder is deleted"] = sorted(r["folder"] for r in cmd_finish(qa)["repos"]) == ["../dev/api", "../dev/web-app"]
        # the older layout (dev/frontend/<repo>, dev/backend/<repo>) is moved to dev/<repo>
        qa3 = os.path.join(tmp, "work3", "qa"); os.makedirs(qa3)
        legacy = os.path.join(tmp, "work3", "dev", "frontend", "web-app")
        git("clone", "-q", fe_url, legacy)
        os.makedirs(os.path.join(qa3, "knowledge"))
        open(os.path.join(qa3, "knowledge", "dev-config.md"), "w").write(
            "| Role | URL | Branch | Commit | Commit date | Folder | Built |\n|---|---|---|---|---|---|---|\n"
            f"| front end | {fe_url} | develop | abc | 2026-11-01 | ../dev/frontend/web-app | 2026-11-01 |\n")
        ok["older dev-config format still read"] = [r["folder"] for r in read_config(qa3)] == ["../dev/frontend/web-app"]
        f4 = cmd_finish(qa3)
        ok["older frontend/backend layout moved to dev/<repo>"] = os.path.isdir(os.path.join(tmp, "work3", "dev", "web-app", ".git")) and \
            not os.path.exists(os.path.join(tmp, "work3", "dev", "frontend")) and f4["repos"][0]["folder"] == "../dev/web-app"
        # an older workspace layout (one entry per repo) is folded into the dev folder
        old = {"folders": [{"path": "qa-automation"}, {"path": "dev/frontend/web-app"}, {"path": "dev/backend/api"}], "settings": {}}
        json.dump(old, open(os.path.join(parent, "qa-automation.code-workspace"), "w"))
        cmd_finish(qa)
        ws = json.load(open(os.path.join(parent, "qa-automation.code-workspace")))
        ok["older workspace layout updated to the dev folder"] = [x["path"] for x in ws["folders"]] == ["qa-automation", "dev"]
        ws["folders"].append({"path": "notes"}); json.dump(ws, open(os.path.join(parent, "qa-automation.code-workspace"), "w"))
        cmd_finish(qa)
        ws2 = json.load(open(os.path.join(parent, "qa-automation.code-workspace")))
        ok["folders a person added are kept"] = {"path": "notes"} in ws2["folders"] and ws2["folders"][0]["path"] == "qa-automation"
        # new commit upstream -> check counts it, pull fast-forwards it
        open(os.path.join(fe_src, "src", "New.jsx"), "w").write("y")
        sh("add", "-A", cwd=fe_src); sh("commit", "-qm", "new", cwd=fe_src)
        git("push", "-q", fe, "develop", cwd=fe_src)
        chk = cmd_check(qa)
        ok["refresh check counts new commits"] = next(r for r in chk["repos"] if r["repo"] == "web-app").get("new_commits") == 1
        cmd_pull(qa)
        ok["pull fast-forwards to the latest commit"] = os.path.isfile(os.path.join(parent, "dev", "web-app", "src", "New.jsx"))
        open(os.path.join(parent, "dev", "web-app", "src", "App.jsx"), "w").write("changed")
        try:
            cmd_pull(qa); ok["clone with local changes is not touched"] = False
        except Fail:
            ok["clone with local changes is not touched"] = True
        git("checkout", "--", ".", cwd=os.path.join(parent, "dev", "web-app"))
        remove_tree(os.path.join(parent, "dev", "api"))
        ok["clone folder can be deleted (read-only git files on Windows)"] = not os.path.exists(os.path.join(parent, "dev", "api"))
        chk = cmd_check(qa)
        ok["missing clone restored from dev-config.md"] = os.path.isdir(os.path.join(parent, "dev", "api", ".git")) and \
            any(r.get("recloned") for r in chk["repos"])
        # the dev folder is added to the open editor window through the editor's own command
        bindir = os.path.join(tmp, "bin"); os.makedirs(bindir)
        log = os.path.join(tmp, "editor-called.txt")
        for n in ("code", "devin-desktop"):
            if os.name == "nt":
                open(os.path.join(bindir, n + ".cmd"), "w").write(f"@echo {n} %* > \"{log}\"\n")
            else:
                sp = os.path.join(bindir, n); open(sp, "w").write(f"#!/bin/sh\necho {n} \"$@\" > '{log}'\n"); os.chmod(sp, 0o755)
        env_vs = {"PATH": bindir, "TERM_PROGRAM": "vscode", "VSCODE_GIT_ASKPASS_NODE": "/apps/Microsoft VS Code/Code"}
        r1 = cmd_show(qa, env_vs)
        ok["VS Code: dev folder added to the open window (code --add)"] = r1["added"] and \
            open(log).read().split()[:2] == ["code", "--add"] and open(log).read().strip().endswith("dev")
        env_dv = {"PATH": bindir, "TERM_PROGRAM": "vscode", "VSCODE_GIT_ASKPASS_NODE": "/apps/Devin Desktop/Devin Desktop"}
        r2 = cmd_show(qa, env_dv)
        ok["Devin Desktop: its own command is used (devin-desktop --add)"] = r2["added"] and r2["editor"] == "devin-desktop" and \
            open(log).read().split()[0] == "devin-desktop"
        r3 = cmd_show(qa, {"PATH": bindir})
        ok["no editor: says so and points to the backup workspace"] = r3["added"] is False and bool(r3["backup_workspace"])
        ok["no token or user name stored"] = "secret" not in open(os.path.join(qa, "knowledge", "dev-config.md")).read()
    finally:
        remove_tree(tmp)
    width = max(len(k) for k in ok)
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main():
    ap = argparse.ArgumentParser(description="Set up the development repos next to the QA repo (read-only use).")
    ap.add_argument("--qa-repo", default=".", help="QA repo folder (default: current folder)")
    ap.add_argument("--self-test", action="store_true")
    sub = ap.add_subparsers(dest="cmd")
    b = sub.add_parser("branches"); b.add_argument("urls", nargs="+", help="repo links (a branch page link also gives the branch)")
    b.add_argument("--max", type=int, default=MAX_LINKS, help="links taken in this round (default 10)")
    c = sub.add_parser("clone"); c.add_argument("--url", required=True)
    c.add_argument("--branch", default=None, help="not needed when the link names the branch")
    c.add_argument("--role", default=None, help=argparse.SUPPRESS)   # older skills passed a role; it is ignored now
    sub.add_parser("finish"); sub.add_parser("show"); sub.add_parser("check"); sub.add_parser("pull")
    a = ap.parse_args()
    if a.self_test:
        sys.exit(self_test())
    try:
        if a.cmd == "branches":
            links = [u for u in a.urls if u.strip()]
            res = {"repos": [], "deferred": links[a.max:]}
            if res["deferred"]:
                res["note"] = (f"I can take {a.max} links at a time. These {len(res['deferred'])} are for the next round: "
                               "paste them again after this round is finished.")
            for u in links[:a.max]:
                try:
                    res["repos"].append(cmd_branches(u, a.qa_repo))
                except Fail as e:
                    res["repos"].append({"url": split_url(u)[0], "error": str(e)})
        elif a.cmd == "clone":
            res = cmd_clone(a.qa_repo, a.url, a.branch)
        elif a.cmd == "finish":
            res = cmd_finish(a.qa_repo)
        elif a.cmd == "show":
            res = cmd_show(a.qa_repo)
        elif a.cmd == "check":
            res = cmd_check(a.qa_repo)
        elif a.cmd == "pull":
            res = cmd_pull(a.qa_repo)
        else:
            ap.error("give a command: branches, clone, finish, show, check or pull")
        print(json.dumps(res, indent=1))
    except Fail as e:
        print(json.dumps({"error": str(e)}, indent=1))
        sys.exit(2)


if __name__ == "__main__":
    main()
