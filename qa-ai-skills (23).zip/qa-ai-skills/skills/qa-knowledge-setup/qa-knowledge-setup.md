---
name: qa-knowledge-setup
description: One-step, user-friendly entry point that builds, refreshes or checks the whole QA knowledge base for a repo, a folder or a single .robot file, optionally including read-only knowledge from the application's development repo(s). Runs dev-knowledge-builder (when a development repo is included), app-knowledge-builder, keyword-knowledge-builder, locator-knowledge-builder and knowledge-reviewer in order, narrating progress in plain language so any tester can follow. Use when the user says build, setup, refresh, update, rebuild, review or status for knowledge.
version: 0.1.0
---

# QA Knowledge Setup

## 1. Commands
| Command | What it does |
| `/qa-knowledge-setup build` | Build all knowledge for the whole repo, then review |
| `/qa-knowledge-setup build <folder or .robot file>` | Same, limited to that folder or file; adds to existing knowledge |
| `/qa-knowledge-setup build <topic name>` | Same, limited to the tests about that topic, e.g. `build addresses` |
| `/qa-knowledge-setup refresh` | Update only what changed since the last build, and apply any new knowledge format (section 1a); also resumes an interrupted build |
| `/qa-knowledge-setup rebuild` | Rebuild everything from scratch |
| `/qa-knowledge-setup rebuild <folder, .robot file or topic>` | Rebuild only that scope from scratch (extractor runs with `--full`, then steps 2-5 rewrite that scope's knowledge); other knowledge is kept |
| `/qa-knowledge-setup dev` | Add or change the development repo(s) (section 1b), then build only the development knowledge and its links (checklist steps 1, 2, 6 and 7 run; 3-5 show ⏭) |
| `/qa-knowledge-setup status` | Show knowledge status, freshness and knowledge format (and whether a refresh will upgrade it); changes nothing |
| `/qa-knowledge-setup coverage` | Automation coverage map and gap analysis against the development code (section 7); add `with <test case file or folder>` to also compare the manual test cases |
| `/qa-knowledge-setup regression <base> [<head>]` | Regression gap analysis for a change in the development repos, e.g. `regression release-24.3` or `regression main feature/kyc` (section 7) |

Any wording with the same meaning maps to these. No command: if no knowledge exists assume `build`, otherwise `refresh`, and say so in one line.

## 1a. Knowledge format (so a refresh also applies new skill rules)
**Current knowledge format: 4.** The first line of `qa-ai-skills/knowledge/knowledge-status.md` records the format the knowledge was built with: `knowledge_format: 4`. Write it at the end of every build, refresh or rebuild that completes.
| Format | What it adds |
|---|---|
| 2 | application map (`app-map.md`) and run configuration (`run-config.md`) |
| 3 | in `run-config.md` for every suite: the import order, the file that loads the secrets and the path to it (also through nested resources), and the library each suite uses (from `import-chains.json`, `secrets_loaders` and `suite_libraries` in the extract) |
| 4 | keyword and locator knowledge and the factual part of `run-config.md` are rendered by `knowledge_build.py` from the extract plus the saved meaning in `meaning/` (section 1c) |

**Format upgrade (part of every `refresh`):** if the recorded format is missing or lower than the current one, the knowledge was built by an earlier release of these skills. Even when no test or resource file changed:
1. Run the extractor for the knowledge's scope (it adds the new facts; no AI tokens).
2. Update **only** what the newer formats add (for format 3: the run details in `run-config.md` for every suite in the knowledge; for format 4: `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py migrate` (it moves the meaning already in the keyword and locator files into `meaning/`, no AI work), then `knowledge_build.py render all` and `check`). Do not rebuild anything else.
3. Run the reviewer's checks for those parts, then write the new `knowledge_format`.
Say it in one line at the start: "Your knowledge was built by an earlier release of the skills. I'm adding the new run details (import order, secrets loader, library) for <N> suites; nothing else needs rebuilding." In the checklist, step 3 shows "updated run details for <N> suites", steps 4-5 show ⏭ "unchanged".

Older knowledge: if `qa-ai-skills/knowledge/app-map.md` or `qa-ai-skills/knowledge/run-config.md` is missing or `qa-ai-skills/knowledge/.extract/summary.json` has `schema_version` below 2, a `refresh` is not enough; run a full rebuild of the requested scope automatically and say so in one line ("Your knowledge was built by an older version, so I'm rebuilding it with the application map.").
For any scope - whole repo, folder or one file - always build all three knowledge types (app, keyword, locator) for that scope, then review it, and merge into existing knowledge without losing anything.
**Rebuild means rewrite.** For `rebuild`, steps 2 (when the development repo is included), 3, 4 and 5 always run in full for the scope: `split_extract.py plan --rebuild` puts every module in `changed`, and each module's entries are written fresh from its brief by the builder skills, following their current rules. A rebuild still works from the extract and the briefs, never by reading the source files. Comparing the existing knowledge with the extract is the reviewer's job (step 6); it never replaces a rebuild, because it does not apply new rules. Tick steps 2-5 only when this run wrote their entries, and give the count written.
**Refresh builds only what changed:** the plan's `changed` lists say which modules to build per stage; the others are kept as they are. When nothing changed and the knowledge format is current, say "Your knowledge is already up to date" and mark steps 2-6 ⏭. If the plan lists `built_with_older_rules` (the skills were updated since those modules were built), add one line to the final message: "<n> modules were built with older skill rules; run `/qa-knowledge-setup rebuild` when convenient to apply the new rules." A refresh never rebuilds them by itself.

## 1b. Development repos (optional, read-only)
The application's own source code makes the knowledge much stronger: real field IDs and test IDs,
dropdown options, validation rules, business rules, fields that appear only in some cases, and the
data each screen waits for. It is optional; everything works without it.

**Testers never have to say which repo is front end or back end.** They paste the links; every repo
is cloned as it is into `dev/<repo name>`, and `extract_dev.py` works out from each repo's code what
it is (screens, services, or both).

**When to ask.** At the start of `build` and `rebuild` (any scope) and for `dev`, before step 1
work starts. `refresh` and `status` never ask about it. These prompts, and the one pull question on
`refresh` (below), are the only questions the knowledge setup asks. Do not mark any option as
recommended, and never ask one question per message.

**Prompt 1 - the links, in one question.** "Paste your development repo links (up to 10 now; one per
line or separated by spaces). To choose a branch, paste the branch's own page link (for example
`.../tree/develop`) or add `#<branch>`."
- Options: `No - skip the development repos`, and when `qa-ai-skills/knowledge/dev-config.md` exists also
  `Same as last time (<repo names and branches>)`. The links are typed as the answer.
- By agent: **Claude Code** - `AskUserQuestion`, one question; the links go in its "Other" box
  (when there is no "Same as last time", the second option is `I'll paste the links in Other`).
  **VS Code Copilot** - `askQuestions`, one free-text question with the same options.
  **Devin, or no clickable tool** - one plain message, answered in one reply ("no", "same", or the links).
- `No` → step 2 of the checklist shows ⏭ "not included" and nothing else in this section runs.
  `Same as last time` → no more questions: go to "Same as last time" below.
- Links are **added** to the repos already recorded; a repo is dropped only when its `dev/<repo>`
  folder is deleted.
- **A repo that was added before** (the same link, pasted again or chosen with "Same as last time")
  is never cloned again and never asked about again: `branches` returns it with `already_added` and
  its recorded branch (no branch question), and `clone` only fetches the latest code (`action`:
  `updated` with `new_commits`, or `up to date`). Say it in one line, for example "web-app: already
  added, updated to the latest (12 new commits)" or "api: already added, already up to date". Only
  new links are cloned. When every repo is `up to date` and the development knowledge already
  exists, do not extract again: step 2 shows ⏭ "development knowledge already up to date".
- **More than 10 links:** take the first 10 in this round (`branches` reports the rest as
  `deferred`) and say: "I can take 10 links at a time. I'll set up these 10 first, then ask for the
  next ones." After their clones finish, show Prompt 1 again for the deferred links (pre-filled in
  the question text so the user only confirms or edits), and repeat until none are left. Then run
  `finish` once.
- A link with a user name, password or token (`https://user:token@...`) is refused: ask for the plain
  link and say git uses their normal sign-in.

**Prompt 2 - branches, only for the repos whose branch is not known yet, in one prompt.**
Run once for all links of the round: `python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py branches <link> [<link> ...]`.
- A repo whose `branch_from_url` is set needs no question: use that branch. If every repo's branch
  came from its link, there is no prompt 2.
- **Up to 4 repos without a branch:** one question per repo, all in the same prompt: "Branch for
  <name> - <count> branches:" followed by **all** its branches (`all`) as a numbered list inside the
  question text (the user may see only the question). Options: its `suggested` branches (default
  first); any other number or name is typed. If `branch_not_found` is set, start the question with
  "The branch `<name>` in your link does not exist in <repo>." More than 100 branches: list them in a
  chat message just before the prompt and say "type the number or name from the list above".
- **5 or more repos without a branch** (the clickable tools allow only 4 questions at once): one
  question. Before it, write the full branch list of each repo to `qa-ai-skills/knowledge/.tmp/branches.md` and
  show it in the chat; the question text lists each repo with its default branch. Options:
  `Use each repo's default branch`, and `Use <branch> for all, where it exists` (only when the same
  branch, for example `develop`, exists in most of them; others keep their default). Exceptions are
  typed as `<repo>: <branch>, <repo>: <branch>`.
- A repo with `error` (no access, wrong link): say it in one line, skip that repo, and continue with
  the others; the QA knowledge build always continues.

**Where the code goes.** A `dev` folder next to the QA repo (never inside it; the QA repo is never
moved), with every repo directly inside it:
```
<parent folder>/
  <qa repo>/                      unchanged
  dev/<repo name>/                one folder per development repo, named as the repo
  <qa repo name>.code-workspace   backup only: the QA repo and dev, for anyone who wants it
```
Two repos with the same name from different owners: the second is `dev/<repo name>-<owner>`.
Clones from the older layout (`dev/frontend/<repo>`, `dev/backend/<repo>`) are moved to
`dev/<repo>` automatically (only clean clones), and `dev-config.md` is updated.

**Always use the helper `dev_repos.py`** (next to the extractors; run from the QA repo folder with the
same Python as robot). It does every git, folder, workspace and config step the same way in Devin,
VS Code and Claude Code, so never type these git commands or write these files by hand:
1. For every link: `python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py clone --url <link> [--branch <branch>]`
   (`--branch` is left out when the link names the branch). It clones with the team's normal git
   sign-in into `dev/<repo name>`, or reuses an existing clean clone of the same repo (fetch and
   fast-forward only). It refuses links with a user name or token, a folder that holds something
   else, and a clone with local changes; show its `error` in one line and carry on with the others.
2. Once, after the last round: `python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py finish`. It writes
   `qa-ai-skills/knowledge/dev-config.md` (repo, link without credentials, branch, commit, commit date, folder,
   date), the backup workspace file (the QA repo first, then `dev`; folders and settings a person
   added are kept; the development folders are marked read-only), and prints the exact
   `extract_command` for the next step.
3. **The very last action of the whole run** (after the final summary, because the editor may reload
   a window that had only one folder): `python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py show`. It
   finds the editor this terminal belongs to (VS Code, Devin Desktop or Windsurf, Cursor,
   code-server) and runs that editor's own command (`code --add`, `devin-desktop --add`...) to add
   the `dev` folder to the window that is open now, so nothing has to be opened by hand.
   - `added: true`: say "The `dev` folder is now in your window, under your QA repo."
   - `added: false`: say its `note` in one line, and that the folder can be added with File > Add
     Folder to Workspace, or by opening the backup workspace file.
   - Claude Code in a terminal (no editor window) gets `added: false`; say instead: "Claude Code
     reads files outside the QA repo only with your approval. Approve the read of the `dev` folder
     when asked, or add it once with `/add-dir ../dev`."
   Then, in VS Code, add: "Check that the AI tools are still running: Command Palette > MCP: List
   Servers should show robotmcp, playwright, playwright-attach and playwright-session as running."

**Commands always run from the QA repo folder** (the helper, both extractors and every robot run):
`cd` into it first, because in a window with several folders a new terminal may open in another
folder. Nothing ever runs inside a development folder.

**The development repos are strictly read-only:** never edit, format, build, install (`npm
install`, `mvn`, `dotnet restore`...), run, switch branches, commit or push in them. Only
`dev_repos.py` touches them (clone, fetch, fast-forward, and moving clones of the older layout).
Read them only through `extract_dev.py` and, for a specific line range, the file-read tool.

**Extract (no AI tokens).** Run the `extract_command` that `finish` printed, after the QA extractor:
`python qa-ai-skills/skills/qa-knowledge-setup/extract_dev.py --repo <folder> [--repo <folder> ...] --qa-extract qa-ai-skills/knowledge/.extract --out qa-ai-skills/knowledge/.extract/dev`.
It reads each repo as front end, back end or both, from its code, and reports what it found per repo
(`detected` in `dev-summary.json`); say it in one line, for example "web-app: front end (React,
Material UI); kyc-service: back end (Spring Boot)".
For a scoped build (`build <folder, file or topic>`), add `--qa-scope <the matched .robot files,
comma-separated>`: only the development screens those tests use, the screens next to them in the
flow and their dialogs are written.
Then run dev-knowledge-builder.

**"Same as last time", refresh, and a missing clone** all start with
`python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py check`. It moves clones of the older layout, clones
again any repo that is missing (a new Devin session, a new laptop, a deleted folder) from
`qa-ai-skills/knowledge/dev-config.md` (same link and branch), re-creates a missing backup workspace file, and
reports `new_commits` per repo. Say in one line when it re-cloned or moved something. Then:
- `build` or `rebuild` with "same as last time": if there are new commits, run
  `dev_repos.py pull` (fast-forward only) and say so in one line; build from the latest commit.
- `refresh`: if there are new commits, ask one clickable question: "The development repos have new
  commits (<repo>: <n>, ...). Pull them and update the development knowledge?" `Yes` / `No`. On yes,
  `dev_repos.py pull`, then re-run the dev extract and builder for what changed. On no, or no new
  commits, step 2 shows ⏭ "unchanged".
- If there is no `dev-config.md` (`configured: false`), never ask; add one line to the final
  message: "Tip: include your development repos with `/qa-knowledge-setup dev` for stronger locators
  and rules."
- After `check` or `pull`, run `dev_repos.py show` as the last action too, so the `dev` folder is in
  the window.
The script generator never clones or pulls: it uses the knowledge files, which are enough to write
scripts.

## 1c. Fast by design: scripts write the facts, you write the meaning
The knowledge must be complete and exact, and it must be built quickly. Both come from one split of the work:
- **Scripts do every mechanical job, in seconds, with no AI tokens:** `extract_repo.py` reads every test, keyword, locator, variable, route and import with Robot Framework's own parser; `split_extract.py` cuts it into modules and says what changed; `knowledge_build.py` writes the complete keyword knowledge, the complete locator knowledge (stability, duplicates, conflicts, brittle locators, screens), both indexes and the factual half of `run-config.md`, and checks coverage. Nothing can be skipped or miscounted, because no person or AI copies facts by hand.
- **You write only the meaning:** screens, flows, journeys, preconditions and the glossary (app knowledge), one short line per keyword (purpose when undocumented, level, screens, flows) and the flow step mapping, a meaning line for the rare locator whose name says nothing, and the few run-configuration lines that need reading the README or CI files.
- **Never write your own scripts** to collect, convert, count or generate knowledge, and never read `.robot`, `.resource` or development source files to collect facts: every mechanical job has a command above. If a fact you need is missing from the worksheet, open only that line range of one file, and say in one line what the extract lacked.
- **Read the worksheets, not the briefs.** `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py worksheet <app|keyword|locator> <MODULE>` prints a compact view of one module (one line per test, keyword or route). Open `brief.json` only when the worksheet lacks a fact.
- **Write each module's meaning in one go,** then move on; never re-read files you just wrote, and never read the rendered keyword or locator files to check them: `knowledge_build.py check` does that.
- **Batches, not single modules.** `split_extract.py next` hands out the next batch: the most-used modules first (shared keywords that many areas call, then the biggest areas), small modules grouped so one pass covers several (about 60 KB of worksheet), a big one alone. One `knowledge_build.py worksheet all <MODULE ...>` call prints every worksheet of the batch, and one `split_extract.py record --stage all <MODULE ...>` records it. Fewer, larger passes are the main speed gain; the meaning written per module is exactly as complete as before.
- **No command may keep the editor waiting.** Any command that can take more than about a minute (the extractor on a repo with more than 300 test files, `extract_dev.py` on a large development repo, `render all` on a very large extract) runs in the background: `python qa-ai-skills/skills/bg_job.py start <name> -- <command>`, then `python qa-ai-skills/skills/bg_job.py wait <name>` (returns within 45 seconds with its progress lines; repeat until Done, and post the progress line in the chat every few calls). Never run such a command in the foreground. The extractor parses changed files in parallel on its own and saves its cache every 250 files, so a stopped run continues where it was.
- **Refresh is cheap:** the meaning you write is kept in `qa-ai-skills/knowledge/meaning/` (commit it with the knowledge), so unchanged modules need no AI work at all; `render` rebuilds every rendered file from the extract and the saved meaning.

## 2. Progress reporting is mandatory
- **Visible chat text, in every editor.** Every progress line is a normal reply message to the user (in Devin, VS Code Copilot and Claude Code alike), never only inside thinking, a tool's arguments or terminal output. A tester must be able to follow the build by reading the chat alone. Each ticked step shows its time, e.g. "✅ 1. Analysed your repository files (24s)"; time each step with `python qa-ai-skills/skills/ai_run.py stage "<step>"` (start with `ai_run.py start "knowledge setup"`).
- **Checklist first.** **Where the checklist lives:** in the editor's own task list, created once at the start and updated in place (Devin: its todo/plan list; Claude Code: its task list; VS Code Copilot: its todo list), never re-posted as a new block in the chat. Rename an item when it finishes to carry its result and time (e.g. "1. Analysed your repository files (24s)"). In the chat, post only one short line per finished step ("✅ 1. Analysed 214 tests, 380 keywords and 512 locators (24s)") and the messages before anything slow. Only when the editor has no task list, show the checklist as chat text at the start and when a step finishes. The items:
  ```
  Knowledge setup - progress
  ⏳ 1. Analysing your repository files
  ⬜ 2. Learning the development code (screens, fields, rules)
  ⬜ 3. Building the application knowledge (screens, journeys, how tests run)
  ⬜ 4. Building the keyword knowledge
  ⬜ 5. Building the locator knowledge
  ⬜ 6. Reviewing everything against the code
  ⬜ 7. Finishing and summary
  ```
  Marks: ✅ done (with a short result in numbers, e.g. "412 tests, 97 resource files"), ⏳ in progress, ⬜ waiting, ⏭ skipped, ❌ stopped (with the reason). Also use the agent's own task or to-do tool with the same 7 steps, worded as in the checklist, when it has one (Claude Code task list, Copilot to-do list, Devin plan). Mirror the latest checklist at the top of `qa-ai-skills/knowledge/progress.md`.
- **Send a visible chat message to the user** (not only a thought, plan or tool call) at each of these moments: before starting, after the extractor, before and after each step of the checklist, after each module in long runs, and at the end. Never run more than about 2 minutes or 10 tool calls without a visible message.
- Each message is one or two plain lines, using the templates in section 3.
- **Also write every progress message to `qa-ai-skills/knowledge/progress.md`** (overwrite at start of the run, append after), with a timestamp, so the user can open that file anytime to see where the run is.

## 2a. How to talk to the user (narration style)
The user may not know the repo or Robot Framework. Narrate like a helpful colleague:
- Plain language, short sentences, no internal jargon (say "the steps your tests perform", not "flow registry").
- Before each stage, one line on what is happening and why. After it, one line with the result in numbers.
- Never go silent during long work; never flood the chat with file-by-file logs.
- Use exactly the messages below as templates (fill in the values).

## 3. Flow

### Step 1 of 7 - Check and plan
- Locate each skill file by name anywhere under `qa-ai-skills/skills/`: `<name>.md` or `<name>/SKILL.md` or `<name>/<name>.md`, for app-knowledge-builder, keyword-knowledge-builder, locator-knowledge-builder and knowledge-reviewer (and dev-knowledge-builder when the development repo is included). Follow the instructions in each file when running that part. If one is missing: "I can't start yet: the <name> skill is missing from the skills folder."
- Locate the extractor `extract_repo.py` (and, next to it, `extract_dev.py` and `dev_repos.py`) under `qa-ai-skills/skills/` (normally `qa-ai-skills/skills/qa-knowledge-setup/extract_repo.py`) and use that path for every run. If there is more than one, use the newest and say so; if none, stop and say it is missing.
- Record branch and commit. Never create or switch branches.
- Count the scope, then say:

> "I'm going to learn how this application is tested, so I can later write new test scripts for you.
> I found <N> test files with about <T> tests and <R> keyword/resource files.
> I'll do this in 7 steps, shown in the checklist below: analyse your files, learn the development code (if included), learn the application's screens and steps, learn the existing keywords, learn the existing locators, double-check everything against the code, then summarise.
> This can take a while for a large repo. I'll show progress as I go, and if anything stops me you can resume with `/qa-knowledge-setup refresh`.
> Starting now."

Do not wait for an answer; start immediately. Ask no questions before or during the run other than the development repo questions in section 1b (asked before this message for `build`, `rebuild` and `dev`). The scope is exactly what the command gave: no target means the whole repo; an existing path means that folder or file; anything else is a topic name.
For a topic name: match it (case-insensitive, ignoring spaces, hyphens and underscores) against .robot file names, suite and test names, `[Tags]`, `Force Tags` and `[Documentation]`, plus existing flow and screen names in app knowledge. Include the resource files those tests use. List the matched files in the opening message ("Building knowledge for 'addresses': 2 test files, 14 tests: <file names>"). If nothing matches, stop and say so, suggesting the closest file or topic names found; do not build the whole repo instead.

### Step 1 of 7 (continued) - Extract facts (no AI tokens)
Run the extractor in the terminal with the same Python used to run robot (in the background when the scope has more than 300 test files, section 1c: `bg_job.py start extract -- python <extractor path> ...`, then `bg_job.py wait extract` until Done):
`python <extractor path>` (e.g. `python qa-ai-skills/skills/qa-knowledge-setup/extract_repo.py`; add `--scope <path>` once per folder or file for scoped builds; for a topic, pass the matched files as scopes; add `--full` for rebuild).
Say: "Step 1 of 7: Analysing your repository files with Robot Framework's own parser..." then tick step 1 with the counts it prints.
- If it fails (e.g. Robot Framework not found), stop and tell the user the exact error and fix; do not fall back to reading raw files.
- Older repos are read like any other: `.txt`, `.tsv` and pipe-separated suites, `Selenium2Library` (treated as SeleniumLibrary), `Run Keyword If`, and Robot 3.2 or newer. Files the installed Robot cannot parse (for example the old `:FOR` syntax under Robot 4 or newer) are listed in the extractor's "files with parse warnings"; say how many in the step 1 line and list them under "What I created", never drop them silently.
- All builders and the reviewer must use `qa-ai-skills/knowledge/.extract/` (summary.json, tests.json, keywords.json, locators.json, variables.json, import-chains.json, routes.json, ui-signals.json, and `dev/` for the development knowledge) as their source of facts. **Never read the `.robot`, `.resource` or development source files to collect facts again**, not even when a builder's steps say "for each test" or "for each file": those steps mean the entries of the extract. Open a source file only for one specific line range when the extract lacks a fact (for example the meaning of a comment).
- `qa-ai-skills/knowledge/.extract/` is a cache: never edit it by hand; it can be deleted and regenerated at any time. It may contain raw test data. Make sure `.gitignore` contains `qa-ai-skills/knowledge/.extract/`, `qa-ai-skills/knowledge/.tmp/` and `qa-ai-skills/session/` (tell the user the missing lines if not); never commit them. `qa-ai-skills/ai_generated_tests/drafts/` is deliberately not ignored (some agents cannot write to ignored folders) but is never committed.
- The extract includes `routes.json` (real entry routes and prerequisites for every keyword, computed from all tests) and `ui-signals.json` (on-screen messages and UI patterns). Part 1 must use them to build the application map, glossary and UI patterns.

### Step 2 of 7 - development knowledge
Only when the development repo is included (section 1b); otherwise tick ⏭ "not included".
> "Step 2 of 7: Learning the development code - screens, fields, dropdown options, rules and what each screen waits for. I only read it; nothing is changed there."

Clone or update with `dev_repos.py` (section 1b), run the `extract_command` it printed, then dev-knowledge-builder. Step 3 then mixes the result into the application map and glossary (app-knowledge-builder, "With development knowledge"). When finished:
> "Step 2 done: <S> screens, <F> fields, <O> option lists, <R> field rules, <C> fields that appear only in some cases, <E> API endpoints. Business behaviour: <B> business checks, <P> role rules, <T> status changes, <Q> prerequisites, <A> after-save actions. Linked <H> screens to your tests with high confidence (<M> medium, <L> to confirm)."
If cloning or the extract fails, tick ❌ with the reason in one line and continue with step 3: the
QA knowledge never waits for the development repo.
**Old and new frameworks alike.** The extractor reads modern and older front ends (AngularJS 1.x, jQuery pages, JSP, JSF, Thymeleaf, Struts, ASP.NET Web Forms and Razor, FreeMarker, Velocity) and finds pages even without a `package.json`. If its summary warns that a front end gave no screens, do not stop or ask: say in one line which repo and what the warning says, continue with the back-end knowledge and the QA knowledge, and list it under "What I created" so the skills authors can add that framework. Never describe a repo with page files as "back end only".

### Steps 3-5 of 7 - application, keyword and locator knowledge (one pass per module)
> "Step 3 of 7: Building the application, keyword and locator knowledge, one area at a time..."

First run `split_extract.py plan` (section 5) once. Then loop until `next` says all modules are built (it resumes by itself after any stop):
1. `python qa-ai-skills/skills/qa-knowledge-setup/split_extract.py next`: the batch, the progress and the time left. Post its `say` line in the chat ("Batch: MOD-COMMON, MOD-KYC (12 of 340 modules done, about 25 min left)").
2. Its `worksheets` command (`knowledge_build.py worksheet all <MODULE ...>`): every worksheet of the batch in one call.
3. For each module of the batch, write, in this order: the module file `app/<MODULE>.md` (app-knowledge-builder: screens, flows, rules, journeys), its screen lines in `meaning/app/screens.md` and its terms in `glossary.md`, then `meaning/keyword/<MODULE>.md` (keyword-knowledge-builder: one line per keyword and the flow step mapping), then any `meaning/locator/names.md` lines. Every module gets its full meaning; batching changes only how many modules one pass covers.
4. Its `record` command (`split_extract.py record --stage all <MODULE ...>`).
A module too big for one pass (its worksheet is cut off, or it has more than about 150 keywords): write it in parts of about 50 keywords, then record it.
After the last module: `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py render all` writes the application map, every keyword and locator file, both indexes and the facts of `run-config.md` in seconds; then fill only the lines of `run-config.md` marked `<AI ...>` (app-knowledge-builder, run configuration). Write `app-knowledge.md` (the registry of modules, screens and flows) last. Then tick the three steps:
> "Step 3 done: found <S> screens and <F> business flows across <M> areas, with how to reach every screen and what must happen first (<P> preconditions), and how your tests are normally run."
> "Step 4 done: catalogued <K> keywords. <C> of <F> flows are fully covered by existing keywords."
> "Step 5 done: catalogued <L> locators (<H> highly stable, <W> fragile ones flagged)." When development knowledge exists, add: "<B> team locators no longer match the development code; suggested fixes are in the locator knowledge (your files are unchanged)."

### Step 6 of 7 - review
> "Step 6 of 7: Reviewing everything against the actual code..."

First `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py check`: it proves coverage (every keyword, locator and test file of the extract is in the knowledge; every screen and flow ID used exists; no `<AI ...>` line left; every map screen has an entry route). Fix every ERROR it lists now (write the missing meaning lines or app entries, then `render` again), because these are gaps, not opinions. Then run knowledge-reviewer (report only) for the judgement checks; for a small scope (section 5, fast path) the reviewer checks a sample of 10 meaning lines and every screen of the map only. When finished, show the status table (area, status, issues) with the coverage line.

### Step 7 of 7 - Finish (always the last message, never skipped)
Run `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py report`. Your last message has exactly these three parts, in this order:
1. **What I created**: the report's output as it is (every knowledge file, where it is, what it holds, the coverage line), then "Time taken: <minutes>" (from the first progress line).
2. **The result**: if all areas PASS, "I now understand this repo: <M> areas, <F> flows, <K> keywords, <L> locators." Otherwise "<n> areas need attention: <list>. Scripts for those areas may be less reliable. Do you want me to fix the critical issues now?" (only on yes, hand over to knowledge-reviewer remediation, then show this message again).
3. **What you can do next** (with `/` in VS Code and `@` in Devin):
   > - Create a test script now: `/robot-script-generator TC-1234`, `/robot-script-generator qtest TC-1234`, or `/robot-script-generator <test cases .md> first 5`
   > - Check something without a test case: `/robot-script-generator check that <what you want to verify>`
   > - After pulling new code: `/qa-knowledge-setup refresh` (only changed areas are rebuilt)
   > - See the knowledge health anytime: `/qa-knowledge-setup status`
   > - See what the tests cover and miss: `/qa-knowledge-setup coverage` (needs the development repo); for a release: `/qa-knowledge-setup regression <last release tag>`
   When the development knowledge was built in this run, run the coverage build (section 7) before this message and add its one-line result to "The result".

## 4. Failure handling
- If a part fails, stop and say in plain words: "I stopped at part <n> (<name>) because <reason>. What's done is saved. Fix <what> and run `/qa-knowledge-setup refresh` to continue."
- Never leave the user without a next step.

## 5. Memory and stability (prevents editor crashes)
- **Small scope fast path** (one suite file, a folder of up to 10 test files, or a plan with at most 3 changed modules): no questions, no sub-agents, steps 3-5 in one pass per module, `check` then a short review (step 6). One suite file should take a few minutes; if it takes much longer, say which step took the time.
- **Briefs, and sub-agents only when they pay off.** At the start of step 3 (after the development extract, so the briefs include the development links), run `python qa-ai-skills/skills/qa-knowledge-setup/split_extract.py plan` (add `--rebuild` for `rebuild`) and say the result in one line, e.g. "9 modules: 3 to build, 6 unchanged; one agent". It cuts the extract into one small brief per module and says, for each stage (app, keyword, locator), which modules to build (`changed`), which to keep (`unchanged`), and whether sub-agents are worth it (`use_sub_agents`, `max_parallel`).
  - Stages always run in order (development, app, keyword, locator, review); never two stages at once.
  - `use_sub_agents: false` (small scopes, such as one or two suites): build the modules yourself, one after another.
  - `use_sub_agents: true` (40 or more test files and 3 or more modules to build): give each changed module to one sub-agent, at most `max_parallel` at a time, with exactly this task and nothing more:
    > "Build the knowledge for modules <MODULE ...> only (one batch from `split_extract.py next`), in one pass. Run `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py worksheet all <MODULE ...>`, and read only its output, the builder skills (`qa-ai-skills/skills/app-knowledge-builder.md`, `keyword-knowledge-builder.md`, `locator-knowledge-builder.md`) and your module's existing files if they exist. Do not read any `.robot`, `.resource` or development source file, other modules' briefs or knowledge files, and do not write scripts. Write only: `qa-ai-skills/knowledge/app/<MODULE>.md`; your screen lines for `meaning/app/screens.md`, your glossary terms and any locator name lines, returned in your reply (the lead agent adds them to the shared files); and `qa-ai-skills/knowledge/meaning/keyword/<MODULE>.md`. Reply with the files written, those lines, the counts and any open questions."
  - After each module (yours or a sub-agent's): check that its files exist, add the returned shared lines (screens, glossary, locator names), then record it with `python qa-ai-skills/skills/qa-knowledge-setup/split_extract.py record --stage app|keyword|locator <MODULE>`. After all modules, `knowledge_build.py render all`; only you write the shared files, the app index, the run log and `progress.md`.
  - Sub-agents report back to you; you post every progress message. A sub-agent finishing silently is not allowed.
- **Interrupted runs.** If the run logs show the previous run was interrupted (crash or out-of-memory), resume from the last checkpoint and keep the batches small.
- **Always finish all stages.** A stage counts as done only when its index file and run log say complete. After a crash, `/qa-knowledge-setup refresh` resumes the unfinished stage and then runs every remaining stage (keyword, locator, review) automatically.
- **Small pieces.** Inside every stage, work one module (one brief) at a time; split a very large module's brief into groups of about 50 tests or keywords. After each module: write its files, record it, append a checkpoint line to that stage's run log, and do not carry its content forward.
- **Do not open files in editor tabs.** Read files with the file-read tool or terminal commands (e.g. `grep`, `sed -n`) in ranges of at most 300 lines. Close any tabs you opened.
- **No helpers of your own.** The commands in section 1c cover every mechanical job and stream the data themselves.
- **Large scope** (hundreds or thousands of suites, tens of thousands of tests). Tell the user at the start: "This is a large repo: I'll build it in batches, most-used areas first, and save after every batch. You can start generating scripts for the finished areas before the whole build is done." Nothing ever loads the whole repo: scripts cut it into modules, the AI sees one batch, long commands run in the background (section 1c). After each batch post the `next` progress line. Sub-agents, when the plan says so, each take one batch from `next` (never the same batch twice: record before taking the next).
- **Using the knowledge early.** While a large build is still running, a module not built yet has its script-built facts (keywords, locators, routes) but no meaning. The script generator then writes that module's meaning first (this skill's step 3 for that one module, then `record`), so it is never used half-built.
- **Automatic resume.** Every run checks the run logs first and continues from the last checkpoint instead of redoing finished work; modules already recorded with `split_extract.py record` show as `unchanged` in the plan and are skipped. If the editor crashed, the user just runs `/qa-knowledge-setup refresh`.

## 6. Rules
- **One folder for everything the AI creates: `qa-ai-skills/`** (knowledge, generated tests, test case copies, results, session files, backups). Never create a file or folder anywhere else in the QA repo, except the project settings files and commands written by the setup script and, when the user approves, the verified test added to the team's suite. If an older `ai-qa-skills/` folder, or `knowledge/`, `ai_generated_tests/`, `results/ai-scriptgen/` or `.ai_session/` at the repo root exist (a repo set up before), run `python qa-ai-skills/skills/qa_ai_setup.py --move-only` first and say in one line what it moved.
- Write only inside `qa-ai-skills/knowledge/`, plus the development clone folders and the workspace file described in section 1b. Never modify tests, resources, config or skill files, and never change anything inside a development repo.
- Never write helper scripts: every mechanical job has a command (section 1c). `qa-ai-skills/knowledge/.tmp/` holds only the briefs that `split_extract.py` writes; never commit it.
- No sensitive data in any message or output.
- Never commit or push. If asked, propose `chore(knowledge): <build|refresh> knowledge base` and ask before committing.

## 7. Coverage map, gap analysis and regression gap analysis
The coverage analysis answers the questions managers ask: how much of the application do our automated tests really cover, what is not covered, what should be automated next, and what does a release change that no test covers. It is measured, not estimated: `coverage.py` reads what the development code contains (screens, fields, buttons, validation rules, conditions, role rules, business rules, status changes, API calls, outside systems such as BMC or Alfresco, messages, dropdown options) and what every automated test really does (each test expanded through its keywords and arguments down to the library actions and the locators they act on), and matches them by id, test id, name, model binding and visible text. It needs the development knowledge (section 1b); without it, say so in one line and offer `/qa-knowledge-setup dev`.

**Build** (`/qa-knowledge-setup coverage`): checklist "Coverage: reading tests -> matching to the code -> writing the reports".
1. `python qa-ai-skills/skills/qa-knowledge-setup/coverage.py build` (add `--cases <test case files or folders>` when the user gives manual test cases). On a large repo run it in the background (`bg_job.py start coverage -- ...`, then `bg_job.py wait coverage`).
2. **Check the doubtful items, then decide them (this is where you add judgement; never change a status without evidence).** Open `gaps.md` and look at the P1 items and every Gap on a screen that tests clearly use (a likely miss in matching: a test acting through a generic XPath, a custom keyword library, a locator built at run time). For each one, check the test and keyword knowledge; when a test does cover it, add one line to `knowledge/coverage/decisions.md`: `<item ID> | Covered | <the test and why>`; when an item is not testable through the UI, `| N/A | <reason>`. Rebuild once if you added decisions. Decisions are kept on every rebuild and marked in every report.
3. Show the result in the chat: the build's one-line result, then the "At a glance" and "Top gaps to automate next" sections of `coverage-map.md` as they are, then the file list (coverage-map.md for managers, coverage.html to open in a browser, coverage-matrix.csv for Excel, gaps.md, gap-test-cases.md).
4. Offer the next step with clickable options: "Automate the top gaps" (hands `knowledge/coverage/gap-test-cases.md` to `/robot-script-generator`, which reads it like any test case file: cards first, user approval, then scripts), "Open the report", "Done".

**Regression** (`/qa-knowledge-setup regression <base> [<head>]`): first refresh the development knowledge for the head commit (`dev`), then `python qa-ai-skills/skills/qa-knowledge-setup/coverage.py regression --base <base> --head <head>`. If it says a ref is not in the clone, show the exact fetch command it gives and ask before running it (it only adds history to the local clone; the development repo itself stays read-only). Show: the changed items, the existing tests to run for this change (offer to run them with the script generator's watched runs), and the regression gaps (changed and not fully covered) with their priority; files `regression-<base>-<head>.md` and `.html`.

**What the statuses mean** (say this once when showing a first report): Covered = a test exercises the item the way it matters (types into the field, clicks the button, breaks the rule and checks the message, checks both sides of a condition, tests with a user who lacks the role); Partial = a test touches it, but only the easy path; Gap = no automated test touches it; N/A = reachable only through an API, so it needs an API test. Coverage % = Covered + half of Partial. Priority: P1 first (business and role rules, outside systems, unreached screens, money or personal-data fields, code that changed recently), then P2, P3.

Rules: read-only on every repo; the reports stay in `knowledge/coverage/` next to the knowledge (commit them only when the team wants to share them; ask before any commit); they never contain test data values (only lengths and option names), client IDs or credentials.
