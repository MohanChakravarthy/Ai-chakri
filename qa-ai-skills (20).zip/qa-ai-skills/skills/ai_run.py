#!/usr/bin/env python3
"""
ai_run.py - times every step of a robot-script-generator run and writes its summary facts.

The AI calls it at each checklist step, so the user sees live where the minutes go, and the
summary (time per step, runs, fix attempts, where each new locator came from, the slowest
keywords with their existing code) is written by this script, never from memory.

    python qa-ai-skills/skills/ai_run.py start "TC-1328 Update the preferred address"
    python qa-ai-skills/skills/ai_run.py stage "Checking the environment and logging in"
    python qa-ai-skills/skills/ai_run.py run qa-ai-skills/results/run1      after each Robot run
    python qa-ai-skills/skills/ai_run.py attempt "added the wait for the search frame"
    python qa-ai-skills/skills/ai_run.py run <folder> --files <suite> <resource> records each test against its code
    python qa-ai-skills/skills/ai_run.py final                                which tests still need a pass, and the --test options
    python qa-ai-skills/skills/ai_run.py promote <suite> --resource <res>    move tests that passed twice to verified/ (not copy)
    python qa-ai-skills/skills/ai_run.py summary                              at the end
    python qa-ai-skills/skills/ai_run.py suggest "<keyword>" <code file>     the faster version under the existing code
    python qa-ai-skills/skills/ai_run.py suggestions                          existing next to suggested code; fails if one is missing

Two passes per test, on the same code: a pass counts only while the test's own lines, the keywords and
variables it uses and the suite setup are unchanged since that run, so a final run holds only the
tests that still need a pass (never skipped tests, never tests already proven twice).

stage prints how long the previous step took ("Step 3 took 1m 05s"); run reads output.xml
(passed, failed, time per test) and ai-timing.json; summary prints the facts in Markdown and
saves them to qa-ai-skills/results/run-summary-<time>.md. Under "Faster code suggestions" it
shows the existing code of each slow keyword; the AI writes the suggested code under it (the
team's files are never changed).
Python 3.8+, standard library only.
"""
import argparse, contextlib, datetime, importlib.util, io, json, os, re, shutil, sys, tempfile, time
import xml.etree.ElementTree as ET


def ai_home(root="."):
    d = os.path.join(root, "qa-ai-skills")
    return d if os.path.isdir(d) else root


def state_path(root="."):
    return os.path.join(ai_home(root), "session", "run.json")


def load(root="."):
    try:
        with open(state_path(root), encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def save(st, root="."):
    p = state_path(root)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(st, fh, indent=1)


def dur(sec):
    sec = int(round(sec or 0))
    if sec < 60:
        return f"{sec}s"
    m, s = divmod(sec, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"


def now():
    return time.time()


def close_stage(st, t=None):
    if st["stages"] and st["stages"][-1].get("end") is None:
        st["stages"][-1]["end"] = t or now()
        return st["stages"][-1]
    return None


# ======================================================================== output.xml
def _secs(status):
    """Elapsed seconds of a <status> element (RF 7: elapsed; RF 3-6: starttime/endtime)."""
    if status is None:
        return 0.0
    if status.get("elapsed"):
        try:
            return float(status.get("elapsed"))
        except ValueError:
            return 0.0
    fmt = "%Y%m%d %H:%M:%S.%f"
    try:
        a = datetime.datetime.strptime(status.get("starttime"), fmt)
        b = datetime.datetime.strptime(status.get("endtime"), fmt)
        return (b - a).total_seconds()
    except Exception:
        return 0.0


def read_heartbeat(folder):
    try:
        with open(os.path.join(folder, "ai-heartbeat.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def read_output(folder):
    """{'tests': [(name, status, secs)], 'passed', 'failed', 'skipped', 'secs', 'setup_secs'}
    A run that was stopped by force may have no complete output.xml: then the finished tests come from
    the listener's heartbeat, and the run is marked incomplete."""
    path = os.path.join(folder, "output.xml") if os.path.isdir(folder) else folder
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        hb = read_heartbeat(folder if os.path.isdir(folder) else os.path.dirname(folder))
        if not hb:
            raise SystemExit(f"No readable output.xml in {folder} and no heartbeat: the run did not start or was stopped before any test.")
        tests = [(r["name"], r["status"], r.get("secs", 0.0)) for r in hb.get("results", [])]
        if hb.get("test"):
            tests.append((hb["test"], "FAIL", round(time.time() - (hb.get("test_started") or time.time()), 1)))
        messages = {r["name"]: r.get("message", "") for r in hb.get("results", []) if r.get("status") != "PASS"}
        if hb.get("test"):
            messages[hb["test"]] = "Execution terminated by signal (the run was stopped by force)"
        return {"tests": tests, "passed": sum(1 for x in tests if x[1] == "PASS"), "failed": sum(1 for x in tests if x[1] == "FAIL"),
                "skipped": sum(1 for x in tests if x[1] == "SKIP"), "secs": round(sum(x[2] for x in tests), 1), "setup_secs": 0.0,
                "messages": messages, "incomplete": True}
    suite = root.find("suite")
    tests, messages = [], {}
    for t in root.iter("test"):
        st = t.find("status")
        tests.append((t.get("name"), st.get("status") if st is not None else "?", round(_secs(st), 1)))
        if st is not None and st.get("status") != "PASS":
            msg = (st.text or st.get("message") or "").strip()
            if not msg:                                 # Robot 7 keeps the message in a <msg> of the failing keyword
                m = next((x for x in t.iter("msg") if (x.get("level") or x.get("l")) in ("FAIL", "SKIP")), None)
                msg = (m.text or "").strip() if m is not None else ""
            messages[t.get("name")] = re.sub(r"\s+", " ", msg)[:240]
    setup = 0.0
    if suite is not None:
        for kw in suite.iter():
            if kw.tag in ("kw", "setup") and (kw.get("type") or "").upper() == "SETUP" or kw.tag == "setup":
                setup += _secs(kw.find("status"))
                break
    total = _secs(suite.find("status")) if suite is not None else sum(x[2] for x in tests)
    return {"tests": tests, "passed": sum(1 for x in tests if x[1] == "PASS"), "failed": sum(1 for x in tests if x[1] == "FAIL"),
            "skipped": sum(1 for x in tests if x[1] == "SKIP"), "secs": round(total, 1), "setup_secs": round(setup, 1), "messages": messages}



# ======================================================================== Robot files as blocks (for pass counting and promote)
SECTION = re.compile(r"^\*{3}\s*(settings?|variables?|test cases?|tasks?|keywords?|comments?)\s*\*{0,3}\s*$", re.I)
CODE_SETTINGS = re.compile(r"^(suite|test|task)\s+(setup|teardown|template|timeout)\b|^(force|default)?\s*tags\b", re.I)


def norm(x):
    return re.sub(r"[\s_]+", "", (x or "").lower())


def read_blocks(path):
    """{'pre': [lines], 'sections': [{'kind', 'head', 'pre': [lines], 'blocks': [{'name', 'lines'}]}]} - verbatim lines."""
    with open(path, encoding="utf-8") as fh:
        lines = fh.read().splitlines()
    doc = {"pre": [], "sections": []}
    cur = None
    for l in lines:
        m = SECTION.match(l.strip()) if l.startswith("*") else None
        if m:
            k = m.group(1).lower()
            kind = "settings" if k.startswith("setting") else "variables" if k.startswith("variable") else \
                "tests" if k.startswith(("test", "task")) else "keywords" if k.startswith("keyword") else "comments"
            cur = {"kind": kind, "head": l, "pre": [], "blocks": []}
            doc["sections"].append(cur)
            continue
        if cur is None:
            doc["pre"].append(l)
            continue
        if cur["kind"] in ("tests", "keywords"):
            if l and not l[0].isspace() and not l.startswith("#"):
                cur["blocks"].append({"name": l.split("  ")[0].split("\t")[0].strip(), "lines": [l]})
            elif cur["blocks"]:
                cur["blocks"][-1]["lines"].append(l)
            else:
                cur["pre"].append(l)
        elif cur["kind"] == "variables":
            m2 = re.match(r"^([$@&%]\{[^}]+\})", l)
            if m2:
                cur["blocks"].append({"name": m2.group(1), "lines": [l]})
            elif l.startswith("...") and cur["blocks"]:
                cur["blocks"][-1]["lines"].append(l)
            elif cur["blocks"] and not l.strip():
                cur["blocks"][-1]["lines"].append(l)
            else:
                cur["pre"].append(l)
        else:
            cur["pre"].append(l)
    return doc


def write_blocks(doc, path):
    out = list(doc["pre"])
    for sec in doc["sections"]:
        if sec["kind"] in ("tests", "keywords", "variables") and not sec["blocks"] and not any(x.strip() for x in sec["pre"]):
            continue
        out.append(sec["head"])
        out += sec["pre"]
        for b in sec["blocks"]:
            body = list(b["lines"])
            while body and not body[-1].strip():
                body.pop()
            out += body + ([""] if sec["kind"] != "variables" else [])
        if sec["kind"] == "variables":
            out.append("")
    while out and not out[-1].strip():
        out.pop()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")


def code_index(files):
    """Keyword and variable blocks of all given files, plus the suite code settings, for dependency closures."""
    kws, vars_, settings, tests = {}, {}, [], {}
    for f in files:
        if not f or not os.path.isfile(f):
            continue
        d = read_blocks(f)
        for sec in d["sections"]:
            for b in sec["blocks"]:
                if sec["kind"] == "keywords":
                    b["kw"] = True
                    kws[norm(b["name"])] = b
                    if "${" in b["name"]:
                        b["rx"] = re.compile("^" + re.sub(r"\\\$\\\{[^}]+\\\}", ".+", re.escape(b["name"])) + "$", re.I)
                elif sec["kind"] == "variables":
                    vars_[norm(b["name"][2:-1])] = b
                elif sec["kind"] == "tests":
                    tests[b["name"]] = b
            if sec["kind"] == "settings":
                settings += [l for l in sec["pre"] if CODE_SETTINGS.match(l)]
        own = [l for sec in d["sections"] if sec["kind"] == "settings" for l in sec["pre"] if CODE_SETTINGS.match(l)]
        for sec in d["sections"]:
            if sec["kind"] == "tests":
                for b in sec["blocks"]:
                    b["settings"] = own                 # a test runs its own suite's setup, not another suite's
    return {"kws": kws, "vars": vars_, "settings": settings, "tests": tests,
            "embedded": [b for b in kws.values() if b.get("rx")]}


def closure(block, idx, with_setup=True):
    """Keyword and variable blocks a test or keyword uses, directly or through other keywords (and the suite setup's)."""
    seen_k, seen_v, todo = set(), set(), [block]
    own = block.get("settings", idx["settings"])
    if with_setup and not block.get("kw") and own:
        todo.append({"name": "(suite settings)", "lines": [""] + [re.sub(r"^\S+(\s\S+)*?\s{2,}", "", l, count=1) for l in own]})
    while todo:
        b = todo.pop()
        for l in b["lines"][1:]:
            if l.strip().startswith("#"):
                continue
            for tok in re.split(r"\s{2,}|\t", l.strip()):
                if not tok or tok.startswith(("[", "#")):
                    continue
                cand = [norm(tok), norm(tok.split(".")[-1])]
                hit = next((idx["kws"][c] for c in cand if c in idx["kws"]), None)
                if hit is None:
                    hit = next((e for e in idx["embedded"] if e["rx"].match(tok)), None)
                if hit is not None and norm(hit["name"]) not in seen_k and hit is not block:
                    seen_k.add(norm(hit["name"]))
                    todo.append(hit)
            for v in re.findall(r"[$@&%]\{([^}\[.]+)", l):
                nv = norm(v)
                if nv in idx["vars"] and nv not in seen_v:
                    seen_v.add(nv)
                    todo.append(idx["vars"][nv])
    return seen_k, seen_v


def test_print(name, idx):
    """Fingerprint of everything a test runs: its own lines, the keywords and variables it uses, the suite's setup lines."""
    b = idx["tests"].get(name)
    if b is None:
        return None
    ks, vs = closure(b, idx)
    parts = ["\n".join(b["lines"]).strip()] + ["\n".join(idx["kws"][k]["lines"]).strip() for k in sorted(ks)] + \
            ["\n".join(idx["vars"][v]["lines"]).strip() for v in sorted(vs)] + sorted(x.strip() for x in b.get("settings", idx["settings"]))
    import hashlib
    return hashlib.sha1("\n\x00".join(parts).encode("utf-8")).hexdigest()[:12]


def pass_counts(st, files):
    """Per test: passes on its current code (a pass counts only while the code it ran is unchanged)."""
    idx = code_index(files)
    res = {}
    for name in idx["tests"]:
        fp = test_print(name, idx)
        good = [r for r in st["runs"] if (r.get("prints") or {}).get(name) == fp and any(t[0] == name and t[1] == "PASS" for t in r["tests"])]
        last = next((t for r in reversed(st["runs"]) for t in r["tests"] if t[0] == name), None)
        res[name] = {"passes": len(good), "last": last[1] if last else "NOT RUN",
                     "changed": any(name in (r.get("prints") or {}) and r["prints"][name] != fp for r in st["runs"])}
    return res, idx

# ======================================================================== commands
def cmd_start(a, root="."):
    st = {"what": a.what, "started": now(), "stages": [], "runs": [], "attempts": [], "notes": []}
    save(st, root)
    print(f"Timing started for: {a.what}")


def cmd_stage(a, root="."):
    st = load(root) or {"what": "run", "started": now(), "stages": [], "runs": [], "attempts": [], "notes": []}
    prev = close_stage(st)
    st["stages"].append({"name": a.name, "start": now(), "end": None})
    save(st, root)
    if prev:
        print(f"{prev['name']}: {dur(prev['end'] - prev['start'])}  (total so far {dur(now() - st['started'])})")
    else:
        print(f"Started: {a.name}")


def cmd_run(a, root="."):
    st = load(root) or {"what": "run", "started": now(), "stages": [], "runs": [], "attempts": [], "notes": []}
    o = read_output(a.folder)
    timing = []
    tp = os.path.join(a.folder, "ai-timing.json")
    if os.path.isfile(tp):
        try:
            with open(tp, encoding="utf-8") as fh:
                timing = json.load(fh)
        except Exception:
            timing = []
    files = list(getattr(a, "files", None) or st.get("files") or [])
    prints = {}
    if files:
        st["files"] = files
        idx = code_index(files)
        prints = {name: test_print(name, idx) for name, _, _ in o["tests"] if name in idx["tests"]}
    learn_budgets(st, timing)
    stall = next((x for x in reversed(st.get("stalls", [])) if os.path.normpath(x["folder"]) == os.path.normpath(a.folder)), None)
    if stall:                                           # stopped by the watch: an environment problem, not a script failure
        o["incomplete"] = True
        o["tests"] = [(n_, "BLOCKED" if n_ == stall.get("test") and s_ != "PASS" else s_, t_) for n_, s_, t_ in o["tests"]]
        o["failed"] = sum(1 for x in o["tests"] if x[1] == "FAIL")
        o["blocked"] = sum(1 for x in o["tests"] if x[1] == "BLOCKED")
        if stall.get("test"):
            o["messages"][stall["test"]] = stall["say"]
    known = {t[0] for r in st["runs"] for t in r["tests"]}
    names = {t[0] for t in o["tests"]}
    kind = "full" if not st["runs"] or not names < known else f"rerun of {len(names)}"
    if o.get("incomplete"):
        kind += ", not completed"
    if getattr(a, "kind", None):
        kind = a.kind
    st["runs"].append({"folder": a.folder, "at": now(), **o, "timing": timing[:40], "prints": prints, "kind": kind})
    save(st, root)
    print(f"Run {len(st['runs'])} ({kind}): {o['passed']} passed, {o['failed']} failed" + (f", {o['skipped']} skipped" if o["skipped"] else "") +
          (f", {o['blocked']} blocked by the environment" if o.get("blocked") else "") +
          f" in {dur(o['secs'])}" + (f" (suite setup {dur(o['setup_secs'])})" if o["setup_secs"] else ""))
    for name, status, secs in o["tests"]:
        if status != "PASS":
            print(f"  {status} {name} ({dur(secs)})" + ("  - environment problem: not a script failure, no fix attempt used" if status == "BLOCKED" else ""))
    if o.get("incomplete") and stall:
        left = [n_ for n_ in stall.get("not_run", []) if n_ not in names]
        if left:
            print(f"  Not run: {len(left)} test(s). " + stall_next(st, stall, left))


def learn_budgets(st, timing):
    """Slowest time of every business step and of every library step inside it, over all runs of this work."""
    b = st.setdefault("budgets", {})
    for row in timing or []:
        if row.get("keyword") == "__steps__":
            for k, v in (row.get("max_s") or {}).items():
                b[k] = max(b.get(k, 0.0), float(v))
        elif row.get("keyword"):
            v = row.get("max_s") or (row.get("total_s", 0.0) / max(1, row.get("calls", 1)))
            b[row["keyword"]] = max(b.get(row["keyword"], 0.0), float(v))


# ======================================================================== watch: slow is not stalled
SLOW_FACTOR = 3.0          # a step is over its budget at 3x its slowest earlier time ...
GRACE_S = 60.0             # ... and at least a minute more than that, and a minute past its own wait limit
CONFIRM_S = 30.0           # over budget on two looks at least this far apart before anything is stopped
LIB_DEFAULT_S = {"SeleniumLibrary": 300.0, "Browser": 10.0}   # page load (SeleniumLibrary 5+) / action timeout (Browser)


def run_config_value(root, key):
    try:
        with open(os.path.join(ai_home(root), "knowledge", "run-config.md"), encoding="utf-8") as fh:
            m = re.search(r"(?im)^\s*-\s*" + re.escape(key) + r"\s*:\s*([^\s(]+)", fh.read())
        return m.group(1) if m else None
    except OSError:
        return None


def to_secs(text):
    m = re.match(r"^\s*(\d+(?:\.\d+)?)\s*(ms|s|sec|secs|seconds?|m|min|mins|minutes?)?\s*$", str(text or ""), re.I)
    if not m:
        return None
    v, u = float(m.group(1)), (m.group(2) or "s").lower()
    return v / 1000 if u == "ms" else v * 60 if u.startswith("m") else v


def budget_for(frame, budgets, lib_default):
    """How long this step may stay silent, and why. Never a fixed number: learned from earlier runs, the
    step's own wait limit, or the library's own limit, whichever is largest."""
    reasons = []
    key = f"{frame.get('parent') or ''} > {frame['name']}" if not frame.get("user") else frame["name"]
    seen = budgets.get(key)
    cands = []
    if seen:
        cands.append((max(SLOW_FACTOR * seen, seen + GRACE_S), f"{SLOW_FACTOR:g}x its slowest earlier time ({dur(seen)})"))
    if frame.get("own_timeout"):
        cands.append((frame["own_timeout"] + GRACE_S, f"its own wait limit ({dur(frame['own_timeout'])}) + 1 min"))
    if not cands:
        cands.append((lib_default + GRACE_S, f"no earlier time: the library's own limit ({dur(lib_default)}) + 1 min"))
    best = max(cands, key=lambda c: c[0])
    return best[0], best[1], seen


def dev_hint(root, target):
    """What the development knowledge says this element does: the API it calls and the systems behind it."""
    if not target:
        return ""
    k = os.path.join(ai_home(root), "knowledge")
    try:
        locs = json.load(open(os.path.join(k, ".extract", "locators.json"), encoding="utf-8"))
        value = next((l["value"] for l in locs if l["variable"] == target), target)
        scr = json.load(open(os.path.join(k, ".extract", "dev", "dev-screens.json"), encoding="utf-8"))
    except Exception:
        return ""
    ident = re.sub(r"^(id|name|css|xpath|data-testid)[:=]", "", str(value)).strip("#[]'\" ")
    ident = re.sub(r".*(?:data-testid|data-test|id|name)\s*=\s*['\"]?([\w\-.]+).*", r"\1", ident)
    for sc in scr:
        for e in sc.get("elements", []):
            if ident and ident in (e.get("id"), e.get("testid"), e.get("name")):
                apis = [a for a in sc.get("apis", []) if ident in (a.get("triggered_by") or [])]
                if not apis:
                    return f"Element {ident} on screen {sc.get('route') or sc.get('id')}."
                a = apis[0]
                ints = ", ".join(a.get("integrations") or [])
                return (f"It calls {a['method']} {a['url']}" + (f", which uses {ints}" if ints else "") +
                        " (development knowledge): the likely cause is that service, not the script.")
    return ""


def stall_next(st, stall, left):
    """Which of the tests not run use the stalled step (they would hang the same way) and which can run now."""
    files = [f for f in st.get("files") or [] if os.path.isfile(f)]
    same, others = [], []
    if files and stall.get("user_step"):
        idx = code_index(files)
        stalled_kw = norm(stall["user_step"])
        for n_ in left:
            b = idx["tests"].get(n_)
            uses = b is not None and (stalled_kw in closure(b, idx)[0] or any(norm(stall["user_step"]) in norm(l) for l in b["lines"]))
            (same if uses else others).append(n_)
    else:
        others = list(left)
    out = []
    if same:
        out.append(f"Waiting for the environment (they use '{stall['user_step']}'): " + "; ".join(same) + ".")
    if others:
        out.append("Can run now: " + " ".join(f'--test "{x}"' for x in others))
    return " ".join(out)


def cmd_watch(a, root="."):
    """One short look at a running Robot run (returns within --max seconds). Tells a slow step from a stalled
    one; a stalled run is stopped safely and recorded as an environment problem."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("bg_job", os.path.join(os.path.dirname(os.path.abspath(__file__)), "bg_job.py"))
    bg = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bg)
    st = load(root) or {"what": "run", "started": now(), "stages": [], "runs": [], "attempts": [], "notes": []}
    w = st.setdefault("watch", {})
    lib = run_config_value(root, "library") or ("Browser" if os.path.isfile(os.path.join(ai_home(root), "knowledge", ".extract", "browser")) else "SeleniumLibrary")
    lib_default = to_secs(run_config_value(root, "page load timeout")) or LIB_DEFAULT_S.get(lib, 300.0)
    end_at = time.time() + max(5, min(a.max, 55))
    while True:
        js, _ = bg.state_of(a.job, root)
        hb = read_heartbeat(a.folder)
        if not js:
            raise SystemExit(f"No background run named {a.job}: start it with bg_job.py start {a.job} -- robot ...")
        if js["status"] != "running":
            res = (hb or {}).get("results", [])
            line = f"Run finished ({js['status']}): {sum(1 for r in res if r['status'] == 'PASS')} passed, " \
                   f"{sum(1 for r in res if r['status'] == 'FAIL')} failed" + \
                   (f", {sum(1 for r in res if r['status'] == 'SKIP')} skipped" if any(r['status'] == 'SKIP' for r in res) else "")
            if w.get(a.folder, {}).get("stopped"):
                line += " - stopped by the watch (environment problem recorded)"
            print(line + f". Next: python qa-ai-skills/skills/ai_run.py run {a.folder}")
            w.pop(a.folder, None)
            save(st, root)
            return 0
        state = w.setdefault(a.folder, {})
        if hb and hb.get("stack"):
            frame = hb["stack"][-1]
            silent = time.time() - max(frame["started"], hb.get("last_event") or 0)
            limit, why, seen = budget_for(frame, st.get("budgets", {}), lib_default)
            user_step = next((f["name"] for f in reversed(hb["stack"]) if f["user"]), frame["name"])
            done = len(hb.get("results", []))
            where = f"test {done + 1}" + (f" ({hb['test']})" if hb.get("test") else "") + f" - step '{user_step}'" + \
                    (f" > {frame['name']}" if frame["name"] != user_step else "")
            if silent <= limit:
                state.pop("over_since", None)
                slow = seen and silent > 1.5 * seen
                if time.time() >= end_at:
                    print(f"Running: {where}, {dur(silent)}" + (f" (slower than usual: {dur(seen)} on earlier runs; it may take up to {dur(limit)} by {why})" if slow else ""))
                    save(st, root)
                    return 0
            else:
                if state.get("stop_requested"):
                    since = time.time() - state["stop_requested"]
                    if since > 120:
                        bg.cmd_stop(a.job, root)
                        print(f"Stopped by force after {dur(since)} (Robot did not answer the safe stop). Next: python qa-ai-skills/skills/ai_run.py run {a.folder}")
                        save(st, root)
                        return 0
                    if since > 60 and state.get("count", 1) < 2:
                        state["count"] = 2
                        with open(os.path.join(a.folder, "ai-stop-request.json"), "w") as fh:
                            json.dump({"count": 2, "at": now()}, fh)
                    if time.time() >= end_at:
                        print(f"Stopping safely: waiting for Robot to finish the teardowns ({dur(since)}).")
                        save(st, root)
                        return 0
                elif not state.get("over_since"):
                    state["over_since"] = time.time()
                    state["events"] = hb.get("events")
                    print(f"Not moving: {where} has had no progress for {dur(silent)} (allowed {dur(limit)}: {why}). Looking again before anything is stopped.")
                elif time.time() - state["over_since"] >= CONFIRM_S and hb.get("events") == state.get("events"):
                    hint = dev_hint(root, frame.get("target") or next((f.get("target") for f in reversed(hb["stack"]) if f.get("target")), None))
                    health = ""
                    hurl = run_config_value(root, "health url")
                    if hurl and hurl.startswith("http"):
                        import urllib.request
                        t0 = time.time()
                        try:
                            with urllib.request.urlopen(hurl, timeout=5) as rsp:
                                health = f" The application itself answers ({rsp.status} in {time.time() - t0:.1f}s), so it is waiting on a service behind it."
                        except Exception as e:
                            health = f" The application's health check fails too ({type(e).__name__}): the test environment is down or overloaded."
                    say = (f"Environment problem: {where} got no response for {dur(silent)} (allowed {dur(limit)}: {why}). "
                           f"Not a script failure; no fix attempt used." + (" " + hint if hint else "") + health)
                    not_run = []
                    files = [f for f in st.get("files") or [] if os.path.isfile(f)]
                    if files:
                        done_names = {r["name"] for r in hb.get("results", [])} | {hb.get("test")}
                        not_run = [n_ for n_ in code_index(files)["tests"] if n_ not in done_names]
                    st.setdefault("stalls", []).append({"folder": a.folder, "test": hb.get("test"), "user_step": user_step,
                                                        "step": frame["name"], "silent_s": round(silent), "limit_s": round(limit),
                                                        "why": why, "say": say, "at": now(), "not_run": not_run})
                    with open(os.path.join(a.folder, "ai-stop-request.json"), "w") as fh:
                        json.dump({"count": 1, "at": now()}, fh)
                    state.update(stop_requested=time.time(), count=1, stopped=True)
                    print(say)
                    print("Stopping the run safely (the test fails, its teardown still runs and restores shared data).")
                    save(st, root)
                    return 2
                else:
                    if hb.get("events") != state.get("events"):
                        state.pop("over_since", None)
                    if time.time() >= end_at:
                        print(f"Still no progress: {where}, {dur(silent)}. Checking again before stopping.")
                        save(st, root)
                        return 0
        elif time.time() >= end_at:
            print("Running: starting up" if not hb else "Running: between steps")
            save(st, root)
            return 0
        time.sleep(2)


def cmd_attempt(a, root="."):
    st = load(root) or {"what": "run", "started": now(), "stages": [], "runs": [], "attempts": [], "notes": []}
    st["attempts"].append({"reason": a.reason[:200], "at": now()})
    save(st, root)
    print(f"Fix attempt {len(st['attempts'])}: {a.reason}")


def cmd_status(a, root="."):
    """Where the last run stands, so a stopped run continues instead of starting again."""
    st = load(root)
    if not st:
        print("No run recorded: start a new one.")
        return
    age = now() - st["started"]
    cur = st["stages"][-1] if st["stages"] else None
    if st.get("summary"):
        print(f"Last run finished: {st['what']} ({dur(age)} ago). Start a new one.")
    elif age > 24 * 3600:
        print(f"Last run is older than a day and unfinished: {st['what']}. Start a new one.")
    else:
        done = [s["name"] for s in st["stages"][:-1]]
        print(f"Unfinished run: {st['what']} (started {dur(age)} ago)")
        print(f"Done: {'; '.join(done) or 'nothing yet'}")
        print(f"Stopped during: {cur['name'] if cur else 'the start'}")
        print(f"Robot runs so far: {len(st['runs'])}; fix attempts: {len(st['attempts'])}")


def keyword_source(path, line, limit=18, name=None):
    """The existing keyword's lines (definition line and its body), found by its name when given."""
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except Exception:
        return []
    i = max(0, int(line or 1) - 1)
    if name:
        norm_ = lambda x: re.sub(r"[\s_]+", "", x.lower())
        hits = [j for j, l in enumerate(lines) if l and not l[0].isspace() and norm_(l) == norm_(name)]
        if hits:
            i = min(hits, key=lambda j: abs(j - i))
    out = [lines[i]] if i < len(lines) else []
    for l in lines[i + 1:]:
        if l and not l[0].isspace() or l.startswith("***"):
            break
        out.append(l)
        if len(out) >= limit:
            out.append("    ...")
            break
    while out and not out[-1].strip():
        out.pop()
    return out


def slow_spots(runs, session_timing):
    """Business keywords worth a speed suggestion, with the cause."""
    agg = {}
    for r in runs:
        for t in r.get("timing", []):
            k = agg.setdefault(t["keyword"], {"keyword": t["keyword"], "calls": 0, "total_s": 0.0, "sleep_s": 0.0, "wait_s": 0.0,
                                              "source": t.get("source"), "line": t.get("line"), "runs": 0})
            k["calls"] += t.get("calls", 1)
            k["total_s"] += t.get("total_s", 0)
            k["sleep_s"] += t.get("sleep_s", 0)
            k["wait_s"] += t.get("wait_s", 0)
            k["runs"] += 1
    rows = []
    for k in agg.values():
        n = max(1, k["runs"])
        per_run, sleep, wait = k["total_s"] / n, k["sleep_s"] / n, k["wait_s"] / n
        causes = []
        if sleep >= 1:
            causes.append(f"fixed Sleep of {sleep:.0f}s per run")
        if wait > 5 and wait > per_run / 3:
            causes.append(f"waits {wait:.0f}s per run")
        if k["calls"] / n > 1 and re.search(r"log ?in|sign ?in|open (the )?browser|launch", k["keyword"], re.I):
            causes.append(f"runs {k['calls'] / n:.0f} times per run (once per test)")
        if per_run > 20 and not causes:
            causes.append(f"takes {per_run:.0f}s per run")
        if causes:
            rows.append(dict(k, per_run=per_run, causes=causes))
    for t in session_timing or []:
        if t.get("seconds", 0) > 60:
            rows.append({"keyword": t["keyword"], "calls": 1, "per_run": t["seconds"], "sleep_s": 0, "wait_s": 0, "source": None, "line": None,
                         "causes": [f"took {t['seconds']:.0f}s in the live session"]})
    return sorted(rows, key=lambda r: -r["per_run"])[:6]


def cmd_summary(a, root="."):
    st = load(root)
    if not st:
        raise SystemExit("No timing for this run: start it with ai_run.py start \"<what>\".")
    close_stage(st)
    end = now()
    total = end - st["started"]
    out = [f"# Run summary: {st['what']}", "", f"Total time: {dur(total)}", "", "## Where the time went", "| Step | Time | Share |", "|---|---|---|"]
    for s in st["stages"]:
        secs = (s.get("end") or end) - s["start"]
        out.append(f"| {s['name']} | {dur(secs)} | {round(100 * secs / max(total, 1))}% |")
    if st["runs"]:
        words = []
        for i, r in enumerate(st["runs"], 1):
            kind = r.get("kind") or "full"
            what = "all tests" if kind == "full" else f"only the {len(r['tests'])} that needed it"
            words.append(f"run {i} ({what}): {r['passed']} passed" + (f", {r['failed']} failed" if r["failed"] else "") +
                         (f", {r['skipped']} skipped" if r.get("skipped") else "") + f", {dur(r['secs'])}")
        out += ["", f"## Robot runs: {len(st['runs'])}", "; ".join(words) + ".",
                "| Run | Kind | Tests | Passed | Failed | Skipped | Time | Suite setup |", "|---|---|---|---|---|---|---|---|"]
        for i, r in enumerate(st["runs"], 1):
            out.append(f"| {i} | {r.get('kind') or 'full'} | {len(r['tests'])} | {r['passed']} | {r['failed']} | {r.get('skipped', 0)} | {dur(r['secs'])} | "
                       f"{dur(r['setup_secs']) if r['setup_secs'] else '-'} |")
        final = {}
        for r in st["runs"]:
            for t in r["tests"]:
                final[t[0]] = t[1]
        fp = sum(1 for v in final.values() if v == "PASS")
        fs = sum(1 for v in final.values() if v == "SKIP")
        ff = sum(1 for v in final.values() if v == "FAIL")
        out.append(f"Final result per test: {fp} passed" + (f", {ff} failed" if ff else "") + (f", {fs} skipped" if fs else "") +
                   f" (of {len(final)}).")
        if st.get("stalls"):
            out += ["", "## Runs not completed (environment problems)",
                    "These runs were stopped because a step got no response far beyond its usual time and its own wait limit. "
                    "They are not script failures and used no fix attempt; the two-run proof is still pending."]
            for x in st["stalls"]:
                out.append(f"- {x['test'] or 'between tests'}: step '{x['user_step']}' ({x['step']}) no response for {dur(x['silent_s'])}; "
                           f"allowed {dur(x['limit_s'])} ({x['why']}). Rerun when the environment answers: --test \"{x['test']}\"")
        if st.get("files"):
            res, _ = pass_counts(st, [f for f in st["files"] if os.path.isfile(f)])
            twice = sum(1 for r in res.values() if r["passes"] >= 2)
            out.append(f"Passed twice on their final code: {twice} of {len(res)}. A pass counts only while the test's own lines, "
                       "the keywords and variables it uses and the suite setup are unchanged since that run.")
    out += ["", f"## Fix attempts: {len(st['attempts'])}"] + [f"{i}. {x['reason']}" for i, x in enumerate(st["attempts"], 1)]
    proven = []
    pp = os.path.join(ai_home(root), "session", "proven.json")
    if os.path.isfile(pp):
        try:
            with open(pp, encoding="utf-8") as fh:
                rows_ = json.load(fh)
            proven = [r for r in rows_ if r.get("at", "") >= datetime.datetime.fromtimestamp(st["started"]).isoformat(timespec="seconds")]
        except Exception:
            proven = []
    if proven:
        src = {"dev": "the development code (checked live)", "screen": "the screen's controls list (checked live)",
               "playwright": "Playwright's view of the page (checked live)", "team": "existing team locators"}
        ok = [r for r in proven if r.get("ok", True)]
        by = {}
        for r in ok:
            by.setdefault(r.get("source", "screen"), []).append(r)
        out += ["", f"## New locators: {len(ok)} proven" + (f", {len(proven) - len(ok)} candidates rejected" if len(proven) > len(ok) else "")]
        for k, rows in by.items():
            ratings = {}
            for r in rows:
                ratings[r.get("rating", "-")] = ratings.get(r.get("rating", "-"), 0) + 1
            out.append(f"- From {src.get(k, k)}: {len(rows)} (" + ", ".join(f"{n} {k2}" for k2, n in ratings.items()) + ")")
        if not any(r.get("source") == "playwright" for r in proven):
            out.append("- Playwright was not needed: every new element was found in the development code or the screen's controls.")
    session_timing = []
    stp = os.path.join(ai_home(root), "session", "timing.json")
    if os.path.isfile(stp):
        try:
            with open(stp, encoding="utf-8") as fh:
                session_timing = json.load(fh)
        except Exception:
            pass
    slow = slow_spots(st["runs"], session_timing)
    if slow:
        out += ["", "## Slowest steps", "| Keyword | Per run | Calls | Sleep | Waits | Where |", "|---|---|---|---|---|---|"]
        for r in slow:
            where = f"{os.path.relpath(r['source'], root) if r.get('source') else '-'}:{r.get('line') or ''}"
            out.append(f"| {r['keyword']} | {dur(r['per_run'])} | {r['calls']} | {dur(r.get('sleep_s', 0))} | {dur(r.get('wait_s', 0))} | {where} |")
        out += ["", "## Faster code suggestions (for the team; nothing was changed)"]
        for r in slow:
            code = keyword_source(r["source"], r["line"], name=r["keyword"]) if r.get("source") else []
            out.append(f"### {r['keyword']}: {'; '.join(r['causes'])}")
            if code:
                out += ["Existing:", "```robotframework"] + code + ["```"]
            kept = earlier_suggestion(st, r["keyword"])     # a summary written again keeps the suggestions already made
            out += kept or ["Suggested: <write the faster version here, using the repo's own wait keywords; or 'none: the time is the application's'>"]
    else:
        out += ["", "## Faster code suggestions", "None: no keyword had a fixed Sleep, a long wait or a repeated login."]
    text = "\n".join(out)
    folder = os.path.join(ai_home(root), "results")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"run-summary-{datetime.datetime.now().strftime('%Y%m%d-%H%M')}.md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    st["summary"] = path
    save(st, root)
    print(text)
    print(f"\n(saved to {path})")


def earlier_suggestion(st, keyword):
    p = st.get("summary")
    if not p or not os.path.isfile(p):
        return []
    with open(p, encoding="utf-8") as fh:
        text = fh.read()
    m = re.search(r"(?ms)^### " + re.escape(keyword) + r":.*?(?=^#{2,3} |\Z)", text)
    if not m:
        return []
    k = re.search(r"(?ms)^Suggested:\n```robotframework\n.*?\n```(\nSaves: [^\n]*)?", m.group(0))
    return k.group(0).split("\n") if k else []


def cmd_final(a, root="."):
    """Which tests still need a pass on their current code, and the one command that runs only those."""
    st = load(root)
    if not st or not st["runs"]:
        raise SystemExit("No Robot run recorded yet: run 1 runs the whole suite.")
    files = list(a.files or st.get("files") or [])
    if not files:
        raise SystemExit("Give the suite and resource files: ai_run.py final --files <suite.robot> <resource> ...")
    res, _ = pass_counts(st, files)
    blocked = [n for n, r in res.items() if r["last"] == "BLOCKED"]
    need = [n for n, r in res.items() if r["passes"] < 2 and r["last"] not in ("SKIP", "BLOCKED")]
    skipped = [n for n, r in res.items() if r["last"] == "SKIP"]
    if blocked:
        print(f"Blocked by the environment (rerun when it answers again; two-run proof still pending): " + "; ".join(blocked))
        print("  Rerun them alone: " + " ".join(f'--test "{n}"' for n in blocked))
    done = [n for n, r in res.items() if r["passes"] >= 2]
    for n, r in res.items():
        mark = "proven" if r["passes"] >= 2 else "skipped" if r["last"] == "SKIP" else f"{r['passes']} of 2"
        print(f"  {mark:<8} {n}" + ("  (code changed since an earlier pass; that pass no longer counts)" if r["changed"] and r["passes"] < 2 else ""))
    if not need:
        print(f"No more runs needed: {len(done)} test(s) passed twice on their current code" +
              (f"; {len(skipped)} skipped (see the drafts note)" if skipped else "") + ".")
        return
    print(f"Next run: {len(need)} of {len(res)} test(s)" + (f" (not the {len(done)} already proven twice" if done else "") +
          ((", " if done else " (not ") + f"the {len(skipped)} skipped" if skipped else "") + (")" if done or skipped else "") + ".")
    print("Robot options: " + " ".join(f'--test "{n}"' for n in need))
    if getattr(a, "parallel", 0) and len(need) > 1:
        if shutil.which("pabot"):
            procs = min(int(a.parallel), len(need))
            print(f"Parallel (the tests share no data and no single-session user): pabot --testlevelsplit --processes {procs} "
                  "<the normal options> " + " ".join(f'--test "{n}"' for n in need))
        else:
            print("Parallel runs need pabot (pip install robotframework-pabot); running them one after another.")


def cmd_promote(a, root="."):
    """Move the tests that passed twice from drafts/ to verified/ (moved, not copied), with exactly the code they use."""
    st = load(root) or {"runs": []}
    suite = a.suite
    resources = list(a.resource or [])
    files = [suite] + resources
    if a.tests:
        proven = list(a.tests)
    else:
        res, _ = pass_counts(st, files)
        proven = [n for n, r in res.items() if r["passes"] >= 2]
    if not proven:
        print("Nothing to move: no test has passed twice on its current code.")
        return
    rel = os.path.relpath(os.path.abspath(suite), os.path.abspath(os.path.join(ai_home(root), "ai_generated_tests", "drafts")))
    if rel.startswith(".."):
        raise SystemExit("The suite is not under qa-ai-skills/ai_generated_tests/drafts/.")
    vdir = os.path.join(ai_home(root), "ai_generated_tests", "verified")
    to_v = lambda p: os.path.join(vdir, os.path.relpath(os.path.abspath(p), os.path.abspath(os.path.join(ai_home(root), "ai_generated_tests", "drafts"))))
    idx = code_index(files)
    move_k, move_v = set(), set()
    for n in proven:
        if n not in idx["tests"]:
            raise SystemExit(f"Test not found in the suite: {n}")
        ks, vs = closure(idx["tests"][n], idx)
        move_k |= ks
        move_v |= vs
    keep = [n for n in idx["tests"] if n not in proven]
    moved = {"tests": 0, "keywords": 0, "variables": 0}

    def split(path, is_suite):
        d = read_blocks(path)
        vpath = to_v(path)
        vd = read_blocks(vpath) if os.path.isfile(vpath) else {"pre": list(d["pre"]), "sections": [
            {"kind": s_["kind"], "head": s_["head"], "pre": list(s_["pre"]) if s_["kind"] in ("settings", "comments") else [], "blocks": []}
            for s_ in d["sections"]]}
        for sec in d["sections"]:
            if sec["kind"] not in ("tests", "keywords", "variables"):
                continue
            vsec = next((x for x in vd["sections"] if x["kind"] == sec["kind"]), None)
            if vsec is None:
                vsec = {"kind": sec["kind"], "head": sec["head"], "pre": [], "blocks": []}
                vd["sections"].append(vsec)
            have = {norm(b["name"]) for b in vsec["blocks"]}
            stay = []
            for b in sec["blocks"]:
                key = norm(b["name"]) if sec["kind"] != "variables" else norm(b["name"][2:-1])
                go = (b["name"] in proven) if sec["kind"] == "tests" else (key in (move_k if sec["kind"] == "keywords" else move_v))
                if sec["kind"] == "tests" and is_suite is False:
                    go = False
                if go:
                    if norm(b["name"]) not in have:
                        vsec["blocks"].append(b)
                        moved[sec["kind"] if sec["kind"] != "tests" else "tests"] += 1
                    # a local keyword or variable still used by a test that stays is kept in the draft too
                    if sec["kind"] != "tests" and is_suite and any(
                            (key in closure(idx["tests"][k2], idx)[0 if sec["kind"] == "keywords" else 1]) for k2 in keep):
                        stay.append(b)
                else:
                    stay.append(b)
            sec["blocks"] = stay
        write_blocks(vd, vpath)
        return d, vpath

    sd, vsuite = split(suite, True)
    rdocs = [(r, *split(r, None)) for r in resources]
    for r, rd, vres in rdocs:                           # a draft resource that still holds code imports the verified one
        rleft = any(s_["blocks"] for s_ in rd["sections"] if s_["kind"] in ("keywords", "variables"))
        if rleft:
            rd_set = next((x for x in rd["sections"] if x["kind"] == "settings"), None)
            line = "Resource    " + os.path.relpath(vres, os.path.dirname(os.path.abspath(r))).replace(os.sep, "/")
            if rd_set is None:
                rd["sections"].insert(0, {"kind": "settings", "head": "*** Settings ***", "pre": [line, ""], "blocks": []})
            elif line not in rd_set["pre"]:
                rd_set["pre"].insert(0, line)
            write_blocks(rd, r)
        else:
            os.remove(r)
            ss = next((x for x in sd["sections"] if x["kind"] == "settings"), None)
            if ss:                                      # the draft suite now uses the verified resource
                base = os.path.basename(r)
                ss["pre"] = [("Resource    " + os.path.relpath(vres, os.path.dirname(os.path.abspath(suite))).replace(os.sep, "/"))
                             if re.match(r"^Resource\s", l) and l.rstrip().endswith(base) else l for l in ss["pre"]]
    if keep:
        write_blocks(sd, suite)
    else:
        os.remove(suite)
        for r in resources:                             # nothing left uses what is still in the draft resources
            if os.path.isfile(r):
                os.remove(r)
        dfolder = os.path.dirname(os.path.abspath(suite))
        note = os.path.join(dfolder, "DRAFTS-NOTE.md")
        if os.path.isfile(note):
            os.remove(note)
        try:
            os.rmdir(dfolder)
        except OSError:
            pass
    if st.get("runs"):                                 # pass counting follows the tests to where they now live
        now_files = [vsuite] + [v for _, _, v in rdocs if os.path.isfile(v)] + [f for f in [suite] + resources if os.path.isfile(f)]
        st["files"] = list(dict.fromkeys(os.path.relpath(f, root) if not os.path.isabs(f) else f for f in now_files))
        save(st, root)
    # the note: why each remaining test is still a draft and what it needs
    if keep:
        last = {}
        for r in st["runs"]:
            for t in r["tests"]:
                last[t[0]] = (t[1], (r.get("messages") or {}).get(t[0], ""))
        needs = dict(x.split("=", 1) for x in (a.note or []) if "=" in x)
        note = os.path.join(os.path.dirname(os.path.abspath(suite)), "DRAFTS-NOTE.md")
        out = ["# Still in drafts", "", "These tests did not pass twice yet, so they stay here. Passing tests were moved to "
               f"`{os.path.relpath(vsuite, root).replace(os.sep, '/')}`.", "", "| Test | Last result | Why | What it needs |", "|---|---|---|---|"]
        for n in keep:
            status, msg = last.get(n, ("NOT RUN", ""))
            need_ = needs.get(n, "-")
            if status == "BLOCKED" and n not in needs:
                need_ = f"the environment to answer again, then a rerun: --test \"{n}\" (two passes still needed)"
            out.append(f"| {n} | {'BLOCKED (environment, run not completed)' if status == 'BLOCKED' else status} | "
                       f"{msg.replace('|', '/') or '-'} | {need_.replace('|', '/')} |")
        with open(note, "w", encoding="utf-8") as fh:
            fh.write("\n".join(out) + "\n")
        missing = [n for n in keep if n not in needs and last.get(n, ("", ""))[0] != "BLOCKED"]
        if missing:
            print("Add what each remaining test needs: --note \"<test name>=<what it needs>\" for: " + "; ".join(missing))
    print(f"Moved to verified: {len(proven)} test(s), {moved['keywords']} keyword(s), {moved['variables']} variable(s) -> "
          f"{os.path.relpath(vsuite, root)}")
    print(f"Left in drafts: {len(keep)} test(s)" + (" (see DRAFTS-NOTE.md)" if keep else "; the drafts folder for this suite was removed"))


def cmd_finish(a, root="."):
    """The handover in one call: proves nothing is left to run, moves the proven tests to verified/, writes the
    summary and checks the faster-code suggestions. Prints what the user gets, ready for the chat."""
    st = load(root)
    if not st or not st.get("runs"):
        raise SystemExit("Nothing to hand over: no Robot run recorded.")
    files = [f for f in st.get("files") or [] if os.path.isfile(f)]
    res, _ = pass_counts(st, files)
    need = [n for n, r in res.items() if r["passes"] < 2 and r["last"] not in ("SKIP", "FAIL", "BLOCKED")]
    if need:
        print(f"Not ready to hand over: {len(need)} test(s) still need a pass on their current code: " + "; ".join(need))
        print("Run: python qa-ai-skills/skills/ai_run.py final")
        sys.exit(1)
    drafts = os.path.join("ai_generated_tests", "drafts")
    suites = [f for f in files if f.endswith(".robot") and drafts in os.path.normpath(f)]
    moved_any = False
    for suite in suites:
        here = os.path.dirname(os.path.abspath(suite))
        res_files = [f for f in files if not f.endswith(".robot") and os.path.dirname(os.path.abspath(f)) == here]
        proven = [n for n in read_tests(suite) if res.get(n, {}).get("passes", 0) >= 2 and n not in (a.hold or [])]
        if proven:
            cmd_promote(argparse.Namespace(suite=suite, resource=res_files, tests=proven, note=a.note), root)
            moved_any = True
    st = load(root)
    cmd_summary(argparse.Namespace(), root)
    try:
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()):    # the summary above already shows the section
            cmd_suggestions(argparse.Namespace(), root)
        sugg_ok = True
    except SystemExit:
        sugg_ok = False
    print("\n## Handover")
    v = sorted({f for f in st.get("files") or [] if os.path.isfile(f) and "verified" in os.path.normpath(f)})
    d = sorted({f for f in st.get("files") or [] if os.path.isfile(f) and drafts in os.path.normpath(f)})
    if v:
        print("Verified (passed twice): " + ", ".join(v))
    if d:
        print("Still in drafts (see DRAFTS-NOTE.md next to them): " + ", ".join(d))
    if a.hold:
        print("Waiting for your OK on a changed check: " + "; ".join(a.hold))
    if not sugg_ok:
        print("MISSING: faster code suggestions (ai_run.py suggest), then run finish again.")
        sys.exit(1)
    print("Next: the approval question (add the verified tests to your suite?)." if moved_any or v else "Nothing passed twice: nothing to add.")


def read_tests(path):
    try:
        return [b["name"] for sec in read_blocks(path)["sections"] if sec["kind"] == "tests" for b in sec["blocks"]]
    except OSError:
        return []


PLACEHOLDER = "Suggested: <write the faster version"


def summary_path(st):
    p = st.get("summary") if st else None
    if not p or not os.path.isfile(p):
        raise SystemExit("No saved summary yet: run ai_run.py summary first.")
    return p


def cmd_suggest(a, root="."):
    """Put the faster version of one slow keyword into the saved summary, under its existing code."""
    st = load(root)
    p = summary_path(st)
    with open(p, encoding="utf-8") as fh:
        text = fh.read()
    with open(a.code_file, encoding="utf-8") as fh:
        code = fh.read().rstrip("\n")
    head = re.search(r"(?m)^### " + re.escape(a.keyword) + r":.*$", text)
    if not head:
        raise SystemExit(f"No slow keyword named '{a.keyword}' in the summary.")
    tail = text[head.end():]
    nxt = re.search(r"(?m)^#{2,3} ", tail)
    part = tail[:nxt.start()] if nxt else tail
    block = ["Suggested:", "```robotframework", code, "```"] if code.strip().lower() not in ("none", "") else []
    why = (a.why or "").strip()
    new_part = re.sub(r"(?m)^Suggested: <write.*$\n?", "", part).rstrip("\n")
    new_part = re.sub(r"(?ms)^Suggested:\n```robotframework\n.*?\n```\n?(Saves: .*\n?)?", "", new_part + "\n").rstrip("\n")
    add = "\n".join(block + ([f"Saves: {why}"] if why else []))
    text = text[:head.end()] + new_part + "\n" + add + "\n" + ("\n" + tail[nxt.start():] if nxt else "")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(text)
    print(f"Saved the suggestion for {a.keyword} in {p}")


def cmd_suggestions(a, root="."):
    """The Faster code suggestions section, existing next to suggested code, ready for the chat. Fails if one is missing."""
    st = load(root)
    p = summary_path(st)
    with open(p, encoding="utf-8") as fh:
        text = fh.read()
    m = re.search(r"(?ms)^## Faster code suggestions.*?(?=^## |\Z)", text)
    sec = m.group(0).rstrip() if m else ""
    missing = re.findall(r"(?m)^### (.+?):", sec) if PLACEHOLDER in sec else []
    missing = [k for k in missing if re.search(r"(?ms)^### " + re.escape(k) + r":.*?(?=^### |\Z)", sec).group(0).count(PLACEHOLDER)]
    print(sec)
    if missing:
        print("\nMISSING: write the faster version for: " + "; ".join(missing) + " (ai_run.py suggest \"<keyword>\" <code file>).")
        sys.exit(1)


# ======================================================================== self-test
OUT7 = """<?xml version="1.0" encoding="UTF-8"?>
<robot generator="Robot 7.1"><suite name="Drafts"><kw name="Login To Portal" type="SETUP"><status status="PASS" start="2026-11-19T10:00:00" elapsed="40.0"/></kw>
<test name="TC-1 One"><status status="PASS" start="2026-11-19T10:00:40" elapsed="30.5"/></test>
<test name="TC-2 Two"><status status="FAIL" start="2026-11-19T10:01:10" elapsed="12.0">Element not found</status></test>
<status status="FAIL" start="2026-11-19T10:00:00" elapsed="83.0"/></suite></robot>"""
OUT6 = """<?xml version="1.0" encoding="UTF-8"?>
<robot generator="Robot 6.1"><suite name="Drafts"><test name="TC-1 One"><status status="PASS" starttime="20261119 10:00:00.000" endtime="20261119 10:00:31.500"/></test>
<status status="PASS" starttime="20261119 10:00:00.000" endtime="20261119 10:00:32.000"/></suite></robot>"""


def self_test():
    ok = {}
    tmp = tempfile.mkdtemp(prefix="ai_run_selftest_")
    cwd = os.getcwd()
    try:
        os.chdir(tmp)
        os.makedirs("qa-ai-skills/results/run1")
        os.makedirs("qa-ai-skills/results/run2")
        os.makedirs("qa-ai-skills/session")
        os.makedirs("resources")
        with open("resources/common.resource", "w") as fh:
            fh.write("*** Keywords ***\nLogin To Portal\n    [Arguments]    ${u}    ${p}\n    Open Browser    ${URL}    chrome\n    Sleep    10s\n    Input Text    id:user    ${u}\n\nOther\n    No Operation\n")
        with open("qa-ai-skills/results/run1/output.xml", "w") as fh:
            fh.write(OUT7)
        with open("qa-ai-skills/results/run2/output.xml", "w") as fh:
            fh.write(OUT6)
        timing = [{"keyword": "Login To Portal", "calls": 2, "total_s": 80.0, "sleep_s": 20.0, "wait_s": 4.0,
                   "source": os.path.abspath("resources/common.resource"), "line": 2},
                  {"keyword": "Open Client", "calls": 2, "total_s": 6.0, "sleep_s": 0, "wait_s": 1.0, "source": None, "line": None}]
        with open("qa-ai-skills/results/run1/ai-timing.json", "w") as fh:
            json.dump(timing, fh)
        with open("qa-ai-skills/session/proven.json", "w") as fh:
            json.dump([{"locator": "css:[data-testid='a']", "rating": "Strong", "source": "dev", "ok": True, "at": "2999-01-01T00:00:00"},
                       {"locator": "xpath://label[normalize-space()='B']/..//input", "rating": "Good", "source": "screen", "ok": True, "at": "2999-01-01T00:00:00"},
                       {"locator": "id:mui-1", "source": "dev", "ok": False, "at": "2999-01-01T00:00:00"}], fh)
        import io, contextlib
        class A: pass
        def call(fn, **kw):
            a = A()
            for k, v in kw.items():
                setattr(a, k, v)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                fn(a)
            return buf.getvalue()
        call(cmd_start, what="TC-1 and TC-2")
        call(cmd_stage, name="Read the test case")
        st = load()
        st["stages"][0]["start"] -= 65
        save(st)
        o = call(cmd_stage, name="Running the tests")
        ok["each step's time is printed when the next starts"] = o.startswith("Read the test case: 1m 05s")
        o1 = call(cmd_run, folder="qa-ai-skills/results/run1")
        ok["Robot 7 output: passed, failed, time, suite setup, failing test named"] = "1 passed, 1 failed in 1m 23s (suite setup 40s)" in o1 and "FAIL TC-2 Two" in o1
        o2 = call(cmd_run, folder="qa-ai-skills/results/run2")
        ok["Robot 6 output read too"] = "1 passed, 0 failed in 32s" in o2
        call(cmd_attempt, reason="added the wait for the search frame")
        ok["status shows an unfinished run and the step it stopped in (resume)"] = "Stopped during: Running the tests" in call(cmd_status)
        s = call(cmd_summary)
        ok["summary: time per step, runs and attempts"] = "| Read the test case | 1m 05s |" in s and "| 1 | full | 2 | 1 | 1 | 0 | 1m 23s | 40s |" in s and "1. added the wait" in s
        ok["summary: where new locators came from, rejected candidates counted"] = "From the development code (checked live): 1 (1 Strong)" in s and \
            "1 candidates rejected" in s and "Playwright was not needed" in s
        ok["summary: slow keyword with cause and its existing code"] = "### Login To Portal: fixed Sleep of 20s per run; runs 2 times per run (once per test)" in s and \
            "    Sleep    10s" in s and "Other" not in s.split("Existing:")[1].split("```")[1]
        ok["after the summary, status says the run is finished"] = "Last run finished" in call(cmd_status)
        ok["summary saved in results"] = any(f.startswith("run-summary-") for f in os.listdir("qa-ai-skills/results"))
        # suggestions are mandatory: existing code next to the suggested code, in the saved file
        o = call(cmd_suggestions) if False else None
        try:
            call(cmd_suggestions)
            ok["suggestions: a missing faster version fails the check"] = False
        except SystemExit:
            ok["suggestions: a missing faster version fails the check"] = True
        with open("fast.robot", "w") as fh:
            fh.write("Login To Portal\n    [Arguments]    ${u}    ${p}\n    Open Browser    ${URL}    chrome\n    Wait Until Element Is Visible    id:user\n    Input Text    id:user    ${u}")
        call(cmd_suggest, keyword="Login To Portal", code_file="fast.robot", why="about 20s per run (the fixed Sleep)")
        o = call(cmd_suggestions)
        saved = open(load()["summary"], encoding="utf-8").read()
        ok["suggestions: existing and suggested code shown and saved, placeholder gone"] = \
            "Existing:" in o and "Suggested:\n```robotframework\nLogin To Portal" in o and "Saves: about 20s" in o and PLACEHOLDER not in saved and "Wait Until Element Is Visible" in saved
        call(cmd_summary)
        again = open(load()["summary"], encoding="utf-8").read()
        ok["a summary written again keeps the suggestions already made"] = PLACEHOLDER not in again and "Saves: about 20s" in again
        # pass counting, the final run plan and promote (moved, not copied)
        D = "qa-ai-skills/ai_generated_tests/drafts/voc"
        os.makedirs(D)
        with open(D + "/voc.robot", "w") as fh:
            fh.write("*** Settings ***\nResource    voc.resource\nSuite Setup    Open App\n\n*** Test Cases ***\n"
                     "TC-1 One\n    Open Client    a\n    Check Status\n\nTC-2 Two\n    Open Client    b\n    Check Pending\n\n"
                     "TC-3 Three\n    Skip    needs data\n")
        with open(D + "/voc.resource", "w") as fh:
            fh.write("*** Variables ***\n${STATUS}    css:[data-testid='status']\n${PENDING}    css:[data-testid='pending']\n\n*** Keywords ***\n"
                     "Open App\n    No Operation\n\nOpen Client\n    [Arguments]    ${c}\n    No Operation\n\nCheck Status\n    Log    ${STATUS}\n\n"
                     "Check Pending\n    Log    ${PENDING}\n")
        def out(name, tests):
            os.makedirs(f"qa-ai-skills/results/{name}")
            with open(f"qa-ai-skills/results/{name}/output.xml", "w") as fh:
                fh.write('<?xml version="1.0"?><robot generator="Robot 7.1"><suite name="Voc">' +
                         "".join(f'<test name="{n}"><status status="{s_}" elapsed="5.0">{m_}</status></test>' for n, s_, m_ in tests) +
                         '<status status="PASS" elapsed="20.0"/></suite></robot>')
        call(cmd_start, what="VOC batch")
        F = [D + "/voc.robot", D + "/voc.resource"]
        out("r1", [("TC-1 One", "PASS", ""), ("TC-2 Two", "FAIL", "Element not found"), ("TC-3 Three", "SKIP", "needs data")])
        call(cmd_run, folder="qa-ai-skills/results/r1", files=F, kind=None)
        with open(D + "/voc.resource") as fh:             # fix only TC-2's own keyword
            rtxt = fh.read()
        with open(D + "/voc.resource", "w") as fh:
            fh.write(rtxt.replace("Check Pending\n    Log    ${PENDING}", "Check Pending\n    Wait For    ${PENDING}"))
        out("r2", [("TC-2 Two", "PASS", "")])
        o = call(cmd_run, folder="qa-ai-skills/results/r2", files=None, kind=None)
        ok["run kind recorded: a rerun of only the failed test is named so"] = "Run 2 (rerun of 1)" in o
        o = call(cmd_final, files=None)
        ok["final run plan: only tests short of two passes on current code, skipped test left out"] = \
            'Next run: 2 of 3' in o and '--test "TC-1 One" --test "TC-2 Two"' in o and "TC-3" not in o.split("Robot options:")[1]
        rtxt = open(D + "/voc.resource").read()
        with open(D + "/voc.resource", "w") as fh:             # a shared keyword changed: TC-1's earlier pass no longer counts
            fh.write(rtxt.replace("Open Client\n    [Arguments]    ${c}\n    No Operation", "Open Client\n    [Arguments]    ${c}\n    Log    ${c}"))
        o = call(cmd_final, files=None)
        ok["a pass stops counting when shared code it ran changed"] = any(l.strip().startswith("0 of 2") and "TC-1 One  (code changed" in l for l in o.splitlines())
        out("r3", [("TC-1 One", "PASS", ""), ("TC-2 Two", "PASS", ""), ("TC-3 Three", "SKIP", "needs a client with an expired VID")])
        call(cmd_run, folder="qa-ai-skills/results/r3", files=None, kind=None)
        out("r4", [("TC-1 One", "PASS", ""), ("TC-2 Two", "PASS", "")])
        call(cmd_run, folder="qa-ai-skills/results/r4", files=None, kind=None)
        o = call(cmd_final, files=None)
        ok["no more runs once every test passed twice"] = "No more runs needed" in o
        o = call(cmd_promote, suite=D + "/voc.robot", resource=[D + "/voc.resource"], tests=None, note=["TC-3 Three=a client with an expired VID in the test environment"])
        V = "qa-ai-skills/ai_generated_tests/verified/voc"
        vs, ds = open(V + "/voc.robot").read(), open(D + "/voc.robot").read()
        vr, dr = open(V + "/voc.resource").read(), open(D + "/voc.resource").read() if os.path.isfile(D + "/voc.resource") else ""
        note = open(D + "/DRAFTS-NOTE.md").read()
        ok["promote: passing tests moved (not copied), skipped test stays with a note"] = \
            "TC-1 One" in vs and "TC-2 Two" in vs and "TC-1 One" not in ds and "TC-3 Three" in ds and "TC-3 Three" not in vs and \
            "needs a client with an expired VID" in note and "a client with an expired VID in the test environment" in note
        ok["promote: the code the passing tests use goes with them; drafts keep only what is left"] = \
            "Check Pending" in vr and "${PENDING}" in vr and "Open App" in vr and "Check Pending" not in dr and \
            "Suite Setup    Open App" in vs and "Resource    voc.resource" in vs and \
            ("Resource    ../../verified/voc/voc.resource" in ds or "../../verified/voc/voc.resource" in dr)
        o = call(cmd_promote, suite=D + "/voc.robot", resource=[D + "/voc.resource"] if os.path.isfile(D + "/voc.resource") else [], tests=["TC-3 Three"], note=None)
        ok["promote: when nothing is left, the drafts folder of the suite is removed"] = not os.path.exists(D) and "TC-3 Three" in open(V + "/voc.robot").read()
        # the handover in one call
        D2 = "qa-ai-skills/ai_generated_tests/drafts/pay"
        os.makedirs(D2)
        with open(D2 + "/pay.robot", "w") as fh:
            fh.write("*** Settings ***\nResource    pay.resource\n\n*** Test Cases ***\nTC-7 Pay\n    Pay Now\n\nTC-8 Refund\n    Pay Now\n")
        with open(D2 + "/pay.resource", "w") as fh:
            fh.write("*** Keywords ***\nPay Now\n    No Operation\n")
        call(cmd_start, what="pay")
        F2 = [D2 + "/pay.robot", D2 + "/pay.resource"]
        out("p1", [("TC-7 Pay", "PASS", ""), ("TC-8 Refund", "FAIL", "Refund button not found")])
        call(cmd_run, folder="qa-ai-skills/results/p1", files=F2, kind=None)
        out("p2", [("TC-7 Pay", "PASS", ""), ("TC-8 Refund", "FAIL", "Refund button not found")])
        call(cmd_run, folder="qa-ai-skills/results/p2", files=None, kind=None)
        try:
            o = call(cmd_finish, note=["TC-8 Refund=the refund screen in the test environment"], hold=None)
            ok["finish: hands over in one call (verified moved, failing test left with its note)"] = False
        except SystemExit:
            o = ""
        st_ = load()
        # the watch: a step that stays silent far beyond its learned time is stopped safely as an environment problem
        global GRACE_S, CONFIRM_S
        old_g, old_c = GRACE_S, CONFIRM_S
        GRACE_S, CONFIRM_S = 1.0, 1.0
        try:
            W = "qa-ai-skills/results/w1"
            os.makedirs(W)
            fake = os.path.abspath("fake_robot.py")
            with open(fake, "w") as fh:
                fh.write("import json,os,sys,time\nW=sys.argv[1]\nt0=time.time()\n"
                         "hb={'pid':os.getpid(),'test':'TC-8 Refund','test_started':t0,'events':5,'last_event':t0-20,"
                         "'results':[{'name':'TC-7 Pay','status':'PASS','secs':3.0,'message':''}],'done':False,"
                         "'stack':[{'name':'Submit Refund','user':True,'started':t0-20,'own_timeout':None,'parent':None},"
                         "{'name':'Click Element','user':False,'started':t0-20,'own_timeout':None,'parent':'Submit Refund','target':'${REFUND_BTN}'}]}\n"
                         "json.dump(hb,open(os.path.join(W,'ai-heartbeat.json'),'w'))\n"
                         "while not os.path.exists(os.path.join(W,'ai-stop-request.json')):\n    time.sleep(0.2)\n"
                         "hb['results'].append({'name':'TC-8 Refund','status':'FAIL','secs':25.0,'message':'Execution terminated by signal'})\n"
                         "hb['test']=None; hb['stack']=[]; hb['done']=True\njson.dump(hb,open(os.path.join(W,'ai-heartbeat.json'),'w'))\n")
            st_ = load()
            st_["budgets"] = {"Submit Refund > Click Element": 1.0}
            st_["files"] = F2
            save(st_)
            spec = importlib.util.spec_from_file_location("bg_job", os.path.join(os.path.dirname(os.path.abspath(__file__)), "bg_job.py"))
            bgm = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(bgm)
            with contextlib.redirect_stdout(io.StringIO()):
                bgm.cmd_start("run-w1", [sys.executable, fake, os.path.abspath(W)], ".")
            time.sleep(1.0)
            o1 = call(cmd_watch, folder=W, job="run-w1", max=5)
            time.sleep(1.2)
            try:
                o2 = call(cmd_watch, folder=W, job="run-w1", max=5)
            except SystemExit:
                o2 = ""
            ok["watch: silent step past its learned time is checked twice, then stopped as an environment problem"] = \
                "Not moving" in o1 and "Environment problem" in (o1 + o2) and "no fix attempt used" in (o1 + o2) and \
                (o1 + o2).index("Not moving") < (o1 + o2).index("Environment problem") and os.path.isfile(W + "/ai-stop-request.json")
            for _ in range(20):
                o3 = call(cmd_watch, folder=W, job="run-w1", max=3)
                if "Run finished" in o3:
                    break
            o4 = call(cmd_run, folder=W, files=None, kind=None)
            o5 = call(cmd_final, files=None)
            ok["a stopped run: blocked test kept apart (not a failure, rerun command given), no output.xml needed"] = \
                "Run finished" in o3 and "1 blocked by the environment" in o4 and "not completed" in o4 and \
                "Blocked by the environment" in o5 and '--test "TC-8 Refund"' in o5
        finally:
            GRACE_S, CONFIRM_S = old_g, old_c
        ok["finish: hands over in one call (verified moved, failing test left with its note)"] = \
            os.path.isfile("qa-ai-skills/ai_generated_tests/verified/pay/pay.robot") and "TC-8 Refund" in open(D2 + "/pay.robot").read() \
            and "TC-7 Pay" not in open(D2 + "/pay.robot").read() and "refund screen" in open(D2 + "/DRAFTS-NOTE.md").read() \
            and os.path.isfile(st_["summary"])
    finally:
        os.chdir(cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    print()
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] == ["--self-test"]:
        return self_test()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("start"); s.add_argument("what")
    s = sub.add_parser("stage"); s.add_argument("name")
    s = sub.add_parser("run"); s.add_argument("folder"); s.add_argument("--files", nargs="+"); s.add_argument("--kind")
    s = sub.add_parser("final"); s.add_argument("--files", nargs="+"); s.add_argument("--parallel", type=int, default=0)
    s = sub.add_parser("finish"); s.add_argument("--note", action="append"); s.add_argument("--hold", nargs="+")
    s = sub.add_parser("promote"); s.add_argument("suite"); s.add_argument("--resource", nargs="+"); s.add_argument("--tests", nargs="+")
    s.add_argument("--note", action="append")
    s = sub.add_parser("suggest"); s.add_argument("keyword"); s.add_argument("code_file"); s.add_argument("--why")
    sub.add_parser("suggestions")
    s = sub.add_parser("watch"); s.add_argument("folder"); s.add_argument("--job", required=True); s.add_argument("--max", type=int, default=45)
    s = sub.add_parser("attempt"); s.add_argument("reason")
    sub.add_parser("summary")
    sub.add_parser("status")
    a = ap.parse_args(argv)
    {"start": cmd_start, "stage": cmd_stage, "run": cmd_run, "attempt": cmd_attempt, "summary": cmd_summary, "status": cmd_status,
     "final": cmd_final, "finish": cmd_finish, "promote": cmd_promote, "suggest": cmd_suggest, "suggestions": cmd_suggestions, "watch": cmd_watch}[a.cmd](a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
