"""
ai_session.py - Robot Framework helper library used ONLY by the AI skills (robot-script-generator).

It lets the AI agent, rf-mcp and Playwright MCP share one live browser safely:

    AI Save Screen        save main page + every frame + a list of controls + a screenshot
    AI Open Door          save the screen, then open a local "door" (127.0.0.1:9222) so
                          Playwright MCP can attach to the SAME browser. Does not block.
    AI Close Door         close the door immediately (also closes on timeout and at exit)
    AI Checkpoint         for a normal Robot run: open the door and PAUSE until the AI writes
                          qa-ai-skills/session/continue (or the time limit passes), then close it
    AI Check Locator      the judge: prove a locator matches exactly one visible element in
                          the right frame and, optionally, that an action really changes state;
                          rates it Strong / Good / Weak and rejects generated IDs
    AI Set Label          show or update the AI status badge (blue = rf-mcp, purple = Playwright,
                          yellow = the AI's final Robot run)
    AI Run Steps          run several existing keywords in ONE call (the whole known route), each with
                          its badge, timing and an optional proof element; stops at the first failure
    AI Check Locators     the judge for many candidates in ONE call, with where each came from
                          (development code, the saved screen, Playwright); returns a table, never fails
    AI Suggest Locators   candidate locators for the test case's words, built from the saved screen's
                          controls list by the locator rules (test ID, id/name, label, text), ranked
    AI Run Step           run one existing keyword in an rf-mcp session with the badge shown before
                          and redrawn after (page changes wipe it), and record how long it took
    AI Check Variables    start-up check: report which required variables are missing or empty
                          (names only, never values)
    AI Share Login        save this browser's login (cookies + local storage) so Playwright MCP
                          (`playwright-session`) can open the same page, logged in, in its own
                          window. Used for Browser library suites and whenever the door is unavailable

Import it only in AI sessions and the AI's own helper files (start-up check, reach run,
locator checks). Never in the generated test, team suites or CI:
    Library    ../../../skills/ai_session.py
(the path from qa-ai-skills/ai_generated_tests/drafts/<module>/; work it out again for any other folder)

Safety:
- The door listens on 127.0.0.1 only, forwards to the browser's own local debug port
  (chromedriver opens one in every Chrome run), and closes on command, after
  `door_timeout` seconds (default 1800), and when the Python process ends.
- Saved screens can contain application data. They go to qa-ai-skills/session/ (git-ignored) and the
  generator deletes them at the end of the run. Nothing here clicks Save/Submit/Delete.
- Works with SeleniumLibrary and the Browser library. Every keyword supports both; the only
  difference is how Playwright MCP gets a live view: SeleniumLibrary (Chrome/Edge) through the
  door, the Browser library through AI Share Login (it starts its own browser, which nothing
  else can join). If a suite imports both libraries, the one with an open browser is used.
- AI Share Login writes login cookies to qa-ai-skills/session/ (git-ignored). The generator deletes them
  at the end of the run.
"""
import atexit
import json
import os
import re
import select
import socket
import socketserver
import threading
import time
from datetime import datetime

ROBOT_LIBRARY_SCOPE = "GLOBAL"

SESSION_DIR = os.environ.get("AI_SESSION_DIR") or (os.path.join("qa-ai-skills", "session") if os.path.isdir("qa-ai-skills") else ".ai_session")
DOOR_HOST = "127.0.0.1"

CONTROLS_JS = r"""
return (function () {
  const out = [];
  const q = 'input,select,textarea,button,a[href],[role],[contenteditable="true"],label';
  const els = Array.from(document.querySelectorAll(q)).slice(0, 600);
  for (const el of els) {
    const r = el.getBoundingClientRect();
    const st = window.getComputedStyle(el);
    const visible = r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
    let label = el.getAttribute('aria-label') || '';
    if (!label && el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) label = l.innerText.trim();
    }
    if (!label && el.closest('label')) label = el.closest('label').innerText.trim();
    const item = {
      tag: el.tagName.toLowerCase(), type: el.getAttribute('type') || '',
      role: el.getAttribute('role') || '', id: el.id || '', name: el.getAttribute('name') || '',
      testid: (TA => TA ? el.getAttribute(TA) : '')(['data-testid','data-test','data-qa','data-cy','data-automation-id'].find(a => el.getAttribute(a))),
      testattr: ['data-testid','data-test','data-qa','data-cy','data-automation-id'].find(a => el.getAttribute(a)) || '',
      label: (label || '').slice(0, 120), text: (el.innerText || '').trim().slice(0, 80),
      placeholder: el.getAttribute('placeholder') || '', visible: visible,
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      required: !!el.required || el.getAttribute('aria-required') === 'true',
      checked: (el.type === 'checkbox' || el.type === 'radio') ? !!el.checked :
               (el.getAttribute('aria-checked') || null),
      maxlength: el.getAttribute('maxlength') || '', pattern: el.getAttribute('pattern') || ''
    };
    if (el.tagName === 'SELECT') item.options = Array.from(el.options).slice(0, 100).map(o => o.text.trim());
    out.push(item);
  }
  return JSON.stringify(out);
})();
"""

CHECKED_JS = r"""
const e = arguments[0];
let i = e.matches('input') ? e : e.querySelector('input[type=checkbox],input[type=radio]');
if (!i && e.getAttribute('for')) i = document.getElementById(e.getAttribute('for'));
if (i) return !!i.checked;
const a = e.getAttribute('aria-checked') || (e.querySelector('[aria-checked]') || {getAttribute: () => null}).getAttribute('aria-checked');
return a === 'true';
"""

_INDICATOR_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_activity_indicator.js")


MODES = ("rf", "playwright", "robot")


def _badge_script(text, keyword="", mode="rf"):
    """Full indicator script plus the label, so the badge is drawn even on a page that
    Playwright attached to (its init script only runs on pages Playwright opens itself).
    mode: 'rf' (blue, rf-mcp), 'playwright' (purple), 'robot' (yellow, the AI's Robot run)."""
    try:
        js = open(_INDICATOR_FILE, encoding="utf-8").read()
    except Exception:
        js = ""
    mode = mode if mode in MODES else "rf"
    t, k, m = json.dumps(str(text)[:90]), json.dumps(str(keyword or "")[:80]), json.dumps(mode)
    return ("window.__aiLabelText = %s; window.__aiKeywordText = %s; window.__aiMode = %s;\n"
            % (t, k, m)) + js + \
           "\ntry { window.__aiSetLabel && window.__aiSetLabel(%s, %s, %s) } catch (e) {}" % (t, k, m)


# Locator strength (section 4a of robot-script-generator.md)
GENERATED_ID = re.compile(
    r"(mui-\d+|:r[0-9a-z]+:|react-select-\d+|ember\d+|ext-gen\d+|ext-comp-\d+|jss\d+|"
    r"css-[a-z0-9]{5,}|makeStyles|ng-tns-|cdk-[a-z-]*\d+|mat-[a-z-]*-\d+|"
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}|j_idt\d+|\b\d{5,}\b)", re.I)
TEST_ID = re.compile(r"data-(testid|test-id|test|qa|cy|automation-id)", re.I)
STABLE_ATTR = re.compile(r"(^(id|name)[:=])|(\[@?(id|name)\s*=)|(^css[:=]\s*#[\w-]+$)|(^#[\w-]+$)", re.I)
FRAGILE = re.compile(r"(^(xpath[:=])?\s*/html|^(xpath[:=])?\s*/[a-z]|\[\d+\]|nth-child|nth-of-type|nth=\d|"
                     r"following::|preceding::|ancestor::\*|\(//.*\)\[\d+\])", re.I)


def rate_locator(locator):
    """Returns (rating, reason). Rating: Strong, Good, Weak or Rejected."""
    loc = str(locator or "").strip()
    if GENERATED_ID.search(loc):
        return "Rejected", "uses an auto-generated ID or class that changes between builds"
    if FRAGILE.search(loc):
        return "Weak", "depends on page structure or position; ask developers for a test ID"
    if TEST_ID.search(loc):
        return "Strong", "uses a dedicated test ID"
    if STABLE_ATTR.search(loc):
        return "Strong", "uses a stable id or name"
    return "Good", "anchored on a label, accessible name or visible text"


# ----------------------------------------------------------------------------- candidates from a saved screen
def _q(v):
    return "'" + v + "'" if "'" not in v else '"' + v + '"'


def candidates_for(c, library="SeleniumLibrary"):
    """Candidate locators for one control from controls.json, best first (section 4a order)."""
    sel = library != "Browser"
    pre = (lambda k: k + ":") if sel else (lambda k: k + "=")
    out = []
    tag, role = c.get("tag", ""), c.get("role", "")
    if c.get("testid"):
        attr = c.get("testattr") or "data-testid"
        out.append(f"{pre('css')}[{attr}={_q(c['testid'])}]" if sel else f'css=[{attr}="{c["testid"]}"]')
    if c.get("id") and not GENERATED_ID.search(c["id"]):
        out.append(f"{pre('id')}{c['id']}")
    if c.get("name") and not GENERATED_ID.search(c["name"]):
        out.append(f"{pre('name')}{c['name']}" if sel else f'css=[name="{c["name"]}"]')
    label = (c.get("label") or "").strip()
    text = (c.get("text") or "").strip()
    if label and tag in ("input", "select", "textarea") or (label and role in ("combobox", "textbox", "checkbox", "radio", "switch")):
        field = "input" if tag not in ("select", "textarea") else tag
        out.append(f"{pre('xpath')}//label[normalize-space()={_q(label)}]/..//{field}")
        out.append(f"{pre('css')}[aria-label={_q(label)}]" if sel else f'css=[aria-label="{label}"]')
    if c.get("placeholder"):
        out.append(f"{pre('css')}{tag or 'input'}[placeholder={_q(c['placeholder'])}]" if sel else f'css={tag or "input"}[placeholder="{c["placeholder"]}"]')
    if text and len(text) <= 40 and (tag in ("button", "a") or role in ("button", "tab", "link", "menuitem", "option")):
        t = "button" if tag == "button" or role == "button" else ("a" if tag == "a" else "*")
        r_ = f"[@role={_q(role)}]" if t == "*" and role else ""
        out.append(f"{pre('xpath')}//{t}{r_}[normalize-space()={_q(text)}]")
    seen, res = set(), []
    for loc in out:
        if loc not in seen:
            seen.add(loc)
            rating, why = rate_locator(loc)
            if rating != "Rejected":
                res.append((loc, rating))
    order = {"Strong": 0, "Good": 1, "Weak": 2}
    return sorted(res, key=lambda x: order[x[1]])


def suggest_from_controls(controls, words, library="SeleniumLibrary", per_word=3):
    """For each word or phrase of the test case: the best matching visible controls with ready,
    rated candidate locators. Pure function, so it is fast and testable."""
    def score(c, w):
        w = w.lower().strip()
        fields = [(c.get("label") or ""), (c.get("text") or ""), (c.get("placeholder") or ""), (c.get("testid") or ""),
                  (c.get("name") or ""), (c.get("id") or "")]
        best = 0
        for i, f in enumerate(fields):
            f = f.lower().strip()
            if not f:
                continue
            if f == w:
                best = max(best, 100 - i)
            elif w in f or f in w and len(f) > 3:
                best = max(best, 60 - i)
            elif all(x in re.sub(r"[-_]", " ", f) for x in w.split()):
                best = max(best, 40 - i)
        if best and not c.get("visible", True):
            best -= 30
        return best
    result = {}
    for w in words:
        ranked = sorted(((score(c, w), i, c) for i, c in enumerate(controls)), key=lambda x: (-x[0], x[1]))
        hits = [(sc, c) for sc, _, c in ranked if sc > 0][:per_word]
        result[w] = [{"control": {k: c.get(k) for k in ("tag", "role", "label", "text", "id", "name", "testid", "visible", "disabled") if c.get(k) not in (None, "")},
                      "match": sc, "candidates": candidates_for(c, library)} for sc, c in hits]
    return result


def parse_spec(spec):
    """'Keyword | arg | arg | proof=<locator>' or 'locator | frame=.. | action=.. | value=..' -> (head, args, options)."""
    parts = [p.replace("\\|", "|").strip() for p in re.split(r"\s\|\s(?![^\[]*\])", str(spec))]
    head, args, opts = parts[0], [], {}
    for p in parts[1:]:
        m = re.match(r"^(proof|frame|action|value|source|timeout)=(.*)$", p)
        if m:
            opts[m.group(1)] = m.group(2)
        else:
            args.append(p)
    return head, args, opts


# ----------------------------------------------------------------------------- door (TCP proxy)
class _Pipe(socketserver.BaseRequestHandler):
    def handle(self):
        door = self.server.door
        try:
            upstream = socket.create_connection(door.target, timeout=10)
        except OSError:
            return
        door._track(self.request, upstream)
        socks = [self.request, upstream]
        try:
            while not door.closed:
                r, _, _ = select.select(socks, [], [], 0.5)
                for s in r:
                    data = s.recv(65536)
                    if not data:
                        return
                    (upstream if s is self.request else self.request).sendall(data)
        except OSError:
            pass
        finally:
            for s in socks:
                try:
                    s.close()
                except OSError:
                    pass


class _Server(socketserver.ThreadingTCPServer):
    # On Windows SO_REUSEADDR lets two programs share a port; keep the door's port exclusive.
    allow_reuse_address = os.name != "nt"
    daemon_threads = True


class _Door:
    def __init__(self, port, target, timeout):
        self.target = target
        self.closed = False
        self._socks = []
        self._lock = threading.Lock()
        self.server = _Server((DOOR_HOST, port), _Pipe)
        self.server.door = self
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.timer = threading.Timer(timeout, self.close)
        self.timer.daemon = True
        self.timer.start()

    def _track(self, *socks):
        with self._lock:
            self._socks.extend(socks)

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            self.timer.cancel()
        except Exception:
            pass
        with self._lock:
            for s in self._socks:          # cut live connections immediately
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    s.close()
                except OSError:
                    pass
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass


# ----------------------------------------------------------------------------- library
class ai_session:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self, door_port=9222, door_timeout=1800, session_dir=SESSION_DIR):
        self.door_port = int(door_port)
        self.door_timeout = int(door_timeout)
        self.session_dir = session_dir
        self._door = None
        atexit.register(self._close_quietly)

    # -- helpers -------------------------------------------------------------------
    def _lib(self):
        """Returns ('SeleniumLibrary' | 'Browser', instance). When a suite imports both, the
        library that has an open browser wins. Works with library aliases."""
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        found = []
        try:
            all_libs = bi.get_library_instance(all=True)
        except Exception:
            all_libs = {}
        for alias, inst in all_libs.items():
            cls = type(inst).__name__
            mro = {c.__name__ for c in type(inst).__mro__}
            if "SeleniumLibrary" in mro or cls in ("Selenium2Library", "ExtendedSelenium2Library"):
                found.append(("SeleniumLibrary", inst, alias))     # Selenium2Library 3.x is SeleniumLibrary
            elif cls == "Browser":
                found.append((cls, inst, alias))
        if not found:
            raise RuntimeError("No SeleniumLibrary or Browser library is imported in this session.")
        if len(found) > 1:
            for cls, inst, alias in found:
                try:
                    if cls == "SeleniumLibrary":
                        inst.driver                       # raises when no browser is open
                        self._bname = alias
                        return cls, inst
                    if bi.run_keyword(f"{alias}.Get Browser Ids"):
                        self._bname = alias
                        return cls, inst
                except Exception:
                    continue
        cls, inst, alias = found[0]
        self._bname = alias
        return cls, inst

    def _bk(self, keyword, *args):
        """Run a Browser library keyword by its full name (avoids clashes with SeleniumLibrary
        keywords of the same name, e.g. Get Element Count)."""
        from robot.libraries.BuiltIn import BuiltIn
        return BuiltIn().run_keyword(f"{getattr(self, '_bname', 'Browser')}.{keyword}", *args)

    def _state(self, **kw):
        os.makedirs(self.session_dir, exist_ok=True)
        path = os.path.join(self.session_dir, "state.json")
        state = {}
        if os.path.exists(path):
            try:
                state = json.load(open(path, encoding="utf-8"))
            except Exception:
                state = {}
        state.update(kw)
        state["updated_at"] = datetime.now().isoformat(timespec="seconds")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1)
        return state

    def _close_quietly(self):
        try:
            if self._door:
                self._door.close()
        except Exception:
            pass

    def _selenium_frames(self, driver, depth=0, path=()):
        """Yield (path, page_source) for every frame, max 3 levels deep."""
        from selenium.webdriver.common.by import By
        out = []
        if depth > 3:
            return out
        frames = driver.find_elements(By.CSS_SELECTOR, "iframe,frame")
        for i, fr in enumerate(frames):
            ident = fr.get_attribute("id") or fr.get_attribute("name") or f"index{i}"
            try:
                driver.switch_to.frame(fr)
                out.append((path + (ident,), driver.page_source))
                out.extend(self._selenium_frames(driver, depth + 1, path + (ident,)))
            except Exception:
                pass
            finally:
                driver.switch_to.default_content()
                for p in path:                       # re-enter the parent chain
                    try:
                        driver.switch_to.frame(p if not p.startswith("index") else int(p[5:]))
                    except Exception:
                        break
        return out

    # -- keywords ------------------------------------------------------------------
    def ai_set_label(self, text, keyword="", mode="rf"):
        """Show the AI badge (drawing it if missing). Line 1 is plain English
        ("AI assistant is logging in"), line 2 shows "Keyword: <name>" (hidden when empty).
        mode: rf (blue, default), playwright (purple), robot (yellow). Step names only, never data."""
        try:
            kind, lib = self._lib()
            script = _badge_script(text, keyword, mode)
            if kind == "SeleniumLibrary":
                lib.driver.switch_to.default_content()
                lib.driver.execute_script(script)
            else:
                self._bk("Evaluate JavaScript", None, "() => {" + script + "}")
        except Exception:
            pass

    def ai_save_screen(self, name="screen"):
        """Save page source, every frame's source, a controls list and a screenshot.

        Returns the folder path. Files: page.html, frames/<path>.html, frames.json,
        controls.json (main page), screenshot.png.
        """
        kind, lib = self._lib()
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        folder = os.path.join(self.session_dir, "screens", f"{stamp}-{re.sub(r'[^\w-]', '_', name)}")
        os.makedirs(os.path.join(folder, "frames"), exist_ok=True)
        frame_map = []
        if kind == "SeleniumLibrary":
            d = lib.driver
            d.switch_to.default_content()
            open(os.path.join(folder, "page.html"), "w", encoding="utf-8").write(d.page_source)
            try:
                open(os.path.join(folder, "controls.json"), "w", encoding="utf-8").write(
                    d.execute_script(CONTROLS_JS) or "[]")
            except Exception:
                pass
            for path, src in self._selenium_frames(d):
                fn = "__".join(path) + ".html"
                open(os.path.join(folder, "frames", fn), "w", encoding="utf-8").write(src)
                frame_map.append({"frame_path": list(path), "file": "frames/" + fn})
            d.switch_to.default_content()
            try:
                d.save_screenshot(os.path.join(folder, "screenshot.png"))
            except Exception:
                pass
            url = d.current_url
        else:
            open(os.path.join(folder, "page.html"), "w", encoding="utf-8").write(
                self._bk("Get Page Source"))
            try:
                open(os.path.join(folder, "controls.json"), "w", encoding="utf-8").write(
                    self._bk("Evaluate JavaScript", None, "() => {" + CONTROLS_JS + "}") or "[]")
            except Exception:
                pass
            try:
                count = int(self._bk("Get Element Count", "css=iframe, frame"))
            except Exception:
                count = 0
            for i in range(min(count, 20)):
                fsel = f"css=iframe, frame >> nth={i}"
                try:
                    ident = (self._bk("Get Attribute", fsel, "id") or
                             self._bk("Get Attribute", fsel, "name") or f"index{i}")
                except Exception:
                    ident = f"index{i}"
                try:
                    src = self._bk("Evaluate JavaScript", f"{fsel} >>> css=html", "(e) => e.outerHTML")
                    fn = re.sub(r"[^\w-]", "_", str(ident)) + ".html"
                    open(os.path.join(folder, "frames", fn), "w", encoding="utf-8").write(src or "")
                    frame_map.append({"frame_path": [str(ident)], "frame_selector": fsel,
                                      "file": "frames/" + fn})
                except Exception:
                    pass
            try:
                self._bk("Take Screenshot", "filename=" + os.path.abspath(os.path.join(folder, "screenshot")))
            except Exception:
                pass
            url = self._bk("Get Url")
        json.dump(frame_map, open(os.path.join(folder, "frames.json"), "w"), indent=1)
        self._state(last_screen=folder, url_host=re.sub(r"^(\w+://[^/]+).*", r"\1", url or ""))
        return folder

    def ai_open_door(self, label="AI assistant is reviewing this page (nothing will be saved)"):
        """Save the screen, then open the local door to this browser. Returns the door URL.

        Does not block: rf-mcp keeps control, Playwright MCP (playwright-attach) can join.
        SeleniumLibrary with Chrome or Edge. With the Browser library (or another browser) it saves
        the screen and returns NONE; then use AI Share Login and the playwright-session MCP entry.
        """
        folder = self.ai_save_screen("door")
        self.ai_set_label(label, "", "playwright")
        kind, lib = self._lib()
        if kind != "SeleniumLibrary":
            self._state(door="unavailable (the Browser library starts its own browser; use AI Share Login)",
                        door_open=False, in_control="ai")
            return "NONE"
        caps = lib.driver.capabilities or {}
        dbg = None
        for key, val in caps.items():
            if isinstance(val, dict) and "debuggerAddress" in val:
                dbg = val["debuggerAddress"]
        if not dbg:
            self._state(door="unavailable (no debug address: the browser is not Chrome or Edge; use AI Share Login)",
                        door_open=False, in_control="ai")
            return "NONE"
        host, port = dbg.rsplit(":", 1)
        host = "127.0.0.1" if host in ("localhost", "127.0.0.1", "") else host
        if self._door and not self._door.closed:
            self._door.close()
        try:
            self._door = _Door(self.door_port, (host, int(port)), self.door_timeout)
        except OSError:
            self._door = None
            self._state(door=f"unavailable (port {self.door_port} is busy; change door_port)",
                        door_open=False, in_control="ai")
            return "NONE"
        url = f"http://{DOOR_HOST}:{self.door_port}"
        # Prove the door reaches this browser before anyone attaches to it.
        try:
            import urllib.request
            direct = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # never via a proxy
            with direct.open(url + "/json/version", timeout=5) as r:
                ok = "Browser" in json.loads(r.read().decode("utf-8", "replace"))
        except Exception:
            ok = False
        if not ok:
            self._door.close()
            self._state(door="unavailable (the browser did not answer through the door)",
                        door_open=False, in_control="ai")
            return "NONE"
        d = lib.driver
        # What Playwright must see after attaching (same-page check, section 5 Stage 3).
        self._state(door=url, door_open=True, in_control="playwright", screen=folder,
                    door_closes_after_s=self.door_timeout, page_title=d.title or "",
                    page_url=d.current_url or "", open_tabs=len(d.window_handles))
        return url

    def ai_close_door(self, label="AI assistant is continuing with the existing steps"):
        """Close the door now and cut any Playwright connection."""
        if self._door:
            self._door.close()
        self._state(door_open=False, in_control="rf-mcp")
        self.ai_set_label(label, "", "rf")

    def ai_checkpoint(self, timeout=600, name="checkpoint"):
        """For a normal Robot run (fallback level 3): open the door and pause until the AI
        creates qa-ai-skills/session/continue, or until `timeout` seconds pass. Then close the door."""
        flag = os.path.join(self.session_dir, "continue")
        if os.path.exists(flag):
            os.remove(flag)
        door = self.ai_open_door()
        shared = None
        if door == "NONE":
            try:
                shared = self.ai_share_login()
            except Exception:
                shared = None
        self._state(paused=True, checkpoint=name, door=door, login_shared=shared,
                    resume_by=f"create the file {flag}")
        end = time.time() + int(timeout)
        while time.time() < end and not os.path.exists(flag):
            time.sleep(1)
        self.ai_close_door()
        resumed = os.path.exists(flag)
        if resumed:
            os.remove(flag)
        self._state(paused=False, resumed_by="signal" if resumed else "timeout")
        return "continued" if resumed else "timeout"

    def ai_run_step(self, keyword, *args):
        """Run an existing keyword exactly as given (rf-mcp sessions), with the badge.

        Line 1 is plain English derived from the keyword name, line 2 shows the keyword.
        The badge is drawn before the step and again after it, because page loads remove it.
        Duration is appended to qa-ai-skills/session/timing.json for the speed suggestions.
        Returns the keyword's return value. Failures are re-raised unchanged.
        """
        from robot.libraries.BuiltIn import BuiltIn
        line1, line2 = "AI assistant is running a test step", keyword
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "ai_activity_indicator", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                      "ai_activity_indicator.py"))
            ind = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(ind)
            if "${" not in keyword:
                line1, line2 = ind.friendly_label(keyword)
        except Exception:
            pass
        self.ai_set_label(line1, line2, "rf")
        start = time.time()
        status = "PASS"
        try:
            return BuiltIn().run_keyword(keyword, *args)
        except Exception:
            status = "FAIL"
            raise
        finally:
            secs = round(time.time() - start, 2)
            try:
                os.makedirs(self.session_dir, exist_ok=True)
                path = os.path.join(self.session_dir, "timing.json")
                rows = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []
                rows.append({"keyword": keyword, "seconds": secs, "status": status})
                json.dump(rows, open(path, "w", encoding="utf-8"), indent=1)
            except Exception:
                pass
            self.ai_set_label(line1, line2, "rf")

    def ai_share_login(self, path=None):
        """Save this browser's login state (cookies and local storage of the current site) to
        qa-ai-skills/session/storage-state.json in Playwright's format, plus the page URL and title, so the
        `playwright-session` MCP entry can open the same page, already logged in, in its own
        window. Returns the file path. Contains session cookies: local only, deleted at the end.
        Sign-ins that keep the session only in sessionStorage cannot be shared this way; the
        same-page check then fails and the generator reads the saved screen instead."""
        kind, lib = self._lib()
        os.makedirs(self.session_dir, exist_ok=True)
        target = os.path.abspath(path or os.path.join(self.session_dir, "storage-state.json"))
        if kind == "SeleniumLibrary":
            d = lib.driver
            d.switch_to.default_content()
            cookies = []
            for c in d.get_cookies():
                same = str(c.get("sameSite") or "Lax").capitalize()
                cookies.append({"name": c.get("name"), "value": c.get("value"),
                                "domain": c.get("domain") or "", "path": c.get("path") or "/",
                                "expires": c.get("expiry", -1), "httpOnly": bool(c.get("httpOnly")),
                                "secure": bool(c.get("secure")),
                                "sameSite": same if same in ("Strict", "Lax", "None") else "Lax"})
            origin = d.execute_script("return location.origin")
            items = d.execute_script("return Object.entries(window.localStorage || {})") or []
            state = {"cookies": cookies,
                     "origins": [{"origin": origin,
                                  "localStorage": [{"name": k, "value": v} for k, v in items]}]}
            with open(target, "w", encoding="utf-8") as f:
                json.dump(state, f)
            title, url = d.title or "", d.current_url or ""
        else:
            import shutil
            saved = self._bk("Save Storage State")
            if os.path.abspath(saved) != target:
                shutil.copyfile(saved, target)
            title, url = self._bk("Get Title") or "", self._bk("Get Url") or ""
        self._state(login_shared=target, page_title=title, page_url=url)
        return target

    def ai_check_variables(self, *names):
        """Start-up check. For each variable name (e.g. ${URL}, ${DB_HOST}) report OK, EMPTY or
        MISSING. Never returns or logs values. Fails listing the problems, so the AI can stop
        and tell the user before any test step runs."""
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        result, problems = {}, []
        for n in names:
            name = n if n.startswith(("${", "@{", "&{")) else "${%s}" % n
            try:
                val = bi.get_variable_value(name)
            except Exception:
                val = None
            state = "MISSING" if val is None else ("EMPTY" if str(val).strip() == "" else "OK")
            result[name] = state
            if state != "OK":
                problems.append(f"{name} {state}")
        self._state(variables_check=result)
        if problems:
            raise AssertionError("Start-up check failed: " + ", ".join(problems))
        return result

    def ai_run_steps(self, *steps):
        """Run the known route in ONE call. Each step: 'Keyword | arg | arg' with an optional
        '| proof=<locator>' that must be visible after the step (the screen it should reach).
        Each step shows the badge, is timed (session/timing.json) and is checked for a native
        alert. Stops at the first failure and raises with the steps done so far, so nothing is
        guessed. Returns one line per step: 'PASS 4.2s Login To Portal (proof visible)'."""
        from robot.libraries.BuiltIn import BuiltIn
        report = []
        for spec in steps:
            kw, args, opts = parse_spec(spec)
            t0 = time.time()
            try:
                self.ai_run_step(kw, *args)
                note = ""
                if opts.get("proof"):
                    kind, lib = self._lib()
                    timeout = opts.get("timeout") or "30s"
                    if kind == "SeleniumLibrary":
                        BuiltIn().run_keyword("SeleniumLibrary.Wait Until Element Is Visible", opts["proof"], timeout)
                    else:
                        self._bk("Wait For Elements State", opts["proof"], "visible", timeout)
                    note = " (proof visible)"
                alert = self._alert_text()
                if alert:
                    raise AssertionError(f"an unexpected browser alert is open: {alert[:120]}")
                report.append(f"PASS {time.time() - t0:.1f}s {kw}{note}")
            except Exception as e:
                report.append(f"FAIL {time.time() - t0:.1f}s {kw}: {str(e).splitlines()[0][:200]}")
                raise AssertionError("Stopped at the first failing step:\n" + "\n".join(report))
        return "\n".join(report)

    def _alert_text(self):
        try:
            kind, lib = self._lib()
            if kind == "SeleniumLibrary":
                return lib.driver.switch_to.alert.text
        except Exception:
            return ""
        return ""

    def ai_check_locators(self, *specs, source="screen"):
        """The judge for many candidates in ONE call. Each spec: 'locator' or
        'locator | frame=<frames> | action=<click|check|uncheck|type|select> | value=<v>'.
        `source` says where the candidates came from: dev (the development code), screen (the
        saved screen's controls), playwright (Playwright's view), team (an existing locator).
        Never fails: returns one line per candidate 'OK Strong <locator>' or 'NO <reason> <locator>',
        and records each with its source in session/proven.json for the summary."""
        label = {"dev": "AI assistant is checking locators from the development code",
                 "playwright": "AI assistant is checking the locators Playwright found",
                 "team": "AI assistant is checking existing locators"}.get(source, "AI assistant is checking locators found on this screen")
        self.ai_set_label(label, f"{len(specs)} to check", "rf")
        lines = []
        for spec in specs:
            loc, _, opts = parse_spec(spec)
            try:
                res = self.ai_check_locator(loc, frame=opts.get("frame"), action=opts.get("action"), value=opts.get("value"))
                lines.append(f"OK {res['rating']} {loc}")
                self._mark_source(loc, source, True)
            except Exception as e:
                lines.append(f"NO {str(e).splitlines()[0][:120]} | {loc}")
                self._mark_source(loc, source, False)
        self.ai_set_label(label, f"{sum(1 for l in lines if l.startswith('OK'))} of {len(specs)} proven", "rf")
        return "\n".join(lines)

    def _mark_source(self, locator, source, ok):
        path = os.path.join(self.session_dir, "proven.json")
        try:
            rows = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []
        except Exception:
            rows = []
        for r in reversed(rows):
            if r.get("locator") == locator and "source" not in r:
                r["source"], r["ok"] = source, ok
                break
        else:
            rows.append({"locator": locator, "source": source, "ok": ok, "at": datetime.now().isoformat(timespec="seconds")})
        os.makedirs(self.session_dir, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=1)

    def ai_suggest_locators(self, *words, screen=None):
        """Candidate locators for the test case's words (field labels, button texts), built from
        the controls list of the last saved screen (or `screen`), in this suite's library syntax,
        best first and rated. Read this instead of the page source. Then prove the candidates
        with AI Check Locators (source=screen)."""
        folder = screen or json.load(open(os.path.join(self.session_dir, "state.json"), encoding="utf-8")).get("last_screen")
        controls = json.load(open(os.path.join(folder, "controls.json"), encoding="utf-8"))
        kind, _ = self._lib()
        res = suggest_from_controls(controls, list(words), kind)
        lines = []
        for w, hits in res.items():
            if not hits:
                lines.append(f"{w}: no matching control on this screen (inspect with Playwright)")
            for h in hits:
                c = h["control"]
                what = f"{c.get('tag', '')}{'/' + c['role'] if c.get('role') else ''} \"{c.get('label') or c.get('text') or c.get('name') or c.get('id') or ''}\""
                lines.append(f"{w}: {what}{' (hidden)' if not c.get('visible', True) else ''} -> " +
                             " || ".join(f"{loc} [{rating}]" for loc, rating in h["candidates"][:3]))
        return "\n".join(lines)

    def ai_check_locator(self, locator, frame=None, action=None, value=None):
        """The judge. Proves `locator`, written in the suite's own library syntax:

        - exactly one element matches, and it is visible
        - if `action` is given (click | check | uncheck | type | select), performing it
          changes the state as expected (type/select need `value`)

        `frame`: SeleniumLibrary - a frame locator, or several joined by ' >> ' for nested
        frames; Browser library - the frame selector(s) joined by ' >>> '.
        It also rates the locator (Strong / Good / Weak) and fails on auto-generated IDs or
        classes (e.g. mui-123, :r5:, css-1x2y3z), which change between builds.
        Always returns to the main page. Fails with a clear message otherwise.
        Never use it on Save/Submit/Delete buttons.
        """
        rating, reason = rate_locator(locator)
        if rating == "Rejected":
            raise AssertionError(f"Locator rejected: {reason}: {locator}")
        self.ai_set_label("AI assistant is checking a new field", "", "rf")
        kind, lib = self._lib()
        if kind == "SeleniumLibrary":
            result = self._check_selenium(lib, locator, frame, action, value)
        else:
            result = self._check_browser(locator, frame, action, value)
        result.update({"rating": rating, "rating_reason": reason, "library": kind})
        os.makedirs(self.session_dir, exist_ok=True)
        cands = os.path.join(self.session_dir, "proven.json")
        proven = []
        if os.path.exists(cands):
            try:
                proven = json.load(open(cands, encoding="utf-8"))
            except Exception:
                proven = []
        proven.append({"locator": locator, "frame": frame, "action": action, "library": kind,
                       "rating": rating, "rating_reason": reason,
                       "at": datetime.now().isoformat(timespec="seconds")})
        json.dump(proven, open(cands, "w", encoding="utf-8"), indent=1)
        return result

    @staticmethod
    def _one_visible(total, visible, locator):
        if total == 0:
            raise AssertionError(f"Locator matched 0 elements: {locator}")
        if visible != 1:
            raise AssertionError(f"Locator must match exactly 1 visible element, matched "
                                 f"{visible} visible of {total}: {locator}")

    def _check_selenium(self, lib, locator, frame, action, value):
        lib.unselect_frame()
        try:
            if frame:
                for f in str(frame).split(" >> "):
                    lib.select_frame(f.strip())
            els = lib.find_elements(locator)
            visible = [e for e in els if e.is_displayed()]
            self._one_visible(len(els), len(visible), locator)
            el = visible[0]
            d = lib.driver
            result = {"tag": el.tag_name, "enabled": el.is_enabled()}
            if action:
                a = action.lower()
                if a in ("check", "uncheck"):
                    want = a == "check"
                    if bool(d.execute_script(CHECKED_JS, el)) != want:
                        el.click()
                    if bool(d.execute_script(CHECKED_JS, el)) != want:
                        raise AssertionError(f"'{a}' did not change the state of {locator}")
                elif a == "click":
                    el.click()
                elif a == "type":
                    el.clear()
                    el.send_keys(value or "")
                    if (el.get_attribute("value") or "") != (value or ""):
                        raise AssertionError(f"Typed value did not stick in {locator}")
                elif a == "select":
                    from selenium.webdriver.support.select import Select
                    if el.tag_name.lower() != "select":
                        raise AssertionError("'select' works on native <select> lists only; for a "
                                             "custom dropdown check the opener with action=click, "
                                             "then the option locator with action=click")
                    Select(el).select_by_visible_text(value)
                    if Select(el).first_selected_option.text.strip() != str(value).strip():
                        raise AssertionError(f"Option '{value}' was not selected in {locator}")
                else:
                    raise ValueError(f"Unknown action: {action}")
                result["action"] = a
            return result
        finally:
            lib.unselect_frame()

    def _check_browser(self, locator, frame, action, value):
        sel = f"{frame} >>> {locator}" if frame else locator
        total = int(self._bk("Get Element Count", sel))
        elements = self._bk("Get Elements", sel) if total else []
        visible = []
        for e in elements:
            try:
                states = [str(x).lower() for x in (self._bk("Get Element States", e) or [])]
            except Exception:
                states = []
            if "visible" in states:
                visible.append((e, states))
        self._one_visible(total, len(visible), locator)
        el, states = visible[0]
        result = {"enabled": "enabled" in states}
        if action:
            a = action.lower()
            if a in ("check", "uncheck"):
                self._bk("Check Checkbox" if a == "check" else "Uncheck Checkbox", el)
                if bool(self._bk("Get Checkbox State", el)) != (a == "check"):
                    raise AssertionError(f"'{a}' did not change the state of {locator}")
            elif a == "click":
                self._bk("Click", el)
            elif a == "type":
                self._bk("Fill Text", el, value or "")
                if str(self._bk("Get Property", el, "value") or "") != (value or ""):
                    raise AssertionError(f"Typed value did not stick in {locator}")
            elif a == "select":
                self._bk("Select Options By", el, "text", value)
                got = self._bk("Get Selected Options", el, "text")
                got = got if isinstance(got, (list, tuple)) else [got]
                if str(value).strip() not in [str(g).strip() for g in got]:
                    raise AssertionError(f"Option '{value}' was not selected in {locator}")
            else:
                raise ValueError(f"Unknown action: {action}")
            result["action"] = a
        return result


def _self_test():
    ok = {}
    controls = [
        {"tag": "input", "type": "text", "id": "mui-123", "name": "", "testid": "", "label": "Display name", "text": "", "placeholder": "", "visible": True},
        {"tag": "button", "id": "", "name": "", "testid": "save-btn", "testattr": "data-testid", "label": "", "text": "Save", "visible": True},
        {"tag": "select", "id": "addressType", "name": "addressType", "testid": "", "label": "Address type", "text": "", "visible": True},
        {"tag": "a", "role": "tab", "id": "", "testid": "", "label": "", "text": "Addresses", "visible": True},
        {"tag": "button", "id": "", "testid": "", "label": "", "text": "Save", "visible": False},
    ]
    r = suggest_from_controls(controls, ["Display name", "Save", "Address type", "Addresses", "Audit"], "SeleniumLibrary")
    ok["label-based locator for a field whose id is generated (mui-123 rejected)"] = \
        r["Display name"][0]["candidates"][0][0] == "xpath://label[normalize-space()='Display name']/..//input" and \
        not any("mui-123" in c for h in r["Display name"] for c, _ in h["candidates"])
    ok["test ID first, rated Strong; the visible button ranked above the hidden one"] = \
        r["Save"][0]["candidates"][0] == ("css:[data-testid='save-btn']", "Strong") and r["Save"][0]["control"]["visible"] is True
    ok["stable id and name for a native select"] = r["Address type"][0]["candidates"][0] == ("id:addressType", "Strong")
    ok["tab found by its text"] = any(c.startswith("xpath://a[normalize-space()='Addresses']") for c, _ in r["Addresses"][0]["candidates"])
    ok["no match is reported, not guessed"] = r["Audit"] == []
    rb = suggest_from_controls(controls, ["Save"], "Browser")
    ok["Browser library syntax"] = rb["Save"][0]["candidates"][0][0] == 'css=[data-testid="save-btn"]'
    ok["step specs: keyword, arguments and proof element"] = parse_spec("Open Client | ${CLIENT} | proof=css:[data-testid='client-header']") == \
        ("Open Client", ["${CLIENT}"], {"proof": "css:[data-testid='client-header']"})
    ok["locator specs: frame, action, value"] = parse_spec("id:x | frame=id:main >> id:inner | action=type | value=abc") == \
        ("id:x", [], {"frame": "id:main >> id:inner", "action": "type", "value": "abc"})
    width = max(len(k) for k in ok)
    print()
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


if __name__ == "__main__":
    import sys
    sys.exit(_self_test() if sys.argv[1:2] == ["--self-test"] else 0)
