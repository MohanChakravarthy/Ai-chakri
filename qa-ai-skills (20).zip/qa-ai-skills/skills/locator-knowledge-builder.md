---
name: locator-knowledge-builder
description: Builds or incrementally refreshes the locator knowledge base of a Robot Framework QA automation repository. Catalogues every locator (variables, locator files, inline locators in keywords and tests), normalises their strategy and syntax for Browser (Playwright) or SeleniumLibrary, rates their stability, and links each to the screen IDs from app-knowledge-builder and the keyword IDs from keyword-knowledge-builder, so robot-script-generator can reuse existing locators and add new ones in the right place and style. Use when asked to build, refresh or rebuild locator knowledge.
version: 0.1.0
---

# Locator Knowledge Builder

## 1. Purpose and principles
Give robot-script-generator a reliable answer to: "Is there already a locator for this element on this screen, what is its exact variable name and syntax, how stable is it, and where should a new locator go?"

- **Evidence only.** Every entry comes from a real definition in the repo, with file and line.
- **Read-only on the codebase.** Never modify, move, format or delete repo files. Write only inside `qa-ai-skills/knowledge/`.
- **Static analysis only.** Do not open a browser or call Playwright MCP in this skill; live verification belongs to robot-script-generator.
- **Linked by IDs.** Use screen IDs from `qa-ai-skills/knowledge/app-knowledge.md` and keyword IDs from `qa-ai-skills/knowledge/keyword-knowledge.md` exactly. Never invent screen or keyword IDs.
- **Stable IDs, deterministic output.** Sort by locator ID; use the templates below.
- **No secrets or personal data.** Locators containing real customer names, emails or IDs are recorded with the value masked and flagged.

## 2. Prerequisites and inputs
**Primary source of facts: `qa-ai-skills/knowledge/.extract/locators.json`** (variable and inline locators with exact value, file, line and used_by) plus `variables.json` and `summary.json` (duplicates, library per file). Copy values exactly; never re-collect them from raw files. If `.extract/` is missing or stale, run the extractor (`extract_repo.py` found under `qa-ai-skills/skills/`) first. The extractor's locator detection is heuristic: also review variables in `variables.json` whose names or values look like selectors but were not flagged, and add them. Your job here is meaning: element type, business meaning, screen links, stability rating and conventions.

- `qa-ai-skills/knowledge/app-knowledge.md` and `qa-ai-skills/knowledge/keyword-knowledge.md` must exist. If either is missing, stop and ask the user to run the earlier builders first.
- `qa-ai-skills/knowledge/config.yaml` (optional): same paths and excludes as the other builders; optional `locator_paths`.
- Sources: `*** Variables ***` sections, variable files (`.py`, `.yaml`, `.json`), dedicated locator or page-object files, `.resource` files, and inline locators inside keywords and tests.

## 3. Outputs
**The locator knowledge is rendered by a script, completely.** `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py render locator` writes every locator from the extract: ID, variable, file and line, element type, meaning (from the variable name), strategy and selector, dynamic placeholders, frame, stability with its reason (section 5), users, status, the screen (through the keywords that use it and their screens in the keyword meaning), duplicates, conflicts, brittle locators, where new locators go, and the development-code suggestions. Your only part: `knowledge_build.py worksheet locator <MODULE>` lists the variables whose name says nothing about the element (for example `${LOC_7}`); add one line each to `qa-ai-skills/knowledge/meaning/locator/names.md`: `${LOC_7} | link | First client in the search results`. Locators reach the right screen through the keyword meaning, so write that first (keyword-knowledge-builder). Never write or edit the rendered files by hand; hand-written `## Notes` sections are kept.
```
qa-ai-skills/knowledge/
  locator-knowledge.md          # index, conventions, registry
  locators/
    SCREEN-<...>.md             # locators grouped by screen
    UNMAPPED.md                 # locators not yet tied to a screen
  locator-knowledge.log.md      # run history (append-only)
```

## 4. Procedure

### Step 1: Pre-flight
- Capture `git rev-parse HEAD` and branch; warn about uncommitted changes to locator or resource files.
- Load the screen registry from app knowledge and the keyword registry from keyword knowledge.
- Inventory: count locator variables, locator files, inline locators. Show the inventory before heavy processing.

### Step 2: Full or incremental
The plan from `split_extract.py` decides (qa-knowledge-setup step 1): build the modules in this stage's `changed` list, keep `unchanged` ones. For `rebuild`, every module is in `changed`. Modules listed in `not_in_this_extract` are outside this run's scope: never delete or change their files. A module's locators may go into several screen files; report every screen file written, so the module can be recorded with them.

### Step 3: Detect conventions (write to the index)
- Automation library per file: Browser or SeleniumLibrary, and per suite from `summary.json` `suite_libraries` (a suite can get its library through a shared resource; "mixed" means both).
- Where locators live: variables sections, separate locator files per page, page objects, or inline.
- Naming style of locator variables (e.g. `${ADDRESS_TYPE_DROPDOWN}`, `${btn_save}`), and any prefixes or suffixes for element type.
- Preferred strategies actually used (e.g. `id=`, `css=`, `xpath=`, `text=`, `data-testid`, Selenium `id:` / `xpath:` / `css:`).
- Dynamic locator patterns: templated variables (`${ROW_BY_NAME}` with `{name}` placeholders), `Replace String`, `Format String`, embedded arguments.
- Frame, iframe and shadow DOM handling patterns (`>>>`, `Select Frame`, `id=frame >>> css=...`).

### Step 4: What the script renders (never write it by hand)
`knowledge_build.py render locator` writes, for every locator of the extract: the locator ID `LOC-<SCREEN or COMMON>-<NAME>`, the variable (or `inline`), file and line; the strategy and normalised selector; the element type and meaning (from the variable name, or your `names.md` line); dynamic placeholders; the frame part; the users and the status; the stability rating with its reason (section 5); and the screen, reached through the keywords that use it and their screens (most-used screen first, the others listed; none: `UNMAPPED.md`). Your input is only `meaning/locator/names.md`, for the names the worksheet lists.

### Step 5: Quality issues (rendered; you add only what needs the development code)
The script reports duplicates (with the preferred one), conflicts, brittle locators, inline locators and the team locators listed in `missing_in_dev` (`possibly stale - check live`). **With development knowledge** (`qa-ai-skills/knowledge/dev/dev-qa-links.md` exists), add one line per suggestion to `qa-ai-skills/knowledge/meaning/locator/dev-suggestions.md`, built from the element's test ID, then stable id or name, then label:
```
${OLD_SAVE_BTN} | fix | css:[data-testid='address-save'] | the old id is not in the development code; dev-qa-links names this button
${ADDRESS_TYPE_XPATH} | stronger | id:addressType | weak XPath; the development code gives the select a stable id
```
`fix` for a possibly stale locator with a likely replacement; `stronger` for a weak team locator whose element has a test ID or stable id. They are rendered under "Suggested fixes from the development code (not applied)" in the screen file and counted in the index. Never change the team's files.

### Step 6: Self-validate
Run `knowledge_build.py render locator`, then `knowledge_build.py check`; fix what they list. Never write helper scripts.
- Locator IDs unique; file paths and lines exist.
- Every screen and keyword ID used exists in the other knowledge files.
- Counts in the index match the screen files.
- No unmasked personal data or secrets.

### Step 7: Report
Run type, locators catalogued, mapped vs unmapped, stability breakdown, duplicates, conflicts, brittle locators, output paths. Do not commit.

## 5. Stability rating
- **High:** dedicated test attributes (`data-testid`, `data-qa`), stable unique `id`, ARIA role + accessible name.
- **Medium:** semantic CSS, short relative XPath anchored on stable attributes or labels, exact visible text of stable labels.
- **Low:** absolute XPath, index or position based, generated classes or IDs, long or translated text.
The generator prefers High, then Medium; Low locators are reused only if no alternative exists, and flagged.
These match the ratings the generator gives new locators: High = Strong, Medium = Good, Low = Weak. Auto-generated IDs and classes (e.g. `mui-123`, `:r5:`, `react-select-3-input`, `css-1x2y3z`, `j_idt42`) are always Low and listed under "brittle locators" in the report, so the team can ask developers for test IDs.

## 6. ID rules
- `LOC-<SCREEN-SHORT>-<NAME>` or `LOC-COMMON-<NAME>`, uppercase, hyphenated, unique; made by the script from the screen and the variable name. The variable name is the lasting reference (generated tests and the generator use variables, never locator IDs).

## 7. Templates

### Screen file: `qa-ai-skills/knowledge/locators/SCREEN-<...>.md`
```
# Locators: <Screen name> (SCREEN-<...>)
Last updated: <ISO date> | Commit: <hash>
Defined in: <main locator file for this screen>

| Locator ID | Variable | Element | Meaning | Strategy | Selector | Dynamic | Stability | Used by | Status |

## Details (only for dynamic, framed, duplicate or low-stability locators)
### LOC-<...>
- File: <path>:<line>
- Placeholders: {name} filled by <keyword ID>
- Frame: <frame locator>
- Duplicate of: LOC-<...> (preferred: yes|no)
- Stability reason: <why>

## Where new locators for this screen go
<file path and section, following the repo convention>

## Suggested fixes from the development code (not applied)
<only when development knowledge exists: variable | current value | why | suggested locator | dev source file:line>
```

### Index file: `qa-ai-skills/knowledge/locator-knowledge.md`
```
# Locator Knowledge: <project_name>

## Metadata
- schema_version: 1
- generated_at / last_commit / branch
- linked_app_commit / linked_keyword_commit

## Conventions
- Library, locator storage layout, naming style (with a real example)
- Strategies in use and the preferred order for new locators
- Dynamic locator pattern (with a real example)
- Frame / shadow DOM pattern

## Screen coverage
| Screen ID | Locators | High | Medium | Low | File |

## Quality findings
- Duplicates, conflicts, brittle locators, inline locators, unmapped count
```

## 8. Error handling
- Unparseable file: skip, log, continue.
- Locator built at runtime that cannot be resolved statically: record its pattern and the keyword that builds it, mark `Dynamic: yes (runtime)`.
- Ambiguous screen mapping: link the primary screen, list the others.
- Large files: process in sections; never skim.

## 9. Example requests
- "@locator-knowledge-builder build the locator knowledge for this repo."
- "@locator-knowledge-builder refresh locator knowledge since the last run."
- "@locator-knowledge-builder rebuild locator knowledge for the Addresses screen only."
