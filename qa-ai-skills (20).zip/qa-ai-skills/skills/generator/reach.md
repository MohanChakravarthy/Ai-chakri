# Robot Script Generator - Reaching the screen (sections 4, 5a, 12; Stage 2)
Part of robot-script-generator.md: its rules (section 1) and fast path (section 1a) always apply. Section numbers are the same as in the full skill.

## 4. Roles and tools (one job per part)
The tools never talk to each other directly. You (the agent following this skill) are the hub. They share three things: you, one live browser, and the session folder `qa-ai-skills/session/` (`state.json` records who is in control, the screen, the frame and the door; `candidates.json` holds candidate locators; `proven.json` the judged ones).

| Part | Role | Job | Never |
|---|---|---|---|
| You, the agent | Hub | Plan, decide, pass control, write, report | Write a locator that was not proven |
| rf-mcp (Robot Framework MCP) | Hands | Run known steps live with the repo's real keywords (run configuration, vault, frames, login, navigation) to reach the screen; run the judge | Run setup or login twice in one session; read new screens when Playwright is available |
| Playwright MCP | Eyes | Read new screens only, when the development code and the screen's controls could not prove an element (section 1a step 4): on the live page through the door, or on a mock screen | Run known steps, navigate away, save data |
| `AI Check Locators` / `AI Check Locator` (in `qa-ai-skills/skills/ai_session.py`) | Judge | Prove each new locator (many in one call): exactly one visible match, right frame, the action really changes state; rate it, reject generated IDs, record its source | Be skipped |
| Normal `robot` run | Proof | The only source of PASS | Be replaced by a session result |

**Helper library `ai_session.py`** (find it by name under `qa-ai-skills/skills/`; import it only in rf-mcp sessions and the AI's helper files (`_reach_<id>.robot`, `_check_<id>.robot` for locator checks); never in the generated test, team files or CI): `AI Save Screen` (main page, every frame, a controls list, a screenshot into `qa-ai-skills/session/screens/`), `AI Open Door` (save the screen and open a local door at `http://127.0.0.1:9222` to the same browser; does not block), `AI Close Door`, `AI Checkpoint` (for a normal Robot run: open the door and pause until `qa-ai-skills/session/continue` exists or a time limit), `AI Run Steps` (the known route in one call, section 1a), `AI Check Locators` (many candidates in one call, with their source), `AI Suggest Locators` (rated candidates from the saved screen's controls), `AI Check Locator`, `AI Set Label`, `AI Run Step`, `AI Check Variables`, `AI Share Login`. Every keyword works with SeleniumLibrary and the Browser library. `AI Open Door` first proves the door reaches the browser and records the page's URL and title for the same-page check; it returns `NONE` if the port is busy, the browser does not answer, the browser is not Chrome or Edge, or the suite uses the Browser library (then Level 1B).

**Why two tools.** rf-mcp runs the repo's own keywords, so login, vault, frames and navigation behave exactly as in the team's tests; it can only act on locators someone already knows. Playwright MCP gives a clean view of a new screen, listing every element by its role and visible name (for example "combobox: Display name", "button: Save"), and can open dropdowns and dialogs before any locator exists; on React/MUI screens this is far more reliable than reading raw page code. So rf-mcp reaches the screen, the development code and the screen's controls give most new locators, Playwright reads what they cannot, and Robot Framework proves every locator and runs the test. Neither tool ever does the other's job; the final proof is always a normal Robot run.

**Three Playwright MCP entries** (see `qa-ai-skills/setup/mcp-config-examples/`), all loading `qa-ai-skills/skills/ai_activity_indicator.js` as their init script (purple badge):
- `playwright`: its own browser, for mock screens and standalone pages.
- `playwright-attach`: joins the very same browser behind the door (`http://127.0.0.1:9222`). SeleniumLibrary with Chrome or Edge only.
- `playwright-session`: its own window, opened with the login that `AI Share Login` saved (`qa-ai-skills/session/storage-state.json`). Used for Browser library suites (the Browser library starts its own browser, which nothing else can join) and whenever the door is unavailable.

**Library per suite.** `qa-ai-skills/knowledge/run-config.md` (from `summary.json` `suite_libraries`) says whether the target suite uses SeleniumLibrary, the Browser library, or both ("mixed"). Everything in this skill works for both; where they differ, this skill says so. In a mixed suite, each new locator is written in the syntax of the library whose keyword uses it, and the judge uses the library that has the browser open.

### Stage 2 - Check the environment, log in and reach the screen (checklist steps 3-4, one session, one login)
**The start-up check happens inside the same session, during the one login you need anyway**, so nothing runs twice:
1. Session start (variables, working folder, imports, below): an import or variable error is reported as a start-up failure.
2. `AI Check Variables` with the URL, user and connection variable names from `run-config.md` (OK / EMPTY / MISSING, never values).
3. The suite-setup chain (secrets / vault) runs once without error.
4. Database: only if the route uses data from a query, its existing keyword runs once as part of the route.
5. The existing login keyword reaches the home screen (its proof element), in a headed browser.
**All passed:** tick step 3 with one line, e.g. "Environment UAT: secrets, settings, application and login all working." Keep this browser and session for steps 4-6 (no second login).
**Anything failed:** stop, show `| Check | Result | What it means |` (mask passwords, tokens and connection strings), give the most likely fix (e.g. "the secrets loader did not receive the environment", "rf-mcp was started outside the repo folder"), and wait for "fixed, proceed". Start-up failures never use fix attempts.
**Once per conversation:** if the check already passed in this conversation for the same environment and the session is still open, reuse it: no new check and no new login (rule 13). If the session was closed, the login in the new session is the check.
**Every step KNOWN** (nothing to explore): skip Stages 2 and 3 and go straight to Stage 4. The first full run (Stage 5) is the check: steps 3-4 are ticked as "checked during run 1" and steps 5-6 are skipped (⏭ nothing new to explore). A failure before the first test step is handled as a start-up failure (section 6), not a script failure.

Use the highest level that works; say which one in one line. Every level ends with the judge and a normal Robot run.

| Level | Used when | Hands | How new parts are seen |
|---|---|---|---|
| 1 | SeleniumLibrary with Chrome or Edge; rf-mcp and `playwright-attach` available | rf-mcp | Playwright joins the same browser through the door (`AI Open Door`), same-page check (Stage 3) |
| 1B | Browser library suites, or SeleniumLibrary when the door returns `NONE` (Firefox, port busy) | rf-mcp | `AI Share Login`, then `playwright-session` opens the same page, logged in, in its own window; same-page check (Stage 3) |
| 2 | 1 and 1B unavailable, or the same-page check fails (e.g. the sign-in is kept only in session storage) | rf-mcp | The saved screen (page, frames, controls list with labels and roles, screenshot from `AI Save Screen`), plus the suite's own library keywords through rf-mcp to open a panel or dropdown (never save) |
| 3 | rf-mcp unavailable or unstable | a short Robot "reach" run that ends with `AI Checkpoint` | The checkpoint opens the door (SeleniumLibrary) or shares the login (Browser library), saves the screen and pauses; then as Level 1, 1B or 2 |
| 4 | Nothing else can reach the screen | none | Playwright's own browser; the user logs in by hand in that window; you follow the full step list (section 5a) |

**Levels 1, 1B and 2 (rf-mcp):** start one session that reproduces a normal run exactly, using `run-config.md`:
- **Command-line variables first.** Before importing anything, set every variable the normal command passes (e.g. the environment: `--variable ENV:<env>` overrides the suite file's default), with `Set Global Variable`. Never use the suite file's default environment when the run config names a different one.
- **Working folder.** Imports may use `${EXECDIR}` (the folder robot is started from, normally the repo root) or `${CURDIR}`. If the rf-mcp session is not running from the run-config working folder, set `${EXECDIR}` to that folder before importing, or import those files with absolute paths built from it.
- **Imports, exactly as the suite.** Import the target suite's own `Library`, `Resource` and `Variables` lines (the depth-0 rows of its entry in `qa-ai-skills/knowledge/.extract/import-chains.json`, also listed in `run-config.md`), **in the same order and with the same arguments** (a variables file that takes the environment gets the run-config environment), then `ai_session.py` last. Never import a nested file on its own: resources load their own imports, and importing the secrets loader directly would load it twice. Before the first import, check with `run-config.md` which file loads the secrets and through which resource (e.g. `suite -> global.resource -> common_password_handler.resource`), and confirm that path is in the list.
- **If an import or a variable fails** ("Variable '${...}' not found", "Resource file does not exist"): stop. Look the variable up in `import-chains.json` and the extract's variables to find the file that defines it and the import that should have loaded it first; report that file, that import line and whether it was missing, out of order or needs a command-line variable. Then start a fresh session with the corrected imports (never set the value by hand). If it still fails, drop to Level 3 and say so.
 Run the suite-setup chain once, exactly as `run-config.md` lists it (folder init files may be `__init__.robot` or `__init__.txt`; when the run config says they have no setup, run none of them and do not ask), then the suite's own setup, so vault values load. Then run the KNOWN steps with the same arguments the source test uses (data as variables), **all in one call:** `AI Run Steps    <Keyword | arg | proof=<proof element>>    ...` (section 1a; badge and timing per step), with the proof element of each screen from the app map, so the step verification protocol (section 12) is applied to every step inside the call. Use `AI Run Step    <keyword>    <arguments...>` only to rerun a single step. If one keyword runs longer than `slow_keyword_limit` (default 90 seconds), tell the user in one line ("Logging in is taking longer than usual; still waiting") and keep waiting up to its own timeout; never type into the page while an existing keyword is still running. Stop at the first failure and go to section 6; Playwright never takes over a failed known step.
**Level 3 (reach run):** write `qa-ai-skills/ai_generated_tests/drafts/<module>/_reach_<id>.robot` with the target suite's settings, `AI Check Variables` as the first step (the start-up check), the known steps only, and a last step `AI Checkpoint    timeout=600`. Run it headed in the background with the normal command from `run-config.md` plus `--listener <qa-ai-skills/skills/ai_activity_indicator.py> --variable AI_RUN:steps` (blue badge). Wait until `qa-ai-skills/session/state.json` says `paused: true`. If the run fails before that, go to section 6.

### 5a. Full step list (Level 4 only)
When Playwright must walk known steps itself (for Browser library suites the selectors are already Playwright selectors and can be used as they are), run the extractor with `--steps "<keyword>"` for each keyword on the route and follow `qa-ai-skills/knowledge/.extract/steps.json` exactly: every inner library step, frame switches (`FRAME`), new windows (`WINDOW`) and waits (`WAIT`) included. Steps marked `CONDITIONAL` or `RUNTIME` must be checked on the page before acting. Verify the page after every action (section 12). A mismatch means the translation is wrong, never that the keyword is broken.

## 12. Step verification protocol (after every action, in exploration and in fixing)
Never assume an action worked. After each click, fill, select or navigation:
1. **Settle:** wait for loading to finish using the repo's own pattern (spinners or skeletons gone, network idle, element states). No fixed Sleep.
2. **Scan for interruptions:** modals, dialogs, native alerts, confirm boxes, toasts or snackbars, banners, inline validation errors, session-expired or login pages, new tabs or windows. Read their text.
3. **Confirm the expected state:** the target screen's proof element is visible, or the expected element state changed (checked, selected, value set, row added).
4. **Decide:**
   - Expected state present and no interruption: continue.
   - Interruption matches a known blocking message in the map: apply its fix (satisfy the precondition), re-plan, continue. Report it in the plan.
   - Interruption is a normal confirm (e.g. "Are you sure?") required by the test case: handle it the way existing keywords do.
   - Unknown interruption or expected state missing: take an accessibility or DOM snapshot, stop that path, and explain in plain words what is on screen. At most one retry, and only for clear timing issues.
5. Never report a screen as reached, or an element as "not found", until steps 1 to 3 are done.
