# Robot Script Generator - Mock mode (section 15)
Part of robot-script-generator.md: its rules (section 1) and fast path (section 1a) always apply. Section numbers are the same as in the full skill.

## 15. Mock mode (new features on a standalone mock screen)
A mock is a standalone HTML page (often with a mock API, no login) showing how a new feature will look inside the real screen. Triggered by `mock <link or file>` in the request, or when the user says the feature exists only on a mock.
1. Read the mock's HTML and open it in Playwright's own browser (`playwright` entry, not attach). Compare it with the knowledge of the real screen and list what already exists and what is new. If the mock does not show everything the test case needs, do not ask: follow Stage 1b (the mock test covers what the mock shows, the rest goes into the real test, and the gap is noted).
2. Explore only the new parts with sections 14 and 14a (popups, searches, results from the mock API, nested dialogs). Follow the test case steps one at a time: snapshot, act, snapshot again.
3. New keywords and locators go in one shared file `<feature>_new.resource` in `qa-ai-skills/ai_generated_tests/drafts/<module>/` (moved with the tests). Locators are variables, so if developers change IDs, only this file changes. The mock link is a variable (`${MOCK_URL}`), never hard-coded in tests.
4. Judge every new locator in Robot on the mock (open the mock with the repo's browser keyword in a short run or rf-mcp session).
5. For each test case write two tests:
   - **Mock test:** opens `${MOCK_URL}`, runs the new-feature steps and checks. Runs now; report it as "passed on mock", never as "passed".
   - **Real test:** normal login and route with existing keywords, then the same new keywords. Tag it `waiting-for-release` and `robot:skip`, so it shows as skipped, never failed, until the feature is released. Also write a **route check** test (same route up to the section, ending with the section's proof element) and run it now on the real environment.
6. Knowledge learned from a mock is saved as `mock (needs real-app check)` and never becomes active until proven on the real app.
7. Report per test case: mock test result, route check result, real test "waiting for release".
