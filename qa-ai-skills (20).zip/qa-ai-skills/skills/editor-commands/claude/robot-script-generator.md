---
description: Generate a proven Robot Framework test from a test case ID (add "qtest" first to fetch it from qTest), a test case file with a selection (all, first 10, next 10, failed, 5-20, TC IDs, "test case 3"), "mock <link>" for a mock screen, or a plain request.
argument-hint: TC-1234 | qtest TC-1234 | path/to/test-cases.md [all | first 10 | next 10 | failed | 5-20 | TC-101 ...] [mock <link>] | what to check
---
Follow every instruction in @qa-ai-skills/skills/robot-script-generator.md exactly, including the progress checklist, the environment question (the only question), the start-up check during login, the run configuration, the locator strategy, the judge, the two-run rule and the approval questions. Use the MCP servers robotmcp, playwright, playwright-attach, playwright-session and, for `qtest` requests, qtest as that file describes.

Request: $ARGUMENTS
