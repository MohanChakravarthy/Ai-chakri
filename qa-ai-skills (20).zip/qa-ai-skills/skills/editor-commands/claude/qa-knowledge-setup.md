---
description: Build, refresh, rebuild or check the AI knowledge of this Robot Framework repo (SeleniumLibrary or Browser library).
argument-hint: build [suite file | folder | topic] | refresh | rebuild <scope> | dev | status
---
Follow every instruction in @qa-ai-skills/skills/qa-knowledge-setup/qa-knowledge-setup.md exactly, using the builder and reviewer skills it names under qa-ai-skills/skills/, including the 7-step progress checklist and its clickable questions about the development repo shown in the chat and updated at every step.

Request: $ARGUMENTS
