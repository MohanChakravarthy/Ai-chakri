---
mode: agent
description: Build, refresh, rebuild or check the QA knowledge base (whole repo, a folder, a .robot file or a topic).
---
Follow every instruction in [qa-knowledge-setup](../../qa-ai-skills/skills/qa-knowledge-setup/qa-knowledge-setup.md) exactly, including the progress checklist (shown in the chat and updated at every step) and its clickable questions about the development repo.

Command: ${input:command:build | refresh | rebuild | dev | status, optionally followed by a folder, .robot file or topic}
