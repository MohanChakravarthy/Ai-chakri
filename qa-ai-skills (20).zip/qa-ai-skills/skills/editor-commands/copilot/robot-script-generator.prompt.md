---
mode: agent
description: Generate a proven Robot Framework test from a test case ID (add "qtest" first to fetch it from qTest), a test case file with a selection (all, first 10, next 10, failed, 5-20, TC IDs, "test case 3"), "mock <link>" for mock screens, or a plain request.
---
Follow every instruction in [robot-script-generator](../../qa-ai-skills/skills/robot-script-generator.md) exactly, including the progress checklist (shown in the chat and updated at every step), the environment question (the only question), the start-up check during login, the run configuration, the locator strategy, the judge, the two-run rule and the approval questions.

Request: ${input:request:TC-1234, qtest TC-1234, test-cases.md first 10, or what to check}
