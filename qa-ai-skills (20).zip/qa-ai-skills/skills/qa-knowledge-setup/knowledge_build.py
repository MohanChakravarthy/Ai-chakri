#!/usr/bin/env python3
"""
knowledge_build.py - writes the factual part of the QA knowledge from the extract, completely and in
seconds, so the AI only writes what needs understanding (and never writes its own helper scripts).

    Who does what
    - The extract (extract_repo.py) holds every fact: tests, keywords, locators, variables, routes,
      import chains. Nothing here reads .robot or .resource files again.
    - The AI writes the meaning, briefly, per module, into qa-ai-skills/knowledge/meaning/:
        keyword/<MODULE>.md   one line per keyword: ID | level | purpose | screens | flows,
                              plus the flow step -> keyword mapping
        locator/names.md      only for locator variables whose name says nothing (e.g. ${LOC_7})
      The meaning files are kept (committed with the knowledge), so a refresh re-renders everything
      and the AI only writes meaning for modules that changed.
    - This script renders every keyword and locator file, both indexes and the factual part of
      run-config.md, then checks coverage: every keyword, locator and test file of the extract must
      be in the knowledge.

Commands (run from the QA repo root):
  worksheet app|keyword|locator <MODULE>   compact facts for the AI to write the meaning (small output)
  render keyword|locator|app-map|run-config|all
                                           write the knowledge files from the extract + meaning
  check                                    coverage and consistency; exit code 1 when something is missing
  compare <old knowledge folder>           counts both (keywords, locators, screens, flows, routes...) to prove
                                           a rebuild lost nothing
  migrate                                  once, for knowledge written by an earlier release: moves its meaning
                                           into meaning/ (no AI work), then run render all
  report                                   what knowledge exists, with counts (for the final message)
  --self-test
Python 3.8+, standard library only.
"""
import argparse, datetime, json, os, re, subprocess, sys, tempfile, shutil
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import split_extract as SX                                   # noqa: E402  (same folder: module ownership, briefs)

GEN_START, GEN_END = "<!-- generated:start (knowledge_build.py; do not edit by hand) -->", "<!-- generated:end -->"


# ======================================================================== places and basics
def ai_home(repo="."):
    d = os.path.join(repo, "qa-ai-skills")
    return d if os.path.isdir(d) else repo


def P(repo="."):
    k = os.path.join(ai_home(repo), "knowledge")
    return {"k": k, "x": os.path.join(k, ".extract"), "meaning": os.path.join(k, "meaning"), "app": os.path.join(k, "app"),
            "kw": os.path.join(k, "keywords"), "loc": os.path.join(k, "locators")}


def jload(p, default):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def read(p):
    try:
        with open(p, encoding="utf-8") as fh:
            return fh.read()
    except Exception:
        return ""


def write(p, text):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text.rstrip() + "\n")
    os.replace(tmp, p)


def git(repo, *args):
    try:
        return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True, timeout=10).stdout.strip()
    except Exception:
        return ""


def slug(text, maxlen=40):
    s = re.sub(r"\$\{[^}]*\}", "X", str(text))
    s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").upper()
    return s[:maxlen].strip("-") or "X"


def norm(s):
    return re.sub(r"[\s_]+", "", str(s).lower())


def keep_sections(old_text, names=("Notes", "Learned", "Learned entries")):
    """Hand-written sections of an existing file that a re-render must keep."""
    out = []
    for name in names:
        m = re.search(r"(?ms)^## " + re.escape(name) + r"\b.*?(?=^## |\Z)", old_text)
        if m:
            out.append(m.group(0).rstrip())
    return out


ABBREV = {"btn": "button", "txt": "text", "lbl": "label", "ddl": "dropdown", "dd": "dropdown", "chk": "checkbox", "chkbox": "checkbox",
          "rdo": "radio", "lnk": "link", "tbl": "table", "msg": "message", "hdr": "header", "img": "image", "num": "number",
          "addr": "address", "desc": "description", "dlg": "dialog", "tb": "text box", "cb": "checkbox"}


def human(var):
    """${ADDRESS_TYPE_DROPDOWN} -> 'Address type dropdown'; ${SAVE_BTN} -> 'Save button'."""
    n = re.sub(r"^[$@&%]\{|\}$", "", var or "")
    n = re.sub(r"([a-z])([A-Z])", r"\1 \2", n).replace("_", " ").replace("-", " ").strip().lower()
    n = " ".join(ABBREV.get(w, w) for w in n.split())
    return (n[:1].upper() + n[1:]) if n else ""


USAGE_TYPE = ((r"^select from list|^select options by|^list selection should|^get selected list", "dropdown"),
              (r"^input text|^input password|^clear element text|^fill text|^type text|^textfield", "input"),
              (r"^click button|^button should", "button"), (r"^select checkbox|^unselect checkbox|^checkbox should|^check checkbox", "checkbox"),
              (r"^select radio|^radio button should", "radio"), (r"^click link|^link should", "link"),
              (r"^select frame|^unselect frame", "frame"), (r"^table should|^get table cell", "grid"))


def usage_type(var, ex):
    """The element type from the library keywords the team applies to this locator (one pass, cached)."""
    if not hasattr(ex, "_usage_types"):
        ex._usage_types = {}
        for k in ex.keywords:
            for st in k.get("steps") or []:
                t = next((t for pat, t in USAGE_TYPE if re.search(pat, st.get("keyword", ""), re.I)), None)
                if t:
                    for a in st.get("args", []):
                        for m in re.findall(r"[$@&]\{([^}]+)\}", a):
                            ex._usage_types.setdefault(norm(m), t)
    return ex._usage_types.get(norm(var.strip("${}@&")))


def unclear_name(var):
    n = re.sub(r"^[$@&%]\{|\}$", "", var or "")
    words = [w for w in re.split(r"[_\W]+|(?<=[a-z])(?=[A-Z])", n) if w]
    meaningful = [w for w in words if len(w) > 2 and not re.fullmatch(r"(loc|locator|xpath|css|id|elem|element|var|obj|txt|lbl|btn)\d*", w, re.I)
                  and not w.isdigit()]
    return not meaningful


# ======================================================================== the extract, shared by all commands
class Extract:
    def __init__(self, repo="."):
        self.repo = repo
        p = P(repo)
        self.p = p
        x = p["x"]
        self.summary = jload(os.path.join(x, "summary.json"), {})
        self.tests = jload(os.path.join(x, "tests.json"), [])
        self.keywords = jload(os.path.join(x, "keywords.json"), [])
        self.locators = jload(os.path.join(x, "locators.json"), [])
        self.routes = jload(os.path.join(x, "routes.json"), {})
        self.chains = jload(os.path.join(x, "import-chains.json"), {})
        self.dev_links = jload(os.path.join(x, "dev", "dev-links.json"), {})
        if not self.tests and not self.keywords:
            raise SystemExit(f"No extract in {x}: run extract_repo.py first.")
        self.briefs, self.file_mod = SX.cached_briefs(x, p["k"])
        self.kw_mod = {}
        for mod, b in self.briefs.items():
            for k in b["keywords_owned"]:
                self.kw_mod[SX.kid(k)] = mod
        self.kw_by_kid = {SX.kid(k): k for k in self.keywords}
        # stable keyword IDs: KW-<NAME>; the file name is added only when two keywords share a name.
        # They do not depend on the module, so regrouping modules never orphans the saved meaning.
        names = Counter(slug(k["name"], 50) for k in self.keywords)
        self.kw_id, used = {}, set()
        for k in sorted(self.keywords, key=lambda k: (k["file"], k["line"] or 0)):
            base = "KW-" + slug(k["name"], 50)
            if names[slug(k["name"], 50)] > 1:
                base += "-" + slug(os.path.splitext(os.path.basename(k["file"]))[0], 20)
            i, kid_ = 2, base
            while kid_ in used:
                kid_, i = f"{base}-{i}", i + 1
            used.add(kid_)
            self.kw_id[SX.kid(k)] = kid_
        # callers: which tests call each keyword (directly or through other keywords)
        self.callers = defaultdict(list)
        for t in self.tests:
            seen = set()
            stack = [r for s in t.get("steps", []) for r in s.get("resolved", [])]
            while stack:
                k_id = stack.pop()
                if k_id in seen or k_id not in self.kw_by_kid:
                    continue
                seen.add(k_id)
                self.callers[k_id].append(f"{t['file']}::{t['name']}")
                for tg in (self.kw_by_kid[k_id].get("resolved_calls") or {}).values():
                    stack.extend(tg)
        self.loc_vars = {norm(l["variable"].strip("${}@&")): l for l in self.locators if l.get("variable")}

    def lib_of(self, file):
        return (self.summary.get("libraries_per_file") or {}).get(file) or "-"


# ======================================================================== meaning files (written by the AI)
def read_kw_meaning(path):
    """{KW-ID: {level, purpose, screens, flows}}, {FLOW-ID: {name, steps:[(n, step, kw)]}}"""
    kws, flows, cur = {}, {}, None
    for line in read(path).splitlines():
        s = line.strip()
        if not s or s.startswith("#") and not s.startswith("##"):
            continue
        if s.startswith("## "):
            cur = None
            continue
        parts = [x.strip() for x in s.strip("|").split("|")]
        if parts and parts[0].startswith("KW-") and len(parts) >= 2:
            parts += [""] * (5 - len(parts))
            kws[parts[0]] = {"level": parts[1].lower() if parts[1] not in ("-", "") else "", "purpose": "" if parts[2] in ("-", "") else parts[2],
                             "screens": [x.strip() for x in parts[3].split(",") if x.strip().startswith("SCREEN-")],
                             "flows": [x.strip() for x in parts[4].split(",") if x.strip().startswith("FLOW-")]}
        elif parts and parts[0].startswith("FLOW-"):
            cur = parts[0]
            flows[cur] = {"name": parts[1] if len(parts) > 1 else "", "steps": []}
        elif cur and parts and parts[0].isdigit() and len(parts) >= 3:
            flows[cur]["steps"].append((int(parts[0]), parts[1], parts[2]))
    return kws, flows


def read_all_kw_meaning(repo="."):
    """Meaning from every file in meaning/keyword/, whatever module name it was written under."""
    d = os.path.join(P(repo)["meaning"], "keyword")
    kws, flows = {}, {}
    for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if f.endswith(".md") and not f.startswith("_"):
            k, fl = read_kw_meaning(os.path.join(d, f))
            kws.update(k)
            flows.update({key: dict(v, file=f) for key, v in fl.items()})
    return kws, flows


def read_loc_names(path):
    out = {}
    for line in read(path).splitlines():
        parts = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(parts) >= 3 and re.match(r"^[$@&]\{", parts[0]):
            out[parts[0]] = {"type": parts[1], "meaning": parts[2]}
    return out


def read_dev_suggestions(repo="."):
    """meaning/locator/dev-suggestions.md: '${VAR} | fix|stronger | <locator> | why' (from the development code)."""
    out = {}
    for line in read(os.path.join(P(repo)["meaning"], "locator", "dev-suggestions.md")).splitlines():
        parts = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(parts) >= 3 and re.match(r"^[$@&]\{", parts[0]):
            out[parts[0]] = {"kind": parts[1].lower(), "locator": parts[2], "why": parts[3] if len(parts) > 3 else ""}
    return out


def app_registry(repo="."):
    """SCREEN and FLOW IDs (with names) defined in the app knowledge."""
    p = P(repo)
    screens, flows = {}, {}
    files = [os.path.join(p["app"], f) for f in sorted(os.listdir(p["app"]))] if os.path.isdir(p["app"]) else []
    for f in files + [os.path.join(p["k"], "app-knowledge.md"), os.path.join(p["k"], "app-map.md")]:
        for m in re.finditer(r"(?m)^#{2,4}\s+(SCREEN-[A-Z0-9-]+)\s*\|\s*(.+)$", read(f)):
            screens.setdefault(m.group(1), m.group(2).strip())
        for m in re.finditer(r"(?m)^#{2,4}\s+(FLOW-[A-Z0-9-]+)\s*\|\s*(.+)$", read(f)):
            flows.setdefault(m.group(1), m.group(2).strip())
        for m in re.finditer(r"(?m)^\|\s*(SCREEN-[A-Z0-9-]+)\s*\|\s*([^|]+)\|", read(f)):
            screens.setdefault(m.group(1), m.group(2).strip())
        for m in re.finditer(r"(?m)^\|\s*(FLOW-[A-Z0-9-]+)\s*\|\s*([^|]+)\|", read(f)):
            flows.setdefault(m.group(1), m.group(2).strip())
    return screens, flows


def module_flows(repo, mod):
    """FLOW-ID -> (name, [steps]) and SCREEN-ID -> name from the module's app file."""
    text = read(os.path.join(P(repo)["app"], f"{mod}.md"))
    flows, screens = {}, {}
    for m in re.finditer(r"(?ms)^### (FLOW-[A-Z0-9-]+)\s*\|\s*(.+?)$(.*?)(?=^### |^## |\Z)", text):
        steps = re.findall(r"(?m)^\s+\d+\.\s+(.+)$", m.group(3))
        flows[m.group(1)] = (m.group(2).strip(), steps)
    for m in re.finditer(r"(?m)^### (SCREEN-[A-Z0-9-]+)\s*\|\s*(.+)$", text):
        screens[m.group(1)] = m.group(2).strip()
    return flows, screens


# ======================================================================== keyword facts
def suggested_level(k, ex):
    user_calls = [t for tg in (k.get("resolved_calls") or {}).values() for t in tg]
    steps = len(k.get("steps") or [])
    if len(set(user_calls)) >= 3:
        return "flow"
    if not user_calls and steps <= 2:
        return "step"
    return "page"


def step_sig(k):
    return tuple(norm(s.get("keyword", "")) + "|" + "|".join(s.get("args", [])) for s in (k.get("steps") or []))


def keyword_facts(ex):
    """Duplicates (same steps), Sleep usage, locator variables used, library keywords in use."""
    by_sig = defaultdict(list)
    for k in ex.keywords:
        sig = step_sig(k)
        if len(sig) >= 2:
            by_sig[sig].append(SX.kid(k))
    dup = {}
    for ids in by_sig.values():
        if len(ids) > 1:
            pref = max(ids, key=lambda i: (ex.kw_by_kid[i].get("used_count", 0), -len(i)))
            for i in ids:
                dup[i] = (pref, [x for x in ids if x != i])
    sleeps = [SX.kid(k) for k in ex.keywords if any(norm(s.get("keyword", "")).endswith("sleep") for s in k.get("steps") or [])]
    loc_used = {}
    for k in ex.keywords:
        vs = []
        for s in k.get("steps") or []:
            for a in s.get("args", []):
                for v in re.findall(r"[$@&]\{([^}]+)\}", a):
                    l = ex.loc_vars.get(norm(v))
                    if l and l["variable"] not in vs:
                        vs.append(l["variable"])
        loc_used[SX.kid(k)] = vs
    lib_kw = Counter()
    for owner in [t["steps"] for t in ex.tests] + [k.get("steps") or [] for k in ex.keywords]:
        for s in owner:
            if not s.get("resolved") and s.get("keyword") and not s["keyword"].startswith(("${", "@{", "&{")):
                if s.get("context") not in ("TEMPLATE",):
                    lib_kw[s["keyword"]] += 1
    for k in ex.keywords:
        for c, r in (k.get("resolved_calls") or {}).items():
            if not r and not c.startswith("${"):
                pass
    return dup, sleeps, loc_used, lib_kw


# ======================================================================== worksheets (what the AI reads)
def cmd_worksheet(stage, mod, repo=".", ex=None):
    if stage == "all" or isinstance(mod, (list, tuple)):
        ex = ex or Extract(repo)                       # one load of the extract for a whole batch
        mods = mod if isinstance(mod, (list, tuple)) else [mod]
        stages = ["app", "keyword", "locator"] if stage == "all" else [stage]
        for i, m in enumerate(mods):
            if len(mods) > 1:
                print(f"\n======== Module {i + 1} of {len(mods)}: {m} ========")
            for st in stages:
                if st == "app" and not (ex.briefs.get(m) or {}).get("tests"):
                    continue                            # shared modules have no tests: no app worksheet
                cmd_worksheet(st, m, repo, ex)
        return
    ex = ex or Extract(repo)
    if mod not in ex.briefs:
        raise SystemExit(f"Unknown module {mod}. Modules: {', '.join(sorted(ex.briefs))}")
    b = ex.briefs[mod]
    out = []
    if stage == "keyword":
        flows, screens = module_flows(repo, mod)
        reg_s, reg_f = app_registry(repo)
        out.append(f"# Keyword worksheet: {mod} ({len(b['keywords_owned'])} keywords)")
        out.append(f"Write qa-ai-skills/knowledge/meaning/keyword/{mod}.md: one line per keyword, then the flow step mapping:")
        out.append("  KW-ID | level (step/page/flow) | purpose in business words, or - to use its documentation | SCREEN-IDs | FLOW-ID:step, ...")
        out.append("  ## Flow step mapping")
        out.append("  FLOW-ID | flow name")
        out.append("  1 | business step | KW-ID (or GAP)")
        if screens:
            out.append("\nScreens of this module: " + "; ".join(f"{k} {v}" for k, v in screens.items()))
        if flows:
            out.append("Flows of this module:")
            for fid, (name, steps) in flows.items():
                out.append(f"  {fid} {name}: " + " / ".join(f"{i}. {s}" for i, s in enumerate(steps, 1)))
        if mod.startswith("MOD-COMMON") and reg_f:
            out.append("All flows (shared keywords serve many): " + "; ".join(f"{k} {v}" for k, v in list(reg_f.items())[:120]))
        other_screens = [s for s in reg_s if s not in screens]
        if other_screens:
            out.append(f"Other screens ({len(other_screens)}): " + ", ".join(other_screens[:60]) + (" ..." if len(other_screens) > 60 else ""))
        out.append("\nKeywords (ID | name | where | arguments | documentation | calls | used by | suggested level):")
        for k in sorted(b["keywords_owned"], key=lambda k: (k["file"], k["line"] or 0)):
            i = SX.kid(k)
            doc = (k.get("documentation") or "").split("\n")[0][:90] or "(no documentation)"
            calls = [ex.kw_by_kid[t]["name"] for tg in (k.get("resolved_calls") or {}).values() for t in tg if t in ex.kw_by_kid]
            lib = [s["keyword"] for s in (k.get("steps") or []) if not s.get("resolved")][:4]
            users = ex.callers.get(i, [])
            out.append(f"{ex.kw_id[i]} | {k['name']} | {k['file']}:{k['line']} | {', '.join(k.get('arguments') or []) or '-'} | {doc} | "
                       f"{' + '.join(x for x in (', '.join(dict.fromkeys(calls)), ', '.join(lib)) if x) or '-'} | "
                       f"{len(users)} test{'' if len(users) == 1 else 's'}{': ' + '; '.join(u.split('::')[1] for u in users[:2]) if users else ''} | {suggested_level(k, ex)}")
        if b["keywords_called_from_elsewhere"]:
            out.append("\nShared keywords this module's tests also use (for the flow mapping; their meaning is written in their own module):")
            out.append("; ".join(f"{ex.kw_id.get(c['id'], c['id'])} {c['name']}" for c in b["keywords_called_from_elsewhere"][:80]))
    elif stage == "locator":
        names = read_loc_names(os.path.join(P(repo)["meaning"], "locator", "names.md"))
        unclear = [l for l in b["locators_owned"] if l.get("variable") and unclear_name(l["variable"]) and l["variable"] not in names]
        out.append(f"# Locator worksheet: {mod} ({len(b['locators_owned'])} locators; everything is rendered from the code)")
        if os.path.isfile(os.path.join(P(repo)["k"], "dev", "dev-qa-links.md")):
            weak = [l for l in b["locators_owned"] if l.get("variable") and (rate(l["value"])[0] != "High")]
            if weak:
                out.append("With the development code: check these against dev/dev-qa-links.md and add a 'fix' or 'stronger' line to "
                           "meaning/locator/dev-suggestions.md where the code gives a test ID or stable id:")
                out += [f"  {l['variable']} = {l['value'][:80]} ({rate(l['value'])[0]}: {rate(l['value'])[1]})" for l in weak[:60]]
        if not unclear:
            out.append("Nothing to write for names: every locator name says what it is.")
        else:
            out.append("Only these names say nothing about the element. Add one line each to qa-ai-skills/knowledge/meaning/locator/names.md:")
            out.append("  ${VARIABLE} | element type (button, input, dropdown, option, tab, link, grid, row, cell, checkbox, radio, label, dialog, frame, message) | meaning")
            for l in unclear:
                users = [u.split("::")[-1] for u in l.get("used_by", [])][:3]
                out.append(f"{l['variable']} | {l['value'][:80]} | used by: {', '.join(users) or '-'}")
    elif stage == "app":
        out.append(f"# App worksheet: {mod} ({len(b['tests'])} tests, {len(b['keywords_owned'])} own keywords)")
        out.append("Write the module file app/" + mod + ".md (screens, flows, rules, journeys), and one line per screen in "
                   "qa-ai-skills/knowledge/meaning/app/screens.md: SCREEN-ID | name | " + mod + " | entry keyword ID | preconditions | "
                   "proof ${VAR} (only to override) | exit; extra '- Label: text' lines below a screen are copied into the map. "
                   "Entry routes, proof elements and transitions are rendered from the code (render app-map).")
        out.append("Tests (file::name [tags] - documentation | business steps as keyword names):")
        for t in b["tests"]:
            steps = [s["keyword"] for s in t.get("steps", []) if s.get("context") != "TEMPLATE" or True]
            tags = ", ".join(t.get("tags") or [])
            doc = (t.get("documentation") or "").split("\n")[0][:80]
            out.append(f"- {t['file']}::{t['name']}" + (f" [{tags}]" if tags else "") + (f" - {doc}" if doc else "") + " | " +
                       " > ".join(dict.fromkeys(steps))[:400])
        out.append("\nEntry routes per keyword (shortest real route; tests using; always run before):")
        for k_id, r in list(b["routes"].items())[:120]:
            ex_r = (r.get("example_routes") or [{}])[0]
            name = ex.kw_by_kid.get(k_id, {}).get("name", k_id.split("::")[-1])
            before = ", ".join(x.split("::")[-1] for x in r.get("always_before", []))
            route = " > ".join(ex_r.get("route", []))
            out.append(f"- {name}: {r.get('tests_using')} test{'' if r.get('tests_using') == 1 else 's'}; before: {before or '-'}; route: {route[:300]} (from {ex_r.get('source_test', '-')})")
        if b["messages"]:
            out.append("\nOn-screen messages the tests handle: " + "; ".join(f"\"{m.get('text', '')[:60]}\" ({m.get('where')})" for m in b["messages"][:30]))
        if b["dev_links"]:
            out.append("\nDevelopment links: " + "; ".join(f"{l.get('screen')} ({l.get('confidence')})" for l in b["dev_links"][:20]))
    print("\n".join(out))


# ======================================================================== render: keywords
def render_keywords(ex, repo="."):
    p = P(repo)
    commit, branch, now = git(repo, "rev-parse", "--short", "HEAD") or "-", git(repo, "rev-parse", "--abbrev-ref", "HEAD") or "-", \
        datetime.datetime.now().isoformat(timespec="seconds")
    reg_s, reg_f = app_registry(repo)
    dup, sleeps, loc_used, lib_kw = keyword_facts(ex)
    meaning_all, flows_all = read_all_kw_meaning(repo)
    problems = [f"meaning written for {i}, which is not in the extract (renamed or removed?)" for i in meaning_all if i not in set(ex.kw_id.values())]
    inv = {v: k for k, v in ex.kw_id.items()}
    mod_of_kw = {ex.kw_id[i]: m for i, m in ex.kw_mod.items()}
    flows_by_mod = defaultdict(dict)
    for fid, f in flows_all.items():                         # a flow goes to the module that owns most of its keywords
        owners = Counter(mod_of_kw.get(kw) for _, _, kw in f["steps"] if kw in mod_of_kw)
        target = owners.most_common(1)[0][0] if owners else "MOD-" + (f.get("file") or "MOD-COMMON.md")[4:-3]
        flows_by_mod[target][fid] = f
    files_written = []
    registry = []
    for mod in sorted(ex.briefs):
        b = ex.briefs[mod]
        if not b["keywords_owned"] and not flows_by_mod.get(mod):
            continue
        meaning, flows = meaning_all, flows_by_mod.get(mod, {})
        out_path = os.path.join(p["kw"], f"{mod}.md")
        kept = keep_sections(read(out_path))
        lines = [f"# Keywords: {mod[4:].replace('-', ' ').title()} ({mod})", f"Last updated: {now} | Commit: {commit}", ""]
        if flows:
            lines.append("## Flow step mapping")
            for fid, f in flows.items():
                lines.append(f"### {fid} | {f['name'] or reg_f.get(fid, '')}")
                lines.append("| # | Business step | Keyword ID | Keyword call |")
                lines.append("|---|---|---|---|")
                for n, step, kwid in f["steps"]:
                    k = ex.kw_by_kid.get(inv.get(kwid))
                    call = (k["name"] + ("    " + "    ".join(k.get("arguments") or []) if k.get("arguments") else "")) if k else "-"
                    lines.append(f"| {n} | {step} | {kwid} | {call} |")
                lines.append("")
        lines.append("## Keywords")
        for k in sorted(b["keywords_owned"], key=lambda k: ex.kw_id[SX.kid(k)]):
            i = SX.kid(k)
            kw_id = ex.kw_id[i]
            m = meaning.get(kw_id, {})
            doc = (k.get("documentation") or "").split("\n")[0].strip()
            purpose, inferred = (m.get("purpose"), "yes") if m.get("purpose") else ((doc, "no") if doc else ("(not described yet)", "-"))
            if purpose == "(not described yet)":
                problems.append(f"{kw_id}: no purpose (no documentation and no meaning line)")
            level = m.get("level") or suggested_level(k, ex) + " (suggested)"
            for sid in m.get("screens", []):
                if reg_s and sid not in reg_s:
                    problems.append(f"{kw_id}: screen {sid} is not in the app knowledge")
            for fl in m.get("flows", []):
                if reg_f and fl.split(":")[0] not in reg_f:
                    problems.append(f"{kw_id}: flow {fl.split(':')[0]} is not in the app knowledge")
            calls = list(dict.fromkeys(ex.kw_id[t] for tg in (k.get("resolved_calls") or {}).values() for t in tg if t in ex.kw_id))
            users = ex.callers.get(i, [])
            d = dup.get(i)
            pref = "yes" if not d or d[0] == i else f"no (duplicate of {ex.kw_id[d[0]]}, which is preferred)"
            if d and d[0] == i:
                pref = f"yes (same steps as {', '.join(ex.kw_id[x] for x in d[1])})"
            status = "active" if (k.get("used_count") or users) else "unused"
            lines += [f"### {kw_id} | {k['name']}", f"- File: {k['file']}:{k['line']}", f"- Library: {ex.lib_of(k['file'])}",
                      f"- Level: {level}", f"- Arguments: {', '.join(k.get('arguments') or []) or 'none'}",
                      f"- Returns: {', '.join(k.get('returns') or []) or 'none'}", f"- Purpose: {purpose} (inferred: {inferred})",
                      f"- Screens: {', '.join(m.get('screens', [])) or '-'}", f"- Flows: {', '.join(m.get('flows', [])) or '-'}",
                      f"- Calls: {', '.join(calls) or '-'}", f"- Locator variables: {', '.join(loc_used.get(i, [])) or '-'}",
                      f"- Used by: {len(users)} test{'' if len(users) == 1 else 's'}" + (f", e.g. {'; '.join(users[:3])}" if users else ""),
                      f"- Preferred: {pref}", f"- Status: {status}"]
            if i in sleeps:
                lines.append("- Note: uses a fixed Sleep")
            lines.append("")
            registry.append((kw_id, k["name"], mod, level.split(" ")[0], len(users), status))
        unlinked = [ex.kw_id[SX.kid(k)] for k in b["keywords_owned"] if not meaning.get(ex.kw_id[SX.kid(k)], {}).get("screens")
                    and not meaning.get(ex.kw_id[SX.kid(k)], {}).get("flows")]
        if unlinked:
            lines += ["## Unlinked", "Keywords with no screen or flow yet: " + ", ".join(unlinked), ""]
        lines += kept
        write(out_path, "\n".join(lines))
        files_written.append(out_path)
    # ---- index
    kn = P(repo)["k"]
    conv_extra = read(os.path.join(p["meaning"], "keyword", "_conventions.md")).strip()
    lib_counts = Counter(v for v in (ex.summary.get("libraries_per_file") or {}).values() if v)
    names = [k["name"] for k in ex.keywords]
    title_case = sum(1 for n in names if re.match(r"^([A-Z][\w']*)(\s+[A-Z0-9${][\w${}']*)*$", n))
    args = [a for k in ex.keywords for a in (k.get("arguments") or [])]
    up = sum(1 for a in args if re.match(r"^[$@&]\{[A-Z0-9_]+\}", a))
    documented = sum(1 for k in ex.keywords if (k.get("documentation") or "").strip())
    waits = [k for k, _ in lib_kw.most_common() if k.lower().startswith(("wait", "get text", "should", "element should", "page should"))][:10]
    loc_files = Counter(l["file"] for l in ex.locators if l.get("variable"))
    most_used = max(ex.keywords, key=lambda k: k.get("used_count", 0)) if ex.keywords else None
    flows_mapped = sum(1 for f in flows_all.values() if f["steps"] and all(s[2] != "GAP" for s in f["steps"]))
    gaps = [(fid, s[1]) for fid, f in flows_all.items() for s in f["steps"] if s[2] == "GAP"]
    idx = [f"# Keyword Knowledge: {os.path.basename(os.path.abspath(repo))}", "", "## Metadata", "- schema_version: 2 (rendered by knowledge_build.py)",
           f"- generated_at: {now}", f"- last_commit: {commit}", f"- branch: {branch}", "",
           "## Conventions",
           f"- Automation library: " + (", ".join(f"{k} ({v} files)" for k, v in lib_counts.most_common()) or "-"),
           f"- Keyword naming: {title_case} of {len(names)} keywords use Title Case" + (f", e.g. \"{most_used['name']}\"" if most_used else ""),
           f"- Argument style: {up} of {len(args)} arguments in UPPER_CASE" if args else "- Argument style: -",
           f"- Documentation: {documented} of {len(names)} keywords have [Documentation]",
           f"- Waits and checks in use: {', '.join(waits) or '-'}",
           f"- Where locators live: {', '.join(f'{f} ({n})' for f, n in loc_files.most_common(5)) or '-'}",
           f"- Test organisation: {ex.summary.get('test_organisation', '-')}"]
    if conv_extra:
        idx += ["", conv_extra]
    idx += ["", "## Registry", "| Keyword ID | Name | Module | Level | Used by | Status |", "|---|---|---|---|---|---|"]
    idx += [f"| {a} | {b_} | {c} | {d} | {e} | {f} |" for a, b_, c, d, e, f in sorted(registry)]
    idx += ["", "## Library keywords in use", "| Keyword | Uses |", "|---|---|"]
    idx += [f"| {k} | {n} |" for k, n in lib_kw.most_common(80)]
    idx += ["", "## Coverage", f"- Flows fully mapped: {flows_mapped} of {len(flows_all)}"]
    if gaps:
        idx.append("- Gap steps (no keyword yet): " + "; ".join(f"{f} '{s}'" for f, s in gaps[:40]))
    idx += ["", "## Quality findings",
            f"- Duplicates (same steps): {len({d[0] for d in dup.values()})} groups" + (": " + "; ".join(
                f"{ex.kw_id[pref]} preferred over {', '.join(ex.kw_id[x] for x in others)}" for i, (pref, others) in dup.items() if i == pref)[:2000]
                if dup else ""),
            f"- Keywords with a fixed Sleep: {len(sleeps)}" + (": " + ", ".join(ex.kw_id[i] for i in sleeps[:40]) if sleeps else ""),
            f"- Unused keywords: {sum(1 for r in registry if r[5] == 'unused')}" +
            (": " + ", ".join(r[0] for r in registry if r[5] == "unused")[:1500] if any(r[5] == "unused" for r in registry) else "")]
    write(os.path.join(kn, "keyword-knowledge.md"), "\n".join(idx))
    return files_written, problems


# ======================================================================== render: locators
GENERATED_ID = re.compile(r"(mui-\d+|:r[0-9a-z]+:|react-select-\d+|css-[0-9a-z]{5,}|j_idt\d+|ember\d+|ext-gen\d+|\b[0-9a-f]{8}-[0-9a-f]{4}-|\d{5,})", re.I)


def parse_locator(value):
    v = (value or "").strip()
    m = re.match(r"^(id|css|xpath|name|link|partial link|class|tag|dom|jquery|identifier|text|data-testid|data-test-id|data-qa|role|label|placeholder|alt|title)\s*[:=]\s*(.*)$", v, re.I)
    if m:
        return m.group(1).lower(), m.group(2)
    if v.startswith(("//", "(//", "./")):
        return "xpath", v
    if v.startswith(("#", ".", "[")):
        return "css", v
    return "implicit", v


def rate(value):
    strat, sel = parse_locator(value)
    s = sel.lower()
    if GENERATED_ID.search(sel):
        return "Low", "generated id or class"
    if re.search(r"^/html|^/body", sel) or re.search(r"\[\d+\]|nth-child|nth=|:nth|>> nth", sel):
        return "Low", "position or absolute path"
    if re.search(r"data-(testid|test-id|test|qa|cy)", s) or strat in ("data-testid", "data-test-id", "data-qa"):
        return "High", "test attribute"
    if strat in ("id", "name", "identifier") or re.fullmatch(r"#[\w-]+", sel) or re.search(r"@id=['\"][\w-]+['\"]\]?$", sel):
        return "High", "stable id or name"
    if strat in ("role",) or re.search(r"aria-label|role=|@aria|label\b|placeholder|normalize-space|text\(\)|has-text|text=", s) or strat in ("text", "label", "placeholder", "link"):
        return "Medium", "label, accessible name or text"
    if strat == "xpath" and len(sel) > 120:
        return "Low", "long XPath"
    if strat == "class" or re.match(r"^\.[\w-]+$", sel):
        return "Medium", "class name"
    return "Medium", "short CSS or XPath"


def element_type(var, value):
    n = (var or "").lower()
    for pat, t in ((r"btn|button", "button"), (r"dropdown|select|combo|ddl|_dd\b", "dropdown"), (r"option|opt\b", "option"),
                   (r"checkbox|chk|chkbox", "checkbox"), (r"radio|rdo|rb_", "radio"), (r"input|field|txt|textbox|textarea|_tb\b", "input"),
                   (r"tab\b|_tab|tab_", "tab"), (r"link|lnk|anchor", "link"), (r"grid|table|tbl", "grid"), (r"row", "row"), (r"cell|col", "cell"),
                   (r"label|lbl", "label"), (r"dialog|modal|popup", "dialog"), (r"i?frame", "frame"), (r"msg|message|toast|error|alert|warning", "message"),
                   (r"title|header|heading", "heading"), (r"menu", "menu"), (r"icon", "icon")):
        if re.search(pat, n):
            return t
    v = (value or "").lower()
    for pat, t in ((r"//button|button\[|^button|role=['\"]?button", "button"), (r"//input|input\[|^input", "input"), (r"//select|^select", "dropdown"),
                   (r"//a\b|//a\[|^a\[|^a\.", "link"), (r"//table|//tr|//td", "grid"), (r"iframe", "frame")):
        if re.search(pat, v):
            return t
    return "element"


def render_locators(ex, repo="."):
    p = P(repo)
    now, commit = datetime.datetime.now().isoformat(timespec="seconds"), git(repo, "rev-parse", "--short", "HEAD") or "-"
    reg_s, _ = app_registry(repo)
    names = read_loc_names(os.path.join(p["meaning"], "locator", "names.md"))
    dev_sug = read_dev_suggestions(repo)
    kw_screens = {kw_id: m.get("screens", []) for kw_id, m in read_all_kw_meaning(repo)[0].items()}
    id_of = {v: k for k, v in ex.kw_id.items()}
    by_name_file = {(k["file"], k["name"]): ex.kw_id[SX.kid(k)] for k in ex.keywords}
    by_value = defaultdict(list)
    for l in ex.locators:
        if l.get("variable"):
            by_value[re.sub(r"\s+", " ", l["value"].strip())].append(l)
    by_var = defaultdict(set)
    for l in ex.locators:
        if l.get("variable"):
            by_var[l["variable"]].add(l["value"])
    screens = defaultdict(list)
    used_ids, rows_all = set(), []
    missing_dev = {(m.get("file"), m.get("variable")): m for m in (ex.dev_links.get("missing_in_dev") or [])}
    for l in ex.locators:
        users_kw = []
        for ref in l.get("used_by", []):
            typ, rest = ref.split(":", 1) if ":" in ref else ("", ref)
            f, _, name = rest.partition("::")
            if typ == "keyword" and (f, name) in by_name_file:
                users_kw.append(by_name_file[(f, name)])
        votes = Counter(s for kw in users_kw for s in kw_screens.get(kw, []))
        screen = votes.most_common(1)[0][0] if votes else None
        others = [s for s in votes if s != screen]
        var = l.get("variable")
        base = f"LOC-{(screen[7:] if screen else 'COMMON')}-{slug(re.sub(r'^[$@&%]{|}$', '', var) if var else 'INLINE', 30)}"
        lid, i = base, 2
        while lid in used_ids:
            lid, i = f"{base}-{i}", i + 1
        used_ids.add(lid)
        stab, why = rate(l["value"])
        strat, sel = parse_locator(l["value"])
        nm = names.get(var or "", {})
        dyn = re.findall(r"\$\{[^}]+\}|\{[^}]*\}|%s", l["value"])
        same = by_value.get(re.sub(r"\s+", " ", l["value"].strip()), [])
        dup_pref = max(same, key=lambda x: len(x.get("used_by", []))) if len(same) > 1 else None
        etype = nm.get("type") or element_type(var, l["value"])
        if etype == "element" and var:
            etype = usage_type(var, ex) or etype
        row = {"id": lid, "var": var or "inline", "file": l["file"], "line": l.get("line"), "type": etype,
               "meaning": nm.get("meaning") or (human(var) if var else f"inline in {', '.join(users_kw) or l['file']}"),
               "strategy": strat, "selector": sel, "dynamic": ("yes: " + ", ".join(dyn)) if dyn else "no",
               "frame": l["value"].split(">>>")[0].strip() if ">>>" in l["value"] else "", "stability": stab, "why": why,
               "users": users_kw, "used": len(l.get("used_by", [])), "status": "active" if l.get("used_by") else "unused",
               "dup_of": (dup_pref.get("variable") if dup_pref is not None and dup_pref is not l else None),
               "conflict": len(by_var.get(var, ())) > 1 if var else False, "others": others, "origin": l.get("origin"),
               "dev": missing_dev.get((l["file"], var))}
        screens[screen or "UNMAPPED"].append(row)
        rows_all.append(row)
    written = []
    old_files = set(os.listdir(p["loc"])) if os.path.isdir(p["loc"]) else set()
    for scr, rows in sorted(screens.items()):
        fname = f"{scr}.md"
        path = os.path.join(p["loc"], fname)
        kept = keep_sections(read(path))
        main_file = Counter(r["file"] for r in rows if r["var"] != "inline").most_common(1)
        lines = [f"# Locators: {reg_s.get(scr, 'Not yet tied to a screen') if scr != 'UNMAPPED' else 'Not yet tied to a screen'} ({scr})",
                 f"Last updated: {now} | Commit: {commit}", f"Defined in: {main_file[0][0] if main_file else '-'}", "",
                 "| Locator ID | Variable | Element | Meaning | Strategy | Selector | Dynamic | Stability | Used by | Status |",
                 "|---|---|---|---|---|---|---|---|---|---|"]
        for r in sorted(rows, key=lambda r: r["id"]):
            sel = r["selector"].replace("|", "\\|")[:160]
            lines.append(f"| {r['id']} | {r['var']} | {r['type']} | {r['meaning']} | {r['strategy']} | `{sel}` | {r['dynamic'].split(':')[0]} | "
                         f"{r['stability']} | {r['used']}{' (' + ', '.join(r['users'][:3]) + ')' if r['users'] else ''} | {r['status']} |")
        details = [r for r in rows if r["dynamic"] != "no" or r["frame"] or r["dup_of"] or r["stability"] == "Low" or r["conflict"] or r["others"]]
        if details:
            lines += ["", "## Details"]
            for r in details:
                lines.append(f"### {r['id']}")
                lines.append(f"- File: {r['file']}:{r['line']}")
                if r["dynamic"] != "no":
                    lines.append(f"- Placeholders: {r['dynamic'][5:]}")
                if r["frame"]:
                    lines.append(f"- Frame: {r['frame']}")
                if r["dup_of"]:
                    lines.append(f"- Duplicate of: {r['dup_of']} (preferred: no)")
                if r["conflict"]:
                    lines.append(f"- Conflict: {r['var']} is defined with different values in several files")
                if r["others"]:
                    lines.append(f"- Also used on: {', '.join(r['others'])}")
                lines.append(f"- Stability reason: {r['why']}")
        lines += ["", "## Where new locators for this screen go",
                  f"{main_file[0][0] if main_file else 'the module resource file'} (Variables section, same naming style)"]
        devs = [r for r in rows if r["dev"] or r["var"] in dev_sug]
        if devs:
            lines += ["", "## Suggested fixes from the development code (not applied)",
                      "| Variable | Current value | Suggestion | Why |", "|---|---|---|---|"]
            for r in devs:
                sg = dev_sug.get(r["var"], {})
                what = (("Suggested fix" if sg.get("kind", "").startswith("fix") else "Stronger option") + f": `{sg['locator']}`") if sg else "-"
                why = sg.get("why") or ""
                if r["dev"]:
                    why = (why + "; " if why else "") + f"possibly stale - check live: {', '.join(r['dev'].get('not_found', []))} not found in the development code"
                lines.append(f"| {r['var']} | `{r['selector'][:80]}` | {what} | {why} |")
        lines += [""] + kept
        write(path, "\n".join(lines))
        written.append(path)
        old_files.discard(fname)
    for f in old_files:                                        # screens that no longer have locators
        if f.endswith(".md") and (f.startswith("SCREEN-") or f == "UNMAPPED.md"):
            os.remove(os.path.join(p["loc"], f))
    # ---- index
    strat = Counter(r["strategy"] for r in rows_all)
    ex_var = next((r for r in rows_all if r["var"] != "inline"), None)
    ex_dyn = next((r for r in rows_all if r["dynamic"] != "no"), None)
    ex_frame = next((r for r in rows_all if r["frame"]), None)
    idx = [f"# Locator Knowledge: {os.path.basename(os.path.abspath(repo))}", "", "## Metadata", "- schema_version: 2 (rendered by knowledge_build.py)",
           f"- generated_at: {now}", f"- last_commit: {commit}", "", "## Conventions",
           f"- Library: {', '.join(f'{k} ({v})' for k, v in Counter((ex.summary.get('libraries_per_file') or {}).values()).most_common() if k) or '-'}",
           f"- Where locators live: {', '.join(f'{f} ({n})' for f, n in Counter(r['file'] for r in rows_all if r['var'] != 'inline').most_common(6))}",
           f"- Naming example: {ex_var['var']} = `{ex_var['selector'][:80]}`" if ex_var else "- Naming example: -",
           f"- Strategies in use: {', '.join(f'{k} {v}' for k, v in strat.most_common())}",
           "- Preferred order for new locators: test attribute, stable id or name, label or accessible name, short relative XPath",
           f"- Dynamic pattern: {ex_dyn['var']} = `{ex_dyn['selector'][:80]}`" if ex_dyn else "- Dynamic pattern: none found",
           f"- Frame pattern: `{ex_frame['frame']}`" if ex_frame else "- Frame pattern: none found",
           "", "## Screen coverage", "| Screen ID | Locators | High | Medium | Low | File |", "|---|---|---|---|---|---|"]
    for scr, rows in sorted(screens.items()):
        c = Counter(r["stability"] for r in rows)
        idx.append(f"| {scr} | {len(rows)} | {c['High']} | {c['Medium']} | {c['Low']} | locators/{scr}.md |")
    low = [r for r in rows_all if r["stability"] == "Low"]
    dups = [r for r in rows_all if r["dup_of"]]
    conf = sorted({r["var"] for r in rows_all if r["conflict"]})
    inline = [r for r in rows_all if r["var"] == "inline"]
    idx += ["", "## Quality findings",
            f"- Brittle (Low) locators: {len(low)}" + (": " + ", ".join(f"{r['var']} ({r['why']})" for r in low[:40]) if low else ""),
            f"- Duplicates (same value, different variables): {len(dups)}" + (": " + ", ".join(f"{r['var']} = {r['dup_of']}" for r in dups[:40]) if dups else ""),
            f"- Conflicts (same variable, different values): {len(conf)}" + (": " + ", ".join(conf[:40]) if conf else ""),
            f"- Inline locators: {len(inline)}", f"- Not yet tied to a screen: {len(screens.get('UNMAPPED', []))}",
            f"- Possibly stale (not in the development code): {sum(1 for r in rows_all if r['dev'])}",
            f"- Suggested fixes and stronger options from the development code: {sum(1 for r in rows_all if r['var'] in dev_sug)}"]
    write(os.path.join(p["k"], "locator-knowledge.md"), "\n".join(idx))
    return written, rows_all


# ======================================================================== render: app map (facts from the routes, names from the AI)
def read_screens(repo="."):
    """meaning/app/screens.md: 'SCREEN-ID | name | MODULE | entry KW-ID | preconditions | proof ${VAR} (optional) | exit (optional)',
    followed by optional '- Label: text' lines copied into that screen's entry."""
    path = os.path.join(P(repo)["meaning"], "app", "screens.md")
    screens, cur, tail = {}, None, []
    for line in read(path).splitlines():
        t = line.strip()
        if t.startswith("## ") or tail:
            tail.append(line)
            continue
        if t.startswith("SCREEN-"):
            parts = [x.strip() for x in t.split("|")] + [""] * 7
            cur = parts[0]
            screens[cur] = {"name": parts[1], "module": parts[2], "entry": parts[3], "pre": parts[4], "proof": parts[5], "exit": parts[6], "extra": []}
        elif t.startswith("- ") and cur:
            screens[cur]["extra"].append(t)
    if tail:
        screens["_tail"] = tail
    return screens


WAITISH = re.compile(r"^(wait|element should|page should|get text|element text should|wait for elements state|get element|title should)", re.I)


def _loc_in(step, ex):
    if WAITISH.match(step.get("keyword", "")):
        for a in step.get("args", []):
            m = re.search(r"[$@&]\{([^}]+)\}", a)
            if m and ex.loc_vars.get(norm(m.group(1))):
                return ex.loc_vars[norm(m.group(1))]["variable"]
    return None


def proof_of(k, ex, source_test=None):
    """The screen's proof element: the last locator the entry keyword itself waits for or checks,
    else the first one the source test waits for or checks right after calling it."""
    found = None
    for st in (k.get("steps") or []):
        found = _loc_in(st, ex) or found
    if found or not source_test:
        return found
    f, _, name = source_test.partition("::")
    t = next((t for t in ex.tests if t["file"] == f and t["name"] == name), None)
    if t:
        steps = t.get("steps", [])
        idx = next((i for i, st in enumerate(steps) if st.get("keyword") == k["name"]), None)
        for st in steps[idx + 1: idx + 4] if idx is not None else []:
            v = _loc_in(st, ex)
            if v:
                return v
    return None


def render_app_map(ex, repo="."):
    p = P(repo)
    screens = read_screens(repo)
    inv = {v: k for k, v in ex.kw_id.items()}
    entry_of = {}
    problems = []
    lines = [f"# Application Map: {os.path.basename(os.path.abspath(repo))}", "Start state: logged out",
             "(Entry routes, entry keywords, proof elements and transitions are rendered from the code by knowledge_build.py;"
             " names, preconditions and extra lines come from meaning/app/screens.md.)", ""]
    tail = screens.pop("_tail", [])
    for sid, sc in screens.items():
        k_id = inv.get(sc["entry"])
        entry_of[sid] = k_id
    for sid, sc in screens.items():
        k_id = entry_of.get(sid)
        k = ex.kw_by_kid.get(k_id) if k_id else None
        lines.append(f"## {sid} | {sc['name']}")
        lines.append(f"- Module: {sc['module'] or ex.kw_mod.get(k_id, '-')}")
        if not k:
            lines.append(f"- Entry keyword: Open question: {sc['entry'] or 'none given'} is not a keyword in the extract")
            problems.append(f"{sid}: entry keyword {sc['entry'] or '-'} not found")
        else:
            lines.append(f"- Entry keyword: {k['name']} ({k['file']}:{k['line']})")
            r_ = ex.routes.get(k_id) or {}
            exs = sorted(r_.get("example_routes") or [], key=lambda e: len(e.get("route", [])))
            if exs:
                lines.append(f"- Entry route (from {exs[0].get('source_test', '-')}):")
                lines += [f"  {i}. {step}" for i, step in enumerate(exs[0]["route"], 1)]
            else:
                lines.append(f"- Entry route: the tests call {k['name']} directly after the suite setup (no earlier steps)")
            if r_.get("always_before"):
                lines.append("- Always run before it: " + ", ".join(x.split("::")[-1] for x in r_["always_before"]))
        r0 = (ex.routes.get(k_id) or {}) if k else {}
        single = " (probable: single test, verify live)" if r0.get("tests_using") == 1 else ""
        lines.append(f"- Preconditions: {sc['pre'] or 'logged in'}{single}")
        src_test = (sorted(r0.get("example_routes") or [], key=lambda e: len(e.get("route", []))) or [{}])[0].get("source_test")
        proof = sc["proof"] or (proof_of(k, ex, src_test) if k else None)
        if proof:
            lv = ex.loc_vars.get(norm(proof.strip("${}@&")))
            lines.append(f"- Proof element: {proof} ({human(proof)}{', ' + lv['file'] if lv else ''})")
        else:
            lines.append("- Proof element: Open question: the entry keyword waits for no locator; prove the screen by its title or a stable heading")
        trans = []
        for other, ok_id in entry_of.items():
            if other == sid or not ok_id or not k_id:
                continue
            for e in (ex.routes.get(ok_id) or {}).get("example_routes") or []:
                names = [x.split("    ")[0].strip() for x in e.get("route", [])]
                if k and k["name"] in names and names.index(k["name"]) == len(names) - 2:   # a direct move only
                    trans.append(f"-> {other} via {names[-1]}")
                    break
        if trans:
            lines.append("- Transitions: " + "; ".join(dict.fromkeys(trans)))
        if sc["exit"]:
            lines.append(f"- Exit: {sc['exit']}")
        lines += sc["extra"]
        lines.append("")
    lines += tail
    path = os.path.join(p["k"], "app-map.md")
    write(path, "\n".join(lines))
    return path, len(screens), problems


# ======================================================================== compare (old knowledge vs new)
def cmd_compare(old_dir, repo="."):
    """Counts what two knowledge folders hold, so a rebuild can be shown to lose nothing."""
    def stats(d):
        def cat(sub):
            f = os.path.join(d, sub)
            return "\n".join(read(os.path.join(f, x)) for x in sorted(os.listdir(f))) if os.path.isdir(f) else ""
        kw, loc, app = cat("keywords"), cat("locators"), cat("app")
        amap = read(os.path.join(d, "app-map.md"))
        return {"keywords": len(set(re.findall(r"(?m)^### KW-[A-Z0-9-]+ \| (.+)$", kw))),
                "keywords with a purpose": len(re.findall(r"(?m)^- Purpose: (?!\(not described)", kw)),
                "keywords linked to a screen": len(re.findall(r"(?m)^- Screens: SCREEN-", kw)),
                "flow step mappings": len(re.findall(r"(?m)^### FLOW-", kw)),
                "locator variables": len(set(re.findall(r"\|\s*([$@&]\{[^}]+\})\s*\|", loc))),
                "screens (app knowledge)": len(set(re.findall(r"SCREEN-[A-Z0-9-]+", app))),
                "flows (app knowledge)": len(set(re.findall(r"(?m)^#{2,4} (FLOW-[A-Z0-9-]+)", app))),
                "map screens": len(re.findall(r"(?m)^## SCREEN-", amap)),
                "map screens with an entry route": len(re.findall(r"(?m)^- Entry route", amap)),
                "map screens with a proof element": len(re.findall(r"(?m)^- Proof element: (?!Open question)", amap)),
                "glossary terms": max(0, len(re.findall(r"(?m)^\|", read(os.path.join(d, "glossary.md")))) - 2)}
    a, b = stats(old_dir), stats(P(repo)["k"])
    print(f"{'What':36} {'Before':>8} {'Now':>8}")
    worse = 0
    for k in a:
        mark = "" if b[k] >= a[k] else "  <- fewer"
        worse += bool(mark)
        print(f"{k:36} {a[k]:>8} {b[k]:>8}{mark}")
    print("RESULT " + ("nothing lost" if not worse else f"{worse} item(s) have fewer entries: check them before relying on the new knowledge"))
    return worse


# ======================================================================== render: run-config (facts only)
def render_run_config(ex, repo="."):
    p = P(repo)
    path = os.path.join(p["k"], "run-config.md")
    old = read(path)
    s = ex.summary
    suites = sorted(set(ex.chains) | set((s.get("suite_libraries") or {}).keys()))
    g = [GEN_START, "## Facts from the code (rendered from the extract; never edit by hand)",
         f"- Automation library per suite: " + ("; ".join(f"{k}: {v or 'none found'}" for k, v in sorted((s.get('suite_libraries') or {}).items())) or "-"),
         f"- Folder init files: {', '.join(s.get('init_files') or []) or 'none'}",
         "- Setups in init files: " + ("; ".join(f"{d}: " + ", ".join(f"{k}={v.get('name') if isinstance(v, dict) else v}" for k, v in st.items())
                                          for d, st in (s.get("init_suite_setups") or {}).items() if st) or "none"),
         "- Variable files and their arguments: " + ("; ".join(f"{v['file']} imports {v['import']}" + (f" with {', '.join(v.get('args') or [])}" if v.get("args") else "")
                                                         for v in (s.get("variables_imports") or [])) or "none"),
         f"- Imports the extractor could not follow: {', '.join(map(str, s.get('unresolved_imports') or [])) or 'none'}",
         "- Secrets loading, and how each suite reaches it:"]
    loaders = s.get("secrets_loaders") or {}
    if loaders:
        for suite, ls in sorted(loaders.items()):
            for l in ls:
                g.append(f"  - {suite}: {l.get('via')}")
    else:
        g.append("  - no secrets loader found in the imports")
    g.append("- Import order per suite (depth 0, in file order; the generator imports exactly these lines):")
    for suite in suites:
        rows = [r for r in ex.chains.get(suite, []) if r.get("depth") == 0]
        if rows:
            g.append(f"  - {suite}: " + " | ".join(f"{r['type']} {r['import']}" + (f" {' '.join(r.get('args') or [])}" if r.get("args") else "") for r in rows))
    setups = {}
    for t in ex.tests:
        st = (t.get("suite_settings") or {})
        if t["file"] not in setups:
            setups[t["file"]] = ", ".join(f"{k}: {v.get('name')}" for k, v in st.items() if isinstance(v, dict) and k in ("SuiteSetup", "SuiteTeardown", "TestSetup", "TestTeardown") and v.get("name"))
    g.append("- Suite setup chain per suite: " + ("; ".join(f"{f}: {v}" for f, v in sorted(setups.items()) if v) or "none"))
    g.append(GEN_END)
    gen = "\n".join(g)
    if GEN_START in old and GEN_END in old:
        new = re.sub(re.escape(GEN_START) + r".*?" + re.escape(GEN_END), lambda m: gen, old, flags=re.S)
        if not re.search(r"(?im)^- parallel:", new):     # knowledge from an earlier release: add the switch, off
            new = re.sub(r"(?m)^(- Open questions:)", "- parallel: no   (the team sets yes only when tests may run at the same time: "
                                                      "no single-session user, no shared data changed)\n\\1", new, count=1)
    else:
        top = old.strip() or "\n".join([f"# Run Configuration: {os.path.basename(os.path.abspath(repo))}",
                                        "- Normal command: <AI: from README, argument files, CI or scripts; ask the user once if nothing shows it>",
                                        "- Working folder robot is started from (${EXECDIR}): <AI>",
                                        "- Command-line variables and the defaults they override: <AI: names only>",
                                        "- Environments: <AI: every environment name found and how one is chosen>",
                                        "- How secrets reach the tests: <AI: vault keyword, variables file, .env or --variable; names only>",
                                        "- Environment variables required: <AI: names only>",
                                        "- Browser and headed switch: <AI>",
                                        "- Login retries inside keywords: <AI>",
                                        "- parallel: no   (the team sets yes only when tests may run at the same time: no single-session user, no shared data changed)",
                                        "- health url: none   (optional: a page of the test environment that answers when it is up; tells an environment problem from a script problem)",
                                        "- page load timeout: <AI: the repo's own setting, or 300s, the SeleniumLibrary default>",
                                        "- Open questions: <AI or none>"])
        new = top + "\n\n" + gen
    write(path, new)
    return path


# ======================================================================== migrate (knowledge written by hand before)
def cmd_migrate(repo="."):
    """Moves the meaning from keyword and locator files written by an earlier release (by hand, by the AI)
    into meaning/, so render can take over with no AI work. Existing meaning lines are never overwritten."""
    ex = Extract(repo)
    p = P(repo)
    by_name = defaultdict(list)
    for k in ex.keywords:
        by_name[norm(k["name"])].append(k)
    old_to_new, per_mod, flows_per_mod, done = {}, defaultdict(list), defaultdict(list), 0
    have, _ = read_all_kw_meaning(repo)
    texts = {f: read(os.path.join(p["kw"], f)) for f in sorted(os.listdir(p["kw"]))} if os.path.isdir(p["kw"]) else {}
    for f, text in texts.items():
        for m in re.finditer(r"(?ms)^### (KW-[A-Z0-9-]+) \| (.+?)$(.*?)(?=^### |^## |\Z)", text):
            old_id, name, body = m.group(1), m.group(2).strip(), m.group(3)
            cands = by_name.get(norm(name), [])
            fm = re.search(r"(?m)^- File: ([^:\n]+)", body)
            k = next((c for c in cands if fm and c["file"] == fm.group(1).strip()), cands[0] if cands else None)
            if not k:
                continue
            new_id = ex.kw_id[SX.kid(k)]
            old_to_new[old_id] = new_id
            if new_id in have:
                continue
            g = lambda key: (re.search(r"(?m)^- " + key + r": (.*)$", body) or [None, ""])[1].strip()
            purpose = g("Purpose")
            inferred = "inferred: yes" in purpose
            purpose = re.sub(r"\s*\(inferred: \w+\)\s*$", "", purpose)
            if not inferred or purpose.startswith("("):
                purpose = "-"
            level = g("Level").split(" ")[0] or "-"
            screens = ", ".join(re.findall(r"SCREEN-[A-Z0-9-]+", g("Screens")))
            flows = ", ".join(re.findall(r"FLOW-[A-Z0-9-]+(?:\s*\(step \d+\)|:\d+)?", g("Flows"))).replace(" (step ", ":").replace(")", "")
            per_mod[ex.kw_mod.get(SX.kid(k), "MOD-COMMON")].append(f"{new_id} | {level} | {purpose} | {screens} | {flows}")
            done += 1
    for f, text in texts.items():
        for m in re.finditer(r"(?ms)^### (FLOW-[A-Z0-9-]+) \| (.+?)$(.*?)(?=^### |^## |\Z)", text):
            rows = re.findall(r"(?m)^\|\s*(\d+)\s*\|\s*([^|]+?)\s*\|\s*(KW-[A-Z0-9-]+|GAP)\s*\|", m.group(3))
            if rows:
                mod = "MOD-" + f[4:-3] if f.startswith("MOD-") else "MOD-COMMON"
                flows_per_mod[mod].append((m.group(1), m.group(2).strip(), [(n, st, old_to_new.get(kw, kw)) for n, st, kw in rows]))
    d = os.path.join(p["meaning"], "keyword")
    os.makedirs(d, exist_ok=True)
    for mod in sorted(set(per_mod) | set(flows_per_mod)):
        path = os.path.join(d, f"{mod}.md")
        old = read(path)
        lines = [old.rstrip()] if old.strip() else [f"# Keyword meaning: {mod} (moved from the earlier keyword files)"]
        lines += per_mod.get(mod, [])
        if flows_per_mod.get(mod) and "## Flow step mapping" not in old:
            lines.append("## Flow step mapping")
            for fid, name, rows in flows_per_mod[mod]:
                lines.append(f"{fid} | {name}")
                lines += [f"{n} | {st} | {kw}" for n, st, kw in rows]
        write(path, "\n".join(lines))
    names = read_loc_names(os.path.join(p["meaning"], "locator", "names.md"))
    add = []
    for f in sorted(os.listdir(p["loc"])) if os.path.isdir(p["loc"]) else []:
        for m in re.finditer(r"(?m)^\|\s*LOC-[A-Z0-9-]+\s*\|\s*([$@&]\{[^}]+\})\s*\|\s*([^|]*)\|\s*([^|]*)\|", read(os.path.join(p["loc"], f))):
            var, typ, meaning = m.group(1), m.group(2).strip(), m.group(3).strip()
            if unclear_name(var) and var not in names and meaning:
                names[var] = {"type": typ, "meaning": meaning}
                add.append(f"{var} | {typ or 'element'} | {meaning}")
    if add:
        lp = os.path.join(p["meaning"], "locator", "names.md")
        write(lp, (read(lp).rstrip() + "\n" if read(lp).strip() else "# Locator names that say nothing about the element\n") + "\n".join(add))
    print(f"Moved the meaning of {done} keywords and {sum(len(v) for v in flows_per_mod.values())} flow mappings into meaning/keyword/, "
          f"and {len(add)} locator meanings into meaning/locator/names.md. Next: knowledge_build.py render all, then check.")


# ======================================================================== check (coverage and consistency)
def cmd_check(repo=".", quiet=False):
    ex = Extract(repo)
    p = P(repo)
    kw_text = "\n".join(read(os.path.join(p["kw"], f)) for f in sorted(os.listdir(p["kw"]))) if os.path.isdir(p["kw"]) else ""
    loc_text = "\n".join(read(os.path.join(p["loc"], f)) for f in sorted(os.listdir(p["loc"]))) if os.path.isdir(p["loc"]) else ""
    app_text = "\n".join(read(os.path.join(p["app"], f)) for f in sorted(os.listdir(p["app"]))) if os.path.isdir(p["app"]) else ""
    reg_s, reg_f = app_registry(repo)
    errors, warns = [], []
    kw_in = set(re.findall(r"(?m)^### (KW-[A-Z0-9-]+) \|", kw_text))
    miss_kw = [ex.kw_id[SX.kid(k)] for k in ex.keywords if ex.kw_id[SX.kid(k)] not in kw_in]
    vars_in = set(re.findall(r"\|\s*([$@&]\{[^}]+\})\s*\|", loc_text))
    miss_loc = sorted({l["variable"] for l in ex.locators if l.get("variable") and l["variable"] not in vars_in})
    test_files = sorted({t["file"] for t in ex.tests})
    miss_tests = [f for f in test_files if f not in app_text]
    used_s = set(re.findall(r"SCREEN-[A-Z0-9-]+", kw_text + loc_text))
    used_f = set(re.findall(r"FLOW-[A-Z0-9-]+", kw_text))
    bad_s = sorted(s for s in used_s if reg_s and s not in reg_s)
    bad_f = sorted(f for f in used_f if reg_f and f not in reg_f)
    undescribed = kw_text.count("(not described yet)")
    unlinked = len(re.findall(r"(?m)^- Screens: -$", kw_text))
    unmapped = len(re.findall(r"(?m)^\| LOC-COMMON-", read(os.path.join(p["loc"], "UNMAPPED.md"))))
    placeholders = [f for f in ("run-config.md", "app-map.md", "app-knowledge.md", "glossary.md") if "<AI" in read(os.path.join(p["k"], f))]
    app_map = read(os.path.join(p["k"], "app-map.md"))
    map_screens = re.findall(r"(?ms)^## (SCREEN-[A-Z0-9-]+).*?(?=^## |\Z)", app_map)
    no_route = [m.group(1) for m in re.finditer(r"(?ms)^## (SCREEN-[A-Z0-9-]+)(.*?)(?=^## |\Z)", app_map) if "Entry route" not in m.group(2)]
    no_proof = [m.group(1) for m in re.finditer(r"(?ms)^## (SCREEN-[A-Z0-9-]+)(.*?)(?=^## |\Z)", app_map) if "Proof element" not in m.group(2)]
    missing_files = [f for f in ("app-knowledge.md", "app-map.md", "glossary.md", "run-config.md", "keyword-knowledge.md", "locator-knowledge.md")
                     if not os.path.isfile(os.path.join(p["k"], f))]
    if missing_files:
        errors.append("missing knowledge files: " + ", ".join(missing_files))
    if miss_kw:
        errors.append(f"{len(miss_kw)} keywords of the extract are not in the keyword knowledge (render keyword): " + ", ".join(miss_kw[:15]))
    if miss_loc:
        errors.append(f"{len(miss_loc)} locator variables are not in the locator knowledge (render locator): " + ", ".join(miss_loc[:15]))
    if miss_tests:
        errors.append(f"{len(miss_tests)} test files are not in any app module file: " + ", ".join(miss_tests[:15]))
    if bad_s:
        errors.append("screen IDs used but not defined in the app knowledge: " + ", ".join(bad_s[:15]))
    if bad_f:
        errors.append("flow IDs used but not defined in the app knowledge: " + ", ".join(bad_f[:15]))
    if placeholders:
        errors.append("unfilled <AI ...> lines in: " + ", ".join(placeholders))
    if no_route:
        errors.append("app-map screens without an entry route: " + ", ".join(no_route[:15]))
    if no_proof:
        warns.append("app-map screens without a proof element line: " + ", ".join(no_proof[:15]))
    if undescribed:
        warns.append(f"{undescribed} keywords have no purpose yet (no documentation and no meaning line)")
    if unlinked:
        warns.append(f"{unlinked} keywords are not linked to a screen")
    if unmapped:
        warns.append(f"{unmapped} locators are not tied to a screen (UNMAPPED.md)")
    n_kw, n_loc = len(ex.keywords), len({l['variable'] for l in ex.locators if l.get('variable')})
    res = {"keywords": f"{n_kw - len(miss_kw)} of {n_kw}", "locators": f"{n_loc - len(miss_loc)} of {n_loc}",
           "test_files": f"{len(test_files) - len(miss_tests)} of {len(test_files)}", "screens": len(reg_s), "flows": len(reg_f),
           "app_map_screens": len(map_screens), "errors": errors, "warnings": warns}
    if not quiet:
        print(f"Coverage: keywords {res['keywords']}, locators {res['locators']}, test files {res['test_files']}; "
              f"{res['screens']} screens, {res['flows']} flows, {res['app_map_screens']} screens in the map.")
        for e in errors:
            print("ERROR  " + e)
        for w in warns:
            print("WARN   " + w)
        print("RESULT " + ("PASS" if not errors else "FAIL") + (f" with {len(warns)} warning(s)" if warns else ""))
    return res


# ======================================================================== report (the end of a knowledge build)
def cmd_report(repo="."):
    p = P(repo)
    k = p["k"]
    rel = os.path.relpath(k, repo).replace("\\", "/")
    def count(path, pat):
        return len(re.findall(pat, read(path)))
    rows = []
    def add(label, path, what):
        if os.path.exists(path):
            rows.append(f"- {label}: {os.path.relpath(path, repo).replace(os.sep, '/')} ({what})")
    kw_files = sorted(os.listdir(p["kw"])) if os.path.isdir(p["kw"]) else []
    loc_files = sorted(os.listdir(p["loc"])) if os.path.isdir(p["loc"]) else []
    app_files = sorted(os.listdir(p["app"])) if os.path.isdir(p["app"]) else []
    reg_s, reg_f = app_registry(repo)
    add("Application overview", os.path.join(k, "app-knowledge.md"), f"{len(app_files)} modules, {len(reg_s)} screens, {len(reg_f)} flows")
    add("Application map", os.path.join(k, "app-map.md"), f"{count(os.path.join(k, 'app-map.md'), r'(?m)^## SCREEN-')} screens with routes and preconditions")
    n_terms = max(0, count(os.path.join(k, "glossary.md"), r"(?m)^\|") - 2)
    add("Glossary", os.path.join(k, "glossary.md"), f"{n_terms} term{'' if n_terms == 1 else 's'}")
    add("UI patterns", os.path.join(k, "ui-patterns.md"), "frames, dialogs, dropdowns, waits")
    add("Run configuration", os.path.join(k, "run-config.md"), "command, environments, secrets loading, import order")
    kw_total = sum(count(os.path.join(p["kw"], f), r"(?m)^### KW-") for f in kw_files)
    add("Keyword knowledge", os.path.join(k, "keyword-knowledge.md"), f"{kw_total} keywords in {len(kw_files)} module files under {rel}/keywords/")
    loc_total = sum(count(os.path.join(p["loc"], f), r"(?m)^\| LOC-") for f in loc_files)
    add("Locator knowledge", os.path.join(k, "locator-knowledge.md"), f"{loc_total} locators in {len(loc_files)} screen files under {rel}/locators/")
    if os.path.isdir(os.path.join(k, "dev")):
        add("Development knowledge", os.path.join(k, "dev", "index.md"), f"{len(os.listdir(os.path.join(k, 'dev')))} files under {rel}/dev/")
    add("Status", os.path.join(k, "knowledge-status.md"), "review result per area")
    print(f"Knowledge created in {rel}/")
    print("\n".join(rows))
    c = cmd_check(repo, quiet=True)
    print(f"Coverage: keywords {c['keywords']}, locators {c['locators']}, test files {c['test_files']}." +
          ("" if not c["errors"] else f" {len(c['errors'])} gap(s): run knowledge_build.py check for details."))


# ======================================================================== self-test
def dumpj(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh)


def self_test():
    ok = {}
    tmp = tempfile.mkdtemp(prefix="kb_selftest_")
    cwd = os.getcwd()
    try:
        os.chdir(tmp)
        x = os.path.join("qa-ai-skills", "knowledge", ".extract")
        os.makedirs(x)
        os.makedirs(os.path.join("qa-ai-skills", "knowledge", "app"))
        kws = [
            {"name": "Login To Portal", "file": "resources/common.resource", "line": 5, "documentation": "Logs in to the portal", "arguments": ["${user}", "${password}"],
             "returns": [], "steps": [{"keyword": "Input Text", "args": ["${USER_FIELD}", "${user}"], "line": 6, "context": ""},
                                      {"keyword": "Click Button", "args": ["${LOGIN_BTN}"], "line": 7, "context": ""}], "calls": ["Input Text", "Click Button"],
             "resolved_calls": {"Input Text": [], "Click Button": []}, "used_count": 3},
            {"name": "Open Client", "file": "resources/client.resource", "line": 3, "documentation": "", "arguments": ["${name}"], "returns": [],
             "steps": [{"keyword": "Input Text", "args": ["${SEARCH_INPUT}", "${name}"], "line": 4, "context": ""},
                       {"keyword": "Click Element", "args": ["${LOC_7}"], "line": 5, "context": ""},
                       {"keyword": "Sleep", "args": ["2s"], "line": 6, "context": ""}], "calls": ["Input Text", "Click Element", "Sleep"],
             "resolved_calls": {"Input Text": [], "Click Element": [], "Sleep": []}, "used_count": 2},
            {"name": "Open Client Copy", "file": "resources/client.resource", "line": 10, "documentation": "", "arguments": ["${name}"], "returns": [],
             "steps": [{"keyword": "Input Text", "args": ["${SEARCH_INPUT}", "${name}"], "line": 11, "context": ""},
                       {"keyword": "Click Element", "args": ["${LOC_7}"], "line": 12, "context": ""},
                       {"keyword": "Sleep", "args": ["2s"], "line": 13, "context": ""}], "calls": [], "resolved_calls": {}, "used_count": 0},
            {"name": "Add Address", "file": "resources/client.resource", "line": 20, "documentation": "", "arguments": [], "returns": [],
             "steps": [{"keyword": "Click Button", "args": ["${ADD_ADDRESS_BTN}"], "line": 21, "context": ""}], "calls": ["Click Button"],
             "resolved_calls": {"Click Button": []}, "used_count": 1},
        ]
        tests = [
            {"file": "tests/client/addresses.robot", "name": "Add a home address", "line": 5, "tags": ["TC-1"], "documentation": "",
             "steps": [{"keyword": "Login To Portal", "args": ["${U}", "${P}"], "line": 6, "context": "", "resolved": ["resources/common.resource::Login To Portal"]},
                       {"keyword": "Open Client", "args": ["${C}"], "line": 7, "context": "", "resolved": ["resources/client.resource::Open Client"]},
                       {"keyword": "Add Address", "args": [], "line": 8, "context": "", "resolved": ["resources/client.resource::Add Address"]},
                       {"keyword": "Element Should Be Visible", "args": ["${ADDRESS_GRID}"], "line": 9, "context": "", "resolved": []}],
             "suite_settings": {"SuiteSetup": {"name": "Load Secrets"}}},
            {"file": "tests/client/search.robot", "name": "Find a client", "line": 5, "tags": [], "documentation": "",
             "steps": [{"keyword": "Login To Portal", "args": ["${U}", "${P}"], "line": 6, "context": "", "resolved": ["resources/common.resource::Login To Portal"]},
                       {"keyword": "Open Client", "args": ["${C}"], "line": 7, "context": "", "resolved": ["resources/client.resource::Open Client"]}],
             "suite_settings": {}},
            {"file": "tests/admin/users.robot", "name": "List users", "line": 5, "tags": [], "documentation": "",
             "steps": [{"keyword": "Login To Portal", "args": ["${U}", "${P}"], "line": 6, "context": "", "resolved": ["resources/common.resource::Login To Portal"]}],
             "suite_settings": {}},
        ]
        locs = [
            {"variable": "${USER_FIELD}", "value": "id:username", "file": "resources/common.resource", "line": 2, "origin": "variable",
             "used_by": ["keyword:resources/common.resource::Login To Portal"]},
            {"variable": "${LOGIN_BTN}", "value": "css:[data-testid='login']", "file": "resources/common.resource", "line": 3, "origin": "variable",
             "used_by": ["keyword:resources/common.resource::Login To Portal"]},
            {"variable": "${SEARCH_INPUT}", "value": "xpath://label[normalize-space()='Client']/..//input", "file": "resources/client.resource", "line": 1,
             "origin": "variable", "used_by": ["keyword:resources/client.resource::Open Client", "keyword:resources/client.resource::Open Client Copy"]},
            {"variable": "${LOC_7}", "value": "xpath:/html/body/div[3]/div[2]/span", "file": "resources/client.resource", "line": 2, "origin": "variable",
             "used_by": ["keyword:resources/client.resource::Open Client"]},
            {"variable": "${ADD_ADDRESS_BTN}", "value": "id:mui-12345", "file": "resources/client.resource", "line": 3, "origin": "variable",
             "used_by": ["keyword:resources/client.resource::Add Address"]},
            {"variable": "${ADDRESS_GRID}", "value": "css:[data-testid='addresses']", "file": "resources/client.resource", "line": 4, "origin": "variable",
             "used_by": ["test:tests/client/addresses.robot::Add a home address"]},
        ]
        dumpj(os.path.join(x, "keywords.json"), kws)
        dumpj(os.path.join(x, "tests.json"), tests)
        dumpj(os.path.join(x, "locators.json"), locs)
        dumpj(os.path.join(x, "variables.json"), [])
        dumpj(os.path.join(x, "routes.json"), {"resources/client.resource::Open Client": {"tests_using": 2, "always_before": ["resources/common.resource::Login To Portal"],
                                                               "example_routes": [{"source_test": "tests/client/search.robot::Find a client",
                                                                                   "route": ["Login To Portal    ${U}    ${P}", "Open Client    ${C}"]}]}})
        dumpj(os.path.join(x, "import-chains.json"), {"tests/client/addresses.robot": [{"depth": 0, "type": "Resource", "import": "../../resources/client.resource", "file": "resources/client.resource",
                                                     "args": []},
                                                    {"depth": 1, "type": "Resource", "import": "common.resource", "file": "resources/common.resource", "args": []}]})
        dumpj(os.path.join(x, "summary.json"), {"libraries_per_file": {"resources/common.resource": "SeleniumLibrary", "resources/client.resource": "SeleniumLibrary"},
                   "suite_libraries": {"tests/client/addresses.robot": "SeleniumLibrary"}, "init_files": [], "init_suite_setups": {},
                   "variables_imports": [], "unresolved_imports": [], "test_organisation": "many-tests-per-suite",
                   "secrets_loaders": {"tests/client/addresses.robot": [{"file": "resources/secrets.resource",
                                                                         "via": "tests/client/addresses.robot -> resources/common.resource -> resources/secrets.resource"}]}})
        with open(os.path.join("qa-ai-skills", "knowledge", "app", "MOD-CLIENT.md"), "w") as fh:
            fh.write("# Module: Client (MOD-CLIENT)\n## Screens\n### SCREEN-CLIENT-SEARCH | Client search\n### SCREEN-CLIENT-ADDRESSES | Addresses tab\n"
                     "## Flows\n### FLOW-CLIENT-ADD-ADDRESS | Add an address\n- Steps:\n  1. Log in\n  2. Open the client\n  3. Add the address\n"
                     "- Source tests: tests/client/addresses.robot::Add a home address; tests/client/search.robot::Find a client\n")
        os.makedirs(os.path.join("qa-ai-skills", "knowledge", "keywords"))
        with open(os.path.join("qa-ai-skills", "knowledge", "keywords", "MOD-CLIENT.md"), "w") as fh:
            fh.write("# Keywords: Client\n## Flow step mapping\n### FLOW-CLIENT-ADD-ADDRESS | Add an address\n| # | Business step | Keyword ID | Keyword call |\n"
                     "| 1 | Log in | KW-COMMON-LOGIN-TO-PORTAL | Login To Portal |\n| 2 | Open the client | KW-CLIENT-OPEN-CLIENT | Open Client |\n"
                     "## Keywords\n### KW-CLIENT-OPEN-CLIENT | Open Client\n- File: resources/client.resource:3\n- Level: page\n"
                     "- Purpose: Opens a client from search (inferred: yes)\n- Screens: SCREEN-CLIENT-SEARCH\n- Flows: FLOW-CLIENT-ADD-ADDRESS (step 2)\n"
                     "### KW-COMMON-LOGIN-TO-PORTAL | Login To Portal\n- File: resources/common.resource:5\n- Level: flow\n- Purpose: Logs in (inferred: no)\n- Screens: -\n- Flows: -\n")
        import io, contextlib
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_migrate(".")
        mig, mfl = read_all_kw_meaning(".")
        ok["migrate: meaning of hand-written keyword files moved, old IDs translated"] = \
            mig.get("KW-OPEN-CLIENT", {}).get("purpose") == "Opens a client from search" and mig["KW-OPEN-CLIENT"]["flows"] == ["FLOW-CLIENT-ADD-ADDRESS:2"] \
            and mig.get("KW-LOGIN-TO-PORTAL", {}).get("purpose") == "" and mfl["FLOW-CLIENT-ADD-ADDRESS"]["steps"][0][2] == "KW-LOGIN-TO-PORTAL"
        shutil.rmtree(os.path.join("qa-ai-skills", "knowledge", "meaning"))
        shutil.rmtree(os.path.join("qa-ai-skills", "knowledge", "keywords"))
        ex = Extract(".")
        ok["modules and stable keyword IDs (by name, not by module)"] = set(ex.briefs) >= {"MOD-CLIENT", "MOD-ADMIN"} and \
            ex.kw_id["resources/client.resource::Open Client"] == "KW-OPEN-CLIENT" and len(set(ex.kw_id.values())) == 4
        import io, contextlib
        buf = io.StringIO()
        mod = ex.kw_mod["resources/client.resource::Open Client"]
        with contextlib.redirect_stdout(buf):
            cmd_worksheet("keyword", mod, ".")
        ws = buf.getvalue()
        ok["keyword worksheet: one compact line per keyword, with flows and screens to link"] = \
            "Open Client | resources/client.resource:3" in ws and "(no documentation)" in ws and "FLOW-CLIENT-ADD-ADDRESS" in ws \
            and len(ws) < 4000
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_worksheet("locator", mod, ".")
        ok["locator worksheet asks only about names that say nothing (${LOC_7})"] = "${LOC_7}" in buf.getvalue() and "${SEARCH_INPUT}" not in buf.getvalue()
        oc, aa = ex.kw_id["resources/client.resource::Open Client"], ex.kw_id["resources/client.resource::Add Address"]
        os.makedirs(os.path.join("qa-ai-skills", "knowledge", "meaning", "keyword"))
        with open(os.path.join("qa-ai-skills", "knowledge", "meaning", "keyword", f"{mod}.md"), "w") as fh:
            fh.write(f"# Keyword meaning: {mod}\n{oc} | page | Searches a client and opens its page | SCREEN-CLIENT-SEARCH | FLOW-CLIENT-ADD-ADDRESS:2\n"
                     f"{aa} | step | Starts adding an address | SCREEN-CLIENT-ADDRESSES | FLOW-CLIENT-ADD-ADDRESS:3\n"
                     "## Flow step mapping\nFLOW-CLIENT-ADD-ADDRESS | Add an address\n"
                     f"1 | Log in | {ex.kw_id['resources/common.resource::Login To Portal']}\n2 | Open the client | {oc}\n3 | Add the address | {aa}\n4 | Check the grid | GAP\n")
        os.makedirs(os.path.join("qa-ai-skills", "knowledge", "meaning", "locator"))
        with open(os.path.join("qa-ai-skills", "knowledge", "meaning", "locator", "names.md"), "w") as fh:
            fh.write("${LOC_7} | link | First client in the search results\n")
        kf, problems = render_keywords(ex, ".")
        ktext = read(os.path.join("qa-ai-skills", "knowledge", "keywords", f"{mod}.md"))
        ok["keyword file: every fact rendered (file, arguments, calls, locators, users)"] = \
            f"### {oc} | Open Client" in ktext and "- File: resources/client.resource:3" in ktext and "${SEARCH_INPUT}" in ktext and \
            "- Used by: 2 tests" in ktext and "Searches a client and opens its page (inferred: yes)" in ktext
        ok["keyword file: duplicates, preferred, Sleep and unused found by the script"] = \
            "duplicate of" in ktext and "uses a fixed Sleep" in ktext and "- Status: unused" in ktext
        ok["keyword file: flow step mapping with the call, gaps kept"] = "| 2 | Open the client |" in ktext and "| 4 | Check the grid | GAP |" in ktext
        idx = read(os.path.join("qa-ai-skills", "knowledge", "keyword-knowledge.md"))
        ok["keyword index: registry, library keywords, coverage, findings"] = "## Registry" in idx and "| Click Button |" in idx and \
            "Flows fully mapped: 0 of 1" in idx and "Keywords with a fixed Sleep: 2" in idx
        with open(os.path.join("qa-ai-skills", "knowledge", "meaning", "locator", "dev-suggestions.md"), "w") as fh:
            fh.write("${SEARCH_INPUT} | stronger | css:[data-testid='client-search'] | the development code gives this field a test ID\n")
        lf, rows = render_locators(ex, ".")
        ok["development-code suggestions rendered next to the locator (not applied)"] = \
            "Stronger option: `css:[data-testid='client-search']`" in read(os.path.join("qa-ai-skills", "knowledge", "locators", "SCREEN-CLIENT-SEARCH.md"))
        ltext = read(os.path.join("qa-ai-skills", "knowledge", "locators", "SCREEN-CLIENT-SEARCH.md"))
        ok["locator files: grouped by screen through the keywords that use them"] = "| LOC-CLIENT-SEARCH-SEARCH-INPUT | ${SEARCH_INPUT} |" in ltext and \
            os.path.isfile(os.path.join("qa-ai-skills", "knowledge", "locators", "SCREEN-CLIENT-ADDRESSES.md"))
        r = {x["var"]: x for x in rows}
        ok["stability rated by rule (test id High, label Medium, absolute and generated Low)"] = r["${LOGIN_BTN}"]["stability"] == "High" and \
            r["${SEARCH_INPUT}"]["stability"] == "Medium" and r["${LOC_7}"]["stability"] == "Low" and r["${ADD_ADDRESS_BTN}"]["stability"] == "Low"
        ok["element type and meaning: from the name, or the AI's names.md line"] = r["${ADD_ADDRESS_BTN}"]["type"] == "button" and \
            r["${ADD_ADDRESS_BTN}"]["meaning"] == "Add address button" and r["${LOC_7}"]["meaning"] == "First client in the search results"
        ok["locators used only by tests are kept (not tied to a screen yet)"] = "${ADDRESS_GRID}" in read(os.path.join("qa-ai-skills", "knowledge", "locators", "UNMAPPED.md"))
        os.makedirs(os.path.join("qa-ai-skills", "knowledge", "meaning", "app"), exist_ok=True)
        with open(os.path.join("qa-ai-skills", "knowledge", "meaning", "app", "screens.md"), "w") as fh:
            fh.write(f"SCREEN-CLIENT-SEARCH | Client search | MOD-CLIENT | {oc} | logged in |  | back to the home page\n"
                     "- Blocking messages: none known\n"
                     f"SCREEN-CLIENT-ADDRESSES | Addresses tab | MOD-CLIENT | {aa} | client page open | ${{ADDRESS_GRID}} |\n")
        mp, nscr, mprob = render_app_map(ex, ".")
        mt = read(mp)
        ok["app map: entry keyword, entry route copied from a real test, transitions, extra lines"] = nscr == 2 and \
            "- Entry keyword: Open Client (resources/client.resource:3)" in mt and "1. Login To Portal    ${U}    ${P}" in mt and \
            "- Always run before it: Login To Portal" in mt and "- Blocking messages: none known" in mt and "Proof element: ${ADDRESS_GRID}" in mt
        ok["app map: missing proof element becomes an open question, never invented"] = "Proof element: Open question" in mt
        rc = render_run_config(ex, ".")
        rct = read(rc)
        ok["run-config: facts rendered (library, secrets path, import order, suite setup), AI lines marked"] = \
            "resources/common.resource -> resources/secrets.resource" in rct and "Resource ../../resources/client.resource" in rct and \
            "SuiteSetup: Load Secrets" in rct and "<AI" in rct
        with open(rc, "w") as fh:
            fh.write(rct.replace("<AI: from README, argument files, CI or scripts; ask the user once if nothing shows it>", "robot -d results tests")
                     .replace("<AI or none>", "none"))
        render_run_config(ex, ".")
        ok["run-config: a re-render keeps the AI's lines and refreshes only the facts"] = "robot -d results tests" in read(rc) and read(rc).count(GEN_START) == 1
        with open(os.path.join("qa-ai-skills", "knowledge", "keywords", f"{mod}.md"), "a") as fh:
            fh.write("\n## Notes\n- learned: the search needs two characters\n")
        render_keywords(ex, ".")
        ok["hand-written Notes kept when re-rendering"] = "the search needs two characters" in read(os.path.join("qa-ai-skills", "knowledge", "keywords", f"{mod}.md"))
        old_k = os.path.join(tmp, "oldk")
        shutil.copytree(os.path.join("qa-ai-skills", "knowledge"), old_k)
        with contextlib.redirect_stdout(io.StringIO()):
            worse_same = cmd_compare(old_k, ".")
        with open(os.path.join(old_k, "app-map.md"), "a") as fh:
            fh.write("## SCREEN-X | X\n- Entry route (from t):\n## SCREEN-Y | Y\n- Entry route (from t):\n## SCREEN-Z | Z\n- Entry route (from t):\n")
        with contextlib.redirect_stdout(io.StringIO()):
            worse_more = cmd_compare(old_k, ".")
        ok["compare: same knowledge shows nothing lost; fewer map screens are flagged"] = worse_same == 0 and worse_more >= 1
        res = cmd_check(".", quiet=True)
        ok["check: every keyword and locator of the extract is covered"] = res["keywords"] == "4 of 4" and res["locators"] == "6 of 6"
        ok["check: finds test files with no app module, missing files and placeholders"] = \
            any("tests/admin/users.robot" in e for e in res["errors"]) and any("missing knowledge files" in e for e in res["errors"]) and \
            any("<AI" in e for e in res["errors"])
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_report(".")
        ok["report lists what was created, where, with counts"] = "Knowledge created in qa-ai-skills/knowledge/" in buf.getvalue() and \
            "4 keywords in" in buf.getvalue() and "6 locators in" in buf.getvalue()
        import time as _t
        t0 = _t.time()
        big_k = [dict(kws[1], name=f"Do Thing {i}", line=i, file=f"resources/m{i % 20}.resource") for i in range(1500)]
        big_l = [dict(locs[2], variable=f"${{FIELD_{i}}}", value=f"css:[data-testid='f{i}']", file=f"resources/m{i % 20}.resource", line=i,
                      used_by=[f"keyword:resources/m{i % 20}.resource::Do Thing {i}"]) for i in range(3000)]
        dumpj(os.path.join(x, "keywords.json"), kws + big_k)
        dumpj(os.path.join(x, "locators.json"), locs + big_l)
        ex2 = Extract(".")
        render_keywords(ex2, ".")
        render_locators(ex2, ".")
        ok["1,500 keywords and 3,000 locators rendered in under 20 seconds"] = _t.time() - t0 < 20 and cmd_check(".", quiet=True)["locators"] == "3006 of 3006"
        kt2 = "\n".join(read(os.path.join("qa-ai-skills", "knowledge", "keywords", f)) for f in os.listdir(os.path.join("qa-ai-skills", "knowledge", "keywords")))
        ok["the saved meaning survives modules being regrouped"] = "Searches a client and opens its page" in kt2 and "| 1 | Log in | KW-LOGIN-TO-PORTAL | Login To Portal" in kt2
    finally:
        os.chdir(cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    print()
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] == ["--self-test"]:
        return self_test()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("worksheet"); w.add_argument("stage", choices=["app", "keyword", "locator", "all"]); w.add_argument("module", nargs="+")
    r = sub.add_parser("render"); r.add_argument("what", choices=["keyword", "locator", "app-map", "run-config", "all"])
    c = sub.add_parser("compare"); c.add_argument("old_knowledge_folder")
    sub.add_parser("check"); sub.add_parser("report"); sub.add_parser("migrate")
    a = ap.parse_args(argv)
    if a.cmd == "worksheet":
        cmd_worksheet(a.stage, a.module if len(a.module) > 1 or a.stage == "all" else a.module[0])
    elif a.cmd == "render":
        ex = Extract(".")
        if a.what in ("keyword", "all"):
            files, problems = render_keywords(ex)
            print(f"Keyword knowledge: {len(ex.keywords)} keywords in {len(files)} module files." +
                  (f" {len(problems)} to look at: " + "; ".join(problems[:10]) if problems else ""))
        if a.what in ("locator", "all"):
            files, rows = render_locators(ex)
            c = Counter(r["stability"] for r in rows)
            print(f"Locator knowledge: {len(rows)} locators in {len(files)} screen files ({c['High']} High, {c['Medium']} Medium, {c['Low']} Low).")
        if a.what in ("app-map", "all") and read_screens():
            path, n, problems = render_app_map(ex)
            print(f"Application map: {n} screens with entry routes from the code in {path}." + (" " + "; ".join(problems[:10]) if problems else ""))
        if a.what in ("run-config", "all"):
            path = render_run_config(ex)
            left = read(path).count("<AI")
            print(f"Run configuration facts written to {path}" + (f"; {left} line(s) for you to fill (marked <AI ...>)." if left else "."))
    elif a.cmd == "check":
        return 1 if cmd_check()["errors"] else 0
    elif a.cmd == "report":
        cmd_report()
    elif a.cmd == "migrate":
        cmd_migrate()
    elif a.cmd == "compare":
        return 1 if cmd_compare(a.old_knowledge_folder) else 0
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(0)
