#!/usr/bin/env python3
"""
split_extract.py - cuts the QA extract into one small brief per module, decides what must be (re)built,
and records what was built. Part of the QA AI skills; used by qa-knowledge-setup. No AI tokens.

Why: builders (and sub-agents) must never read the whole repo or the whole extract. Each one reads
only its module's brief. A module whose brief and builder rules did not change since it was last
built is skipped.

Commands (run from the QA repo folder; all print JSON):
  plan [--rebuild] [--extract knowledge/.extract] [--knowledge knowledge] [--skills skills]
       writes knowledge/.tmp/briefs/<MODULE>/brief.json for every module (plus COMMON for keywords and
       locators shared by several modules), and prints per stage (app, keyword, locator) which modules
       are changed or unchanged, the brief sizes, and whether sub-agents are worth using.
  record --stage app|keyword|locator <MODULE> [<MODULE> ...] [--wrote <file> ...]
       after a module's knowledge files are written: stores its fingerprint, the builder rules it was
       built with and the files written (default <stage folder>/<MODULE>.md; locator screen files are
       passed with --wrote) in knowledge/build-state.json.
  next [--budget-kb 60] [--max 8]
       the next batch of modules to build: most-used first (modules whose keywords many others call), small
       modules grouped so one pass covers several, a big one alone; with done/total and minutes left.
       Resumes by itself: recorded modules are never offered again.
  record --stage all <MODULE> ...   records the three stages of a whole batch in one call.
  A module is rebuilt when its part of the extract changed or a recorded file is missing (refresh),
  or always (rebuild). Modules built with older builder rules are listed, not rebuilt, on refresh.
  --self-test

Modules come from the test folders (first folder under the common test root; one folder -> one module
per suite file), with `module_map:` overrides from knowledge/config.yaml (`  <folder or tag>: <Name>`).
Python 3.8+, standard library only.
"""
import argparse, datetime, hashlib, json, os, re, shutil, sys, tempfile
from collections import defaultdict

STAGES = {"app": ("app-knowledge-builder.md", "app"), "keyword": ("keyword-knowledge-builder.md", "keywords"),
          "locator": ("locator-knowledge-builder.md", "locators")}
SUB_AGENT_MIN_TEST_FILES = 40      # below this, one agent is faster and cheaper
SUB_AGENT_MIN_CHANGED = 3          # and only when at least this many modules need building
MAX_PARALLEL = 4
def ai_home(repo="."):
    """All AI files live in <QA repo>/qa-ai-skills/ (knowledge, generated tests, results, session).
    A repo set up before that folder existed keeps using the repo root."""
    d = os.path.join(repo, "qa-ai-skills")
    return d if os.path.isdir(d) else repo

COMMON_SPLIT_BYTES = 300_000       # a larger shared brief is cut into one brief per resource file


def jload(path, default):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def canon(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def mod_id(name):
    return "MOD-" + (re.sub(r"[^A-Z0-9]+", "-", str(name).upper()).strip("-") or "MAIN")


def read_module_map(knowledge):
    """`module_map:` block of knowledge/config.yaml as {folder or tag (lower): name}. No YAML library needed."""
    p = os.path.join(knowledge, "config.yaml")
    out, inside = {}, False
    if not os.path.isfile(p):
        return out
    for line in open(p, encoding="utf-8"):
        if re.match(r"^module_map\s*:", line):
            inside = True
            continue
        if inside:
            m = re.match(r"^\s+['\"]?([^:'\"]+?)['\"]?\s*:\s*['\"]?([^'\"#\n]+?)['\"]?\s*(#.*)?$", line)
            if m:
                out[m.group(1).strip().lower()] = m.group(2).strip()
            elif line.strip() and not line.startswith((" ", "\t")):
                inside = False
    return out


def assign_modules(tests, module_map):
    files = sorted({t["file"] for t in tests})
    dirs = [os.path.dirname(f).replace("\\", "/") for f in files]
    common = os.path.commonpath(dirs).replace("\\", "/") if dirs and all(dirs) else ""
    by_file = {}
    for f in files:
        d = os.path.dirname(f).replace("\\", "/")
        rest = d[len(common):].strip("/") if d.startswith(common) else d
        first = rest.split("/")[0] if rest else ""
        name = first or os.path.splitext(os.path.basename(f))[0]
        for key in (d.lower(), first.lower(), os.path.basename(f).lower()):
            if key and key in module_map:
                name = module_map[key]
        by_file[f] = name
    for t in tests:                                            # a tag in module_map wins
        for tag in t.get("tags", []):
            if str(tag).lower() in module_map:
                by_file[t["file"]] = module_map[str(tag).lower()]
    return {f: mod_id(n) for f, n in by_file.items()}


def kid(k):
    return f'{k["file"]}::{k["name"]}'


def build_briefs(extract, knowledge):
    tests = jload(os.path.join(extract, "tests.json"), [])
    keywords = jload(os.path.join(extract, "keywords.json"), [])
    locators = jload(os.path.join(extract, "locators.json"), [])
    variables = jload(os.path.join(extract, "variables.json"), [])
    routes = jload(os.path.join(extract, "routes.json"), {})
    signals = jload(os.path.join(extract, "ui-signals.json"), {"messages": []})
    links = jload(os.path.join(extract, "dev", "dev-links.json"), {"links": []})
    if not tests:
        raise SystemExit(json.dumps({"error": f"No tests.json in {extract}: run extract_repo.py first"}))
    file_mod = assign_modules(tests, read_module_map(knowledge))
    kw_by_id = {kid(k): k for k in keywords}

    # which modules reach each keyword (tests -> resolved calls, transitively)
    reach = defaultdict(set)
    def walk(k_id, mod, seen):
        if k_id in seen or k_id not in kw_by_id:
            return
        seen.add(k_id)
        reach[k_id].add(mod)
        for targets in (kw_by_id[k_id].get("resolved_calls") or {}).values():
            for tgt in targets:
                walk(tgt, mod, seen)
    for t in tests:
        mod, seen = file_mod[t["file"]], set()
        for s in t.get("steps", []):
            for tgt in s.get("resolved", []):
                walk(tgt, mod, seen)
    # a resource file belongs to one module when only that module uses it; otherwise to COMMON
    file_users = defaultdict(set)
    for k in keywords:
        file_users[k["file"]] |= reach.get(kid(k), set())
    def owner_of_file(f):
        if f in file_mod:
            return file_mod[f]
        users = file_users.get(f, set())
        return next(iter(users)) if len(users) == 1 else "MOD-COMMON"
    for l in locators:                                           # locator-only files: by who uses them
        if l["file"] not in file_users:
            for ref in l.get("used_by", []):
                owner_file = ref.split(":", 1)[1].split("::")[0] if ":" in ref else ""
                file_users[l["file"]] |= ({file_mod[owner_file]} if owner_file in file_mod else
                                          {owner_of_file(owner_file)} if owner_file else set())

    briefs = defaultdict(lambda: {"module": None, "test_files": [], "tests": [], "keywords_owned": [],
                                  "keywords_called_from_elsewhere": [], "locators_owned": [], "variables_owned": [],
                                  "routes": {}, "messages": [], "dev_links": [], "owned_files": []})
    for t in tests:
        b = briefs[file_mod[t["file"]]]
        b["tests"].append(t)
        if t["file"] not in b["test_files"]:
            b["test_files"].append(t["file"])
    owned_files = defaultdict(set)
    for k in keywords:
        mod = owner_of_file(k["file"])
        briefs[mod]["keywords_owned"].append(k)
        owned_files[mod].add(k["file"])
    for l in locators:
        mod = owner_of_file(l["file"])
        briefs[mod]["locators_owned"].append(l)
        owned_files[mod].add(l["file"])
    for v in variables:
        mod = owner_of_file(v["file"])
        if v["file"] in owned_files[mod] or v["file"] in file_mod:
            briefs[mod]["variables_owned"].append(v)
    if "MOD-COMMON" in briefs and len(canon(briefs["MOD-COMMON"])) > COMMON_SPLIT_BYTES:
        big = briefs.pop("MOD-COMMON")
        for f in sorted(owned_files.pop("MOD-COMMON", set())):
            part = mod_id("COMMON-" + os.path.splitext(os.path.basename(f))[0])
            briefs[part]["keywords_owned"] = [k for k in big["keywords_owned"] if k["file"] == f]
            briefs[part]["locators_owned"] = [l for l in big["locators_owned"] if l["file"] == f]
            briefs[part]["variables_owned"] = [v for v in big["variables_owned"] if v["file"] == f]
            owned_files[part] = {f}
    for mod, b in list(briefs.items()):
        b["module"] = mod
        b["owned_files"] = sorted(owned_files[mod] | set(b["test_files"]))
        mine = {kid(k) for k in b["keywords_owned"]}
        used = {k_id for k_id, mods in reach.items() if mod in mods} - mine
        b["keywords_called_from_elsewhere"] = sorted(
            ({"id": k_id, "name": kw_by_id[k_id]["name"], "file": kw_by_id[k_id]["file"],
              "module": owner_of_file(kw_by_id[k_id]["file"]),
              "arguments": kw_by_id[k_id].get("arguments"),
              "documentation": (kw_by_id[k_id].get("documentation") or "").split("\n")[0][:200]}
             for k_id in used if k_id in kw_by_id), key=lambda x: x["id"])
        b["routes"] = {k_id: routes[k_id] for k_id in sorted(mine | used) if k_id in routes}
        files = set(b["owned_files"])
        b["messages"] = [m for m in signals.get("messages", []) if m.get("where", "").split(":")[0] in files]
        b["dev_links"] = [l for l in links.get("links", []) if l.get("qa_file") in files]
        b["tests"].sort(key=lambda t: (t["file"], t["line"]))
    return dict(briefs), file_mod


EXTRACT_FILES = ("tests.json", "keywords.json", "locators.json", "variables.json", "routes.json", "ui-signals.json",
                 os.path.join("dev", "dev-links.json"))


def cached_briefs(extract, knowledge):
    """build_briefs, cached on disk (plain JSON) until an extract file or the module map changes. On a large
    repo this turns every worksheet call after the first from seconds into milliseconds."""
    stamp = []
    for f in EXTRACT_FILES + (os.path.join("..", "config.yaml"),):
        try:
            st_ = os.stat(os.path.join(extract, f))
            stamp.append([f, st_.st_size, st_.st_mtime_ns])
        except OSError:
            stamp.append([f, None, None])
    try:
        stamp.append(["module_map", sha(canon(read_module_map(knowledge)))])
    except Exception:
        pass
    stamp.append(["split", COMMON_SPLIT_BYTES])
    key = sha(canon(stamp))
    cache = os.path.join(knowledge, ".tmp", "briefs-cache.json")
    c = jload(cache, None)
    if c and c.get("key") == key:
        return c["briefs"], c["file_mod"]
    briefs, file_mod = build_briefs(extract, knowledge)
    try:
        os.makedirs(os.path.dirname(cache), exist_ok=True)
        tmp = cache + ".part"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"key": key, "briefs": briefs, "file_mod": file_mod}, fh, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, cache)
    except OSError:
        pass
    return briefs, file_mod


def stage_view(brief, stage):
    """The part of a brief each stage depends on (its fingerprint input)."""
    if stage == "app":
        view = {k: brief[k] for k in ("tests", "keywords_called_from_elsewhere", "routes", "messages", "dev_links")}
        view["own"] = [(k["file"], k["name"], k.get("documentation"), k.get("calls")) for k in brief["keywords_owned"]]
        return view
    if stage == "keyword":
        return {"keywords_owned": brief["keywords_owned"], "callers": [(t["file"], t["name"]) for t in brief["tests"]]}
    return {"locators_owned": brief["locators_owned"], "variables_owned": brief["variables_owned"],
            "keywords": [(k["file"], k["name"]) for k in brief["keywords_owned"]], "dev_links": brief["dev_links"]}


def skill_hash(skills, stage):
    p = os.path.join(skills, STAGES[stage][0])
    try:
        return sha(open(p, encoding="utf-8").read())
    except OSError:
        return "no-skill-file"


def cmd_plan(extract, knowledge, skills, rebuild=False):
    briefs, file_mod = cached_briefs(extract, knowledge)
    bdir = os.path.join(knowledge, ".tmp", "briefs")
    if os.path.isdir(bdir):
        shutil.rmtree(bdir, ignore_errors=True)
    state = jload(os.path.join(knowledge, "build-state.json"), {})
    plan = {"modules": [], "stages": {}, "rebuild": rebuild, "brief_folder": bdir.replace("\\", "/")}
    for mod in sorted(briefs):
        b = briefs[mod]
        path = os.path.join(bdir, mod, "brief.json")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        b["fingerprints"] = {st: sha(canon(stage_view(b, st))) for st in STAGES}
        b["rules"] = {st: skill_hash(skills, st) for st in STAGES}
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(b, fh, indent=1, ensure_ascii=False)
        plan["modules"].append({"module": mod, "tests": len(b["tests"]), "test_files": len(b["test_files"]),
                                "keywords": len(b["keywords_owned"]), "locators": len(b["locators_owned"]),
                                "brief": path.replace("\\", "/"), "brief_kb": round(os.path.getsize(path) / 1024, 1)})
    test_files = len(file_mod)
    for st, (_, folder) in STAGES.items():
        changed, unchanged, older_rules = [], [], []
        for mod in sorted(briefs):
            if st == "app" and not briefs[mod]["tests"]:
                continue                                  # COMMON has no tests: no app module file
            done = state.get(st, {}).get(mod, {})
            files = done["files"] if "files" in done else evidence(st, mod, briefs[mod])
            same = done.get("fingerprint") == briefs[mod]["fingerprints"][st] and \
                all(os.path.isfile(os.path.join(knowledge, f)) for f in files)
            (unchanged if same and not rebuild else changed).append(mod)
            if same and not rebuild and done.get("rules") != briefs[mod]["rules"][st]:
                older_rules.append(mod)
        not_in_extract = sorted(set(state.get(st, {})) - set(briefs))
        subs = test_files >= SUB_AGENT_MIN_TEST_FILES and len(changed) >= SUB_AGENT_MIN_CHANGED
        plan["stages"][st] = {
            "changed": changed, "unchanged": unchanged, "built_with_older_rules": older_rules,
            "not_in_this_extract": not_in_extract, "use_sub_agents": subs,
            "max_parallel": min(MAX_PARALLEL, len(changed)) if subs else 1,
            "reason": (f"{test_files} test files and {len(changed)} modules to build: sub-agents save time" if subs else
                       f"{test_files} test files and {len(changed)} modules to build: one agent is faster and cheaper")}
    plan["test_files"] = test_files
    # most-used first: a module whose keywords many other modules call comes before a module used by one
    callers = defaultdict(set)
    for mod, b in briefs.items():
        for k in b["keywords_called_from_elsewhere"]:
            callers[k["module"]].add(mod)
    for m in plan["modules"]:
        m["used_by_modules"] = len(callers.get(m["module"], set()) - {m["module"]})
        m["weight"] = m["tests"] + 10 * m["used_by_modules"] + m["keywords"]
    plan["planned_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    with open(os.path.join(knowledge, ".tmp", "plan.json"), "w", encoding="utf-8") as fh:
        json.dump({**plan, "fingerprints": {m: briefs[m]["fingerprints"] for m in briefs}}, fh, indent=1)
    return plan


BATCH_KB = 60          # worksheet size one AI pass handles well: small modules are grouped, a big one goes alone
BATCH_MAX = 8


def pending_modules(knowledge):
    plan = jload(os.path.join(knowledge, ".tmp", "plan.json"), None)
    if not plan:
        raise SystemExit(json.dumps({"error": "no plan yet: run split_extract.py plan first"}))
    state = jload(os.path.join(knowledge, "build-state.json"), {})
    todo = set()
    for st, info in plan["stages"].items():
        for mod in info["changed"]:
            done = state.get(st, {}).get(mod, {})
            if done.get("fingerprint") != plan["fingerprints"][mod][st] or plan.get("rebuild") and done.get("recorded", "") < plan["planned_at"]:
                todo.add(mod)
    mods = {m["module"]: m for m in plan["modules"]}
    order = sorted(todo, key=lambda m: (-mods[m].get("weight", 0), m))
    everything = set().union(*[set(i["changed"]) for i in plan["stages"].values()]) if plan["stages"] else set()
    return plan, mods, order, everything


def cmd_next(knowledge, budget_kb=BATCH_KB, max_mods=BATCH_MAX):
    """The next batch to build, most-used modules first, sized so one pass stays fast; with progress and time left."""
    plan, mods, order, everything = pending_modules(knowledge)
    total, left = len(everything), len(order)
    done = total - left
    batch, size = [], 0.0
    for m in order:
        kb = mods[m].get("brief_kb", 1)
        if batch and (size + kb > budget_kb or len(batch) >= max_mods):
            break
        batch.append(m)
        size += kb
    eta = None
    if done:
        try:
            secs = (datetime.datetime.now() - datetime.datetime.fromisoformat(plan["planned_at"])).total_seconds()
            eta = max(1, round(secs / done * left / 60))
        except Exception:
            eta = None
    if not batch:
        return {"batch": [], "done": done, "total": total, "left": 0,
                "say": f"All {total} modules built. Next: knowledge_build.py render all, then check."}
    say = (f"Batch: {', '.join(batch)} ({done} of {total} modules done" +
           (f", about {eta} min left" if eta else "") + ")")
    return {"batch": batch, "done": done, "total": total, "left": left, "batch_kb": round(size, 1), "eta_min": eta, "say": say,
            "worksheets": "python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py worksheet all " + " ".join(batch),
            "record": "python qa-ai-skills/skills/qa-knowledge-setup/split_extract.py record --stage all " + " ".join(batch)}


def evidence(stage, mod, brief):
    """What a built module leaves behind (format 4): the app module file (if it has tests) and the keyword
    meaning file (if it owns keywords). Locator files are rendered from the extract, so they need none."""
    if stage == "app":
        return [f"app/{mod}.md"] if brief.get("tests") else []
    if stage == "keyword":
        return [f"meaning/keyword/{mod}.md"] if brief.get("keywords_owned") else []
    return []


def cmd_record(knowledge, stage, mods, wrote=None):
    if stage == "all":                                  # one call for the three stages of a whole batch
        res = {"recorded": [], "stage": "all"}
        for st in STAGES:
            cmd_record(knowledge, st, mods, None)
        res["recorded"] = list(mods)
        return res
    bdir = os.path.join(knowledge, ".tmp", "briefs")
    path = os.path.join(knowledge, "build-state.json")
    state = jload(path, {})
    done = []
    for mod in mods:
        b = jload(os.path.join(bdir, mod, "brief.json"), None)
        if not b:
            raise SystemExit(json.dumps({"error": f"no brief for {mod}: run plan first"}))
        files = [f.replace("\\", "/") for f in (wrote or evidence(stage, mod, b))]
        files = [f[len(knowledge) + 1:] if f.startswith(knowledge.rstrip("/") + "/") else f for f in files]
        missing = [f for f in files if not os.path.isfile(os.path.join(knowledge, f))]
        if missing:
            raise SystemExit(json.dumps({"error": f"{', '.join(missing)} not found in {knowledge}: write the knowledge files before recording them"}))
        state.setdefault(stage, {})[mod] = {"fingerprint": b["fingerprints"][stage], "rules": b["rules"][stage],
                                            "files": files, "recorded": datetime.datetime.now().isoformat(timespec="seconds")}
        done.append(mod)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(state, fh, indent=1, sort_keys=True)
    return {"recorded": done, "stage": stage}


# --------------------------------------------------------------------------------------- self-test
def self_test():
    tmp = tempfile.mkdtemp(prefix="split_extract_selftest_")
    ok = {}
    cwd = os.getcwd()
    try:
        os.chdir(tmp)
        ext, kn, sk = os.path.join("knowledge", ".extract"), "knowledge", "skills"
        os.makedirs(ext); os.makedirs(sk)
        for f in STAGES.values():
            open(os.path.join(sk, f[0]), "w").write("rules v1")
        def kw(name, file, calls=()):
            return {"name": name, "file": file, "line": 1, "documentation": name, "steps": [], "calls": list(calls),
                    "resolved_calls": {c: [c] for c in calls}}
        keywords = [kw("Login", "resources/common.resource"),
                    kw("Search Client", "resources/common.resource"),
                    kw("Approve Case", "resources/kyc.resource", ["resources/common.resource::Search Client"]),
                    kw("Update Address", "resources/client.resource")]
        def test(name, file, calls):
            return {"name": name, "file": file, "line": 3, "tags": [], "steps": [{"keyword": c.split("::")[1], "resolved": [c], "args": []} for c in calls]}
        tests = [test("TC-1 Approve", "tests/kyc/approve.robot", ["resources/common.resource::Login", "resources/kyc.resource::Approve Case"]),
                 test("TC-2 Reject", "tests/kyc/reject.robot", ["resources/common.resource::Login"]),
                 test("TC-3 Address", "tests/client/address.robot", ["resources/common.resource::Login", "resources/client.resource::Update Address"])]
        locators = [{"variable": "${APPROVE_BTN}", "value": "id:approve", "file": "resources/kyc.resource", "line": 9, "used_by": ["keyword:resources/kyc.resource::Approve Case"]},
                    {"variable": "${LOGIN_BTN}", "value": "id:login", "file": "resources/common.resource", "line": 4, "used_by": []},
                    {"variable": "${ADDR}", "value": "id:addr", "file": "resources/client_locators.resource", "line": 2, "used_by": ["keyword:resources/client.resource::Update Address"]}]
        for n, o in (("tests.json", tests), ("keywords.json", keywords), ("locators.json", locators), ("variables.json", []),
                     ("routes.json", {"resources/kyc.resource::Approve Case": {"entry": ["Login"]}}), ("ui-signals.json", {"messages": [{"text": "Case approved", "where": "tests/kyc/approve.robot:5"}]})):
            json.dump(o, open(os.path.join(ext, n), "w"))
        p = cmd_plan(ext, kn, sk)
        mods = {m["module"]: m for m in p["modules"]}
        ok["one module per test folder, plus COMMON"] = set(mods) == {"MOD-KYC", "MOD-CLIENT", "MOD-COMMON"}
        kyc = json.load(open(mods["MOD-KYC"]["brief"]))
        ok["module brief holds only its own tests"] = [t["name"] for t in kyc["tests"]] == ["TC-1 Approve", "TC-2 Reject"]
        ok["keyword used by one module belongs to it"] = [k["name"] for k in kyc["keywords_owned"]] == ["Approve Case"]
        com = json.load(open(mods["MOD-COMMON"]["brief"]))
        ok["keywords shared by modules go to COMMON"] = {k["name"] for k in com["keywords_owned"]} == {"Login", "Search Client"}
        ok["shared keywords listed by name only in the module brief"] = {k["name"] for k in kyc["keywords_called_from_elsewhere"]} == {"Login", "Search Client"} \
            and all("steps" not in k for k in kyc["keywords_called_from_elsewhere"])
        cli = json.load(open(mods["MOD-CLIENT"]["brief"]))
        ok["locator file follows the module that uses it"] = [l["variable"] for l in cli["locators_owned"]] == ["${ADDR}"]
        ok["routes and messages cut to the module"] = list(kyc["routes"]) == ["resources/kyc.resource::Approve Case"] and len(kyc["messages"]) == 1 and not cli["messages"]
        ok["first run: everything to build"] = set(p["stages"]["keyword"]["changed"]) == set(mods) and "MOD-COMMON" not in p["stages"]["app"]["changed"]
        ok["small scope: one agent"] = p["stages"]["app"]["use_sub_agents"] is False
        nx = cmd_next(kn, budget_kb=1000, max_mods=2)
        ok["next: most-used module first (COMMON, called by every module), batch of 2, progress shown"] = \
            nx["batch"][0] == "MOD-COMMON" and len(nx["batch"]) == 2 and nx["total"] == 3 and nx["done"] == 0 and "0 of 3 modules done" in nx["say"]
        for st in STAGES:
            for m in p["stages"][st]["changed"]:
                if m not in nx["batch"]:
                    continue
                for f in evidence(st, m, json.load(open(mods[m]["brief"]))):
                    os.makedirs(os.path.dirname(os.path.join(kn, f)), exist_ok=True)
                    open(os.path.join(kn, f), "w").write("built")
        cmd_record(kn, "all", nx["batch"])
        nx2 = cmd_next(kn)
        ok["next resumes: recorded modules are not offered again; time left estimated"] = \
            not set(nx2["batch"]) & set(nx["batch"]) and nx2["done"] == 2 and nx2["left"] == 1
        for st in STAGES:
            for m in p["stages"][st]["changed"]:
                for f in evidence(st, m, json.load(open(mods[m]["brief"]))):
                    os.makedirs(os.path.dirname(os.path.join(kn, f)), exist_ok=True)
                    open(os.path.join(kn, f), "w").write("built")
            cmd_record(kn, st, p["stages"][st]["changed"])
        ok["modules with nothing of their own are recorded without a file (shared module: no app file)"] = \
            "MOD-COMMON" in json.load(open(os.path.join(kn, "build-state.json")))["keyword"]
        p2 = cmd_plan(ext, kn, sk)
        ok["nothing changed: every module skipped"] = all(not p2["stages"][st]["changed"] for st in STAGES)
        tests[2]["steps"].append({"keyword": "Search Client", "resolved": ["resources/common.resource::Search Client"], "args": []})
        json.dump(tests, open(os.path.join(ext, "tests.json"), "w"))
        p3 = cmd_plan(ext, kn, sk)
        ok["only the module whose tests changed is rebuilt"] = p3["stages"]["app"]["changed"] == ["MOD-CLIENT"] and p3["stages"]["locator"]["changed"] == []
        open(os.path.join(sk, "keyword-knowledge-builder.md"), "w").write("rules v2")
        p4 = cmd_plan(ext, kn, sk)
        ok["new builder rules: listed on refresh, not rebuilt"] = p4["stages"]["keyword"]["changed"] == ["MOD-CLIENT"] or not p4["stages"]["keyword"]["changed"]
        ok["new builder rules: listed on refresh, not rebuilt"] = ok["new builder rules: listed on refresh, not rebuilt"] and \
            set(p4["stages"]["keyword"]["built_with_older_rules"]) >= {"MOD-KYC", "MOD-COMMON"} and not p4["stages"]["locator"]["built_with_older_rules"]
        os.makedirs(os.path.join(kn, "locators"), exist_ok=True)
        open(os.path.join(kn, "locators", "SCREEN-APPROVAL.md"), "w").write("built")
        cmd_record(kn, "locator", ["MOD-KYC"], ["knowledge/locators/SCREEN-APPROVAL.md"])
        ok["locator screen files recorded and checked"] = cmd_plan(ext, kn, sk)["stages"]["locator"]["changed"] == []
        os.remove(os.path.join(kn, "locators", "SCREEN-APPROVAL.md"))
        ok["missing module file is rebuilt"] = cmd_plan(ext, kn, sk)["stages"]["locator"]["changed"] == ["MOD-KYC"]
        ok["rebuild rebuilds every module"] = set(cmd_plan(ext, kn, sk, rebuild=True)["stages"]["app"]["changed"]) == {"MOD-KYC", "MOD-CLIENT"}
        try:
            os.remove(os.path.join(kn, "app", "MOD-KYC.md")); cmd_record(kn, "app", ["MOD-KYC"]); ok["cannot record a module that was not written"] = False
        except SystemExit:
            ok["cannot record a module that was not written"] = True
        big = [test(f"TC-{i}", f"tests/m{i % 6}/t{i}.robot", ["resources/common.resource::Login"]) for i in range(60)]
        json.dump(big, open(os.path.join(ext, "tests.json"), "w"))
        p5 = cmd_plan(ext, kn, sk, rebuild=True)
        ok["large scope: sub-agents, at most 4 at a time"] = p5["stages"]["app"]["use_sub_agents"] and p5["stages"]["app"]["max_parallel"] == 4
        ok["modules of other suites are never reported as removed"] = all("removed" not in s for s in p5["stages"].values()) and \
            "MOD-KYC" in p5["stages"]["app"]["not_in_this_extract"]
        open(os.path.join(kn, "config.yaml"), "w").write("module_map:\n  m1: Payments\n  m2: Payments\n")
        ok["module_map in config.yaml respected"] = "MOD-PAYMENTS" in {m["module"] for m in cmd_plan(ext, kn, sk)["modules"]}
        global COMMON_SPLIT_BYTES
        saved, COMMON_SPLIT_BYTES = COMMON_SPLIT_BYTES, 10
        json.dump(tests, open(os.path.join(ext, "tests.json"), "w"))
        split = {m["module"] for m in cmd_plan(ext, kn, sk)["modules"]}
        COMMON_SPLIT_BYTES = saved
        ok["large shared brief cut per resource file"] = "MOD-COMMON" not in split and "MOD-COMMON-COMMON" in split
    finally:
        os.chdir(cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main():
    ap = argparse.ArgumentParser(description="Cut the QA extract into module briefs and decide what to build.")
    ap.add_argument("--self-test", action="store_true")
    sub = ap.add_subparsers(dest="cmd")
    pl = sub.add_parser("plan")
    pl.add_argument("--rebuild", action="store_true")
    pl.add_argument("--extract", default=os.path.join(ai_home(), "knowledge", ".extract"))
    pl.add_argument("--knowledge", default=os.path.join(ai_home(), "knowledge"))
    pl.add_argument("--skills", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    rc = sub.add_parser("record")
    rc.add_argument("--stage", choices=list(STAGES) + ["all"], required=True)
    nx = sub.add_parser("next")
    nx.add_argument("--budget-kb", type=float, default=BATCH_KB)
    nx.add_argument("--max", type=int, default=BATCH_MAX)
    nx.add_argument("--knowledge", default=os.path.join(ai_home(), "knowledge"))
    rc.add_argument("modules", nargs="+")
    rc.add_argument("--wrote", nargs="*", default=None, help="knowledge files written for these modules (locator screen files); default <stage folder>/<MODULE>.md")
    rc.add_argument("--knowledge", default=os.path.join(ai_home(), "knowledge"))
    a = ap.parse_args()
    if a.self_test:
        sys.exit(self_test())
    if a.cmd == "plan":
        print(json.dumps(cmd_plan(a.extract, a.knowledge, a.skills, a.rebuild), indent=1))
    elif a.cmd == "next":
        print(json.dumps(cmd_next(a.knowledge, a.budget_kb, a.max), indent=1))
    elif a.cmd == "record":
        print(json.dumps(cmd_record(a.knowledge, a.stage, a.modules, a.wrote), indent=1))
    else:
        ap.error("give a command: plan or record")


if __name__ == "__main__":
    main()
