#!/usr/bin/env python3
"""
extract_dev.py - read-only fact extractor for a development (application) repository.

Part of the QA AI skills. It READS the front-end and back-end source code of the application
under test and writes exact facts as JSON for the dev-knowledge-builder skill. It never writes,
builds, installs, formats or commits anything in the development repositories.

What it collects (no AI, no tokens):
  front end  - framework, screens (routes -> components, including child components and dialogs),
               fields (label, id, test id, name, placeholder, type, required), buttons, tabs,
               headings, dropdown options, validation rules, fields that appear only under a
               condition, data each screen loads (API calls on load) and its loading indicators,
               navigation between screens, i18n texts
  back end   - framework, API endpoints (method, path, handler, request body type), request field
               validation, enums (reference data)
  links      - (with --qa-extract) which dev screens the existing QA locators point to, with the
               evidence (id, test id, name, label, URL) and a confidence level; and, with --qa-scope,
               the dev screens a QA suite uses

Usage:
  python extract_dev.py --frontend <path> [--frontend <path2>] [--backend <path>]...
                        [--out knowledge/.extract/dev] [--qa-extract knowledge/.extract]
                        [--qa-scope tests/a.robot,tests/b.robot]
  python extract_dev.py --self-test

Python 3.8+, standard library only.
"""
import argparse, bisect, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from collections import defaultdict

VERSION = 1
try:
    with open(__file__, "rb") as _fh:
        CODE_HASH = hashlib.sha1(_fh.read()).hexdigest()[:12]   # cache is reset when this script changes
except OSError:
    CODE_HASH = str(VERSION)
SKIP_DIRS = {"node_modules", ".git", "dist", "build", "out", "target", "bin", "obj", "coverage",
             ".next", ".nuxt", ".angular", ".idea", ".vscode", "__pycache__", "venv", ".venv",
             "e2e", "cypress", "playwright", "__tests__", "__mocks__", "storybook-static", "vendor",
             "mocks", "mock", "__fixtures__", "fixtures", "mock-data", "mockdata", "test", "tests", "stories", "seed", "seeds"}
# server-rendered and older page templates: JSP, JSF/Facelets, Thymeleaf/plain HTML, FreeMarker, Velocity,
# Razor, ASP.NET Web Forms, Grails, Handlebars/Mustache, PHP. They are read as pages like any other screen file.
PAGE_EXT = (".html", ".htm", ".xhtml", ".jsp", ".jspx", ".jspf", ".tag", ".ftl", ".ftlh", ".vm", ".cshtml", ".vbhtml",
            ".aspx", ".ascx", ".master", ".gsp", ".hbs", ".handlebars", ".mustache", ".php")
FE_EXT = (".js", ".jsx", ".ts", ".tsx", ".vue") + PAGE_EXT
BE_EXT = (".java", ".kt", ".cs", ".py", ".js", ".ts")
TEST_FILE = re.compile(r"\.(test|spec|stories|cy|e2e)\.[jt]sx?$|Test\.java$|Tests?\.cs$|(^|[\\/])test_[^\\/]*\.py$", re.I)
MAX_FILE = 600_000
def ai_home(repo="."):
    """All AI files live in <QA repo>/qa-ai-skills/ (knowledge, generated tests, results, session).
    A repo set up before that folder existed keeps using the repo root."""
    d = os.path.join(repo, "qa-ai-skills")
    return d if os.path.isdir(d) else repo


# ----------------------------------------------------------------------------------------------
# small helpers
def rel(path, root):
    return os.path.relpath(path, root).replace(os.sep, "/")

def read(path):
    try:
        if os.path.getsize(path) > MAX_FILE:
            return None
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None

def line_of(text, pos):
    return text.count("\n", 0, pos) + 1

def walk(root, exts):
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for fn in files:
            if fn.endswith(exts) and not TEST_FILE.search(os.path.join(d, fn)) and not fn.endswith(".d.ts") \
                    and ".min." not in fn:
                yield os.path.join(d, fn)

def match_close(text, start, open_ch, close_ch):
    """Index just after the bracket that closes text[start] (an open_ch); quotes and template
    strings are skipped. Returns len(text) if unbalanced."""
    depth, i, n, q = 0, start, len(text), None
    while i < n:
        c = text[i]
        if q:
            if c == "\\":
                i += 2
                continue
            if c == q:
                q = None
        elif c in "'\"`":
            q = c
        elif c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return n

def scan_tag(text, lt):
    """text[lt] == '<'. Returns (attr_text, end_index, self_closing) for a JSX/HTML opening tag,
    skipping '>' that appear inside {...} (e.g. arrow functions) and quotes."""
    i, n, depth, q = lt + 1, len(text), 0, None
    while i < n:
        c = text[i]
        if q:
            if c == "\\":
                i += 2
                continue
            if c == q:
                q = None
        elif c in "'\"`" and depth >= 0:
            q = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == ">" and depth == 0:
            body = text[lt + 1:i]
            return body, i + 1, body.rstrip().endswith("/")
        i += 1
        if i - lt > 4000:
            break
    return text[lt + 1:min(n, lt + 200)], min(n, lt + 200), True

ATTR_RE = re.compile(r"""([\w\-:\.\*\[\]\(\)@#]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|\{\s*(?:"([^"]*)"|'([^']*)'|`([^`$]*)`)\s*\}|\{\s*t\(\s*['"]([^'"]+)['"][^)]*\)\s*\}|\{\s*(?:i18n\.)?t\(\s*['"]([^'"]+)['"][^)]*\)\s*\}|\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\})""")
BOOL_ATTR = re.compile(r"(?:^|\s)(required|disabled|readonly|multiple)(?=\s|/|$)")
NESTED_ATTR = re.compile(r"""['"]?(data-testid|data-test|data-qa|data-cy|id|name|aria-label)['"]?\s*:\s*['"]([^'"]+)['"]""")

def parse_attrs(body, i18n):
    """Returns dict of attribute -> value. i18n keys (t('key')) are resolved when a locale exists;
    the key is kept in '<attr>__key'."""
    attrs = {}
    for m in ATTR_RE.finditer(body):
        name = m.group(1)
        lit = next((g for g in m.group(2, 3, 4, 5, 6) if g is not None), None)
        key = m.group(7) or m.group(8)
        expr = m.group(9)
        if lit is not None:
            attrs[name] = lit
        elif key:
            attrs[name] = i18n.get(key, key)
            attrs[name + "__key"] = key
        elif expr is not None:
            attrs[name + "__expr"] = expr.strip()[:200]
            for nm in NESTED_ATTR.finditer(expr):
                attrs.setdefault(nm.group(1), nm.group(2))
    for m in BOOL_ATTR.finditer(" " + re.sub(r"=\s*(\{[^}]*\}|\"[^\"]*\"|'[^']*')", "", body)):
        attrs.setdefault(m.group(1), True)
    # Angular bindings: [label]="'key' | translate", [attr.data-testid]="'x'", [id]="'x'"
    for name in [k for k in attrs if k.startswith("[") and k.endswith("]") and isinstance(attrs[k], str)]:
        plain = name[1:-1].replace("attr.", "")
        val = attrs[name].strip()
        pm = re.match(r"""^'([^']+)'\s*\|\s*translate\b""", val)
        if pm:
            attrs.setdefault(plain, i18n.get(pm.group(1), pm.group(1)))
            attrs.setdefault(plain + "__key", pm.group(1))
        elif re.match(r"^'[^']*'$", val):
            attrs.setdefault(plain, val[1:-1])
    for name in [k for k in attrs if isinstance(attrs[k], str)]:
        pm = re.match(r"""^\{\{\s*'([^']+)'\s*\|\s*translate\b[^}]*\}\}$""", attrs[name].strip())
        if pm:
            attrs[name] = i18n.get(pm.group(1), pm.group(1))
            attrs[name + "__key"] = pm.group(1)
    return attrs

def inner_text(text, end, tag, i18n):
    close = text.find("</" + tag, end)
    if close == -1 or close - end > 400:
        return None
    raw = text[end:close]
    keys = re.findall(r"\bt\(\s*['\"]([^'\"]+)['\"]", raw) or \
        re.findall(r"""['"]([\w\.\-]+)['"]\s*\|\s*translate\b""", raw)
    if keys:
        return i18n.get(keys[0], keys[0])
    mk = MSG_KEY_RE.search(raw)                         # <spring:message code="x"/>, #{msg['x']}, <s:text name="x"/>
    if mk:
        key = next((g for g in mk.groups() if g), None)
        if key and (key in i18n or "." in key):
            return i18n.get(key, key)
    raw = re.sub(r"<[^>]*>", " ", raw)
    raw = re.sub(r"\{[^}]*\}", " ", raw)
    raw = re.sub(r"\s+", " ", raw).strip()
    return raw or None

def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())

# ----------------------------------------------------------------------------------------------
# framework detection
def detect_frameworks(root):
    found, pkgs = set(), []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        if d.count(os.sep) - root.count(os.sep) > 3:
            dirs[:] = []
        for fn in files:
            p = os.path.join(d, fn)
            if fn == "package.json":
                try:
                    data = json.load(open(p, encoding="utf-8"))
                except Exception:
                    continue
                deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                pkgs.append(rel(p, root))
                for k, label in (("react", "React"), ("next", "Next.js"), ("@angular/core", "Angular"),
                                 ("vue", "Vue"), ("nuxt", "Nuxt"), ("@mui/material", "Material UI"),
                                 ("@material-ui/core", "Material UI (v4)"), ("@angular/material", "Angular Material"),
                                 ("antd", "Ant Design"), ("react-hook-form", "React Hook Form"), ("formik", "Formik"),
                                 ("yup", "Yup"), ("zod", "Zod"), ("react-router-dom", "React Router"),
                                 ("express", "Express"), ("@nestjs/core", "NestJS"), ("i18next", "i18next"),
                                 ("react-intl", "react-intl"), ("@ngx-translate/core", "ngx-translate")):
                    if k in deps:
                        found.add(label)
            elif fn == "bower.json":                       # front ends from before npm (AngularJS 1.x, jQuery, Backbone)
                try:
                    data = json.load(open(p, encoding="utf-8"))
                except Exception:
                    continue
                pkgs.append(rel(p, root))
                deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                for k, label in LEGACY_LIBS:
                    if k in deps:
                        found.add(label)
            elif fn in ("pom.xml", "build.gradle", "build.gradle.kts"):
                t = read(p) or ""
                found.add("Java")
                if "spring-boot" in t:
                    found.add("Spring Boot")
                elif "springframework" in t:
                    found.add("Spring MVC")
                for k, label in (("thymeleaf", "Thymeleaf"), ("struts2-core", "Struts 2"), ("struts-core", "Struts 1"),
                                 ("<artifactId>struts<", "Struts 1"), ("jsf-api", "JSF"), ("javax.faces", "JSF"),
                                 ("jakarta.faces", "JSF"), ("primefaces", "PrimeFaces"), ("richfaces", "RichFaces"),
                                 ("freemarker", "FreeMarker"), ("velocity", "Velocity"), ("tomcat-embed-jasper", "JSP"),
                                 ("jstl", "JSP"), ("vaadin", "Vaadin"), ("gwt-user", "GWT"), ("wicket", "Wicket")):
                    if k in t:
                        found.add(label)
            elif fn in ("struts.xml", "struts-config.xml"):
                found.add("Struts 2" if fn == "struts.xml" else "Struts 1")
            elif fn == "faces-config.xml":
                found.add("JSF")
            elif fn in ("web.xml", "Web.config", "web.config", "Global.asax"):
                found.add("Java web app" if fn == "web.xml" else "ASP.NET")
            elif fn.endswith(".csproj"):
                t = read(p) or ""
                found.add(".NET")
                if "AspNetCore" in t or "Microsoft.NET.Sdk.Web" in t:
                    found.add("ASP.NET Core")
            elif fn in ("requirements.txt", "pyproject.toml", "Pipfile"):
                t = (read(p) or "").lower()
                found.add("Python")
                for k, label in (("fastapi", "FastAPI"), ("flask", "Flask"), ("django", "Django")):
                    if k in t:
                        found.add(label)
    found |= page_frameworks(root)
    return sorted(found), pkgs


LEGACY_LIBS = (("angular", "AngularJS"), ("angular-route", "AngularJS"), ("angular-ui-router", "AngularJS"),
               ("jquery", "jQuery"), ("backbone", "Backbone"), ("knockout", "Knockout"), ("ember", "Ember"),
               ("dojo", "Dojo"), ("extjs", "Ext JS"), ("bootstrap", "Bootstrap"))
PAGE_MARKERS = ((re.compile(r"\bng-app\b|\bdata-ng-app\b|angular\.module\s*\(|angular(?:\.min)?\.js"), "AngularJS"),
                (re.compile(r"jquery[\w.\-]*\.js|\$\(\s*document\s*\)\.ready|\$\.ajax\s*\("), "jQuery"),
                (re.compile(r"\bdata-bind\s*="), "Knockout"), (re.compile(r"Backbone\.(?:View|Model)\.extend"), "Backbone"),
                (re.compile(r"\bth:(?:text|field|if|each|href|action)\s*="), "Thymeleaf"),
                (re.compile(r"<%@\s*(?:page|taglib)|<(?:c|fmt|spring|form):\w+"), "JSP"),
                (re.compile(r"xmlns:h\s*=\s*[\"']https?://(?:java\.sun\.com|xmlns\.jcp\.org)/jsf|<h:form\b"), "JSF"),
                (re.compile(r"<p:\w+"), "PrimeFaces"), (re.compile(r"<s:(?:form|textfield|submit)\b"), "Struts 2"),
                (re.compile(r"<html:(?:form|text|submit)\b"), "Struts 1"), (re.compile(r"<asp:\w+[^>]*runat\s*=\s*[\"']server"), "ASP.NET Web Forms"),
                (re.compile(r"@Html\.\w+|\basp-for\s*="), "ASP.NET MVC (Razor)"), (re.compile(r"<#(?:if|list|macro)\b|\$\{[\w.]+\?"), "FreeMarker"),
                (re.compile(r"#(?:if|foreach|set)\s*\(\$"), "Velocity"), (re.compile(r"<g:(?:form|textField)\b"), "Grails"))


def page_frameworks(root, limit=400):
    """Frameworks seen in the page and script files themselves (old front ends often have no package.json)."""
    found, seen = set(), 0
    for p in walk(root, PAGE_EXT + (".js",)):
        seen += 1
        if seen > limit:
            break
        t = (read(p) or "")[:60000]
        for rx, label in PAGE_MARKERS:
            if label not in found and rx.search(t):
                found.add(label)
    return found


def git_info(path):
    def g(*args):
        try:
            r = subprocess.run(["git", "-C", path] + list(args), capture_output=True, text=True, timeout=15)
            return r.stdout.strip() if r.returncode == 0 else None
        except Exception:
            return None
    remote = g("config", "--get", "remote.origin.url")
    if remote:
        remote = re.sub(r"(https?://)[^/@]+@", r"\1", remote)   # never record a user name or token
    return {"branch": g("rev-parse", "--abbrev-ref", "HEAD"), "commit": g("rev-parse", "HEAD"),
            "commit_date": g("log", "-1", "--format=%cI"), "remote": remote}

# ----------------------------------------------------------------------------------------------
# i18n
def load_i18n(root):
    """Flattens locale JSON files (preferring English) into key -> text."""
    cands = []
    for p in walk(root, (".json",)):
        r = rel(p, root).lower()
        if re.search(r"(^|/)(locales?|i18n|translations?|lang|assets/i18n)(/|$)", r) or re.search(r"(^|/)(en|en-us|en_us|en-gb)\.json$", r):
            cands.append(p)
    cands.sort(key=lambda p: (0 if re.search(r"(^|[/\\])en([-_][a-z]+)?([/\\]|\.json$)", p.lower()) else 1, p))
    out = {}
    for p in cands:
        try:
            data = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        def flat(o, pre=""):
            if isinstance(o, dict):
                for k, v in o.items():
                    flat(v, f"{pre}.{k}" if pre else str(k))
            elif isinstance(o, str):
                out.setdefault(pre, o)
        flat(data)
    # Java message bundles (Spring, JSF, Struts): messages.properties, ApplicationResources.properties ...
    props = [p for p in walk(root, (".properties",)) if re.search(r"(messages?|resources?|bundle|labels?|i18n|text)[\w\-]*\.properties$", p, re.I)]
    props.sort(key=lambda p: (0 if re.search(r"_en(_\w+)?\.properties$", p) else 1 if not re.search(r"_[a-z]{2}(_\w+)?\.properties$", p) else 2, p))
    for p in props:
        for line in (read(p) or "").splitlines():
            m = re.match(r"\s*([\w\.\-]+)\s*[=:]\s*(.+?)\s*$", line)
            if m and not line.lstrip().startswith(("#", "!")):
                out.setdefault(m.group(1), m.group(2))
    return out

# ----------------------------------------------------------------------------------------------
# front end
INPUT_TAGS = {"TextField", "Select", "Autocomplete", "Checkbox", "Radio", "RadioGroup", "Switch", "DatePicker",
              "DesktopDatePicker", "MobileDatePicker", "KeyboardDatePicker", "DateTimePicker", "TimePicker",
              "Input", "OutlinedInput", "FilledInput", "NativeSelect", "FormControlLabel", "Field", "Controller",
              "input", "select", "textarea", "mat-select", "mat-checkbox", "mat-radio-button", "mat-radio-group",
              "mat-slide-toggle", "mat-datepicker", "ng-select", "p-dropdown", "p-calendar", "p-checkbox",
              "v-text-field", "v-select", "v-autocomplete", "v-checkbox", "el-input", "el-select", "Dropdown",
              "NumberInput", "NumericFormat", "InputNumber", "DatePickerInput",
              # server-side and older page tags (Spring form, JSF/PrimeFaces, Struts 1/2, ASP.NET, Grails)
              "form:input", "form:password", "form:textarea", "form:select", "form:checkbox", "form:checkboxes",
              "form:radiobutton", "form:radiobuttons", "h:inputText", "h:inputSecret", "h:inputTextarea", "h:selectOneMenu",
              "h:selectManyMenu", "h:selectOneListbox", "h:selectBooleanCheckbox", "h:selectManyCheckbox", "h:selectOneRadio",
              "p:inputText", "p:inputTextarea", "p:password", "p:selectOneMenu", "p:selectCheckboxMenu", "p:calendar",
              "p:datePicker", "p:autoComplete", "p:inputNumber", "p:selectBooleanCheckbox", "p:selectOneRadio",
              "s:textfield", "s:password", "s:textarea", "s:select", "s:checkbox", "s:radio", "s:datetimepicker",
              "html:text", "html:password", "html:textarea", "html:select", "html:checkbox", "html:radio",
              "asp:TextBox", "asp:DropDownList", "asp:ListBox", "asp:CheckBox", "asp:CheckBoxList", "asp:RadioButton",
              "asp:RadioButtonList", "asp:Calendar", "g:textField", "g:select", "g:checkBox", "g:passwordField", "g:textArea"}
ACTION_TAGS = {"Button", "IconButton", "LoadingButton", "Fab", "button", "a", "Link", "NavLink", "Tab",
               "MenuItem", "ListItemButton", "Chip", "ToggleButton", "v-btn", "el-button", "p-button", "mat-tab",
               "form:button", "h:commandButton", "h:commandLink", "h:link", "h:button", "p:commandButton", "p:commandLink",
               "p:tab", "s:submit", "s:a", "html:submit", "html:link", "html:cancel", "asp:Button", "asp:LinkButton",
               "asp:ImageButton", "asp:HyperLink", "g:actionSubmit", "g:link", "g:submitButton"}
OPTION_TAGS = {"MenuItem", "option", "mat-option", "el-option", "ToggleButton", "form:option", "f:selectItem", "asp:ListItem",
               "html:option", "s:option"}
DROPDOWN_TAGS = {"Select", "select", "mat-select", "NativeSelect", "v-select", "el-select", "p-dropdown", "ng-select", "Autocomplete",
                 "Dropdown", "form:select", "h:selectOneMenu", "h:selectManyMenu", "h:selectOneListbox", "p:selectOneMenu",
                 "p:selectCheckboxMenu", "p:autoComplete", "s:select", "html:select", "asp:DropDownList", "asp:ListBox", "g:select"}
CHECK_TAGS = {"Checkbox", "mat-checkbox", "p-checkbox", "v-checkbox", "Switch", "mat-slide-toggle", "form:checkbox", "form:checkboxes",
              "form:radiobutton", "form:radiobuttons", "h:selectBooleanCheckbox", "h:selectManyCheckbox", "h:selectOneRadio",
              "p:selectBooleanCheckbox", "p:selectOneRadio", "s:checkbox", "s:radio", "html:checkbox", "html:radio", "asp:CheckBox",
              "asp:CheckBoxList", "asp:RadioButton", "asp:RadioButtonList", "g:checkBox"}
COND_TAGS = {"c:if", "c:when", "s:if", "s:elseif", "logic:equal", "logic:notEqual", "logic:present", "logic:notPresent",
             "logic:empty", "logic:notEmpty", "sec:authorize", "security:authorize"}
TEXT_TAGS = {"h1", "h2", "h3", "h4", "DialogTitle", "CardHeader", "FormLabel", "InputLabel", "label", "legend",
             "AccordionSummary", "StepLabel", "mat-card-title", "mat-dialog-title", "Typography", "Title", "PageHeader",
             "h:outputLabel", "asp:Label", "s:label", "form:label"}
LABEL_TAGS = {"label", "FormLabel", "InputLabel", "h:outputLabel", "asp:Label", "s:label", "form:label"}
DIALOG_TAGS = {"Dialog", "Modal", "Drawer", "mat-dialog-content", "p-dialog", "el-dialog", "v-dialog", "SweetAlert"}
LOADER_RE = re.compile(r"\b(CircularProgress|LinearProgress|Skeleton|Spinner|Loader|Backdrop|mat-spinner|mat-progress-spinner|mat-progress-bar|p-progressSpinner|v-progress-circular|isLoading|isFetching|loading)\b")
TAG_RE = re.compile(r"<([A-Za-z][\w\.\-]*(?::[A-Za-z][\w\-]*)?)(?=[\s/>])")
API_RE = re.compile(r"""(?:\b(?:axios|http|this\.http|httpClient|api|apiClient|client|request|instance|service|\$http|ky|\$|jQuery|Restangular)\s*\.\s*(get|post|put|patch|delete|getJSON)\s*(?:<[^>()]*>)?\(\s*([`'"])(.+?)\2)|(?:\bfetch\(\s*([`'"])(.+?)\4(?:\s*,\s*\{[^}]*?method\s*:\s*['"](\w+)['"])?)""", re.S)
URL_KEY_RE = re.compile(r"""\burl\s*:\s*([`'"])((?:\.\./|\./)?/?[\w\-{}:./]*[/.][^`'"]*)\1(?:[^}]{0,120}?\b(?:method|type)\s*:\s*['"](\w+)['"])?""", re.S)
RESOURCE_RE = re.compile(r"""\$resource\(\s*(['"])([^'"]+)\1""")
NAV_RE = re.compile(r"""(?:\bnavigate\(\s*([`'"])(.+?)\1|history\.push\(\s*([`'"])(.+?)\3|\$router\.push\(\s*([`'"])(.+?)\5|router\.navigate(?:ByUrl)?\(\s*\[?\s*([`'"])(.+?)\7|\b(?:to|routerLink|href|ng-href|th:href)\s*=\s*(?:\{\s*)?([`'"])((?:#!?)?/[^`'"]*)\9|\$location\.path\(\s*([`'"])(/.+?)\11|window\.location(?:\.href)?\s*=\s*([`'"])(/.+?)\13)""")
ONLOAD_RE = re.compile(r"\$onInit\s*=\s*function\s*\([^)]*\)\s*\{|\$\(\s*document\s*\)\.ready\s*\(|\$\(\s*function\s*\(\s*\)\s*\{|\bng-init\s*=|\buseEffect\s*\(|\bngOnInit\s*\(\s*\)\s*(?::\s*void\s*)?\{|\bcomponentDidMount\s*\(\s*\)\s*\{|\bonMounted\s*\(|\bcreated\s*\(\s*\)\s*\{|\bmounted\s*\(\s*\)\s*\{|\buseQuery\s*\(")
COND_JSX_RE = re.compile(r"\{\s*(!?[\w\.\?\[\]'\"!=<>&|\s\(\)]{1,160}?)\s*(&&|\?)\s*[\(<]")
COND_ATTR_RE = re.compile(r"""(\*ngIf|v-if|v-else-if|v-show|\[hidden\]|@if|(?:data-)?ng-(?:if|show|hide|switch-when)|th:if|th:unless|rendered)\s*=\s*(?:"([^"]+)"|'([^']+)')""")
YUP_RE = re.compile(r"(\w+)\s*:\s*(?:yup|Yup|z|zod)\s*\.\s*(\w+\([^\n]*(?:\n\s*\.[^\n]*)*)")
RHF_RE = re.compile(r"""register\(\s*['"]([\w\.]+)['"]\s*,\s*(\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\})""")
NG_VALID_RE = re.compile(r"(\w+)\s*:\s*(?:new\s+FormControl\(|\[)[^\n]*?((?:Validators\.\w+(?:\([^)]*\))?[\s,\]]*)+)")
ARRAY_CONST_RE = re.compile(r"(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::[^=\n]+)?=\s*\[")
ENUM_TS_RE = re.compile(r"(?:export\s+)?enum\s+(\w+)\s*\{([^}]*)\}")
COMP_DEF_RE = re.compile(r"(?:\.(?:controller|component|directive)\(\s*['\"](\w+)['\"])|(?:export\s+default\s+)?(?:function\s+([A-Z]\w*)\s*\(|(?:const|let)\s+([A-Z]\w*)\s*(?::[^=\n]+)?=\s*(?:React\.)?(?:memo\(|forwardRef\()?\s*(?:\([^)]*\)|\w+)\s*=>|class\s+([A-Z]\w*)\s+extends\s+(?:React\.)?(?:Component|PureComponent)|export\s+class\s+(\w+Component)\b)")
IMPORT_RE = re.compile(r"""import\s+(?:([\w\$]+)\s*,?\s*)?(?:\{([^}]*)\}\s*)?(?:\*\s+as\s+\w+\s*)?from\s+['"]([^'"]+)['"]|import\(\s*['"]([^'"]+)['"]\s*\)|templateUrl\s*:\s*['"]([^'"]+)['"]""")
# pages that pull in other pages or scripts: AngularJS ng-include / ng-controller, JSP and JSF includes,
# Thymeleaf fragments, Razor partials, and the scripts a page loads
INCLUDE_RE = re.compile(r"""(?:\bng-include\s*=\s*["']\s*'([^']+)'|<jsp:include\s+page\s*=\s*["']([^"']+)["']|<%@\s*include\s+file\s*=\s*["']([^"']+)["']|<ui:include\s+src\s*=\s*["']([^"']+)["']|<ui:composition[^>]*\btemplate\s*=\s*["']([^"']+)["']|\bth:(?:replace|insert|include)\s*=\s*["']~?\{?\s*([\w/\-\.]+)|@Html\.(?:Partial|RenderPartial)\(\s*"([^"]+)"|<partial\s+name\s*=\s*"([^"]+)"|<script[^>]+src\s*=\s*["']([^"']+\.js)["']|<c:import\s+url\s*=\s*["']([^"']+)["']|<tiles:insert(?:Attribute|Definition)?[^>]*(?:page|template)\s*=\s*["']([^"']+)["'])""")
NG_CONTROLLER_RE = re.compile(r"""\b(?:data-)?ng-controller\s*=\s*["']\s*(\w+)""")
ANGJS_ROUTE_RE = re.compile(r"""\.when\(\s*(['"])([^'"]*)\1\s*,\s*\{|\.state\(\s*(['"])([\w\.\-]+)\3\s*,\s*\{|\.state\(\s*\{""")
MSG_KEY_RE = re.compile(r"""<(?:spring:message|fmt:message|s:text|bean:message)\s+(?:code|key|name)\s*=\s*["']([^"']+)["']|#\{\s*(?:msg|msgs|messages|bundle|i18n)\s*(?:\[\s*'([^']+)'\s*\]|\.([\w\.]+))\s*\}|#\{([\w\.\-]+)\}|@(?:Resources|Localizer)\.?\[?"?([\w\.]+)""")
ROUTE_TAG_RE = re.compile(r"<Route\b")
ROUTE_OBJ_RE = re.compile(r"""\bpath\s*:\s*(['"`])([^'"`]*)\1""")
LAZY_RE = re.compile(r"""(?:const|let)\s+(\w+)\s*=\s*(?:React\.)?lazy\(\s*\(\)\s*=>\s*import\(\s*['"]([^'"]+)['"]\s*\)""")
FEEDBACK_RE = re.compile(r"""\b(enqueueSnackbar|toast(?:\.\w+)?|message\.\w+|snackBar\.open|toastr\.\w+|notification\.\w+|Notification\.\w+|growl\.\w+|\$mdToast\.\w+|messageService\.add|notify\w*|show\w*(?:Success|Error|Message|Toast|Notification|Alert)\w*|set\w*(?:Success|Error|Message|Alert)\w*|alert)\s*\(\s*(?:\{[^}]*?(?:message|summary|detail|title)\s*:\s*)?(?:t\(\s*|this\.translate\.instant\(\s*|translate\.instant\(\s*|i18n\.t\(\s*)?(['"`])([^'"`]{3,160})\2""")
REFRESH_RE = re.compile(r"\b(refetch|invalidateQueries|mutate\(\s*\)|reload|refresh\w*|load\w*\(\s*\)|fetch\w*\(\s*\)|getAll\w*\(\s*\))")
ROLE_HINT_RE = re.compile(r"""\b(?:roles|allowedRoles|requiredRoles?|permissions?|requiredPermissions?|authorities)\s*[:=]\s*\{?\s*\[([^\]]{1,200})\]|\b(?:hasRole|hasAnyRole|hasPermission|hasAuthority|isInRole|userHasRole|can|checkPermission)\s*\(\s*([^)]{1,120})\)|\b(?:role|requiredRole|permission)\s*=\s*["']([\w\-:\. ]+)["']""")
GENERIC_TEXT = {"save", "cancel", "ok", "close", "search", "submit", "next", "back", "yes", "no", "edit", "delete",
                "add", "remove", "confirm", "reset", "clear", "apply", "done", "update", "create", "view", "open",
                "previous", "continue", "finish", "select", "home", "help", "logout", "login", "menu", "more"}

def regions(text, pattern, opener="{"):
    """[(start, end)] of the block that follows each match (first `opener` after the match)."""
    out = []
    for m in pattern.finditer(text):
        s = text.find(opener if opener else "{", m.start())
        if s == -1 or s - m.end() > 200:
            s = m.end() - 1 if text[m.end() - 1] in "({" else text.find("(", m.start())
        if s == -1:
            continue
        ch = text[s]
        out.append((m.start(), match_close(text, s, ch, ")" if ch == "(" else "}")))
    return out

def html_block_end(text, lt, tag):
    """End index of the element starting at lt (matching close tag, same-name nesting counted)."""
    depth, i = 0, lt
    pat = re.compile(r"<(/?)" + re.escape(tag) + r"(?=[\s/>])")
    for m in pat.finditer(text, lt):
        body, end, selfc = scan_tag(text, m.start()) if not m.group(1) else (None, text.find(">", m.start()) + 1, False)
        if m.group(1):
            depth -= 1
        elif not selfc:
            depth += 1
        else:
            if depth == 0:
                return end
            continue
        if depth == 0:
            return end
        i = end
    return len(text)

def parse_frontend_file(path, root, i18n):
    text = read(path)
    if text is None:
        return None
    f = rel(path, root)
    facts = {"file": f, "components": [], "elements": [], "texts": [], "options": [], "validations": [],
             "conditions": [], "apis": [], "loaders": [], "navigates": [], "imports": [], "routes": [],
             "lazy": {}, "reference": [], "is_dialog": False, "default_export": None}
    for m in COMP_DEF_RE.finditer(text):
        name = next(g for g in m.groups() if g)
        facts["components"].append(name)
    d = re.search(r"export\s+default\s+(?:function\s+|class\s+)?([A-Z]\w*)", text)
    facts["default_export"] = d.group(1) if d else None
    for m in IMPORT_RE.finditer(text):
        spec = m.group(3) or m.group(4) or m.group(5)
        names = [m.group(1)] if m.group(1) else []
        if m.group(2):
            names += [x.split(" as ")[-1].strip() for x in m.group(2).split(",") if x.strip()]
        facts["imports"].append({"spec": spec, "names": names})
    for m in LAZY_RE.finditer(text):
        facts["lazy"][m.group(1)] = m.group(2)

    # condition regions (JSX && / ternary, *ngIf / v-if)
    cond_regions = []
    for m in COND_JSX_RE.finditer(text):
        end = match_close(text, m.start(), "{", "}")
        expr = re.sub(r"\s+", " ", m.group(1)).strip()
        if len(expr) > 2 and not expr.isdigit():
            cond_regions.append((m.start(), end, expr))
    for m in TAG_RE.finditer(text):
        body, _, _ = scan_tag(text, m.start())
        ca = COND_ATTR_RE.search(body)
        if ca:
            cond_regions.append((m.start(), html_block_end(text, m.start(), m.group(1)), ca.group(2) or ca.group(3)))
        elif m.group(1) in COND_TAGS:                   # <c:if test="${...}">, <s:if>, <sec:authorize access="...">
            tm = re.search(r"""\b(?:test|access|ifAnyGranted|ifAllGranted|name|property|value)\s*=\s*(?:"([^"]+)"|'([^']+)')""", body)
            if tm:
                cond_regions.append((m.start(), html_block_end(text, m.start(), m.group(1)), tm.group(1) or tm.group(2)))
    on_load = regions(text, ONLOAD_RE)

    # tags
    last_input = None
    for m in TAG_RE.finditer(text):
        tag = m.group(1)
        short = tag.split(".")[-1]
        if short in DIALOG_TAGS:
            facts["is_dialog"] = True
        interesting = short in INPUT_TAGS or short in ACTION_TAGS or short in TEXT_TAGS or short in OPTION_TAGS
        body, end, selfc = scan_tag(text, m.start())
        has_id = re.search(r"\b(id|ID|data-testid|data-test|data-qa|data-cy|aria-label|formControlName|name|ng-model|data-ng-model|th:field|path|property|asp-for)\s*=", body)
        if not interesting and not has_id:
            continue
        a = parse_attrs(body[len(tag):], i18n)
        pos, line = m.start(), line_of(text, m.start())
        cond = [c for c in cond_regions if c[0] < pos < c[1]]
        visible_when = min(cond, key=lambda c: c[1] - c[0])[2] if cond else None
        for ca in COND_ATTR_RE.finditer(body):
            visible_when = ca.group(2) or ca.group(3)
        txt = None if selfc else inner_text(text, end, tag, i18n)
        if short in OPTION_TAGS and isinstance(a.get("th:each"), str) and last_input is not None:
            em = re.search(r":\s*\$\{\s*([\w\.]+)", a["th:each"])        # <option th:each="t : ${types}">: options from data
            last_input[1]["options_from"] = em.group(1) if em else a["th:each"][:120]
            continue
        if short in OPTION_TAGS and ("value" in a or "Value" in a or "itemValue" in a or txt):
            opt = {"value": a.get("value", a.get("Value", a.get("itemValue", a.get("value__expr")))),
                   "text": txt or a.get("itemLabel") or a.get("Text") or a.get("label"), "line": line}
            if last_input is not None and pos - last_input[0] < 3000:
                last_input[1].setdefault("options", []).append(opt)
            else:
                facts["options"].append(opt)
            if short != "MenuItem":
                continue
        if short in TEXT_TAGS and short not in INPUT_TAGS:
            tk = re.match(r"^#\{\s*([\w\.\-]+)\s*\}$", str(a.get("th:text") or "").strip())
            t = (i18n.get(tk.group(1)) if tk and tk.group(1) in i18n else None) or txt or a.get("title") or a.get("label") or a.get("Text") or \
                (a.get("value") if short in ("h:outputLabel", "s:label") else None)
            if short == "Typography" and not re.match(r"h\d|subtitle|title", str(a.get("variant", ""))):
                t = None
            if t:
                facts["texts"].append({"kind": "label" if short in LABEL_TAGS else short, "text": t, "line": line,
                                       "for": a.get("htmlFor") or a.get("for") or a.get("AssociatedControlID") or a.get("path")})
            if not has_id or short in LABEL_TAGS:
                continue
        el = {"tag": tag, "line": line}
        for k_out, keys in (("id", ("id", "ID", "th:id", "styleId")), ("testid", ("data-testid", "data-test", "data-qa", "data-cy", "testId")),
                            ("name", ("name", "formControlName", "v-model", "[(ngModel)]", "ng-model", "data-ng-model", "th:field",
                                      "path", "property", "asp-for")),
                            ("label", ("label", "aria-label", "title", "itemLabel", "key")), ("placeholder", ("placeholder",)),
                            ("type", ("type",)), ("role", ("role",))):
            for k in keys:
                v = a.get(k)
                if isinstance(v, str) and v:
                    el[k_out] = v
                    if a.get(k + "__key"):
                        el[k_out + "_key"] = a[k + "__key"]
                    break
        if "name" not in el:
            m2 = re.search(r"\{\.\.\.register\(\s*['\"]([\w\.]+)['\"]", body)
            if m2:
                el["name"] = m2.group(1)
        if "name" not in el and short[:2] in ("h:", "p:") and isinstance(a.get("value"), str):
            em = re.match(r"^#\{\s*([\w\.]+)\s*\}$", a["value"].strip())    # JSF value="#{bean.firstName}"
            if em:
                el["name"] = em.group(1)
        if isinstance(el.get("name"), str):
            el["name"] = re.sub(r"^\*\{\s*([\w\.]+)\s*\}$", r"\1", el["name"])   # Thymeleaf th:field="*{firstName}"
        if short.startswith("asp:") and el.get("id"):
            el["server_id"] = True                          # ASP.NET renders it as ...$<ID> unless ClientIDMode="Static"
        if "label" not in el and isinstance(a.get("th:text"), str):
            km = re.match(r"^#\{\s*([\w\.\-]+)\s*\}$", a["th:text"].strip())
            if km:
                el["label"] = i18n.get(km.group(1), km.group(1))
        if txt and short in ACTION_TAGS | {"FormControlLabel"}:
            el["text"] = txt
        if not el.get("text") and short in ACTION_TAGS and isinstance(a.get("value"), str) and not a["value"].startswith(("#{", "${")):
            el["text"] = a["value"]                         # <h:commandButton value="Save">, <s:submit value="Save">, <asp:Button Text>
        if not el.get("text") and isinstance(a.get("Text"), str):
            el["text"] = a["Text"]
        for b in ("required", "disabled", "multiple"):
            if a.get(b) is True or a.get(b) == "true" or a.get("ng-" + b) in ("true", True) or a.get("data-ng-" + b) in ("true", True):
                el[b] = True
        if isinstance(a.get("ng-required"), str) and a["ng-required"] not in ("true", "false"):
            el["required_when"] = a["ng-required"][:200]
        for k in ("ng-maxlength", "ng-minlength", "ng-pattern", "MaxLength"):
            if isinstance(a.get(k), str):
                el.setdefault("rules", []).append(f"{k.replace('ng-', '').lower()}={a[k]}")
        for k in ("maxLength", "maxlength", "minLength", "minlength", "pattern", "min", "max"):
            if isinstance(a.get(k), str):
                el.setdefault("rules", []).append(f"{k.lower()}={a[k]}")
        if a.get("options__expr"):
            el["options_from"] = a["options__expr"].split(".")[0].split("(")[0].strip()
        for k in ("ng-options", "data-ng-options"):            # AngularJS: "t.code as t.name for t in types"
            if isinstance(a.get(k), str):
                om = re.search(r"\bin\s+([\w\.]+)", a[k])
                el["options_from"] = om.group(1) if om else a[k][:120]
        if isinstance(a.get("items"), str):                     # Spring form:select items="${types}"
            el["options_from"] = re.sub(r"^[$#]\{\s*|\s*\}$", "", a["items"])
        if a.get("select__expr") == "" or a.get("select") is True or short in DROPDOWN_TAGS:
            el["kind"] = "dropdown"
        elif short in CHECK_TAGS or el.get("type") in ("checkbox", "radio"):
            el["kind"] = "checkbox"
        elif short == "input" and str(el.get("type", "")).lower() in ("submit", "button", "reset", "image"):
            el["kind"] = "button"
            if isinstance(a.get("value"), str) and not el.get("text"):
                el["text"] = a["value"]
        elif short in INPUT_TAGS:
            el["kind"] = "input"
        elif short in ACTION_TAGS:
            el["kind"] = "tab" if short in ("Tab", "mat-tab") else "button" if short not in ("a", "Link", "NavLink") else "link"
        else:
            el["kind"] = "element"
        if visible_when:
            el["visible_when"] = visible_when
            if ROLE_WORD_RE.search(visible_when):
                el["depends_on_role"] = True
        dis = a.get("disabled__expr") or a.get("[disabled]") or a.get("ng-disabled") or a.get("data-ng-disabled") or a.get("th:disabled") or \
            (a.get("disabled") if isinstance(a.get("disabled"), str) and a["disabled"].startswith(("#{", "${")) else None)
        if isinstance(dis, str) and dis.strip() not in ("", "true", "false"):
            el["disabled_when"] = dis.strip()[:200]
            if ROLE_WORD_RE.search(dis):
                el["depends_on_role"] = True
        if len(el) <= 3 and not el.get("text"):
            continue
        h = handler_of(a)
        if h:
            el["handler"] = h
        facts["elements"].append(el)
        if el["kind"] in ("dropdown", "input"):
            last_input = (pos, el)
    # labels with htmlFor -> element label
    by_id = {e.get("id"): e for e in facts["elements"] if e.get("id")}
    for t in facts["texts"]:
        if t.get("for") in by_id and not by_id[t["for"]].get("label"):
            by_id[t["for"]]["label"] = t["text"]

    # page includes, controllers named in the page, message keys
    for m in INCLUDE_RE.finditer(text):
        spec = next((g for g in m.groups() if g), None)
        if spec and not re.match(r"^(https?:)?//", spec) and not re.search(r"(^|/)(jquery|angular|bootstrap|lodash|moment|vendor|lib)[\w.\-]*\.js$", spec, re.I):
            facts["imports"].append({"spec": spec, "names": [], "loose": True})
    facts["controllers"] = sorted(set(NG_CONTROLLER_RE.findall(text)))
    regs = {}
    for m in re.finditer(r"""\.controller\(\s*['"](\w+)['"]\s*,\s*(?:\[[^\]]*?)?function\s*\([^)]*\)\s*\{""", text):
        b0 = text.find("{", m.end() - 1)
        regs[m.group(1)] = [line_of(text, m.start()), line_of(text, match_close(text, b0, "{", "}"))]
    if len(regs) > 1:                                   # several controllers in one file: each screen keeps only its own calls
        facts["controller_regions"] = regs
    facts["_ctrl_spans"] = list(regs.values())
    # AngularJS routes: $routeProvider.when('/clients', {templateUrl, controller}); ui-router .state('x', {url, ...})
    for m in ANGJS_ROUTE_RE.finditer(text):
        s0 = text.find("{", m.start())
        window = text[s0:match_close(text, s0, "{", "}")][:1500]
        tu = re.search(r"""templateUrl\s*:\s*['"]([^'"]+)['"]""", window)
        ct = re.search(r"""controller\s*:\s*['"](\w+)""", window)
        url = m.group(2) if m.group(2) is not None else (re.search(r"""\burl\s*:\s*['"]([^'"]*)['"]""", window) or [None, None])[1]
        if tu or ct:
            facts["routes"].append({"path": url if url is not None else "/" + (m.group(4) or ""), "component": ct.group(1) if ct else None,
                                    "import": tu.group(1) if tu else None, "controller": ct.group(1) if ct else None,
                                    "line": line_of(text, m.start()), "loose": True, "roles": []})

    # validation rules
    for m in YUP_RE.finditer(text):
        chain = re.sub(r"\s+", " ", m.group(2))
        rules = re.findall(r"\.?(required|max|min|length|matches|email|oneOf|positive|integer|when|nullable|notRequired|optional|regex|url|uuid|refine)\(([^()]*(?:\([^()]*\)[^()]*)*)\)", "." + chain)
        msgs = re.findall(r"""['"]([^'"]{4,120})['"]""", chain)
        facts["validations"].append({"field": m.group(1), "rules": [f"{r}({a.strip()[:80]})" if a.strip() else r for r, a in rules],
                                     "messages": msgs[:4], "line": line_of(text, m.start()), "source": "schema"})
    for m in RHF_RE.finditer(text):
        obj = m.group(2)
        rules = re.findall(r"(required|maxLength|minLength|max|min|pattern|validate)\s*:", obj)
        msgs = re.findall(r"""['"]([^'"]{4,120})['"]""", obj)
        facts["validations"].append({"field": m.group(1), "rules": rules, "messages": msgs[:4],
                                     "line": line_of(text, m.start()), "source": "register"})
    for m in NG_VALID_RE.finditer(text):
        vals = re.findall(r"Validators\.(\w+)(?:\(([^)]*)\))?", m.group(2))
        facts["validations"].append({"field": m.group(1), "rules": [f"{v}({a})" if a else v for v, a in vals],
                                     "messages": [], "line": line_of(text, m.start()), "source": "angular"})

    # data loading and loaders
    for m in API_RE.finditer(text):
        method = (m.group(1) or m.group(6) or "GET").upper()
        url = m.group(3) or m.group(5)
        if not url or ("/" not in url and "${" not in url):
            continue
        url = re.sub(r"\$\{\s*([^}]*?)\s*\}", lambda x: "{" + x.group(1).split(".")[-1] + "}", url)
        call = {"method": method, "url": url, "line": line_of(text, m.start()),
                "on_load": any(s <= m.start() < e for s, e in on_load)}
        if method != "GET":
            call["after"] = after_change(text, m.end(), i18n)
        facts["apis"].append(call)
    for m in URL_KEY_RE.finditer(text):
        if f.endswith(PAGE_EXT) and not re.search(r"<script", text[max(0, m.start() - 3000):m.start()]):
            continue                                        # a url: inside markup is not a call
        facts["apis"].append({"method": (m.group(3) or "GET").upper(), "url": m.group(2),
                              "line": line_of(text, m.start()), "on_load": any(s <= m.start() < e for s, e in on_load)})
    for m in RESOURCE_RE.finditer(text):                    # AngularJS $resource: get/query/save/delete on one URL
        facts["apis"].append({"method": "ANY", "url": m.group(2), "line": line_of(text, m.start()), "on_load": False})
    for m in re.finditer(r"""<form\b[^>]*?(?<![\w\-])(?:action|th:action|actionName)\s*=\s*["']([^"']+)["'][^>]*?(?:\bmethod\s*=\s*["'](\w+)["'])?""", text):
        url = re.sub(r"^@\{|\}$|\$\{pageContext\.request\.contextPath\}|<c:url\s+value=", "", m.group(1))
        if url and not url.startswith(("#", "javascript")):
            facts["apis"].append({"method": (m.group(2) or "POST").upper(), "url": url if url.startswith("/") else "/" + url,
                                  "line": line_of(text, m.start()), "on_load": False, "form_submit": True})
    facts["loaders"] = sorted(set(LOADER_RE.findall(text)))
    for m in ROLE_HINT_RE.finditer(text):
        raw = next(g for g in m.groups() if g)
        names = re.findall(r"""['"]([\w\-:\. ]+)['"]""", raw) or ([raw.strip()] if m.group(3) else [])
        names = [re.sub(r"^ROLE_", "", n).strip() for n in names if n.strip()]
        if names:
            facts.setdefault("role_hints", []).append({"roles": names, "rule": re.sub(r"\s+", " ", m.group(0))[:160],
                                                       "line": line_of(text, m.start())})
    for m in NAV_RE.finditer(text):
        target = next((g for g in m.groups()[1::2] if g), None)
        target = re.sub(r"^#!?", "", target) if target else target
        if target and target.startswith("/"):
            target = re.sub(r"\$\{[^}]*\}", "{param}", target).split("?")[0]
            facts["navigates"].append({"to": target, "line": line_of(text, m.start())})

    # routes: <Route path element|component>
    for m in ROUTE_TAG_RE.finditer(text):
        body, _, _ = scan_tag(text, m.start())
        a = parse_attrs(body, {})
        comp = None
        if a.get("element__expr"):
            c = re.match(r"\s*<\s*([A-Z][\w\.]*)", a["element__expr"])
            comp = c.group(1) if c else None
        comp = comp or (a.get("component__expr") or "").strip() or None
        if a.get("path") is not None or comp:
            facts["routes"].append({"path": a.get("path", ""), "component": comp, "line": line_of(text, m.start())})
    for m in ROUTE_OBJ_RE.finditer(text):
        window = text[m.end():m.end() + 400]
        nxt = ROUTE_OBJ_RE.search(window)
        if nxt:
            window = window[:nxt.start()]
        c = re.search(r"""(?:element\s*:\s*<\s*([A-Z][\w\.]*)|component\s*:\s*([A-Z]\w*)|loadComponent\s*:\s*\(\)\s*=>\s*import\(\s*['"]([^'"]+)['"]\s*\)(?:\s*\.then\(\s*\w+\s*=>\s*\w+\.(\w+))?|loadChildren\s*:\s*\(\)\s*=>\s*import\(\s*['"]([^'"]+)['"]|Component\s*:\s*([A-Z]\w*)|lazy\s*:\s*\(\)\s*=>\s*import\(\s*['"]([^'"]+)['"])""", window)
        if c:
            rr = re.search(r"""roles\s*:\s*\[([^\]]*)\]""", window)
            if c.group(5):   # loadChildren: a group of child routes, not a screen; its routes are read from their own file
                continue
            facts["routes"].append({"path": m.group(2), "component": c.group(1) or c.group(2) or c.group(4) or c.group(6),
                                    "import": c.group(3) or c.group(7), "line": line_of(text, m.start()),
                                    "roles": re.findall(r"""['"]([\w\-:\. ]+)['"]""", rr.group(1)) if rr else []})

    # reference data: arrays of {label, value} and TS enums
    for m in ARRAY_CONST_RE.finditer(text):
        s = text.find("[", m.end() - 1)
        block = text[s:match_close(text, s, "[", "]")]
        pairs = re.findall(r"""(?:label|name|text|title)\s*:\s*(?:['"]([^'"]+)['"]|t\(\s*['"]([^'"]+)['"]\s*\))[^{}]{0,120}?value\s*:\s*['"]?([\w\-\. ]+)['"]?|value\s*:\s*['"]?([\w\-\. ]+)['"]?[^{}]{0,120}?(?:label|name|text)\s*:\s*(?:['"]([^'"]+)['"]|t\(\s*['"]([^'"]+)['"]\s*\))""", block)
        items = []
        for p in pairs:
            label = p[0] or (i18n.get(p[1], p[1]) if p[1] else "") or p[4] or (i18n.get(p[5], p[5]) if p[5] else "")
            value = p[2] or p[3]
            items.append({"value": value.strip(), "text": label})
        if len(items) >= 2:
            facts["reference"].append({"name": m.group(1), "items": items[:200], "line": line_of(text, m.start())})
    for m in ENUM_TS_RE.finditer(text):
        items = [x.split("=")[0].strip() for x in m.group(2).split(",") if x.strip() and not x.strip().startswith("//")]
        vals = [{"value": (x.split("=", 1)[1].strip().strip("'\"") if "=" in x else x.strip()), "text": x.split("=")[0].strip()}
                for x in m.group(2).split(",") if x.strip() and not x.strip().startswith("//")]
        if items:
            facts["reference"].append({"name": m.group(1), "items": vals, "line": line_of(text, m.start())})
    # which function each API call sits in, the functions each function calls, and jQuery handlers bound to ids
    funcs = function_spans(text)
    facts["functions"] = [{"name": f_["name"], "lines": [f_["l1"], f_["l2"]], "calls": f_["calls"]} for f_ in funcs]
    for api in facts["apis"]:
        inner = [f_ for f_ in funcs if f_["l1"] <= api["line"] <= f_["l2"]]
        if inner:
            api["in_function"] = min(inner, key=lambda f_: f_["l2"] - f_["l1"])["name"]
        elif any(a_ <= api["line"] <= b_ for a_, b_ in facts.get("_ctrl_spans", [])):
            api["on_load"] = True                       # AngularJS: the controller body itself runs when the page opens
    facts.pop("_ctrl_spans", None)
    for m in JQ_BIND_RE.finditer(text):
        b0 = text.find("{", m.end() - 1)
        if b0 < 0:
            continue
        l1, l2 = line_of(text, b0), line_of(text, match_close(text, b0, "{", "}"))
        for api in facts["apis"]:
            if l1 <= api["line"] <= l2:
                api.setdefault("bound_to", []).append(m.group(1) or m.group(2))
    return facts


FUNC_DEF_RE = re.compile(r"""(?:\bfunction\s+(\w+)\s*\([^)]*\)\s*\{|\b(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:function\s*\([^)]*\)|\([^)]*\)\s*=>|\w+\s*=>)\s*\{|(?:\$scope|\bvm|\bthis|\bself|\$ctrl)\.(\w+)\s*=\s*(?:async\s*)?(?:function\s*\([^)]*\)|\([^)]*\)\s*=>)\s*\{|^[ \t]*(?:public\s+|private\s+|protected\s+|async\s+)*(\w+)\s*\([^)]*\)\s*(?::\s*[\w<>\[\]|, ]+)?\s*\{|\b(\w+)\s*:\s*(?:async\s*)?function\s*\([^)]*\)\s*\{|\b(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{)""", re.M)
NOT_FUNCS = {"if", "for", "while", "switch", "catch", "function", "return", "constructor", "else", "do", "try", "with", "render"}
JQ_BIND_RE = re.compile(r"""\$\(\s*['"]#([\w\-]+)['"]\s*\)\s*\.\s*(?:on\(\s*['"]click['"]\s*,\s*|click\(\s*|submit\(\s*)(?:function\s*\([^)]*\)|\([^)]*\)\s*=>)\s*\{|document\.getElementById\(\s*['"]([\w\-]+)['"]\s*\)\.addEventListener\(\s*['"]click['"]\s*,\s*(?:function\s*\([^)]*\)|\([^)]*\)\s*=>)\s*\{""")
HANDLER_ATTRS = ("onClick__expr", "onClick", "onSubmit__expr", "ng-click", "data-ng-click", "ng-submit", "(click)", "(ngSubmit)", "@click",
                 "v-on:click", "@submit", "@submit.prevent", "onclick", "th:onclick", "action", "actionListener", "OnClick", "onPress__expr")


def handler_of(a):
    """The function a button or form calls: onClick={() => onSave()}, ng-click="save()", (click)="save()",
    @click="save", action="#{bean.save}", OnClick="btnSave_Click"."""
    for k in HANDLER_ATTRS:
        v = a.get(k)
        if not isinstance(v, str) or not v.strip():
            continue
        v = v.strip()
        m = re.match(r"^#\{\s*\w+\.(\w+)\s*\}$", v)             # JSF action="#{bean.save}"
        if m:
            return m.group(1)
        m = re.search(r"(?:=>\s*\{?\s*(?:await\s+)?|^)(?:this\.|vm\.|\$ctrl\.|props\.)?(\w+)\s*(?:\(|$)", v)
        if m and m.group(1) not in ("function", "e", "event", "true", "false", "null", "async"):
            return m.group(1)
    return None


def function_spans(text):
    """Named functions and methods with their line spans and the functions they call (for button -> API links)."""
    out = []
    for m in FUNC_DEF_RE.finditer(text):
        name = next((g for g in m.groups() if g), None)
        if not name or name in NOT_FUNCS:
            continue
        b0 = text.find("{", m.end() - 1)
        if b0 < 0:
            continue
        b1 = match_close(text, b0, "{", "}")
        body = text[b0:b1]
        calls = sorted(set(re.findall(r"(?:\bthis\.|\$scope\.|\bvm\.|\$ctrl\.|\b)(\w+)\s*\(", body)) - NOT_FUNCS - {name})
        out.append({"name": name, "l1": line_of(text, b0), "l2": line_of(text, b1), "calls": calls[:60]})
    return out

def load_aliases(root):
    """compilerOptions.baseUrl and paths from tsconfig / jsconfig (comments and trailing commas allowed)."""
    out = {"base": None, "paths": []}
    for name in ("tsconfig.json", "tsconfig.base.json", "tsconfig.app.json", "jsconfig.json"):
        p = os.path.join(root, name)
        txt = read(p) if os.path.isfile(p) else None
        if not txt:
            continue
        txt = re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", txt, flags=re.S)
        txt = re.sub(r",\s*([}\]])", r"\1", txt)
        try:
            co = json.loads(txt).get("compilerOptions", {})
        except Exception:
            continue
        base = co.get("baseUrl")
        if base is not None and out["base"] is None:
            out["base"] = os.path.normpath(base).replace(os.sep, "/").strip("./") if base not in (".", "./") else ""
        for pat, targets in (co.get("paths") or {}).items():
            for tg in targets[:2]:
                out["paths"].append((pat, os.path.normpath(os.path.join(base or ".", tg)).replace(os.sep, "/")))
    return out

ALIASES = {"base": None, "paths": []}

def after_change(text, pos, i18n):
    """What the screen does after a call that changes data: messages shown (on success and on
    error), where it goes next, and whether it reloads data. Looks at the code right after the call."""
    window = text[pos:pos + 1500]
    nxt = API_RE.search(window, 10)
    if nxt:
        window = window[:nxt.start()]
    out = {"success_messages": [], "error_messages": [], "navigates_to": None, "reloads": False}
    for m in FEEDBACK_RE.finditer(window):
        msg = i18n.get(m.group(3), m.group(3))
        before = window[:m.start()]
        is_error = bool(re.search(r"\bcatch\b|\berror\s*[:=(]|onError|\.catch\(|err\s*=>|\bfail", before[-300:])) or \
            bool(re.search(r"error|fail|warn", m.group(1), re.I))
        key = "error_messages" if is_error else "success_messages"
        if msg not in out[key]:
            out[key].append(msg)
    for m in NAV_RE.finditer(window):
        target = next((g for g in m.groups()[1::2] if g), None)
        target = re.sub(r"^#!?", "", target) if target else target
        if target and target.startswith("/"):
            out["navigates_to"] = re.sub(r"\$\{[^}]*\}", "{param}", target).split("?")[0]
            break
    for m in re.finditer(r"""(?:\$scope|\bvm|\bthis|\bself)\.(\w*(?:message|msg|error|success|alert|notice|info)\w*)\s*=\s*(['"])([^'"]{3,160})\2""", window, re.I):
        msg = i18n.get(m.group(3), m.group(3))              # AngularJS 1.x / Knockout: $scope.successMessage = 'Saved'
        key = "error_messages" if re.search(r"error|fail|warn", m.group(1), re.I) or re.search(r"\berror\b|catch|fail", window[:m.start()][-200:]) else "success_messages"
        if msg not in out[key]:
            out[key].append(msg)
    out["reloads"] = bool(REFRESH_RE.search(window))
    return out

def resolve_spec(spec, from_file, root, files_set):
    if not spec:
        return None
    base = None
    cands_base = []
    for pat, tg in ALIASES["paths"]:
        if pat.endswith("/*") and spec.startswith(pat[:-1]):
            cands_base.append(tg.replace("*", spec[len(pat) - 1:]))
        elif pat == spec:
            cands_base.append(tg)
    if ALIASES["base"] is not None and not spec.startswith("."):
        cands_base.append(os.path.join(ALIASES["base"], spec).replace(os.sep, "/"))
    for b in cands_base:
        hit = resolve_spec("./" + b, "x", root, files_set) if not b.startswith(".") else None
        if hit:
            return hit
    if spec.startswith("."):
        base = os.path.normpath(os.path.join(os.path.dirname(from_file), spec))
    elif spec.startswith(("@/", "~/")):
        base = os.path.join("src", spec[2:])
    elif not spec.startswith("@") and "/" in spec:
        base = os.path.join("src", spec)
    if base is None:
        return None
    base = base.replace(os.sep, "/")
    for cand in [base] + [base + e for e in (".tsx", ".ts", ".jsx", ".js", ".vue", ".html")] + \
                [base + "/index" + e for e in (".tsx", ".ts", ".jsx", ".js", ".vue")]:
        if cand in files_set:
            return cand
    return None

def resolve_loose(spec, from_file, files_set):
    """Template paths in older front ends are relative to the web root, not the file: 'views/client.html',
    '/WEB-INF/jsp/client.jsp', 'fragments/header', '_Address'. Match them by their tail."""
    if not spec:
        return None
    sp = re.sub(r"^(~/|/|\./)+", "", spec.split("?")[0].split("#")[0].strip()).replace("\\", "/")
    if not sp:
        return None
    if spec.startswith((".", "../")):
        base = os.path.normpath(os.path.join(os.path.dirname(from_file), spec)).replace(os.sep, "/")
        if base in files_set:
            return base
    tails = [sp] + [sp + e for e in (".html", ".htm", ".jsp", ".xhtml", ".cshtml", ".ftl", ".vm", ".js")]
    if "/" not in sp:
        tails += ["_" + sp + ".cshtml", sp + ".cshtml"]
    hits = [f for f in files_set for t in tails if f == t or f.endswith("/" + t)]
    if not hits:
        return None
    here = os.path.dirname(from_file)
    return sorted(set(hits), key=lambda f: (0 if f.startswith(here) else 1, len(f)))[0]


WEB_ROOTS = re.compile(r"^(?:.*/)?(?:src/main/(?:resources/(?:static|public|templates|META-INF/resources)|webapp)|WebContent|WebRoot|web|wwwroot|public|static|app)/")


def page_route(f):
    """The URL a page file is served at, when the file's place says it (static folders, the web app root);
    None for templates a controller renders (WEB-INF, templates/, Views/) - those get the controller's route."""
    if re.search(r"(^|/)(WEB-INF|templates|Views|views/shared|layouts?|fragments?|partials?|includes?)/", f, re.I) and not re.search(r"(^|/)static/", f):
        return None
    m = WEB_ROOTS.match(f)
    if not m:
        return "/" + f if re.search(r"\.(aspx|xhtml|jsp|php)$", f) else None   # served from the project root
    return "/" + f[m.end():]


def route_rx(route, relative=False):
    """Regex for a route; params match one segment. Relative (nested) routes match as a suffix,
    because their parent path is added by the router at run time."""
    segs = [s for s in str(route).split("/") if s]
    if not segs or (relative and all(s[:1] in ":{*" for s in segs)):
        return None
    body = "".join("/" + ("[^/]+" if s[:1] in ":{*" else re.escape(s)) for s in segs)
    return re.compile(("^(?:/.*)?" if relative else "^") + body + "/?$")

def next_route_from_file(f):
    m = re.match(r"(?:src/)?(pages|app)/(.+)$", f)
    if not m or re.search(r"(^|/)(_app|_document|_error|api)(/|\.|$)", m.group(2)):
        return None
    p = m.group(2)
    if m.group(1) == "app":
        if not re.search(r"(^|/)page\.(t|j)sx?$", p):
            return None
        p = re.sub(r"/?page\.(t|j)sx?$", "", p)
    else:
        p = re.sub(r"\.(t|j)sx?$", "", p)
        p = re.sub(r"(^|/)index$", "", p)
    p = re.sub(r"\[\.\.\.(\w+)\]", r"*", p)
    p = re.sub(r"\[(\w+)\]", r":\1", p)
    p = re.sub(r"\(\w+\)/?", "", p)
    return "/" + p.strip("/")

def build_frontend(root, i18n, cache, cache_out, file_routes=False):
    global ALIASES
    ALIASES = load_aliases(root)
    files, facts = [], {}
    for p in walk(root, FE_EXT):
        r = rel(p, root)
        text_hash = None
        try:
            with open(p, "rb") as fh:
                text_hash = hashlib.sha1(fh.read()).hexdigest()
        except OSError:
            continue
        key = f"fe::{root}::{r}"
        c = cache.get(key)
        if c and c.get("hash") == text_hash and c.get("v") == CODE_HASH:
            facts[r] = c["facts"]
        else:
            fx = parse_frontend_file(p, root, i18n)
            if fx is None:
                continue
            facts[r] = fx
        cache_out[key] = {"hash": text_hash, "v": CODE_HASH, "facts": facts[r]}
        files.append(r)
    files_set = set(files)
    # component name -> file, import graph
    comp_file, graph = {}, defaultdict(set)
    for f, fx in facts.items():
        for c in fx["components"] + ([fx["default_export"]] if fx["default_export"] else []):
            comp_file.setdefault(c, f)
        stem = os.path.splitext(os.path.basename(f))[0]
        if stem[:1].isupper():
            comp_file.setdefault(stem, f)
        for imp in fx["imports"]:
            tgt = resolve_spec(imp["spec"], f, root, files_set) or (resolve_loose(imp["spec"], f, files_set) if imp.get("loose") or f.endswith(PAGE_EXT) else None)
            if tgt and tgt != f:
                graph[f].add(tgt)
                for n in imp["names"]:
                    comp_file.setdefault(n, tgt)
        for name, spec in fx["lazy"].items():
            tgt = resolve_spec(spec, f, root, files_set)
            if tgt:
                comp_file[name] = tgt
                graph[f].add(tgt)
    ctrl_of = {}                                        # controller file -> {page file: controller name}
    for f, fx in facts.items():                         # ng-controller="ClientCtrl": the page uses that controller's file
        for ctrl in fx.get("controllers") or []:
            if comp_file.get(ctrl) and comp_file[ctrl] != f:
                graph[f].add(comp_file[ctrl])
                ctrl_of.setdefault(comp_file[ctrl], {})[f] = ctrl
    # screens from routes
    screens = {}
    for f, fx in facts.items():
        for r in fx["routes"]:
            target = None
            if r.get("import"):
                target = resolve_spec(r["import"], f, root, files_set) or resolve_loose(r["import"], f, files_set)
            if not target and r.get("component"):
                target = comp_file.get(r["component"].split(".")[-1])
            if not target:
                continue
            if r.get("controller") and comp_file.get(r["controller"]) and comp_file[r["controller"]] != target:
                graph[target].add(comp_file[r["controller"]])
                ctrl_of.setdefault(comp_file[r["controller"]], {})[target] = r["controller"]
            relative = not r["path"].startswith("/") and r["path"] not in ("", "*")
            path = "/" + r["path"] if relative else r["path"]
            sid = path or "/"
            screens.setdefault(sid, {"route": sid, "component": r.get("component") or os.path.splitext(os.path.basename(target))[0],
                                     "file": target, "defined_in": f"{f}:{r['line']}", "relative_route": relative,
                                     "roles": r.get("roles") or []})
    for f in (files if file_routes else []):
        rp = next_route_from_file(f)
        if rp and rp not in screens:
            screens[rp] = {"route": rp, "component": os.path.splitext(os.path.basename(f))[0], "file": f,
                           "defined_in": f"{f} (file-based route)"}
    if not screens:
        for f in files:
            if re.search(r"(^|/)(pages|views|screens|containers|features)/", f) and facts[f]["elements"] and not f.endswith(PAGE_EXT):
                screens[f] = {"route": None, "component": os.path.splitext(os.path.basename(f))[0], "file": f,
                              "defined_in": f"{f} (page folder, no router found)"}
    # page files no router names (JSP, JSF, Thymeleaf, Razor, ASP.NET, plain HTML with AngularJS 1.x or jQuery):
    # every page with fields or buttons is a screen, unless another screen already includes it
    modern = bool(set(detect_frameworks(root)[0]) & {"React", "Next.js", "Angular", "Vue", "Nuxt"})
    covered = set()
    for sid, sc in screens.items():
        seen, todo = {sc["file"]}, [sc["file"]]
        while todo:
            cur = todo.pop()
            for nxt in graph.get(cur, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    todo.append(nxt)
        covered |= seen
    included = {t for f in files for t in graph.get(f, ()) if t.endswith(PAGE_EXT)}
    for f in files:
        if not f.endswith(PAGE_EXT) or f in covered or f in screens:
            continue
        fx = facts[f]
        if not any(e.get("kind") in ("input", "dropdown", "checkbox", "button") for e in fx["elements"]):
            continue
        if f in included and not re.search(r"\.(jsp|xhtml|aspx|cshtml|gsp)$", f) and re.search(r"(^|/)(partials?|fragments?|includes?|directives?|components?|templates?/(?:partials?|fragments?))/|(^|/)_", f):
            continue                                       # a fragment: it is read with the page that includes it
        if f.endswith((".html", ".htm")) and modern and not page_route(f):
            continue                                       # a component template of a modern app: read through its component
        rt = page_route(f)
        screens[rt or f] = {"route": rt, "component": os.path.splitext(os.path.basename(f))[0], "file": f,
                            "defined_in": f"{f} (page file" + (", served at " + rt if rt else ", route from the controller that renders it") + ")",
                            "page_file": True}
    # shared components (layout, header): imported by many screens -> not part of each screen
    reach = {}
    for sid, s in screens.items():
        seen, todo = {s["file"]}, [(s["file"], 0)]
        while todo:
            cur, dpt = todo.pop()
            if dpt >= 4:
                continue
            for nxt in graph.get(cur, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    todo.append((nxt, dpt + 1))
        reach[sid] = seen
    count = defaultdict(int)
    for seen in reach.values():
        for f in seen:
            count[f] += 1
    n = max(len(screens), 1)
    shared = {f for f, c in count.items() if n >= 5 and c >= max(5, 0.4 * n)}
    # aggregate
    out = []
    for sid, s in sorted(screens.items(), key=lambda kv: str(kv[0])):
        own = [s["file"]] + sorted(f for f in reach[sid] if f != s["file"] and f not in shared)
        agg = {"id": sid, "route": s["route"], "relative_route": s.get("relative_route", False), "page_file": s.get("page_file", False),
               "component": s["component"], "file": s["file"],
               "defined_in": s["defined_in"], "files": own, "elements": [], "texts": [], "validations": [],
               "apis": [], "loaders": [], "navigates_to": [], "dialogs": [], "reference": [], "options": [],
               "roles": s.get("roles") or [], "role_hints": []}
        for f in own:
            fx = facts[f]
            span = None
            if fx.get("controller_regions") and f in ctrl_of:
                name = next((ctrl_of[f][x] for x in [s["file"]] + own if x in ctrl_of[f]), None)
                span = fx["controller_regions"].get(name)
            inside = (lambda item: span is None or span[0] <= item.get("line", 0) <= span[1])
            fx = {**fx, "apis": [a for a in fx["apis"] if inside(a)], "navigates": [n for n in fx["navigates"] if inside(n)]}
            for e in fx["elements"]:
                agg["elements"].append({**e, "file": f})
            for t in fx["texts"]:
                agg["texts"].append({"kind": t["kind"], "text": t["text"], "file": f, "line": t["line"]})
            for v in fx["validations"]:
                agg["validations"].append({**v, "file": f})
            for a in fx["apis"]:
                agg["apis"].append({**a, "file": f, "on_load": a["on_load"] and f == s["file"] or a["on_load"]})
            agg["loaders"] += fx["loaders"]
            for rh in fx.get("role_hints", []):
                agg["role_hints"].append({**rh, "file": f})
            for nv in fx["navigates"]:
                agg["navigates_to"].append({**nv, "file": f})
            if fx["is_dialog"] and f != s["file"]:
                agg["dialogs"].append(f)
            for r in fx["reference"]:
                agg["reference"].append({**r, "file": f})
            for o in fx["options"]:
                agg["options"].append({**o, "file": f})
        agg["loaders"] = sorted(set(agg["loaders"]))
        link_triggers(agg, [facts[f] for f in own])
        out.append(agg)
    # navigation targets -> screen ids
    route_res = [(rx, s["id"]) for s in out if s["route"] and s["route"] not in ("*",)
                 for rx in [route_rx(s["route"], s["relative_route"])] if rx]
    route_res.sort(key=lambda x: 0 if x[0].pattern.startswith("^/") else 1)   # absolute routes first
    for s in out:
        for nv in s["navigates_to"]:
            probe = re.sub(r"\{param\}", "x", nv["to"])
            nv["screen"] = next((sid for rx, sid in route_res if rx.match(probe)), None)
    reference = [{**r, "file": f} for f, fx in facts.items() for r in fx["reference"]]
    return out, reference, sorted(shared), len(files)

def element_key(e):
    return e.get("id") or e.get("testid") or e.get("name") or (("text:" + e["text"]) if e.get("text") else None)


def link_triggers(agg, fxs):
    """Which button or link makes each API call: its handler function reaches the function the call sits in
    (up to 3 calls deep), or a jQuery/DOM handler is bound to its id. On-load calls need no trigger."""
    calls = {}
    for fx in fxs:
        for f_ in fx.get("functions", []):
            calls.setdefault(f_["name"], set()).update(f_["calls"])

    def reach(h, depth=3):
        seen, todo = {h}, [h]
        for _ in range(depth):
            nxt = []
            for x in todo:
                for y in calls.get(x, ()):
                    if y not in seen:
                        seen.add(y)
                        nxt.append(y)
            todo = nxt
        return seen
    for e in agg["elements"]:
        if e.get("handler"):
            e["_reach"] = reach(e["handler"])
    submits = [element_key(e) for e in agg["elements"] if e.get("kind") == "button" and element_key(e) and
               (str(e.get("type", "")).lower() == "submit" or e.get("tag") in ("s:submit", "h:commandButton", "p:commandButton", "asp:Button",
                                                                            "html:submit", "g:submitButton", "g:actionSubmit") or
                re.search(r"(?i)save|submit|send|confirm|update|create|apply|ok\b", e.get("text") or ""))]
    for api in agg["apis"]:
        by = []
        if api.get("form_submit"):
            by += [k for k in submits if k]
        for e in agg["elements"]:
            key = element_key(e)
            if not key:
                continue
            if api.get("in_function") and api["in_function"] in e.get("_reach", ()):
                by.append(key)
            elif key in (api.get("bound_to") or []):
                by.append(key)
        if by:
            api["triggered_by"] = sorted(set(by))
    for e in agg["elements"]:
        e.pop("_reach", None)


# ----------------------------------------------------------------------------------------------
# outside systems the back end calls (BMC, Alfresco, payment, KYC providers ...)
INTEGRATION_PATTERNS = [
    ("Feign client", re.compile(r"""@FeignClient\s*\(\s*(?:(?:name|value)\s*=\s*)?["']([^"']+)["']""")),
    ("REST call", re.compile(r"""\b(\w*(?:[Rr]estTemplate|[Ww]ebClient|[Rr]estClient))\s*\.\s*(?:getForObject|getForEntity|postForObject|postForEntity|exchange|put|delete|patchForObject|get|post|method)\s*\(""")),
    ("SOAP call", re.compile(r"""\b(\w*[Ww]ebServiceTemplate)\s*\.\s*marshalSendAndReceive|@WebServiceClient\s*\(\s*name\s*=\s*["']([^"']+)["']""")),
    ("JMS message", re.compile(r"""\b\w*[Jj]msTemplate\s*\.\s*(?:convertAndSend|send)\s*\(\s*["']([^"']+)["']""")),
    ("Kafka message", re.compile(r"""\b\w*[Kk]afkaTemplate\s*\.\s*send\s*\(\s*["']([^"']+)["']""")),
    ("HTTP call", re.compile(r"""\b(?:HttpClient|httpClient|_httpClient)\s*\.\s*(?:Get|Post|Put|Delete|Send)Async\s*\(|HttpRequest\.newBuilder\(|new\s+HttpPost\(|new\s+HttpGet\(""")),
    ("HTTP call", re.compile(r"""\b(?:axios|got|fetch|requests|httpx)\s*[\.(]\s*(?:get|post|put|delete|request)?\s*\(?\s*[`'"]https?://""")),
]
SYSTEM_WORDS = re.compile(r"(?i)(bmc|alfresco|remedy|sap|salesforce|swift|kyc|aml|sanction|payment|card|core ?banking|crm|dms|document|archive|ldap|"
                          r"active ?directory|sms|email|mail|notification|fax|print|ocr|esign|docusign|credit|bureau|fx|ledger|"
                          r"mainframe|cics|mq|kafka|jms|s3|blob|sharepoint|servicenow|jira|onbase|filenet|documentum|temenos|finacle|flexcube)")


def system_name(cls, hint, file_text):
    """A readable name for the outside system: from the client's own name (BmcValidationClient -> BMC),
    the Feign name, a config key (${alfresco.url} -> Alfresco), or the class name without Client/Service."""
    def pretty(w):
        w = w.strip()
        return w.upper() if len(w) <= 4 else w[:1].upper() + w[1:]
    if hint:
        w = SYSTEM_WORDS.search(hint)
        return pretty(w.group(1)) if w else pretty(re.split(r"[-_.]", hint)[0])
    m = re.search(r"\$\{\s*([\w\-]+)\.(?:[\w\-]+\.)*(?:url|uri|base-?url|endpoint|host)\s*[}:]", file_text, re.I)
    if m:
        return pretty(m.group(1))
    if cls:
        w = SYSTEM_WORDS.search(cls)
        if w:
            return pretty(w.group(1))
    base = re.sub(r"(Client|Service|Gateway|Adapter|Connector|Proxy|Api|Integration|Impl)+$", "", cls or hint or "")
    return base or (hint or cls or "external system")


def find_integrations(root):
    out = []
    for p in walk(root, BE_EXT):
        if re.search(r"(^|/)(test|tests|__tests__|spec)/|Test\.java$|\.spec\.|\.test\.", rel(p, root)):
            continue
        text = read(p) or ""
        if not text:
            continue
        cls = (re.search(r"\b(?:class|interface)\s+(\w+)", text) or [None, None])[1] or os.path.splitext(os.path.basename(p))[0]
        for kind, rx in INTEGRATION_PATTERNS:
            for m in rx.finditer(text):
                hint = next((g for g in m.groups() if g), None) if m.groups() else None
                name = system_name(cls, hint if kind in ("Feign client", "SOAP call") else None, text)
                if kind in ("JMS message", "Kafka message") and hint:
                    name = f"{name} ({hint})" if name.lower() not in hint.lower() else hint
                out.append({"system": name, "kind": kind, "class": cls, "file": rel(p, root), "line": line_of(text, m.start())})
    seen, uniq = set(), []
    for x in out:
        k = (x["system"], x["kind"], x["file"])
        if k not in seen:
            seen.add(k)
            uniq.append(x)
    return uniq


def link_integrations(root, eps, ints):
    """Endpoint -> outside systems it reaches: from the controller file through the classes it uses (up to 4
    steps: controller -> service -> client). Class references are by type name, so this is a strong hint."""
    if not ints or not eps:
        return
    files = {}
    for p in walk(root, BE_EXT):
        t = read(p) or ""
        for c in re.findall(r"\b(?:class|interface)\s+(\w+)", t):
            files.setdefault(c, rel(p, root))
    texts = {}

    def text_of(f):
        if f not in texts:
            texts[f] = read(os.path.join(root, f)) or ""
        return texts[f]
    by_file = {}
    for x in ints:
        by_file.setdefault(x["file"], set()).add(x["system"])
    impl = {}                                           # interface -> the class that implements it
    for c, f in files.items():
        for i_ in re.findall(r"\bclass\s+" + re.escape(c) + r"\b[^{]*?\bimplements\s+([\w\s,<>]+)\{", text_of(f)):
            for nm in re.findall(r"\b([A-Z]\w+)", i_):
                impl.setdefault(nm, c)

    def body_of(f, method):
        t = text_of(f)
        m = re.search(r"\b" + re.escape(method) + r"\s*\([^;{)]*(?:\([^)]*\)[^;{)]*)*\)\s*(?:throws\s+[\w\s,.]+)?\{", t)
        if not m:
            return None
        b0 = t.find("{", m.end() - 1)
        return t[b0:match_close(t, b0, "{", "}")]

    def type_of(f, var):
        t = text_of(f)
        m = re.search(r"\b([A-Z]\w*)(?:<[^>]*>)?\s+" + re.escape(var) + r"\s*[;=,)]", t)
        return m.group(1) if m else (var[:1].upper() + var[1:] if var[:1].islower() else var)

    def trace(f, method, depth=0, seen=None):
        """Systems reached from one method: its calls on fields (service.submit -> RequestService.submit -> ...)."""
        seen = seen if seen is not None else set()
        if depth > 5 or (f, method) in seen:
            return set()
        seen.add((f, method))
        found = set(by_file.get(f, set())) if depth else set()
        body = body_of(f, method)
        if body is None:
            return set(by_file.get(f, set()))
        for var, meth in set(re.findall(r"\b([a-z]\w*)\s*\.\s*(\w+)\s*\(", body)):
            typ = type_of(f, var)
            tf = files.get(typ) or files.get(impl.get(typ, ""))
            if tf:
                found |= by_file.get(tf, set())
                if impl.get(typ) and files.get(impl[typ]):
                    found |= by_file.get(files[impl[typ]], set())
                    found |= trace(files[impl[typ]], meth, depth + 1, seen)
                found |= trace(tf, meth, depth + 1, seen)
        for c in set(re.findall(r"\bnew\s+([A-Z]\w+)", body)):
            if files.get(c):
                found |= by_file.get(files[c], set())
        return found
    for e in eps:
        if e.get("handler") and body_of(e["file"], e["handler"]) is not None:
            found = trace(e["file"], e["handler"])
            if found:
                e["integrations"] = sorted(found)
                e["integrations_from"] = "the handler's calls"
            continue
        seen, todo, found = {e["file"]}, [e["file"]], set()
        for _ in range(4):
            nxt = []
            for f in todo:
                found |= by_file.get(f, set())
                for c in set(re.findall(r"\b([A-Z]\w{2,})\b", text_of(f))):
                    g = files.get(c)
                    if g and g not in seen:
                        seen.add(g)
                        nxt.append(g)
            todo = nxt
        for f in todo:
            found |= by_file.get(f, set())
        if found:
            e["integrations"] = sorted(found)


# ----------------------------------------------------------------------------------------------
# back end
JAVA_CLASS_MAP_RE = re.compile(r"@RequestMapping\(\s*(?:(?:value|path)\s*=\s*)?\{?\s*\"([^\"]*)\"")
JAVA_METHOD_RE = re.compile(r"@(Get|Post|Put|Delete|Patch|Request)Mapping\b(\(([^)]*)\))?")
JAVA_SIG_RE = re.compile(r"(?:public|protected|private)?\s*(?:[\w<>\[\],\.\?\s]+?)\s+(\w+)\s*\(([^)]*(?:\([^)]*\)[^)]*)*)\)")
JAVA_FIELD_RE = re.compile(r"((?:\s*@\w+(?:\([^)]*\))?\s*)+)\s*(?:private|protected|public)\s+(?:final\s+)?([\w<>\[\],\.\? ]+?)\s+(\w+)\s*[;=]")
JAVA_ENUM_RE = re.compile(r"\benum\s+(\w+)\s*\{([^;}]*)")
TS_PROP_RE = re.compile(r"((?:\s*@\w+\([^)]*\)\s*)+)\s*(?:readonly\s+)?(\w+)\s*[?!]?\s*:\s*([\w\[\]<>| ]+)")
CS_PROP_RE = re.compile(r"((?:\s*\[[^\]]+\]\s*)+)\s*public\s+([\w<>\[\]\?, ]+?)\s+(\w+)\s*\{\s*get")
NODE_ROUTE_RE = re.compile(r"""\b(?:router|app|route|server|api)\s*\.\s*(get|post|put|patch|delete)\s*\(\s*['"`]([^'"`]+)['"`]""")
NEST_CTRL_RE = re.compile(r"""@Controller\(\s*(?:['"]([^'"]*)['"])?""")
NEST_METHOD_RE = re.compile(r"""@(Get|Post|Put|Patch|Delete)\(\s*(?:['"]([^'"]*)['"])?\s*\)""")
CS_ROUTE_RE = re.compile(r"""\[Route\(\s*"([^"]*)"\s*\)\]""")
CS_METHOD_RE = re.compile(r"""\[Http(Get|Post|Put|Delete|Patch)(?:\(\s*"([^"]*)"\s*\))?\]""")
PY_ROUTE_RE = re.compile(r"""@(?:\w+)\.(get|post|put|patch|delete|route)\(\s*['"]([^'"]+)['"]([^)]*)\)\s*\n\s*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)""")
VALID_ANN = re.compile(r"@(NotNull|NotBlank|NotEmpty|Size|Pattern|Email|Min|Max|Digits|Past|Future|PastOrPresent|FutureOrPresent|DecimalMin|DecimalMax|Positive|PositiveOrZero|Negative|Length|Range|Valid|IsNotEmpty|IsString|IsEmail|MaxLength|MinLength|Matches|IsIn|IsEnum|IsOptional|IsDateString|IsNumber|IsInt|Min|Max)\b(\([^)]*\))?")
CS_VALID = re.compile(r"\[(Required|StringLength|MaxLength|MinLength|RegularExpression|Range|EmailAddress|Phone|CreditCard|Compare)(\([^\]]*\))?\]")

def join_path(a, b):
    a, b = (a or "").strip(), (b or "").strip()
    p = "/" + "/".join(x.strip("/") for x in (a, b) if x and x.strip("/"))
    return re.sub(r"/+", "/", p)

def parse_backend(root):
    endpoints, dtos, enums = [], {}, []
    for p in walk(root, BE_EXT):
        text = read(p)
        if not text:
            continue
        f = rel(p, root)
        if p.endswith((".java", ".kt")):
            for m in JAVA_ENUM_RE.finditer(text):
                vals = [re.split(r"[\s(]", x.strip())[0] for x in m.group(2).split(",") if re.match(r"\s*[A-Z_][A-Z0-9_]*", x)]
                if vals:
                    enums.append({"name": m.group(1), "items": [{"value": v, "text": v} for v in vals], "file": f, "line": line_of(text, m.start())})
            cm = re.search(r"class\s+(\w+)", text)
            if cm:
                fields = []
                for fm in JAVA_FIELD_RE.finditer(text):
                    anns = VALID_ANN.findall(fm.group(1))
                    if anns:
                        fields.append({"field": fm.group(3), "type": fm.group(2).strip(),
                                       "rules": [a + (args or "") for a, args in anns if a != "Valid"], "line": line_of(text, fm.start(3))})
                if fields:
                    dtos[cm.group(1)] = {"file": f, "fields": fields}
            if "@RestController" in text or "@Controller" in text:
                cls_idx = text.find(" class ")
                base = ""
                bm = JAVA_CLASS_MAP_RE.search(text[:cls_idx if cls_idx > 0 else len(text)])
                if bm:
                    base = bm.group(1)
                for m in JAVA_METHOD_RE.finditer(text, cls_idx if cls_idx > 0 else 0):
                    args = m.group(3) or ""
                    pm = re.search(r"(?:value|path)\s*=\s*\{?\s*\"([^\"]*)\"", args) or re.search(r"^\s*\{?\s*\"([^\"]*)\"", args)
                    sub = pm.group(1) if pm else ""
                    verb = m.group(1).upper()
                    if verb == "REQUEST":
                        vm = re.search(r"RequestMethod\.(\w+)", args)
                        verb = vm.group(1) if vm else "ANY"
                    sm = JAVA_SIG_RE.search(text, m.end(), m.end() + 600)
                    handler, params = (sm.group(1), sm.group(2)) if sm else (None, "")
                    body = re.search(r"@RequestBody\s+(?:@\w+(?:\([^)]*\))?\s+)*(?:final\s+)?([\w<>\.]+)", params)
                    nxt_m = JAVA_METHOD_RE.search(text, m.end())
                    mbody = text[m.end():nxt_m.start() if nxt_m else min(len(text), m.end() + 4000)]
                    vm_ = None if "@RestController" in text or "@ResponseBody" in mbody[:300] else \
                        re.search(r'\breturn\s+(?:new\s+ModelAndView\(\s*)?"(?!redirect:|forward:)([\w/\-\.]+)"|setViewName\(\s*"([\w/\-\.]+)"|new\s+ModelAndView\(\s*"([\w/\-\.]+)"', mbody)
                    endpoints.append({"method": verb, "path": join_path(base, sub), "handler": handler,
                                      **({"view": next(g for g in vm_.groups() if g)} if vm_ else {}),
                                      "request_body": body.group(1).split(".")[-1] if body else None,
                                      "path_params": re.findall(r"@PathVariable(?:\([^)]*\))?\s+\w+\s+(\w+)", params),
                                      "query_params": re.findall(r"@RequestParam(?:\([^)]*\))?\s+[\w<>]+\s+(\w+)", params),
                                      "file": f, "line": line_of(text, m.start())})
        elif p.endswith(".cs"):
            cm = re.search(r"class\s+(\w+)", text)
            if cm:
                fields = [{"field": pm.group(3), "type": pm.group(2).strip(), "rules": [a + (x or "") for a, x in CS_VALID.findall(pm.group(1))],
                           "line": line_of(text, pm.start(3))} for pm in CS_PROP_RE.finditer(text) if CS_VALID.search(pm.group(1))]
                if fields:
                    dtos[cm.group(1)] = {"file": f, "fields": fields}
            for m in re.finditer(r"\benum\s+(\w+)\s*\{([^}]*)\}", text):
                vals = [x.split("=")[0].strip() for x in m.group(2).split(",") if x.strip()]
                enums.append({"name": m.group(1), "items": [{"value": v, "text": v} for v in vals], "file": f, "line": line_of(text, m.start())})
            if re.search(r":\s*Controller\b", text) and "[ApiController]" not in text:   # ASP.NET MVC: actions render views
                cname = re.sub(r"Controller$", "", cm.group(1)) if cm else ""
                for am in re.finditer(r"""((?:\[\w+(?:\([^)]*\))?\]\s*)*)public\s+(?:async\s+)?(?:Task<)?(?:ActionResult|IActionResult|ViewResult)>?\s+(\w+)\s*\(""", text):
                    verb = re.search(r"\[Http(Get|Post|Put|Delete)", am.group(1))
                    rest = text[am.end():am.end() + 3000]
                    vw = re.search(r'return\s+(?:Partial)?View\(\s*"([^"]+)"', rest)
                    endpoints.append({"method": verb.group(1).upper() if verb else "GET", "path": f"/{cname}/{am.group(2)}",
                                      "handler": am.group(2), "request_body": None, "view": vw.group(1) if vw else f"{cname}/{am.group(2)}",
                                      "file": f, "line": line_of(text, am.start())})
            if "ControllerBase" in text or "[ApiController]" in text:
                cname = cm.group(1) if cm else ""
                rm = CS_ROUTE_RE.search(text)
                base = (rm.group(1) if rm else "").replace("[controller]", re.sub(r"Controller$", "", cname).lower())
                for m in CS_METHOD_RE.finditer(text):
                    sm = re.search(r"public\s+[\w<>\[\],\s\.]+?\s+(\w+)\s*\(([^)]*)\)", text[m.end():m.end() + 500])
                    body = re.search(r"\[FromBody\]\s*([\w<>\.]+)", sm.group(2)) if sm else None
                    endpoints.append({"method": m.group(1).upper(), "path": join_path(base, m.group(2) or ""),
                                      "handler": sm.group(1) if sm else None, "request_body": body.group(1) if body else None,
                                      "file": f, "line": line_of(text, m.start())})
        elif p.endswith(".py"):
            for m in PY_ROUTE_RE.finditer(text):
                verb = m.group(1).upper()
                if verb == "ROUTE":
                    mm = re.findall(r"['\"](GET|POST|PUT|PATCH|DELETE)['\"]", m.group(3), re.I)
                    verb = "/".join(x.upper() for x in mm) or "GET"
                body = re.search(r"\w+\s*:\s*([A-Z]\w+)", m.group(5))
                endpoints.append({"method": verb, "path": m.group(2), "handler": m.group(4),
                                  "request_body": body.group(1) if body else None, "file": f, "line": line_of(text, m.start())})
            for cm in re.finditer(r"class\s+(\w+)\((?:BaseModel|Schema|serializers\.\w+)\):", text):
                block = text[cm.end():cm.end() + 3000].split("\nclass ")[0]
                fields = [{"field": x.group(1), "type": x.group(2).strip(), "rules": re.findall(r"(max_length|min_length|regex|pattern|gt|ge|lt|le|required)\s*=\s*([^,)]+)", x.group(2)),
                           "line": line_of(text, cm.end() + x.start())}
                          for x in re.finditer(r"\n\s+(\w+)\s*:\s*([^\n=]+(?:=[^\n]+)?)", block)]
                fields = [{**x, "rules": [f"{a}={b.strip()}" for a, b in x["rules"]]} for x in fields if x["rules"] or "Field(" in x["type"] or "constr(" in x["type"]]
                if fields:
                    dtos[cm.group(1)] = {"file": f, "fields": fields}
        else:  # .js / .ts back end (Express, NestJS)
            server = re.search(r"""require\(\s*['"](?:express|fastify|koa-router|@koa/router)['"]|from\s+['"](?:express|fastify|koa-router|@koa/router|hono)['"]|express\.Router\(|\bRouter\(\)""", text)
            for m in (NODE_ROUTE_RE.finditer(text) if server else ()):
                endpoints.append({"method": m.group(1).upper(), "path": m.group(2), "handler": None, "request_body": None,
                                  "file": f, "line": line_of(text, m.start())})
            cm = NEST_CTRL_RE.search(text)
            if cm:
                for m in NEST_METHOD_RE.finditer(text, cm.end()):
                    rest = re.sub(r"^(?:\s*@\w+\([^)]*\))+", "", text[m.end():m.end() + 600])
                    sm = re.search(r"(\w+)\s*\(([^)]*)\)", rest)
                    body = re.search(r"@Body\(\)\s*\w+\s*:\s*(\w+)", sm.group(2)) if sm else None
                    endpoints.append({"method": m.group(1).upper(), "path": join_path(cm.group(1) or "", m.group(2) or ""),
                                      "handler": sm.group(1) if sm else None, "request_body": body.group(1) if body else None,
                                      "file": f, "line": line_of(text, m.start())})
            kl = re.search(r"class\s+(\w+)", text)
            if kl and re.search(r"@(IsNotEmpty|IsString|MaxLength|IsEmail|Matches|IsIn|IsEnum)\b", text):
                fields = [{"field": pm.group(2), "type": pm.group(3).strip(), "rules": [a + (x or "") for a, x in VALID_ANN.findall(pm.group(1))],
                           "line": line_of(text, pm.start(2))} for pm in TS_PROP_RE.finditer(text) if VALID_ANN.search(pm.group(1))]
                if fields:
                    dtos[kl.group(1)] = {"file": f, "fields": fields}
    # Struts: actions and the page each one shows (struts.xml, struts-config.xml)
    for p in walk(root, (".xml",)):
        fn = os.path.basename(p)
        if not re.match(r"struts(-[\w\-]+)?\.xml$|struts-config[\w\-]*\.xml$", fn):
            continue
        text = read(p) or ""
        f = rel(p, root)
        for am in re.finditer(r"""<action\b([^>]*)>(.*?)</action>|<action\b([^>]*)/>""", text, re.S):
            attrs, inner = am.group(1) or am.group(3) or "", am.group(2) or ""
            nm = re.search(r"""\b(?:name|path)\s*=\s*["']([^"']+)["']""", attrs)
            if not nm:
                continue
            page = re.search(r"""<(?:result|forward)\b[^>]*?(?:path\s*=\s*["']([^"']+)["'][^>]*/?>|>([^<]+)</result>)""", inner)
            path = nm.group(1) if nm.group(1).startswith("/") else "/" + nm.group(1)
            endpoints.append({"method": "ANY", "path": path + (".action" if fn.startswith("struts.") and not path.endswith((".action", ".do")) else
                                                            ".do" if not path.endswith(".do") else ""),
                              "handler": (re.search(r"""\b(?:class|type)\s*=\s*["']([\w\.]+)["']""", attrs) or [None, None])[1],
                              "request_body": None, **({"view": (page.group(1) or page.group(2)).strip()} if page else {}),
                              "file": f, "line": line_of(text, am.start())})
    for e in endpoints:
        if e.get("request_body") and e["request_body"] in dtos:
            e["request_fields"] = dtos[e["request_body"]]["fields"]
            e["request_body_file"] = dtos[e["request_body"]]["file"]
    return endpoints, dtos, enums

# ----------------------------------------------------------------------------------------------
# business facts from the back end: checks, roles, status flows, prerequisites, data model
# (every fact keeps its file and line; nothing is interpreted here, the builder writes plain English)
BIZ_EXT = (".java", ".kt", ".cs", ".py", ".js", ".ts")
METHOD_SIG_RE = re.compile(r"""(?:(?:public|private|protected|internal|static|async|override|virtual|final|suspend)\s+)*[\w<>\[\],\.\? ]*?\b([a-zA-Z_]\w*)\s*\([^()]*(?:\([^()]*\)[^()]*)*\)\s*(?::\s*[\w<>\[\]\| ,\.]+)?\s*(?:throws\s+[\w\., ]+)?\s*\{|\bdef\s+(\w+)\s*\(|\bfun\s+(\w+)\s*\(|(?:const|let)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{|\b(\w+)\s*:\s*(?:async\s*)?function\s*\(|\bfunction\s+(\w+)\s*\(""")
NOT_METHODS = {"if", "for", "while", "switch", "catch", "return", "new", "else", "try", "synchronized", "using", "foreach", "lock", "when", "elif"}
THROW_RE = re.compile(r"""\bthrow\s+new\s+([\w\.]+)\s*\(\s*(?:[\w\.]+\s*,\s*)?(?:(?:String\.format|format|\$)?\(?\s*)?(["'`])(.+?)\2|\braise\s+([\w\.]+)\s*\(\s*(?:status_code\s*=\s*\d+\s*,\s*)?(?:detail\s*=\s*|message\s*=\s*)?([fr]?)(["'])(.+?)\6|\breturn\s+(BadRequest|Conflict|Forbid|Unauthorized|NotFound|UnprocessableEntity)\s*\(\s*(?:new\s*\{[^}]*?)?(["'])(.+?)\9|\bres\s*\.\s*status\s*\(\s*(4\d\d)\s*\)\s*\.\s*(?:json|send)\s*\(\s*(?:\{\s*\w+\s*:\s*)?(["'`])(.+?)\12""")
ASSERT_RE = re.compile(r"""\b(?:Assert\.(?:isTrue|notNull|hasText|state|notEmpty)|Preconditions\.check(?:Argument|State|NotNull)|Objects\.requireNonNull|Validate\.(?:isTrue|notNull))\s*\(\s*(.+?)\s*,\s*["']([^"']+)["']\s*\)""")
ORELSE_RE = re.compile(r"""\.\s*(find\w*|get\w*)\s*\(([^()]*)\)\s*\.\s*orElseThrow\s*\(\s*\(?\)?\s*->\s*new\s+([\w\.]+)\s*\(\s*(?:[\w\.]+\s*,\s*)?(?:["']([^"']+)["'])?""")
ASSERT_TRUE_RE = re.compile(r"""@AssertTrue\s*\(\s*message\s*=\s*["']([^"']+)["']\s*\)\s*(?:public\s+)?boolean\s+(\w+)\s*\(\s*\)\s*\{""")
ROLE_ANN_RE = re.compile(r"""@PreAuthorize\(\s*"([^"]+)"\s*\)|@Secured\(\s*\{?\s*([^)}]+)\}?\s*\)|@RolesAllowed\(\s*\{?\s*([^)}]+)\}?\s*\)|\[Authorize\(\s*(?:Roles\s*=\s*["']([^"']+)["']|Policy\s*=\s*["']([^"']+)["'])[^\]]*\)\]|@Roles\(\s*([^)]+)\)|@(?:roles_required|roles_accepted|permission_required|require_role|requires_roles)\(\s*([^)]+)\)|Depends\(\s*(?:require_role|has_role|RoleChecker|require_permission)\(\s*([^)]*)\)""")
ROLE_CALL_RE = re.compile(r"""\b(?:hasRole|hasAnyRole|hasAuthority|hasAnyAuthority|hasPermission|isInRole|IsInRole|userHasRole|requireRole|checkRole|checkPermission|can)\s*\(\s*([^)]{1,120})\)""")
ROLE_WORD_RE = re.compile(r"\b(role|roles|permission|permissions|authority|authorities|isAdmin|isApprover|isChecker|isMaker|canApprove|canEdit|canView|canSubmit|canDelete|hasRole|hasPermission|entitlement)\b", re.I)
STATUS_WORD_RE = re.compile(r"\b\w*(status|state|stage|lifecycle)\w*\b", re.I)
ENTITY_RE = re.compile(r"@Entity\b|@Table\s*\(|\[Table\(|@Entity\(\s*['\"]|__tablename__\s*=|class\s+\w+\s*\(\s*(?:models\.Model|Base|db\.Model)\s*\)")
SQL_TABLE_RE = re.compile(r"create\s+table\s+(?:if\s+not\s+exists\s+)?([\w\.\"`\[\]]+)\s*\((.*?)\)\s*;", re.I | re.S)

def clean_ident(s):
    return re.sub(r"[\"`\[\]]", "", s or "").split(".")[-1]

_METHOD_CACHE = {}

def enclosing_method(text, pos):
    """Nearest method signature before pos. Signatures are found once per file."""
    key = id(text)
    if _METHOD_CACHE.get("key") != key:
        starts = []
        for m in METHOD_SIG_RE.finditer(text):
            name = next((g for g in m.groups() if g), None)
            if name and name not in NOT_METHODS:
                starts.append((m.start(), name))
        _METHOD_CACHE.clear()
        _METHOD_CACHE.update({"key": key, "text": text, "starts": starts, "pos": [s for s, _ in starts]})
    i = bisect.bisect_left(_METHOD_CACHE["pos"], pos) - 1
    if i < 0 or pos - _METHOD_CACHE["starts"][i][0] > 20000:
        return None
    s, name = _METHOD_CACHE["starts"][i]
    return (name, s)

def condition_before(text, pos):
    """The if-condition that guards the statement at pos (searched in the 400 chars before it)."""
    window_start = max(0, pos - 400)
    last = None
    for m in re.finditer(r"\b(?:if|elif|else\s+if)\s*(\(|[^\n:]+:)", text[window_start:pos]):
        last = m
    if not last:
        return None
    start = window_start + last.start(1)
    if text[start] == "(":
        end = match_close(text, start, "(", ")")
        cond = text[start + 1:end - 1]
    else:
        cond = last.group(1).rstrip(":")
    if text.count("\n", window_start + last.end(), pos) > 3:     # too far away to be the guard
        return None
    return re.sub(r"\s+", " ", cond).strip()[:240]

def kind_of(cond, message, exception):
    blob = f"{cond or ''} {message or ''} {exception or ''}"
    if re.search(r"not\s*found|does\s*not\s*exist|no\s+\w+\s+found|NotFound|NoSuch|EntityNotFound|orElseThrow", blob, re.I):
        return "prerequisite"
    if ROLE_WORD_RE.search(blob) or re.search(r"Forbidden|AccessDenied|Unauthori[sz]ed|not\s+allowed|not\s+permitted|permission", blob, re.I):
        return "permission"
    if STATUS_WORD_RE.search(cond or ""):
        return "status rule"
    return "business check"

def parse_business(root):
    checks, roles, transitions, statuses, entities, tables = [], [], [], [], [], []
    for p in walk(root, BIZ_EXT):
        text = read(p)
        if not text:
            continue
        f = rel(p, root)
        if p.endswith((".js", ".ts")) and not re.search(r"""require\(\s*['"](?:express|fastify|koa|@nestjs)|from\s+['"](?:express|fastify|koa|@nestjs/\w+)['"]|@Injectable\(\)|@Controller\(""", text):
            continue   # front-end file in a single repo: not back-end logic
        cls = re.search(r"\bclass\s+(\w+)", text)
        cls = cls.group(1) if cls else os.path.splitext(os.path.basename(p))[0]
        # 1. checks that stop a request, with the message the user sees
        for m in THROW_RE.finditer(text):
            exc = m.group(1) or m.group(4) or m.group(8) or (f"HTTP {m.group(11)}" if m.group(11) else None)
            msg = m.group(3) or m.group(7) or m.group(10) or m.group(13)
            cond = condition_before(text, m.start())
            if not cond and not msg:
                continue
            meth = enclosing_method(text, m.start())
            checks.append({"kind": kind_of(cond, msg, exc), "condition": cond, "message": msg, "error": exc,
                           "method": meth[0] if meth else None, "class": cls, "file": f, "line": line_of(text, m.start()),
                           "statuses": sorted(set(re.findall(r"\b([A-Z][A-Z0-9_]{2,})\b", cond))) if cond and STATUS_WORD_RE.search(cond) else []})
        for m in ASSERT_RE.finditer(text):
            meth = enclosing_method(text, m.start())
            cond = re.sub(r"\s+", " ", m.group(1))[:240]
            checks.append({"kind": kind_of(cond, m.group(2), None), "condition": cond, "message": m.group(2), "error": "assertion",
                           "method": meth[0] if meth else None, "class": cls, "file": f, "line": line_of(text, m.start()), "statuses": []})
        for m in ORELSE_RE.finditer(text):
            meth = enclosing_method(text, m.start())
            repo_var = re.search(r"(\w+)\s*\.\s*$", text[max(0, m.start() - 80):m.start() + 1])
            checks.append({"kind": "prerequisite", "condition": f"{repo_var.group(1) + '.' if repo_var else ''}{m.group(1)}({m.group(2).strip()}) finds a record",
                           "message": m.group(4), "error": m.group(3), "method": meth[0] if meth else None, "class": cls,
                           "file": f, "line": line_of(text, m.start()), "statuses": []})
        for m in ASSERT_TRUE_RE.finditer(text):
            body_end = match_close(text, m.end() - 1, "{", "}")
            body = re.sub(r"\s+", " ", text[m.end():body_end - 1]).strip()[:240]
            checks.append({"kind": "business check", "condition": body, "message": m.group(1), "error": "cross-field validation",
                           "method": m.group(2), "class": cls, "file": f, "line": line_of(text, m.start()), "statuses": []})
        # 2. roles and permissions (annotations, attributes, decorators, explicit checks)
        ann_spans = []
        for m in ROLE_ANN_RE.finditer(text):
            ann_spans.append((m.start(), m.end()))
            raw = next(g for g in m.groups() if g)
            quoted = re.findall(r"""['"]([\w\-:\., ]+)['"]""", raw)
            names = [x for q in quoted for x in q.split(",")] if quoted else \
                ([x for x in raw.split(",")] if re.match(r"^[\w\-:\., ]+$", raw) else re.findall(r"[A-Z_]{3,}", raw))
            names = [re.sub(r"^ROLE_", "", n.strip()) for n in names if n.strip()]
            after = text[m.end():m.end() + 600]
            on_class = bool(re.match(r"(?:\s*@\w+(?:\([^)]*\))?|\s*\[[^\]]+\])*\s*(?:public\s+|export\s+)?(?:abstract\s+|sealed\s+)?class\b", after))
            if m.group(8) is not None:     # Depends(require_role(...)) sits inside the function's own signature
                line_start = text.rfind("\n", 0, m.start()) + 1
                meth = re.search(r"\bdef\s+(\w+)\s*\(", text[max(0, line_start - 200):m.start()])
            else:
                after2 = re.sub(r"^(?:\s*@\w+(?:\([^)]*\))?|\s*\[[^\]]+\])+", "", after)
                meth = re.match(r"\s*(?:(?:public|private|protected|internal|static|async|override|virtual|final|def)\s+)*(?:[\w<>\[\],\.\?]+\s+)?(\w+)\s*\(", after2)
            roles.append({"roles": names, "rule": re.sub(r"\s+", " ", raw)[:200], "method": None if on_class else (meth.group(1) if meth else None),
                          "class": cls, "applies_to": "whole controller" if on_class else "method", "file": f, "line": line_of(text, m.start())})
        for m in ROLE_CALL_RE.finditer(text):
            names = re.findall(r"""['"]([\w\-:\. ]+)['"]""", m.group(1))
            if not names or any(s <= m.start() < e for s, e in ann_spans):
                continue
            meth = enclosing_method(text, m.start())
            roles.append({"roles": [re.sub(r"^ROLE_", "", n) for n in names], "rule": re.sub(r"\s+", " ", m.group(0))[:200],
                          "method": meth[0] if meth else None, "class": cls, "applies_to": "check in code",
                          "file": f, "line": line_of(text, m.start())})
        # 3. status flows: status enums, and status changes with the status they require first
        for m in re.finditer(r"\benum\s+(\w*(?:Status|State|Stage)\w*)\s*(?::\s*\w+\s*)?\{([^}]*)\}", text):
            vals = [re.split(r"[\s(=,]", x.strip())[0] for x in m.group(2).split(",") if re.match(r"\s*[A-Za-z_]\w*", x)]
            vals = [v for v in vals if v and not v.startswith("//")]
            if vals:
                statuses.append({"name": m.group(1), "values": vals, "file": f, "line": line_of(text, m.start())})
        for m in re.finditer(r"""(?:\.\s*set(\w*(?:Status|State|Stage))\s*\(\s*([\w\.]+)\s*\)|\b(\w*(?i:status|state|stage))\s*=\s*([A-Z]\w*\.[A-Z][A-Z0-9_]+|['"][A-Z][A-Z0-9_]+['"])(?!\s*=))""", text):
            to = (m.group(2) or m.group(4) or "").strip("'\"").split(".")[-1]
            if not re.match(r"^[A-Z][A-Z0-9_]+$", to):
                continue
            meth = enclosing_method(text, m.start())
            body_start = meth[1] if meth else max(0, m.start() - 1500)
            guard_text = text[body_start:m.start()]
            from_ = sorted({x for x in re.findall(r"(?i:status|state|stage)\w*\s*(?:\(\s*\))?\s*(?:==|!=|===|!==|\.equals\(|is\s+not\b|is\b|in\s*\(?)\s*(?:\w+\.)?([A-Z][A-Z0-9_]+)\b", guard_text)} |
                           {x for x in re.findall(r"(?:\w+\.)?([A-Z][A-Z0-9_]+)\s*(?:==|!=|\.equals\()\s*\w*(?:\.get)?(?i:status|state)", guard_text)})
            transitions.append({"to": to, "statuses_checked_before": from_, "field": m.group(1) or m.group(3),
                                "method": meth[0] if meth else None, "class": cls, "file": f, "line": line_of(text, m.start())})
        for m in re.finditer(r"\.source\(\s*(?:\w+\.)?(\w+)\s*\)\s*\.target\(\s*(?:\w+\.)?(\w+)\s*\)(?:\s*\.event\(\s*(?:\w+\.)?(\w+)\s*\))?", text):
            transitions.append({"to": m.group(2), "from": m.group(1), "statuses_checked_before": [m.group(1)], "field": "state machine", "event": m.group(3), "method": None,
                                "class": cls, "file": f, "line": line_of(text, m.start())})
        # 4. data model (understanding only: test databases may differ, queries come from the QA repo)
        seen_entities = set()
        for em in ENTITY_RE.finditer(text):
            if em.group(0).startswith("__tablename__"):
                prev = list(re.finditer(r"\bclass\s+(\w+)", text[:em.start()]))
                if not prev:
                    continue
                ecls, start = prev[-1].group(1), prev[-1].start()
            else:
                nxtc = re.search(r"\bclass\s+(\w+)", text[em.start():em.start() + 600])
                if not nxtc:
                    continue
                ecls, start = nxtc.group(1), em.start()
            if ecls in seen_entities:
                continue
            seen_entities.add(ecls)
            body_from = text.find(ecls, start) + len(ecls)
            nxt_cls = re.search(r"\n\s*(?:@\w+(?:\([^)]*\))?\s*|\[[^\]]+\]\s*)*(?:public\s+|export\s+|internal\s+)?(?:abstract\s+|sealed\s+|partial\s+)?(?:class|enum|interface|record)\s+\w+", text[body_from:])
            seg_end = body_from + (nxt_cls.start() if nxt_cls else len(text) - body_from)
            seg = text[start:seg_end]
            tm = re.search(r"""@Table\s*\(\s*(?:name\s*=\s*)?["']([^"']+)["']|\[Table\(\s*["']([^"']+)["']|@Entity\(\s*['"]([^'"]+)['"]|__tablename__\s*=\s*['"]([^'"]+)['"]""", text[em.start():seg_end])
            table = next((g for g in tm.groups() if g), None) if tm else None
            off = start
            fields = []
            for fm in re.finditer(r"""((?:\s*@\w+(?:\([^)]*\))?)+)\s*(?:private|protected|public)\s+(?:final\s+)?([\w<>\[\],\.\? ]+?)\s+(\w+)\s*[;=]""", seg):
                anns = fm.group(1)
                if "@Transient" in anns:
                    continue
                col = re.search(r"""@(?:Column|JoinColumn)\s*\([^)]*?name\s*=\s*["']([^"']+)["']""", anns)
                fields.append({"field": fm.group(3), "type": fm.group(2).strip(), "column": col.group(1) if col else None,
                               "column_named_by": "annotation" if col else "default naming (check your database)",
                               "nullable": False if re.search(r"nullable\s*=\s*false|@NotNull|@Id\b", anns) else None,
                               "length": (re.search(r"length\s*=\s*(\d+)", anns) or [None, None])[1],
                               "key": "id" if "@Id" in anns else ("link" if re.search(r"@(?:ManyToOne|OneToOne|JoinColumn)", anns) else None),
                               "line": line_of(text, off + fm.start(3))})
            for fm in re.finditer(r"""((?:\s*\[[^\]]+\]\s*)*)\s*public\s+([\w<>\[\]\?, ]+?)\s+(\w+)\s*\{\s*get""", seg):
                col = re.search(r"""\[Column\(\s*["']([^"']+)["']""", fm.group(1))
                fields.append({"field": fm.group(3), "type": fm.group(2).strip(), "column": col.group(1) if col else None,
                               "column_named_by": "attribute" if col else "default naming (check your database)",
                               "nullable": False if "[Required]" in fm.group(1) or "[Key]" in fm.group(1) else None,
                               "length": (re.search(r"\[(?:MaxLength|StringLength)\((\d+)", fm.group(1)) or [None, None])[1],
                               "key": "id" if "[Key]" in fm.group(1) else None, "line": line_of(text, off + fm.start(3))})
            for fm in re.finditer(r"""@Column\(\s*(\{[^}]*\}|['"][^'"]*['"])?\s*\)\s*(\w+)\s*[?!]?\s*:\s*([\w\[\]<>| ]+)""", seg):
                col = re.search(r"""name\s*:\s*['"]([^'"]+)['"]""", fm.group(1) or "")
                fields.append({"field": fm.group(2), "type": fm.group(3).strip(), "column": col.group(1) if col else None,
                               "column_named_by": "decorator" if col else "default naming (check your database)",
                               "nullable": None, "length": None, "key": None, "line": line_of(text, off + fm.start(2))})
            for fm in re.finditer(r"""\n\s+(\w+)\s*(?::\s*[\w\[\]\. ]+)?\s*=\s*(?:db\.|sa\.|models\.)?(?:Column|mapped_column|\w+Field)\(([^\n]*)""", seg):
                col = re.search(r"""(?:name|db_column)\s*=\s*['"]([^'"]+)['"]|^\s*['"]([^'"]+)['"]""", fm.group(2))
                fields.append({"field": fm.group(1), "type": fm.group(2).split(",")[0].strip()[:40],
                               "column": (col.group(1) or col.group(2)) if col else None,
                               "column_named_by": "model" if col else "default naming (check your database)",
                               "nullable": False if "nullable=False" in fm.group(2) or "null=False" in fm.group(2) else None,
                               "length": (re.search(r"max_length\s*=\s*(\d+)|String\((\d+)\)", fm.group(2)) or [None, None])[1],
                               "key": "id" if "primary_key=True" in fm.group(2) else None, "line": line_of(text, off + fm.start(1))})
            if fields:
                entities.append({"entity": ecls, "table": table, "fields": fields, "file": f, "line": line_of(text, start)})
    for p in walk(root, (".sql",)):
        text = read(p)
        if not text:
            continue
        for m in SQL_TABLE_RE.finditer(text):
            cols = []
            for line in re.split(r",\s*\n|\n", m.group(2)):
                cm = re.match(r"""\s*([\w"`\[\]]+)\s+([A-Za-z]+(?:\s*\([\d, ]+\))?)(.*)""", line)
                if cm and cm.group(1).upper() not in ("PRIMARY", "CONSTRAINT", "FOREIGN", "UNIQUE", "KEY", "INDEX", "CHECK"):
                    cols.append({"column": clean_ident(cm.group(1)), "type": cm.group(2), "not_null": "NOT NULL" in cm.group(3).upper(),
                                 "references": (re.search(r"REFERENCES\s+([\w\.\"`\[\]]+)", cm.group(3), re.I) or [None, None])[1]})
            tables.append({"table": clean_ident(m.group(1)), "columns": cols, "file": rel(p, root), "line": line_of(text, m.start())})
    return {"checks": checks, "roles": roles, "transitions": transitions, "statuses": statuses,
            "entities": entities, "tables": tables}

def endpoint_calls(root, endpoints):
    """Method names each endpoint handler calls, so service-level rules can be tied to endpoints."""
    by_file = defaultdict(list)
    for e in endpoints:
        by_file[e["file"]].append(e)
    for f, eps in by_file.items():
        text = read(os.path.join(root, f)) or ""
        lines = text.split("\n")
        for e in eps:
            start = sum(len(l) + 1 for l in lines[:e["line"] - 1])
            if f.endswith(".py"):
                dm = re.search(r"\bdef\s+\w+\s*\([^)]*\)[^:\n]*:", text[start:start + 1500])
                body = text[start + (dm.end() if dm else 0):start + 3000]
                body = re.split(r"\n(?=@|def |class |async def )", body)[0]
            else:
                mb = re.compile(r"\)\s*(?:throws\s+[\w\., ]+)?\s*(?::\s*[\w<>\[\]\| ,\.]+)?\s*\{").search(text, start, start + 2000)
                body = text[mb.end() - 1:match_close(text, mb.end() - 1, "{", "}")] if mb else text[start:start + 1500]
            e["calls"] = sorted(set(re.findall(r"\.\s*([a-zA-Z_]\w*)\s*\(", body)) - {"get", "set", "map", "filter", "of", "status", "json", "send"})[:40]

def tie_business(biz, endpoints):
    """Attach each rule to the endpoints whose handler is, or calls, its method."""
    def eps_for(method, cls, applies_to=None):
        if not method:
            if applies_to == "whole controller":
                return [f"{e['method']} {e['path']}" for e in endpoints if e.get("file") and cls and cls in os.path.basename(e["file"])]
            return []
        return [f"{e['method']} {e['path']}" for e in endpoints if e.get("handler") == method or method in e.get("calls", [])]
    for c in biz["checks"]:
        c["endpoints"] = eps_for(c["method"], c["class"])
    for r in biz["roles"]:
        r["endpoints"] = eps_for(r["method"], r["class"], r["applies_to"])
    for t in biz["transitions"]:
        t["endpoints"] = eps_for(t["method"], t["class"])
        # the checks in the same method are the conditions for this change ("must be Submitted",
        # "must not be Closed"); kept as written, the builder turns them into plain English
        t["guards"] = [{"condition": c["condition"], "message": c["message"], "line": c["line"]}
                       for c in biz["checks"] if c["file"] == t["file"] and c["method"] and c["method"] == t["method"]
                       and c["line"] < t["line"]]
    for e in endpoints:
        e["roles"] = sorted({n for r in biz["roles"] if f"{e['method']} {e['path']}" in r["endpoints"] for n in r["roles"]})

def field_map(screens, endpoints, entities):
    """screen field -> request field -> stored field (database column), by exact normalised names.
    For understanding only: never used to write queries (test databases may differ)."""
    ent_fields = []
    for en in entities:
        for fd in en["fields"]:
            ent_fields.append((norm(fd["field"]), en, fd))
    rows = []
    for s in screens:
        for a in s["apis"]:
            if a["method"] == "GET" or not a.get("endpoint"):
                continue
            ep = next((e for e in endpoints if f"{e['method']} {e['path']}" == a["endpoint"]), None)
            if not ep:
                continue
            req = {norm(x["field"]): x for x in ep.get("request_fields", [])}
            for el in s["elements"]:
                key = norm(el.get("name") or el.get("id") or "")
                if not key:
                    continue
                cand = req.get(key)
                ent = [(en, fd) for k, en, fd in ent_fields if k == key]
                if not cand and not ent:
                    continue
                en, fd = ent[0] if len(ent) == 1 else (None, None)
                rows.append({"screen": s["id"], "field": el.get("label") or el.get("name") or el.get("id"),
                             "element_at": f"{el.get('file')}:{el.get('line')}", "endpoint": a["endpoint"],
                             "request_field": cand["field"] if cand else None,
                             "entity": en["entity"] if en else None, "table": en["table"] if en else None,
                             "column": fd["column"] if fd else None,
                             "note": None if en else ("same name in several stored types" if len(ent) > 1 else "not found in the data model")})
    return rows

# ----------------------------------------------------------------------------------------------
# linking to the QA knowledge (evidence, not names)
QA_TOKEN_PATTERNS = [
    ("testid", re.compile(r"""data-(?:testid|test-id|test|qa|cy)\s*[=:]\s*['"]?([\w\-\.]+)""")),
    ("id", re.compile(r"""(?:^|\s|\()(?:id[:=])\s*([\w\-\.]+)|@id\s*=\s*['"]([^'"]+)['"]|\[id\s*=\s*['"]?([\w\-\.]+)['"]?\]|(?:^|[\s>+~,]|css[:=]\s*)#([\w\-]+)""")),
    ("name", re.compile(r"""(?:^|\s)name[:=]\s*([\w\-\.\[\]]+)|@name\s*=\s*['"]([^'"]+)['"]|\[name\s*=\s*['"]?([\w\-\.\[\]]+)['"]?\]|formcontrolname\s*=\s*['"]([^'"]+)['"]""", re.I)),
    ("text", re.compile(r"""normalize-space\(\.?\)\s*=\s*['"]([^'"]+)['"]|text\(\)\s*=\s*['"]([^'"]+)['"]|contains\(\s*(?:text\(\)|\.|normalize-space\(\.?\))\s*,\s*['"]([^'"]+)['"]\s*\)|has-text\(\s*['"]([^'"]+)['"]\s*\)|text\s*=\s*['"]?([^'"\]]+)['"]?|@(?:aria-label|placeholder|title)\s*=\s*['"]([^'"]+)['"]|\[(?:aria-label|placeholder|title)\s*=\s*['"]([^'"]+)['"]\]""")),
]
WEIGHT = {"testid": 3.0, "id": 3.0, "name": 2.0, "url": 3.0, "text": 1.0}

def qa_tokens(value):
    v = str(value or "")
    out = []
    for kind, rx in QA_TOKEN_PATTERNS:
        for m in rx.finditer(v):
            tok = next((g for g in m.groups() if g), None)
            if tok and "${" not in tok and len(tok) >= 2:
                out.append((kind, tok.strip()))
    return out

def load_qa(qa_dir):
    def j(name, default):
        p = os.path.join(qa_dir, name)
        try:
            return json.load(open(p, encoding="utf-8"))
        except Exception:
            return default
    return j("locators.json", []), j("variables.json", []), j("import-chains.json", {})

def link_screens(screens, qa_dir, qa_scope):
    locators, variables, chains = load_qa(qa_dir)
    if not locators:
        return None, None
    urls = []
    for v in (variables if isinstance(variables, list) else []):
        val = v.get("value") if isinstance(v, dict) else None
        val = re.sub(r"^\$\{[^}]+\}", "", val.strip()) if isinstance(val, str) else val
        if isinstance(val, str) and re.search(r"^(https?://|/)\S+$", val):
            path = re.sub(r"^https?://[^/]+", "", val).split("?")[0]
            path = re.sub(r"\$\{[^}]+\}", "x", path)
            if path and path != "/":
                urls.append((path, v.get("file"), v.get("name")))
    links = []
    covered = defaultdict(set)
    for s in screens:
        idx = defaultdict(list)
        for e in s["elements"]:
            for k in ("testid", "id", "name"):
                if e.get(k):
                    idx[(k, e[k].lower())].append(e)
            for k in ("label", "text", "placeholder"):
                if e.get(k) and isinstance(e[k], str):
                    idx[("text", norm(e[k]))].append(e)
        for t in s["texts"]:
            idx[("text", norm(t["text"]))].append(t)
        per_file = defaultdict(lambda: {"score": 0.0, "evidence": [], "types": set(), "locators": set()})
        for loc in locators:
            for kind, tok in qa_tokens(loc.get("value")):
                key = (kind, tok.lower()) if kind != "text" else ("text", norm(tok))
                hits = idx.get(key)
                if not hits and kind == "id":
                    hits = idx.get(("testid", tok.lower())) or idx.get(("name", tok.lower()))
                if not hits:
                    continue
                w = WEIGHT[kind]
                if kind == "text" and (norm(tok) in GENERIC_TEXT or len(norm(tok)) < 3):
                    w = 0.3
                pf = per_file[loc.get("file")]
                pf["score"] += w
                pf["types"].add(kind)
                pf["locators"].add(loc.get("variable") or loc.get("value"))
                if len(pf["evidence"]) < 8:
                    h = hits[0]
                    pf["evidence"].append({"type": kind, "qa": f"{loc.get('variable') or ''} {loc.get('value')}".strip(),
                                           "dev": f"{h.get('file')}:{h.get('line')}"})
                for h in hits:
                    covered[s["id"]].add(json.dumps({k: h.get(k) for k in ("id", "testid", "name", "label", "text", "line", "file")}, sort_keys=True))
        if s["route"] and s["route"] not in ("/", "*"):
            rx = route_rx(s["route"], s.get("relative_route", False))
            for path, file, name in urls:
                if rx and rx.match(path):
                    pf = per_file[file]
                    pf["score"] += WEIGHT["url"]
                    pf["types"].add("url")
                    pf["evidence"].append({"type": "url", "qa": f"{name} {path}", "dev": s["defined_in"]})
        for qa_file, pf in per_file.items():
            strong = pf["types"] & {"testid", "id", "name", "url"}
            if pf["score"] >= 5 or len(strong) >= 2 or (strong and pf["score"] >= 4):
                conf = "high"
            elif pf["score"] >= 2.5:
                conf = "medium"
            elif pf["score"] > 0:
                conf = "low"
            else:
                continue
            links.append({"screen": s["id"], "component": s["component"], "qa_file": qa_file, "confidence": conf,
                          "score": round(pf["score"], 1), "evidence_types": sorted(pf["types"]),
                          "qa_locators": sorted(x for x in pf["locators"] if x)[:20], "evidence": pf["evidence"]})
    # QA locators whose id / test id / name is found nowhere in the development code (possibly stale)
    all_tokens = set()
    for s in screens:
        for e in s["elements"]:
            for k in ("testid", "id", "name"):
                if e.get(k):
                    all_tokens.add(e[k].lower())
    linked_files = {l["qa_file"] for l in links if l["confidence"] in ("high", "medium")}
    missing = []
    for loc in locators:
        if loc.get("file") not in linked_files:
            continue
        strong = [(k, tok) for k, tok in qa_tokens(loc.get("value")) if k in ("testid", "id", "name")]
        if strong and not any(tok.lower() in all_tokens for _, tok in strong):
            missing.append({"variable": loc.get("variable"), "value": loc.get("value"), "file": loc.get("file"),
                            "not_found": [tok for _, tok in strong]})
    # elements of linked screens that no QA locator uses (coverage gaps)
    gaps = {}
    for s in screens:
        if not any(l["screen"] == s["id"] and l["confidence"] != "low" for l in links):
            continue
        used = {json.loads(x)["line"] for x in covered[s["id"]]}
        gaps[s["id"]] = [{k: e.get(k) for k in ("kind", "label", "text", "id", "testid", "name", "file", "line") if e.get(k)}
                         for e in s["elements"] if e["line"] not in used and e.get("kind") in ("input", "dropdown", "checkbox", "button", "tab")][:60]
    scope = None
    if qa_scope:
        files = set()
        for t in qa_scope:
            files.add(t)
            for row in chains.get(t, []):
                if row.get("file"):
                    files.add(row["file"])
        direct = sorted({l["screen"] for l in links if l["qa_file"] in files and l["confidence"] in ("high", "medium")})
        by_id = {s["id"]: s for s in screens}
        neighbours = set()
        for sid in direct:
            neighbours |= {nv["screen"] for nv in by_id[sid]["navigates_to"] if nv.get("screen")}
            neighbours |= {s["id"] for s in screens if any(nv.get("screen") == sid for nv in s["navigates_to"])}
        scope = {"qa_scope": sorted(qa_scope), "qa_files": sorted(files), "screens": direct,
                 "neighbour_screens": sorted(neighbours - set(direct))}
    return {"links": sorted(links, key=lambda l: (l["screen"], -l["score"])), "coverage_gaps": gaps,
            "missing_in_dev": missing}, scope

# ----------------------------------------------------------------------------------------------
FE_FRAMEWORKS = {"React", "Next.js", "Angular", "Vue", "Nuxt", "Material UI", "Material UI (v4)", "Angular Material", "Ant Design"}
LEGACY_FE = {"AngularJS", "jQuery", "Knockout", "Backbone", "Ember", "Dojo", "Ext JS", "Thymeleaf", "JSP", "JSF", "PrimeFaces", "RichFaces",
             "Struts 1", "Struts 2", "ASP.NET Web Forms", "ASP.NET MVC (Razor)", "FreeMarker", "Velocity", "Grails", "Vaadin", "GWT", "Wicket"}
BE_FRAMEWORKS = {"Spring Boot", "Spring MVC", "Java", "Java web app", "ASP.NET Core", "ASP.NET", ".NET", "FastAPI", "Flask", "Django", "Express", "NestJS",
                 "Struts 1", "Struts 2"}
READ_AS_PAGES = {"Vaadin", "GWT", "Wicket", "Dojo", "Ext JS", "Ember"}   # recognised, but their screens are built in code: pages only


def classify_repo(path):
    """Front end, back end, or both - worked out from the repo's own code, so testers never have to say.
    Returns (is_front_end, is_back_end, reason)."""
    fw, _ = detect_frameworks(path)
    fw = set(fw)
    fe, be = bool(fw & FE_FRAMEWORKS), bool(fw & BE_FRAMEWORKS) or ("Python" in fw and not (fw & FE_FRAMEWORKS))
    reason = ", ".join(sorted(fw)) or ""
    if not fe:                                               # screens without a package.json: old or server-side front ends
        pages = 0
        for p in walk(path, PAGE_EXT):
            if re.search(r"(^|/)(docs?|javadoc|site|reports?|emails?|mail)/", rel(p, path), re.I):
                continue
            pages += 1
            if pages >= 3:
                break
        if pages or fw & LEGACY_FE:
            fe = True
            reason = (reason + "; " if reason else "") + "page files found (" + (", ".join(sorted(fw & LEGACY_FE)) or "server-side or plain HTML pages") + ")"
    if not fe and not be:                                    # no build file says it: count the source files
        counts, seen = defaultdict(int), 0
        for p in walk(path, FE_EXT + BE_EXT):
            seen += 1
            ext = os.path.splitext(p)[1]
            if ext in (".jsx", ".tsx", ".vue") or (ext == ".html" and seen < 3000):
                counts["fe"] += 1
            elif ext in (".java", ".kt", ".cs", ".py"):
                counts["be"] += 1
            if seen >= 5000:
                break
        fe, be = counts["fe"] > 0, counts["be"] > 0
        reason = f"{counts['fe']} screen files, {counts['be']} server files"
    if not fe and not be:
        return True, True, "could not tell from the code; read as both"
    return fe, be, reason


def run(frontends, backends, out, qa_extract=None, qa_scope=None, repos=None):
    frontends, backends, detected = list(frontends), list(backends), {}
    for path in repos or []:
        if not os.path.isdir(path):
            frontends.append(path)                           # reported as "not found" below
            continue
        fe, be, why = classify_repo(os.path.abspath(path))
        detected[path] = {"front end": fe, "back end": be, "detected_from": why}
        if fe:
            frontends.append(path)
        if be:
            backends.append(path)
    os.makedirs(out, exist_ok=True)
    cache_path = os.path.join(out, "cache.json")
    try:
        cache = json.load(open(cache_path, encoding="utf-8"))
    except Exception:
        cache = {}
    cache_out = {}
    summary = {"extractor_version": VERSION, "repos": [], "warnings": []}
    all_screens, all_ref, all_eps, all_dtos, all_enums = [], [], [], {}, []
    all_ints = []
    all_biz = {"checks": [], "roles": [], "transitions": [], "statuses": [], "entities": [], "tables": []}
    for role, paths in (("frontend", frontends), ("backend", backends)):
        for path in paths:
            ap = os.path.abspath(path)
            if not os.path.isdir(ap):
                summary["warnings"].append(f"{role} path not found: {path}")
                continue
            fw, pkgs = detect_frameworks(ap)
            repo = {"role": role, "path": path, "frameworks": fw, "package_files": pkgs, "git": git_info(ap)}
            if path in detected:
                repo["detected"] = detected[path]
            if role == "frontend":
                i18n = load_i18n(ap)
                screens, ref, shared, nfiles = build_frontend(ap, i18n, cache, cache_out, file_routes=bool({"Next.js", "Nuxt"} & set(fw)))
                for s in screens:
                    s["repo"] = path
                all_screens += screens
                all_ref += [{**r, "repo": path} for r in ref]
                repo.update({"files_read": nfiles, "screens": len(screens), "i18n_texts": len(i18n), "shared_components": shared})
                pages_seen = sum(1 for _ in walk(ap, PAGE_EXT))
                repo["page_files"] = pages_seen
                repo["read_as"] = sorted(set(fw) & (FE_FRAMEWORKS | LEGACY_FE)) or ["plain pages (no framework recognised)"]
                if not screens:
                    summary["warnings"].append(f"No screens found in {path}: {pages_seen} page file(s) and no router were recognised"
                                               + ("; the pages hold no fields or buttons" if pages_seen else "") +
                                               ". Tell the skills authors which framework this front end uses.")
                elif set(fw) & READ_AS_PAGES:
                    summary["warnings"].append(f"{path}: {', '.join(sorted(set(fw) & READ_AS_PAGES))} builds screens in code; only its page "
                                               "files were read. Screens built only in code are found live by the script generator.")
            else:
                eps, dtos, enums = parse_backend(ap)
                endpoint_calls(ap, eps)
                ints = find_integrations(ap)
                link_integrations(ap, eps, ints)
                all_ints += [{**x, "repo": path} for x in ints]
                repo["integrations"] = sorted({x["system"] for x in ints})
                biz = parse_business(ap)
                for k, rows in biz.items():
                    all_biz[k] += [{**r, "repo": path} for r in rows]
                repo["business"] = {k: len(v) for k, v in biz.items()}
                for e in eps:
                    e["repo"] = path
                all_eps += eps
                all_dtos.update({k: {**v, "repo": path} for k, v in dtos.items()})
                all_enums += [{**e, "repo": path} for e in enums]
                repo.update({"endpoints": len(eps), "request_types_with_validation": len(dtos), "enums": len(enums)})
                if not eps:
                    summary["warnings"].append(f"No API endpoints found in {path}")
            summary["repos"].append(repo)
    # page screens rendered by a controller (Spring MVC, ASP.NET MVC, Struts): their route is the controller's URL
    views = [e for e in all_eps if e.get("view")]
    for s in all_screens:
        if s.get("route") or not s.get("page_file"):
            continue
        stem = re.sub(r"\.\w+$", "", s["file"]).replace("\\", "/")
        hit = None
        for e in sorted(views, key=lambda e: 0 if e["method"] in ("GET", "ANY") else 1):
            v = e["view"].lstrip("/")
            v = re.sub(r"\.\w+$", "", v)
            if stem.endswith("/" + v) or stem == v:
                hit = e
                break
        if hit:
            s["route"] = hit["path"]
            s["route_from"] = f"{hit['repo']}/{hit['file']}:{hit['line']}"
    # connect screen API calls to back-end endpoints
    ep_rx = [(re.compile("^" + re.sub(r"\\\{[^}]+\\\}|:\w+", "[^/]+", re.escape(e["path"])) + "/?$"), e) for e in all_eps]
    for s in all_screens:
        for a in s["apis"]:
            probe = re.sub(r"\{[^}]+\}", "x", re.sub(r"^https?://[^/]+", "", a["url"]).split("?")[0])
            hit = next((e for rx, e in ep_rx if rx.match(probe) and (e["method"] in (a["method"], "ANY") or "/" in e["method"])), None)
            if not hit and probe.startswith("/api/"):
                hit = next((e for rx, e in ep_rx if rx.match(probe[4:])), None)
            if hit:
                a["endpoint"] = f"{hit['method']} {hit['path']}"
                a["endpoint_at"] = f"{hit['repo']}/{hit['file']}:{hit['line']}"
                if hit.get("integrations"):
                    a["integrations"] = hit["integrations"]
    tie_business(all_biz, all_eps)
    data_map = field_map(all_screens, all_eps, all_biz["entities"])
    def slug(s, i):
        return f"{i:03d}-" + (re.sub(r"[^A-Za-z0-9]+", "-", str(s["route"] or s["component"])).strip("-").lower()[:60] or "root")
    for i, s in enumerate(all_screens, 1):
        s["screen_file"] = f"screens/{slug(s, i)}.json"
    index = {"screens": [{"id": s["id"], "route": s["route"], "screen_file": s["screen_file"], "component": s["component"], "file": s["file"], "repo": s["repo"],
                          "fields": sum(1 for e in s["elements"] if e.get("kind") in ("input", "dropdown", "checkbox")),
                          "buttons": sum(1 for e in s["elements"] if e.get("kind") in ("button", "tab", "link")),
                          "titles": [t["text"] for t in s["texts"] if t["kind"] not in ("label", "FormLabel", "InputLabel")][:6]}
                         for s in all_screens],
             "endpoints": [{"method": e["method"], "path": e["path"], "handler": e.get("handler"), "at": f"{e['repo']}/{e['file']}:{e['line']}"} for e in all_eps]}
    def dump(name, obj):
        with open(os.path.join(out, name), "w", encoding="utf-8") as fh:
            json.dump(obj, fh, indent=1, ensure_ascii=False)
    dump("dev-screens.json", all_screens)
    sdir = os.path.join(out, "screens")
    if os.path.isdir(sdir):
        shutil.rmtree(sdir)
    os.makedirs(sdir)
    for s in all_screens:
        dump(s["screen_file"], s)
    dump("dev-api.json", {"endpoints": all_eps, "request_types": all_dtos, "integrations": all_ints})
    dump("dev-reference-data.json", {"frontend": all_ref, "backend_enums": all_enums})
    dump("dev-index.json", index)
    dump("dev-business.json", {k: all_biz[k] for k in ("checks", "roles", "transitions", "statuses")})
    dump("dev-data-model.json", {"note": "For understanding only. Test databases may differ; database steps use the QA repo's own keywords and queries.",
                                 "entities": all_biz["entities"], "tables": all_biz["tables"], "field_map": data_map})
    links = scope = None
    if qa_extract:
        links, scope = link_screens(all_screens, qa_extract, qa_scope)
        if links is None:
            summary["warnings"].append(f"No QA locators found in {qa_extract}; run extract_repo.py first")
        else:
            dump("dev-links.json", links)
        if scope:
            dump("dev-scope.json", scope)
    summary["counts"] = {"screens": len(all_screens), "fields": sum(i["fields"] for i in index["screens"]),
                         "endpoints": len(all_eps), "reference_lists": len(all_ref) + len(all_enums),
                         "links": len(links["links"]) if links else 0,
                         "qa_locators_not_in_dev": len(links["missing_in_dev"]) if links else 0,
                         "business_checks": sum(1 for c in all_biz["checks"] if c["kind"] in ("business check", "status rule")),
                         "prerequisites": sum(1 for c in all_biz["checks"] if c["kind"] == "prerequisite"),
                         "permission_rules": len(all_biz["roles"]) + sum(1 for c in all_biz["checks"] if c["kind"] == "permission"),
                         "status_changes": len(all_biz["transitions"]), "stored_types": len(all_biz["entities"]) + len(all_biz["tables"]),
                         "after_save_actions": sum(1 for s in all_screens for a in s["apis"] if a.get("after")),
                         "scoped_screens": (len(scope["screens"]) + len(scope["neighbour_screens"])) if scope else None}
    dump("dev-summary.json", summary)
    with open(cache_path, "w", encoding="utf-8") as fh:
        json.dump(cache_out, fh)
    return summary

# ----------------------------------------------------------------------------------------------
SAMPLE = {
 "fe/package.json": json.dumps({"dependencies": {"react": "18", "react-router-dom": "6", "@mui/material": "5", "yup": "1", "axios": "1", "i18next": "23"}}),
 "fe/src/locales/en/common.json": json.dumps({"search": {"lei": "LEI", "title": "Client search"}}),
 "fe/src/App.jsx": """import { Routes, Route } from 'react-router-dom';
import ClientSearch from './pages/ClientSearch';
import ManageSubscriptions from './pages/ManageSubscriptions';
export default function App() {
  return (<Routes>
    <Route path="/clients" element={<ClientSearch />} />
    <Route path="/clients/:id/subscriptions" element={<ManageSubscriptions />} />
  </Routes>);
}
""",
 "fe/src/pages/ClientSearch.jsx": """import { TextField, Button, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
export default function ClientSearch() {
  const navigate = useNavigate();
  const onSearch = async () => { const r = await axios.get('/api/clients/search'); navigate(`/clients/${r.data.id}/subscriptions`); };
  return (<div>
    <Typography variant="h4">{t('search.title')}</Typography>
    <TextField label={t('search.lei')} name="lei" inputProps={{ 'data-testid': 'lei-input' }} onChange={(e) => setLei(e.target.value)} />
    <Button data-testid="search-btn" onClick={() => onSearch()}>Search</Button>
  </div>);
}
""",
 "fe/src/pages/ManageSubscriptions.jsx": """import { useEffect, useState } from 'react';
import { Select, MenuItem, TextField, Button, CircularProgress } from '@mui/material';
import * as yup from 'yup';
import axios from 'axios';
import SubscriptionDialog from '../components/SubscriptionDialog';
const schema = yup.object().shape({
  leiNumber: yup.string().required('LEI is required').matches(/^[A-Z0-9]{20}$/, 'LEI must be 20 characters'),
});
export default function ManageSubscriptions() {
  const [loading, setLoading] = useState(true);
  useEffect(() => { axios.get(`/api/clients/${id}/subscriptions`).then(() => setLoading(false)); }, []);
  const onSave = async () => {
    try {
      await axios.post(`/api/clients/${id}/subscriptions`, form);
      enqueueSnackbar('Subscription saved', { variant: 'success' });
      navigate('/clients');
    } catch (e) {
      enqueueSnackbar('Could not save subscription', { variant: 'error' });
    }
  };
  return (<div>
    <h2>Manage subscription</h2>
    {loading && <CircularProgress data-testid="subs-loading" />}
    <Select id="subscription-type" label="Subscription type" value={type} onChange={(e) => setType(e.target.value)}>
      <MenuItem value="DAILY">Daily</MenuItem>
      <MenuItem value="WEEKLY">Weekly</MenuItem>
    </Select>
    {clientType === 'CORPORATE' && (
      <TextField id="lei-number" label="LEI number" required />
    )}
    <Button id="manage-btn" onClick={() => setOpen(true)}>Manage subscription</Button>
    <Button id="approve-btn" disabled={!hasRole('KYC_APPROVER')}>Approve</Button>
    <Button id="save-btn" onClick={() => onSave()}>Save</Button>
    <SubscriptionDialog open={open} />
  </div>);
}
""",
 "fe/src/components/SubscriptionDialog.jsx": """import { Dialog, DialogTitle, Button } from '@mui/material';
export default function SubscriptionDialog({ open }) {
  return (<Dialog open={open}>
    <DialogTitle>Unsubscribe client</DialogTitle>
    <Button data-testid="confirm-unsubscribe" onClick={() => onConfirm()}>Confirm</Button>
  </Dialog>);
}
""",
 "be/src/main/java/com/bank/KycController.java": """package com.bank;
@RestController
public class KycController {
    @PostMapping("/api/kyc/{caseId}/approve")
    public KycCase approve(@PathVariable String caseId) { return kycService.approve(caseId); }
}
""",
 "be/src/main/java/com/bank/KycService.java": """package com.bank;
@Service
public class KycService {
    @PreAuthorize("hasRole('KYC_APPROVER')")
    public KycCase approve(String caseId) {
        KycCase c = repository.findById(caseId).orElseThrow(() -> new NotFoundException("KYC case not found"));
        if (c.getStatus() != KycStatus.SUBMITTED) {
            throw new BusinessException("Only submitted cases can be approved");
        }
        if (c.getClientType() == ClientType.CORPORATE && c.getLeiNumber() == null) {
            throw new BusinessException("A corporate client must have an LEI");
        }
        c.setStatus(KycStatus.APPROVED);
        return repository.save(c);
    }
}
""",
 "be/src/main/java/com/bank/KycCase.java": """package com.bank;
@Entity
@Table(name = "KYC_CASE")
public class KycCase {
    @Id
    @Column(name = "CASE_ID")
    private String caseId;
    @Column(name = "LEI_NUMBER", length = 20)
    private String leiNumber;
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false)
    private KycStatus status;
}
enum KycStatus { DRAFT, SUBMITTED, APPROVED, REJECTED }
""",
 "be/src/main/resources/db/migration/V1__kyc.sql": """CREATE TABLE KYC_CASE (
  CASE_ID VARCHAR(36) NOT NULL,
  LEI_NUMBER VARCHAR(20),
  STATUS VARCHAR(20) NOT NULL,
  PRIMARY KEY (CASE_ID)
);
""",
 "be/pom.xml": "<project><parent><artifactId>spring-boot-starter-parent</artifactId></parent></project>",
 "be/src/main/java/com/bank/SubscriptionController.java": """package com.bank;
@RestController
@RequestMapping("/api/clients")
public class SubscriptionController {
    @GetMapping("/{id}/subscriptions")
    public List<SubscriptionDto> list(@PathVariable String id) { return null; }
    @PostMapping("/{id}/subscriptions")
    public SubscriptionDto create(@PathVariable String id, @Valid @RequestBody SubscriptionRequest req) { return null; }
}
""",
 "be/src/main/java/com/bank/SubscriptionRequest.java": """package com.bank;
public class SubscriptionRequest {
    @NotBlank
    @Size(max = 20)
    private String leiNumber;
    @NotNull
    private SubscriptionType type;
}
enum SubscriptionType { DAILY, WEEKLY, MONTHLY }
""",
 "ng/package.json": json.dumps({"dependencies": {"@angular/core": "17", "@angular/material": "17"}}),
 "ng/src/app/app.routes.ts": """import { Routes } from '@angular/router';
import { KycReviewComponent } from './kyc/kyc-review.component';
export const routes: Routes = [
  { path: 'kyc/:id', component: KycReviewComponent },
  { path: 'kyc', loadChildren: () => import('./kyc/kyc.routes').then(m => m.KYC_ROUTES) },
];
""",
 "ng/src/app/kyc/kyc-review.component.ts": """import { Component, OnInit } from '@angular/core';
@Component({ selector: 'app-kyc', templateUrl: './kyc-review.component.html' })
export class KycReviewComponent implements OnInit {
  form = new FormGroup({ comment: new FormControl('', [Validators.required, Validators.maxLength(500)]) });
  ngOnInit(): void { this.http.get('/api/kyc/cases').subscribe(); }
}
""",
 "ng/src/app/kyc/kyc-review.component.html": """<h2>KYC review</h2>
<mat-select formControlName="riskRating" data-testid="risk-rating">
  <mat-option value="LOW">Low</mat-option>
  <mat-option value="HIGH">High</mat-option>
</mat-select>
<div *ngIf="form.value.riskRating === 'HIGH'">
  <textarea formControlName="comment" placeholder="Reason for high risk"></textarea>
</div>
""",
 "ng/tsconfig.json": """{
  // comments and trailing commas are allowed here
  "compilerOptions": { "baseUrl": "./", "paths": { "@shared/*": ["src/app/shared/*"], }, },
}""",
 "ng/src/assets/i18n/en.json": json.dumps({"kyc": {"escalate": "Escalate case"}}),
 "ng/src/app/kyc/kyc.routes.ts": """import { Routes } from '@angular/router';
import { KycCaseComponent } from './kyc-case.component';
export const KYC_ROUTES: Routes = [ { path: 'review/:caseId', component: KycCaseComponent } ];
""",
 "ng/src/app/kyc/kyc-case.component.ts": """import { Component } from '@angular/core';
import { EscalateComponent } from '@shared/escalate.component';
@Component({ selector: 'app-kyc-case', template: '<h2>KYC case</h2>' })
export class KycCaseComponent {}
""",
 "ng/src/app/shared/escalate.component.ts": """import { Component } from '@angular/core';
@Component({ selector: 'app-escalate', templateUrl: './escalate.component.html' })
export class EscalateComponent {}
""",
 "ng/src/app/shared/escalate.component.html": """<button [attr.data-testid]="'escalate'" (click)="go()">{{ 'kyc.escalate' | translate }}</button>
""",
 "mono/package.json": json.dumps({"dependencies": {"react": "18", "react-router-dom": "6", "express": "4"}}),
 "mono/src/App.jsx": """import Things from './Things';
export default function App() { return (<Routes><Route path="/things" element={<Things />} /></Routes>); }
""",
 "mono/src/Things.jsx": """import api from './api';
export default function Things() { useEffect(() => { api.get('/api/things'); }, []); return <button id="refresh">Refresh</button>; }
""",
 "mono/server/index.js": """const express = require('express');
const router = express.Router();
router.get('/api/things', (req, res) => res.json([]));
""",
 "qa2/locators.json": json.dumps([{"variable": "${ESCALATE}", "value": "css:[data-testid='escalate']", "file": "resources/kyc.resource"}]),
 "qa2/variables.json": json.dumps([{"name": "${KYC_URL}", "value": "${BASE_URL}/kyc/review/55", "file": "resources/kyc.resource"}]),
 "nx/package.json": json.dumps({"dependencies": {"next": "14", "react": "18"}}),
 "nx/pages/clients/[id].tsx": "export default function ClientPage() { return <div><h1>Client details</h1><input id=\"client-name\" /></div>; }\n",
 "qa/locators.json": json.dumps([
    {"variable": "${LEI_INPUT}", "value": "css:[data-testid='lei-input']", "file": "resources/search.resource"},
    {"variable": "${SEARCH_BTN}", "value": "xpath://button[normalize-space()='Search']", "file": "resources/search.resource"},
    {"variable": "${SUBS_TYPE}", "value": "id:subscription-type", "file": "resources/subs.resource"},
    {"variable": "${MANAGE_BTN}", "value": "xpath://button[normalize-space()='Manage subscription']", "file": "resources/subs.resource"},
    {"variable": "${MANAGE_ID}", "value": "id:manage-btn", "file": "resources/subs.resource"},
    {"variable": "${OLD_FREQ}", "value": "id:frequency-select", "file": "resources/subs.resource"}]),
 "qa/variables.json": json.dumps([{"name": "${SUBS_URL}", "value": "https://uat.bank.test/clients/77/subscriptions", "file": "resources/subs.resource"}]),
 "qa/import-chains.json": json.dumps({"tests/subs.robot": [{"type": "Resource", "file": "resources/subs.resource"}]}),
}

# older and server-side front ends: each one must give screens, fields, options, conditions, routes
LEGACY_SAMPLE = {
 # 1. Spring Boot with an AngularJS 1.2 front end in its static folder (no package.json)
 "ajs/pom.xml": "<project><parent><artifactId>spring-boot-starter-parent</artifactId></parent><dependencies><dependency><artifactId>spring-boot-starter-web</artifactId></dependency></dependencies></project>",
 "ajs/src/main/resources/static/index.html": "<html ng-app=\"bookApp\"><head><script src=\"lib/angular.min.js\"></script><script src=\"js/app.js\"></script><script src=\"js/controllers.js\"></script></head><body><div ng-view></div></body></html>",
 "ajs/src/main/resources/static/js/app.js": "angular.module('bookApp', ['ngRoute']).config(function($routeProvider) {\n  $routeProvider.when('/requests', {templateUrl: 'views/request-list.html', controller: 'RequestListCtrl'})\n  .when('/requests/new', {templateUrl: 'views/request-form.html', controller: 'RequestFormCtrl'})\n  .otherwise({redirectTo: '/requests'});\n});\n",
 "ajs/src/main/resources/static/js/controllers.js": "angular.module('bookApp').controller('RequestListCtrl', function($scope, $http) {\n  $http.get('/api/requests').success(function(d) { $scope.requests = d; });\n}).controller('RequestFormCtrl', function($scope, $http, $location) {\n  $http.get('/api/branches').success(function(d) { $scope.branches = d; });\n  $scope.save = function() {\n    $http.post('/api/requests', $scope.req).success(function() {\n      $scope.successMessage = 'Request saved';\n      $location.path('/requests');\n    }).error(function() {\n      $scope.errorMessage = 'Could not save the request';\n    });\n  };\n});\n",
 "ajs/src/main/resources/static/views/request-form.html": "<h2>New request</h2>\n<form name=\"form\">\n<label for=\"customerName\">Customer name</label>\n<input id=\"customerName\" type=\"text\" ng-model=\"req.customerName\" ng-required=\"true\" ng-maxlength=\"40\">\n<select id=\"branch\" ng-model=\"req.branch\" ng-options=\"b.code as b.name for b in branches\"></select>\n<select id=\"reqType\" ng-model=\"req.type\"><option value=\"PERSONAL\">Personal</option><option value=\"CORPORATE\">Corporate</option></select>\n<div ng-show=\"req.type == 'CORPORATE'\"><input id=\"lei\" ng-model=\"req.lei\"></div>\n<button id=\"saveBtn\" ng-click=\"save()\" ng-disabled=\"form.$invalid\">Save</button>\n<a href=\"#/requests\">Back</a>\n</form>\n",
 "ajs/src/main/resources/static/views/request-list.html": "<h2>Requests</h2><input id=\"search\" ng-model=\"q\" placeholder=\"Search\"><a id=\"newRequest\" class=\"btn\" href=\"#/requests/new\">New request</a><table><tr ng-repeat=\"r in requests\"><td>{{r.customerName}}</td></tr></table>",
 "ajs/src/main/java/com/bank/RequestController.java": "package com.bank;\n@RestController\n@RequestMapping(\"/api/requests\")\npublic class RequestController {\n  private final RequestService requestService;\n  @GetMapping\n  public List<Request> all() { return null; }\n  @PostMapping\n  public Request create(@RequestBody Request r) { return requestService.submit(r); }\n}\n",
 "ajs/src/main/java/com/bank/RequestService.java": "package com.bank;\n@Service\npublic class RequestService {\n  private final BmcValidationClient bmc;\n  private final DocumentArchive archive;\n  public Request submit(Request r) {\n    if (!bmc.validate(r).isValid()) {\n      throw new BusinessException(\"BMC validation failed for this request\");\n    }\n    archive.store(r);\n    return r;\n  }\n}\n",
 "ajs/src/main/java/com/bank/BmcValidationClient.java": "package com.bank;\n@FeignClient(name = \"bmc-validation\", url = \"${bmc.url}\")\npublic interface BmcValidationClient {\n  @PostMapping(\"/validate\")\n  Result validate(Request r);\n}\n",
 "ajs/src/main/java/com/bank/DocumentArchive.java": "package com.bank;\n@Component\npublic class DocumentArchive {\n  @Value(\"${alfresco.base-url}\") private String baseUrl;\n  private final RestTemplate restTemplate;\n  public void store(Request r) { restTemplate.postForObject(baseUrl + \"/nodes\", r, String.class); }\n}\n",
 # 2. Spring MVC (no Boot) with JSP views and a message bundle
 "jsp/pom.xml": "<project><dependencies><dependency><groupId>org.springframework</groupId><artifactId>spring-webmvc</artifactId></dependency><dependency><artifactId>jstl</artifactId></dependency></dependencies></project>",
 "jsp/src/main/java/com/bank/web/ClientController.java": "package com.bank.web;\n@Controller\n@RequestMapping(\"/clients\")\npublic class ClientController {\n  @RequestMapping(value = \"/edit\", method = RequestMethod.GET)\n  public String edit(Model model) {\n    return \"client/edit\";\n  }\n  @PostMapping(\"/save\")\n  public String save(@ModelAttribute Client c) {\n    return \"redirect:/clients\";\n  }\n}\n",
 "jsp/src/main/webapp/WEB-INF/views/client/edit.jsp": "<%@ taglib prefix=\"form\" uri=\"http://www.springframework.org/tags/form\" %>\n<%@ taglib prefix=\"spring\" uri=\"http://www.springframework.org/tags\" %>\n<h1><spring:message code=\"client.title\"/></h1>\n<form:form action=\"/clients/save\" method=\"post\" modelAttribute=\"client\">\n<label for=\"firstName\"><spring:message code=\"client.firstName\"/></label>\n<form:input path=\"firstName\" id=\"firstName\" maxlength=\"30\"/>\n<form:select path=\"type\" id=\"clientType\" items=\"${types}\"/>\n<c:if test=\"${client.type == 'CORPORATE'}\">\n<form:input path=\"lei\" id=\"lei\"/>\n</c:if>\n<input type=\"submit\" id=\"saveClient\" value=\"Save\"/>\n</form:form>\n<jsp:include page=\"/WEB-INF/views/common/footer.jsp\"/>\n",
 "jsp/src/main/webapp/WEB-INF/views/common/footer.jsp": "<div class=\"footer\"><a id=\"helpLink\" href=\"/help\">Help</a></div>",
 "jsp/src/main/resources/messages.properties": "client.title=Edit client\nclient.firstName=First name\n",
 # 3. JSF / PrimeFaces
 "jsf/src/main/webapp/WEB-INF/faces-config.xml": "<faces-config/>",
 "jsf/src/main/webapp/kyc/approve.xhtml": "<html xmlns:h=\"http://xmlns.jcp.org/jsf/html\" xmlns:f=\"http://xmlns.jcp.org/jsf/core\"><h:form id=\"kycForm\">\n<h:outputLabel for=\"comment\" value=\"Comment\"/>\n<h:inputText id=\"comment\" value=\"#{kycBean.comment}\" required=\"true\" maxlength=\"200\"/>\n<h:selectOneMenu id=\"decision\" value=\"#{kycBean.decision}\">\n<f:selectItem itemValue=\"APPROVE\" itemLabel=\"Approve\"/>\n<f:selectItem itemValue=\"REJECT\" itemLabel=\"Reject\"/>\n</h:selectOneMenu>\n<h:commandButton id=\"submit\" value=\"Submit\" action=\"#{kycBean.submit}\" rendered=\"#{kycBean.canApprove}\"/>\n</h:form></html>",
 # 4. Spring Boot with Thymeleaf templates
 "thy/pom.xml": "<project><parent><artifactId>spring-boot-starter-parent</artifactId></parent><dependencies><dependency><artifactId>spring-boot-starter-thymeleaf</artifactId></dependency></dependencies></project>",
 "thy/src/main/java/com/bank/AddressController.java": "@Controller\npublic class AddressController {\n  @GetMapping(\"/address/new\")\n  public String form(Model m) { return \"address/form\"; }\n}\n",
 "thy/src/main/resources/templates/address/form.html": "<html xmlns:th=\"http://www.thymeleaf.org\"><form th:action=\"@{/address/save}\" method=\"post\">\n<label for=\"street\" th:text=\"#{address.street}\">Street</label>\n<input type=\"text\" id=\"street\" th:field=\"*{street}\"/>\n<select id=\"addrType\" th:field=\"*{type}\"><option th:each=\"t : ${types}\" th:value=\"${t}\" th:text=\"${t}\">HOME</option></select>\n<div th:if=\"${showPostal}\"><input id=\"postal\" th:field=\"*{postal}\"/></div>\n<button type=\"submit\" id=\"saveAddr\">Save</button>\n</form></html>",
 "thy/src/main/resources/messages.properties": "address.street=Street name\n",
 # 5. ASP.NET Web Forms and ASP.NET MVC (Razor)
 "net/Web.config": "<configuration/>",
 "net/Default.aspx": "<%@ Page Language=\"C#\" %><form runat=\"server\"><asp:Label AssociatedControlID=\"txtName\" Text=\"Name\" runat=\"server\"/><asp:TextBox ID=\"txtName\" runat=\"server\" MaxLength=\"50\"/>\n<asp:DropDownList ID=\"ddlCountry\" runat=\"server\"><asp:ListItem Value=\"IN\" Text=\"India\"/><asp:ListItem Value=\"GB\" Text=\"United Kingdom\"/></asp:DropDownList>\n<asp:Button ID=\"btnSave\" runat=\"server\" Text=\"Save\"/></form>",
 "net/Controllers/HomeController.cs": "public class HomeController : Controller {\n  public IActionResult Contact() { return View(); }\n}\n",
 "net/Views/Home/Contact.cshtml": "@model ContactModel\n<form asp-action=\"Contact\" method=\"post\"><input asp-for=\"Email\" id=\"email\" /><button type=\"submit\" id=\"send\">Send</button></form>",
 # 6. plain HTML with jQuery, no build file at all
 "jq/public/transfer.html": "<html><script src=\"js/jquery-1.8.3.min.js\"></script><h1>Transfer</h1><input id=\"amount\" name=\"amount\"><button id=\"sendBtn\">Send</button><script>$(document).ready(function(){ $('#sendBtn').click(function(){ $.ajax({url: '/api/transfer', type: 'POST'}); }); });</script></html>",
 # 7. Struts 2 actions with JSP results
 "struts/src/main/resources/struts.xml": "<struts><package name=\"default\"><action name=\"editClient\" class=\"com.bank.ClientAction\"><result>/WEB-INF/jsp/client.jsp</result></action></package></struts>",
 "struts/src/main/webapp/WEB-INF/jsp/client.jsp": "<%@ taglib prefix=\"s\" uri=\"/struts-tags\" %><s:form action=\"saveClient\"><s:textfield name=\"client.name\" id=\"clientName\" label=\"Name\"/><s:submit id=\"save\" value=\"Save\"/></s:form>",
}


def self_test():
    tmp = tempfile.mkdtemp(prefix="extract_dev_selftest_")
    try:
        for name, content in SAMPLE.items():
            p = os.path.join(tmp, name)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w", encoding="utf-8").write(content)
        def snapshot(d):
            h = {}
            for r, _, fs in os.walk(d):
                for fn in fs:
                    p = os.path.join(r, fn)
                    h[p] = hashlib.sha1(open(p, "rb").read()).hexdigest()
            return h
        before = [snapshot(os.path.join(tmp, x)) for x in ("fe", "be", "ng", "nx", "mono")]
        out = os.path.join(tmp, "out")
        s = run([os.path.join(tmp, "fe")], [os.path.join(tmp, "be")], out, os.path.join(tmp, "qa"), ["tests/subs.robot"])
        screens = {x["id"]: x for x in json.load(open(os.path.join(out, "dev-screens.json")))}
        api = json.load(open(os.path.join(out, "dev-api.json")))
        ref = json.load(open(os.path.join(out, "dev-reference-data.json")))
        links = json.load(open(os.path.join(out, "dev-links.json")))
        scope = json.load(open(os.path.join(out, "dev-scope.json")))
        biz = json.load(open(os.path.join(out, "dev-business.json")))
        dm = json.load(open(os.path.join(out, "dev-data-model.json")))
        ms = screens.get("/clients/:id/subscriptions", {"elements": [], "texts": [], "validations": [], "apis": [], "loaders": [], "navigates_to": [], "files": [], "role_hints": []})
        cs = screens.get("/clients", {"elements": [], "texts": [], "navigates_to": []})
        el = lambda scr, **kw: next((e for e in scr["elements"] if all(e.get(k) == v for k, v in kw.items())), None)
        sel = el(ms, id="subscription-type") or {}
        lei = el(ms, id="lei-number") or {}
        ep = {(e["method"], e["path"]): e for e in api["endpoints"]}
        post = ep.get(("POST", "/api/clients/{id}/subscriptions"), {})
        link = next((l for l in links["links"] if l["screen"] == "/clients/:id/subscriptions" and l["qa_file"] == "resources/subs.resource"), {})
        checks = {
            "front-end framework detected (React, Material UI)": {"React", "Material UI"} <= set(s["repos"][0]["frameworks"]),
            "back-end framework detected (Spring Boot)": "Spring Boot" in s["repos"][1]["frameworks"],
            "screens found from the router (2)": set(screens) == {"/clients", "/clients/:id/subscriptions"},
            "translated label resolved (LEI)": bool(el(cs, label="LEI")),
            "test ID inside inputProps captured": bool(el(cs, testid="lei-input")),
            "dropdown options attached to their dropdown": [o["value"] for o in sel.get("options", [])] == ["DAILY", "WEEKLY"],
            "field shown only under a condition": "CORPORATE" in str(lei.get("visible_when")),
            "validation rule from the form schema": any(v["field"] == "leiNumber" and any(r.startswith("required") for r in v["rules"]) and any(r.startswith("matches") for r in v["rules"]) for v in ms["validations"]),
            "data loaded on open and its loading indicator": any(a["on_load"] for a in ms["apis"]) and "CircularProgress" in ms["loaders"],
            "navigation mapped to the target screen": any(n.get("screen") == "/clients/:id/subscriptions" for n in cs["navigates_to"]),
            "dialog included in its parent screen": bool(el(ms, testid="confirm-unsubscribe")) and any("SubscriptionDialog" in d for d in ms["dialogs"]),
            "API endpoints with full paths": ("GET", "/api/clients/{id}/subscriptions") in ep and bool(post),
            "request field validation (NotBlank, Size max 20)": any(f["field"] == "leiNumber" and "NotBlank" in f["rules"] and any(r.startswith("Size") for r in f["rules"]) for f in post.get("request_fields", [])),
            "back-end enum as reference data": any(e["name"] == "SubscriptionType" and len(e["items"]) == 3 for e in ref["backend_enums"]),
            "screen API call matched to its endpoint": any(a.get("endpoint") == "GET /api/clients/{id}/subscriptions" for a in ms["apis"]),
            "QA locators linked to the screen with high confidence": link.get("confidence") == "high" and {"id", "url"} <= set(link.get("evidence_types", [])),
            "business check with its message, tied to its endpoint": any(c["kind"] == "business check" and "CORPORATE" in (c["condition"] or "") and c["message"] == "A corporate client must have an LEI" and "POST /api/kyc/{caseId}/approve" in c["endpoints"] for c in biz["checks"]),
            "status rule found (only submitted cases can be approved)": any(c["kind"] == "status rule" and c["statuses"] == ["SUBMITTED"] for c in biz["checks"]),
            "prerequisite record found (KYC case must exist)": any(c["kind"] == "prerequisite" and c["message"] == "KYC case not found" for c in biz["checks"]),
            "role needed for the endpoint (KYC approver)": ep.get(("POST", "/api/kyc/{caseId}/approve"), {}).get("roles") == ["KYC_APPROVER"],
            "status change with the status it needs first": any(tr["to"] == "APPROVED" and tr["statuses_checked_before"] == ["SUBMITTED"] and any(g["message"] == "Only submitted cases can be approved" for g in tr["guards"]) for tr in biz["transitions"]) and any(st["name"] == "KycStatus" and len(st["values"]) == 4 for st in biz["statuses"]),
            "data model: table and columns from code and migration": any(en["table"] == "KYC_CASE" and any(fd["column"] == "LEI_NUMBER" for fd in en["fields"]) for en in dm["entities"]) and any(tb["table"] == "KYC_CASE" and len(tb["columns"]) == 3 for tb in dm["tables"]),
            "screen field traced to its stored column": any(r["column"] == "LEI_NUMBER" and r["request_field"] == "leiNumber" for r in dm["field_map"]),
            "after save: messages and next screen": any((a.get("after") or {}).get("success_messages") == ["Subscription saved"] and a["after"]["error_messages"] == ["Could not save subscription"] and a["after"]["navigates_to"] == "/clients" for a in ms["apis"]),
            "button that depends on a role": bool((el(ms, id="approve-btn") or {}).get("depends_on_role")) and any("KYC_APPROVER" in h["roles"] for h in ms["role_hints"]),
            "team locator missing from the development code flagged": [m["variable"] for m in links["missing_in_dev"]] == ["${OLD_FREQ}"],
            "suite scope finds its screens and neighbours": scope["screens"] == ["/clients/:id/subscriptions"] and "/clients" in scope["neighbour_screens"],
        }
        for name, content in LEGACY_SAMPLE.items():
            pth = os.path.join(tmp, "legacy", name)
            os.makedirs(os.path.dirname(pth), exist_ok=True)
            open(pth, "w", encoding="utf-8").write(content)
        def legacy(r):
            o_ = os.path.join(tmp, "out_legacy", r)
            sm_ = run([], [], o_, repos=[os.path.join(tmp, "legacy", r)])
            return sm_, {x["id"]: x for x in json.load(open(os.path.join(o_, "dev-screens.json")))}
        sm_a, sc_a = legacy("ajs")
        form = sc_a.get("/requests/new", {"elements": [], "apis": [], "navigates_to": []})
        checks["Spring Boot with AngularJS 1.x in static/: read as front end and back end (no package.json needed)"] = \
            sorted(r["role"] for r in sm_a["repos"]) == ["backend", "frontend"] and "AngularJS" in sm_a["repos"][0]["frameworks"]
        checks["AngularJS: $routeProvider routes give the screens, with their templates and controllers"] = \
            set(sc_a) == {"/requests", "/requests/new"} and any(f.endswith("controllers.js") for f in form.get("files", []))
        checks["AngularJS: ng-model fields, ng-required, ng-maxlength, ng-options, ng-show, ng-disabled"] = \
            (el(form, id="customerName") or {}).get("required") and "maxlength=40" in (el(form, id="customerName") or {}).get("rules", []) \
            and (el(form, id="branch") or {}).get("options_from") == "branches" and "CORPORATE" in str((el(form, id="lei") or {}).get("visible_when")) \
            and (el(form, id="saveBtn") or {}).get("disabled_when") == "form.$invalid" and (el(form, id="customerName") or {}).get("label") == "Customer name"
        checks["AngularJS: $http calls per controller, after-save messages and $location navigation"] = \
            any(a["method"] == "POST" and a.get("endpoint") == "POST /api/requests" and a["after"]["success_messages"] == ["Request saved"]
                and a["after"]["error_messages"] == ["Could not save the request"] and a["after"]["navigates_to"] == "/requests" for a in form["apis"]) \
            and not any(a["url"] == "/api/branches" for a in sc_a.get("/requests", {}).get("apis", []))
        api_a = json.load(open(os.path.join(tmp, "out_legacy", "ajs", "dev-api.json")))
        post = next((e for e in api_a["endpoints"] if e["method"] == "POST" and e["path"] == "/api/requests"), {})
        save_call = next((a for a in form["apis"] if a["method"] == "POST"), {})
        checks["outside systems found (Feign, RestTemplate) and tied to the endpoint and the button that reaches them"] = \
            post.get("integrations") == ["Alfresco", "BMC"] and {x["kind"] for x in api_a["integrations"]} >= {"Feign client", "REST call"} \
            and save_call.get("integrations") == ["Alfresco", "BMC"] and save_call.get("triggered_by") == ["saveBtn"]
        sm_j, sc_j = legacy("jsp")
        ed = next(iter(sc_j.values()), {"elements": [], "apis": []})
        checks["Spring MVC + JSP: route from the controller's view, labels from messages.properties, c:if condition"] = \
            ed.get("route") == "/clients/edit" and (el(ed, id="firstName") or {}).get("label") == "First name" and \
            "CORPORATE" in str((el(ed, id="lei") or {}).get("visible_when")) and (el(ed, id="clientType") or {}).get("kind") == "dropdown" \
            and (el(ed, id="saveClient") or {}).get("text") == "Save" and any(a["url"] == "/clients/save" for a in ed["apis"])
        _, sc_f = legacy("jsf")
        kf = sc_f.get("/kyc/approve.xhtml", {"elements": []})
        checks["JSF: h: fields named from #{bean.field}, f:selectItem options, rendered= condition on a role"] = \
            (el(kf, id="comment") or {}).get("name") == "kycBean.comment" and [o_["value"] for o_ in (el(kf, id="decision") or {}).get("options", [])] == ["APPROVE", "REJECT"] \
            and (el(kf, id="submit") or {}).get("depends_on_role")
        _, sc_t = legacy("thy")
        tf = next(iter(sc_t.values()), {"elements": []})
        checks["Thymeleaf: th:field names, #{...} labels, th:if condition, route from the controller"] = \
            tf.get("route") == "/address/new" and (el(tf, id="street") or {}).get("label") == "Street name" and \
            (el(tf, id="addrType") or {}).get("options_from") == "types" and "showPostal" in str((el(tf, id="postal") or {}).get("visible_when"))
        _, sc_n = legacy("net")
        wf, rz = sc_n.get("/Default.aspx", {"elements": []}), next((v for k, v in sc_n.items() if k.endswith("Contact.cshtml")), {"elements": []})
        checks["ASP.NET Web Forms and MVC Razor: server controls, list items, asp-for, route from the controller"] = \
            (el(wf, id="txtName") or {}).get("label") == "Name" and [o_["value"] for o_ in (el(wf, id="ddlCountry") or {}).get("options", [])] == ["IN", "GB"] \
            and (el(wf, id="btnSave") or {}).get("server_id") and rz.get("route") == "/Home/Contact" and (el(rz, id="email") or {}).get("name") == "Email"
        sm_q, sc_q = legacy("jq")
        checks["plain HTML with jQuery and no build file: screen, fields and $.ajax call"] = \
            sm_q["repos"][0]["role"] == "frontend" and any(a["url"] == "/api/transfer" and a["method"] == "POST" for a in sc_q.get("/transfer.html", {}).get("apis", []))
        _, sc_s = legacy("struts")
        st_ = next(iter(sc_s.values()), {"elements": []})
        checks["Struts 2: route from struts.xml, s: tags with labels"] = st_.get("route") == "/editClient.action" and (el(st_, id="clientName") or {}).get("label") == "Name"
        vd = os.path.join(tmp, "legacy", "vaadin")
        os.makedirs(os.path.join(vd, "src"), exist_ok=True)
        open(os.path.join(vd, "pom.xml"), "w").write("<project><dependency><artifactId>vaadin-core</artifactId></dependency></project>")
        open(os.path.join(vd, "src", "MainView.java"), "w").write("public class MainView extends VerticalLayout { TextField name = new TextField(\"Name\"); }")
        sm_v, _ = legacy("vaadin")
        checks["a front end that gives no screens is reported by name, never silently 'back end only'"] = \
            any(r["role"] == "frontend" for r in sm_v["repos"]) and any("No screens found" in w and "framework" in w for w in sm_v["warnings"])
        out_auto = os.path.join(tmp, "out_auto")
        sa = run([], [], out_auto, repos=[os.path.join(tmp, "fe"), os.path.join(tmp, "be"), os.path.join(tmp, "mono")])
        roles = sorted((os.path.basename(r["path"]), r["role"]) for r in sa["repos"])
        checks["front end or back end worked out from the code (no tester input)"] = roles == [
            ("be", "backend"), ("fe", "frontend"), ("mono", "backend"), ("mono", "frontend")]
        out2 = os.path.join(tmp, "out2")
        run([os.path.join(tmp, "ng"), os.path.join(tmp, "nx")], [], out2)
        s2 = {x["id"]: x for x in json.load(open(os.path.join(out2, "dev-screens.json")))}
        kyc = s2.get("/kyc/:id", {"elements": [], "validations": [], "apis": []})
        com = el(kyc, name="comment") or {}
        checks["Angular screen with its template, options and condition"] = (
            [o["value"] for o in (el(kyc, testid="risk-rating") or {}).get("options", [])] == ["LOW", "HIGH"]
            and "HIGH" in str(com.get("visible_when")) and any(v["field"] == "comment" for v in kyc["validations"])
            and any(a["on_load"] for a in kyc["apis"]))
        case = s2.get("/review/:caseId", {"elements": []})
        esc = el(case, testid="escalate") or {}
        checks["import shortcut (tsconfig paths) followed to a child component"] = bool(esc)
        checks["Angular attribute binding and translate pipe read"] = esc.get("text") == "Escalate case"
        checks["route group (loadChildren) is not treated as a screen"] = "/kyc" not in s2
        out3 = os.path.join(tmp, "out3")
        run([os.path.join(tmp, "ng")], [], out3, os.path.join(tmp, "qa2"))
        l3 = json.load(open(os.path.join(out3, "dev-links.json")))["links"]
        checks["nested route linked to the QA URL ${BASE_URL}/kyc/review/..."] = any(
            l["screen"] == "/review/:caseId" and "url" in l["evidence_types"] and l["confidence"] == "high" for l in l3)
        out4 = os.path.join(tmp, "out4")
        run([os.path.join(tmp, "mono")], [os.path.join(tmp, "mono")], out4)
        eps4 = json.load(open(os.path.join(out4, "dev-api.json")))["endpoints"]
        checks["one repo with both parts: front-end calls not counted as endpoints"] = [(e["method"], e["path"], e["file"]) for e in eps4] == [("GET", "/api/things", "server/index.js")]
        checks["Next.js file-based route found"] = bool(el(s2.get("/clients/:id", {"elements": []}), id="client-name"))
        checks["development repos left untouched (read-only)"] = before == [snapshot(os.path.join(tmp, x)) for x in ("fe", "be", "ng", "nx", "mono")]
        width = max(len(k) for k in checks)
        for k, v in checks.items():
            print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
        ok = all(checks.values())
        print("SELF-TEST PASSED" if ok else "SELF-TEST FAILED", f"({sum(checks.values())} of {len(checks)} OK)")
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def main():
    ap = argparse.ArgumentParser(description="Read-only fact extractor for development repositories.")
    ap.add_argument("--repo", action="append", default=[], help="development repo folder (repeatable); front end or back end is worked out from its code")
    ap.add_argument("--frontend", action="append", default=[], help="front-end repo folder (repeatable)")
    ap.add_argument("--backend", action="append", default=[], help="back-end repo folder (repeatable)")
    ap.add_argument("--out", default=os.path.join(ai_home(), "knowledge", ".extract", "dev"))
    ap.add_argument("--qa-extract", default=None, help="QA extract folder (knowledge/.extract) to link against")
    ap.add_argument("--qa-scope", default=None, help="comma-separated QA suite files; limits dev scope to their screens")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        sys.exit(self_test())
    if not a.repo and not a.frontend and not a.backend:
        ap.error("give at least one --repo folder")
    scope = [x.strip() for x in a.qa_scope.split(",")] if a.qa_scope else None
    s = run(a.frontend, a.backend, a.out, a.qa_extract, scope, repos=a.repo)
    print(json.dumps({"counts": s["counts"], "warnings": s["warnings"],
                      "repos": [dict({k: r[k] for k in ("role", "path", "frameworks")}, branch=r["git"]["branch"], commit=(r["git"]["commit"] or "")[:10]) for r in s["repos"]]}, indent=1))

if __name__ == "__main__":
    main()
