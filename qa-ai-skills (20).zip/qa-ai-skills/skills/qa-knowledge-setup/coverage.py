#!/usr/bin/env python3
"""
coverage.py - automation coverage map, gap analysis and regression gap analysis for the QA repo,
measured against what the development code really contains. Part of the QA AI skills. Standard
library only; read-only on every repo; nothing leaves the machine.

What it measures
  Items come from the development knowledge (knowledge/.extract/dev): screens, fields, buttons,
  validation rules, conditions (shown/enabled when ...), role rules, business rules, status changes,
  API calls, outside systems (BMC, Alfresco ...), messages and dropdown options. Every item has a
  stable ID (for example RULE:/requests/new#customerName:required) and its source file and line.
  Evidence comes from the automated tests (knowledge/.extract): every test is expanded through its
  keywords, with arguments, down to the library actions it performs (types into, clicks, checks shown
  or hidden, checks a text) and the locators it acts on, which are matched to the development
  elements by id, test id, name, model binding or visible text.
  Each item is Covered, Partial or Gap, always with the reason and the tests that prove it; scenario
  gaps are grouped as Negative, Conditional, Boundary, Roles / security, Integration, Status flow,
  Happy path and Data variation, and ranked P1 / P2 / P3 by risk (what kind of rule, outside systems,
  money or personal-data fields, how often the code changed recently).

Commands (run from the QA repo root)
  python qa-ai-skills/skills/qa-knowledge-setup/coverage.py build [--cases <test case file or folder> ...]
        the full analysis -> qa-ai-skills/knowledge/coverage/: coverage-map.md (for managers),
        gaps.md, coverage-matrix.csv (opens in Excel), coverage.html (interactive, offline),
        gap-test-cases.md (the top gaps written as test cases the script generator can automate),
        coverage.json (the data; the next build reports the trend and what changed in the code)
  python ... coverage.py regression --base <ref> [--head <ref>]
        regression gap analysis for a change in the development repos (a release, a branch, a sprint):
        the items the change touched, the existing tests to run, and the touched items no test covers
  python ... coverage.py --self-test

Decisions: qa-ai-skills/knowledge/coverage/decisions.md holds lines `<item ID> | <Covered|Partial|Gap|N/A> | <reason>`
written by a person or by the AI after checking an item by hand. They win over the computed status
on every later build and are marked as decisions in every report.
"""
import argparse, csv, datetime, hashlib, html, io, json, os, re, shutil, subprocess, sys, tempfile
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
STATUSES = ("Covered", "Partial", "Gap")
CATEGORIES = ("Happy path", "Negative", "Conditional", "Boundary", "Roles / security", "Integration", "Status flow", "Data variation")
TYPE_NAMES = {"SCR": "Screen", "FLD": "Field", "ACT": "Button / link", "RULE": "Validation rule", "COND": "Condition",
              "ROLE": "Role rule", "API": "API call", "INT": "Outside system", "MSG": "Message", "BR": "Business rule",
              "TRN": "Status change", "OPT": "Dropdown options", "SRV": "Server validation"}
SENSITIVE = re.compile(r"(?i)amount|balance|limit|rate|price|fee|account|iban|pan\b|card|cvv|dob|birth|ssn|tax|salary|income|passport|"
                       r"national|aadhaar|password|pin\b|otp|routing|swift|bic\b|loan|credit|debit|interest|currency")


def ai_home(root="."):
    h = os.path.join(root, "qa-ai-skills")
    return h if os.path.isdir(h) else root


def jload(path, default):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def slug(s, n=48):
    return re.sub(r"[^a-z0-9]+", "-", str(s or "").lower()).strip("-")[:n] or "x"


def sha(s):
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:10]


# ======================================================================== locators -> element tokens
TOKEN_RX = [
    ("testid", re.compile(r"""data-(?:testid|test-id|test|qa|cy|automation-id)\s*=\s*["']?([\w\-.:]+)""", re.I)),
    ("id", re.compile(r"""^(?:id[:=]|css[:=]\s*#|#)\s*([\w\-.:$]+)$""", re.I)),
    ("id", re.compile(r"""(?<![\w-])@?id\s*=\s*["']([\w\-.:$]+)["']""", re.I)),
    ("id", re.compile(r"""(?:^|[\s>+~,(])#([\w\-]+)""")),
    ("idpart", re.compile(r"""contains\(\s*@id\s*,\s*["']([\w\-.$]+)["']|\[id[$*]=\s*["']?([\w\-.$]+)""", re.I)),
    ("name", re.compile(r"""^name[:=]\s*([\w\-.\[\]]+)$""", re.I)),
    ("name", re.compile(r"""@?name\s*=\s*["']([\w\-.\[\]]+)["']""", re.I)),
    ("model", re.compile(r"""(?:ng-model|data-ng-model|formcontrolname|v-model|th:field|asp-for)\s*=\s*["']\*?\{?([\w\-.]+)\}?["']""", re.I)),
    ("text", re.compile(r"""(?:text\(\)|normalize-space\(\)|normalize-space\(text\(\)\)|\.)\s*=\s*["']([^"']{2,60})["']""")),
    ("text", re.compile(r"""contains\(\s*(?:text\(\)|\.|normalize-space\(\))\s*,\s*["']([^"']{2,60})["']""")),
    ("text", re.compile(r"""^(?:text[:=]|link[:=]|partial link[:=])\s*"?([^"]{2,60}?)"?$""", re.I)),
    ("text", re.compile(r""":has-text\(\s*["']([^"']{2,60})["']\s*\)|>>\s*text=["']?([^"']{2,60})""", re.I)),
    ("text", re.compile(r"""@(?:aria-label|title|placeholder|value)\s*=\s*["']([^"']{2,60})["']|\[(?:aria-label|title|placeholder)=["']([^"']{2,60})["']\]""", re.I)),
]


def tokens(value):
    v = str(value or "").strip()
    out = []
    for kind, rx in TOKEN_RX:
        for m in rx.finditer(v):
            tok = next((g for g in m.groups() if g), None)
            if tok and "${" not in tok and len(tok) >= 2:
                out.append((kind, tok.strip()))
    if not out and re.match(r"^[\"'][^\"']{2,60}[\"']$", v):              # Browser library: "Save" is a text selector
        out.append(("text", v.strip("\"'")))
    return out


# ======================================================================== evidence from the automated tests
SET_RX = re.compile(r"^(input text|input password|type text|type secret|fill text|fill secret|press sequentially|select from list|select options by|"
                    r"select checkbox|unselect checkbox|select radio button|check checkbox|uncheck checkbox|choose file|upload file|"
                    r"clear element text|clear text|set checkbox|select all from list|unselect from list|select from dropdown|input)\b")
CLICK_RX = re.compile(r"^(click|double click|submit form|tap|press keys|press button|click button|click link|click element)")
VIS_RX = re.compile(r"^(element should be visible|wait until element is visible|wait until page contains element|page should contain element|"
                    r"element should be enabled|wait until element is enabled|wait for elements state|get element states|element should exist|"
                    r"page should contain (button|textfield|link|checkbox|list|radio button))")
NOTVIS_RX = re.compile(r"^(element should not be visible|wait until element is not visible|page should not contain element|"
                       r"wait until page does not contain element|element should not exist|page should not contain (button|textfield|link))")
DISABLED_RX = re.compile(r"^(element should be disabled|wait until element is disabled)")
ASSERT_RX = re.compile(r"^(element should contain|element text should be|page should contain|wait until page contains|wait until element contains|"
                       r"should be equal|should contain|should match|should be true|get text|get element attribute|textfield value should be|"
                       r"textfield should contain|list selection should be|alert should be present|handle alert|get alert message|"
                       r"element attribute value should be|get title|title should be|location should|get url|wait for condition|"
                       r"page should not contain|element should not contain|should not be equal|should not contain)")
NAV_RX = re.compile(r"^(go to|navigate to|new page|open browser|go back|reload)")
LOGIN_RX = re.compile(r"(?i)\blog ?in\b|\bsign ?in\b|\blogin\b|authenticat")
NEGATIVE_RX = re.compile(r"(?i)invalid|negative|error|empty|blank|missing|wrong|reject|not allowed|unauthori|forbidden|denied|"
                         r"without|mandatory|required|exceed|too long|too short|maximum|minimum|boundary|limit|special char|"
                         r"duplicate|fail|cannot|can't|must not|should not")
ROLE_NEG_RX = re.compile(r"(?i)unauthori|forbidden|denied|no access|without (the )?(role|permission|right)|read.?only|viewer|not allowed")
LOCATORISH = re.compile(r"^(id|css|xpath|name|link|partial link|class|tag|dom|jquery|text|data|identifier)[:=]|^//|^#[\w-]|^\[|^\.[\w-]", re.I)


class Evidence:
    """Every test expanded through its keywords to the library actions it performs."""

    def __init__(self, x):
        self.kws = defaultdict(list)
        for k in jload(os.path.join(x, "keywords.json"), []):
            self.kws[norm(k["name"])].append(k)
        self.byfile = {(k["file"], norm(k["name"])): k for ks in self.kws.values() for k in ks}
        self.vars = {}
        for v in jload(os.path.join(x, "variables.json"), []):
            if isinstance(v, dict) and v.get("name"):
                self.vars[self.vkey(v["name"])] = v.get("value")
        for l in jload(os.path.join(x, "locators.json"), []):
            self.vars.setdefault(self.vkey(l.get("variable")), l.get("value"))
        self.tests = jload(os.path.join(x, "tests.json"), [])
        self.memo = {}

    @staticmethod
    def vkey(name):
        return norm(re.sub(r"^[$@&%]\{|\}$", "", str(name or "")))

    def resolve(self, arg, scope, depth=0):
        s = str(arg)
        if depth > 4:
            return s

        def sub(m):
            k = self.vkey(m.group(0))
            if k in scope:
                return str(scope[k])
            if k in self.vars and self.vars[k] is not None:
                v = self.vars[k]
                return " ".join(map(str, v)) if isinstance(v, list) else str(v)
            return m.group(0)
        out = re.sub(r"[$@&%]\{[^{}]+\}", sub, s)
        return self.resolve(out, scope, depth + 1) if out != s and "${" in out else out

    def find_kw(self, step):
        for r in step.get("resolved") or []:
            f, _, n = r.partition("::")
            k = self.byfile.get((f, norm(n)))
            if k:
                return k
        ks = self.kws.get(norm(step.get("keyword")))
        return ks[0] if ks and len(ks) == 1 else None

    def bind(self, kw, args, scope):
        names = [a.split("=", 1) for a in kw.get("arguments") or []]
        out, pos = {}, [a for a in args if not re.match(r"^[\w ]+=", str(a))]
        named = dict(str(a).split("=", 1) for a in args if re.match(r"^[\w ]+=", str(a)))
        for i, n in enumerate(names):
            key = self.vkey(n[0])
            if i < len(pos):
                out[key] = self.resolve(pos[i], scope)
            elif key in {self.vkey(k) for k in named}:
                out[key] = self.resolve(next(v for k, v in named.items() if self.vkey(k) == key), scope)
            elif len(n) > 1:
                out[key] = self.resolve(n[1], scope)
        return out

    def expand(self, steps, scope, chain, depth=0):
        """Library actions: (keyword, resolved args, the user-keyword chain that led to it)."""
        acts = []
        for st in steps:
            name = str(st.get("keyword") or "")
            if not name or name.startswith(("FOR", "IF", "END", "ELSE")):
                continue
            kw = self.find_kw(st) if depth < 12 else None
            if kw:
                bound = self.bind(kw, st.get("args") or [], scope)
                key = (kw["file"], kw["name"], json.dumps(sorted(bound.items())))
                if key not in self.memo:
                    self.memo[key] = []
                    self.memo[key] = self.expand(kw.get("steps") or [], bound, (), depth + 1)
                acts.append(("__user__", [kw["name"]] + [str(v) for v in bound.values()], chain))
                acts += [(a, b, chain + (kw["name"],) + c) for a, b, c in self.memo[key]]
            else:
                args = [self.resolve(a, scope) for a in st.get("args") or []]
                low = name.lower().split(".")[-1].strip()
                if low in ("run keyword", "run keyword and expect error", "run keyword and ignore error", "run keyword and return status",
                           "wait until keyword succeeds", "run keyword if", "run keyword unless", "repeat keyword"):
                    skip = {"run keyword": 0, "run keyword and expect error": 1, "run keyword and ignore error": 0,
                            "run keyword and return status": 0, "wait until keyword succeeds": 2, "run keyword if": 1,
                            "run keyword unless": 1, "repeat keyword": 1}[low]
                    if len(args) > skip:
                        inner = {"keyword": args[skip], "args": args[skip + 1:], "resolved": []}
                        if low == "run keyword and expect error":
                            acts.append(("__expect_error__", [str(args[0])], chain))
                        acts += self.expand([inner], scope, chain, depth + 1)
                    continue
                acts.append((low, args, chain))
        return acts

    def per_test(self):
        """For every test: actions on element tokens, asserted texts, values set, users, intent words."""
        out = []
        for t in self.tests:
            acts = self.expand(t.get("steps") or [], {}, ())
            ev = {"test": t["name"], "file": t.get("file"), "ids": [x for x in t.get("tags") or [] if re.search(r"\d", str(x))],
                  "touch": defaultdict(set), "asserted": [], "set_values": defaultdict(list), "users": set(), "nav": set(),
                  "negative": bool(NEGATIVE_RX.search(" ".join([t["name"], t.get("documentation") or ""] + list(t.get("tags") or [])))),
                  "role_negative": bool(ROLE_NEG_RX.search(t["name"] + " " + (t.get("documentation") or "")))}
            for kwname, args, chain in acts:
                if kwname == "__user__":
                    if LOGIN_RX.search(args[0]) and len(args) > 1:
                        ev["users"].add(sha(str(args[1])))          # who logged in, kept only as a fingerprint
                    if NEGATIVE_RX.search(args[0]):
                        ev["negative"] = True
                    if ROLE_NEG_RX.search(args[0]):
                        ev["role_negative"] = True
                    continue
                if kwname == "__expect_error__":
                    ev["negative"] = True
                    ev["asserted"].append(args[0])
                    continue
                kind = ("set" if SET_RX.match(kwname) else "click" if CLICK_RX.match(kwname) else "notvis" if NOTVIS_RX.match(kwname)
                        else "disabled" if DISABLED_RX.match(kwname) else "vis" if VIS_RX.match(kwname)
                        else "assert" if ASSERT_RX.match(kwname) else "nav" if NAV_RX.match(kwname) else None)
                if not kind:
                    continue
                if kind == "nav":
                    for a in args:
                        if re.search(r"^(https?://|/)", str(a)):
                            ev["nav"].add(re.sub(r"^https?://[^/]+", "", str(a)).split("?")[0] or "/")
                    continue
                loc = str(args[0]) if args else ""
                toks = tokens(loc) if LOCATORISH.search(loc) or tokens(loc) else []
                if kwname.startswith("wait for elements state") and len(args) > 1 and re.search(r"hidden|detached", str(args[1]), re.I):
                    kind = "notvis"
                if kwname.startswith("get element states") and re.search(r"disabled", " ".join(map(str, args)), re.I):
                    kind = "disabled"
                for tk in toks:
                    ev["touch"][tk].add(kind)
                    if kind == "set" and len(args) > 1:
                        ev["set_values"][tk].append(str(args[1]))
                texts = [str(a) for a in (args[1:] if toks else args) if a not in ("==", "!=", "*=", "contains", "should be", "equal", "^=", "$=")]
                if kind in ("assert", "vis", "notvis") and texts:
                    ev["asserted"] += [x for x in texts if len(x) >= 3 and not LOCATORISH.search(x) and "${" not in x]
                if kind == "assert" and not toks and args and not LOCATORISH.search(str(args[0])):
                    ev["asserted"].append(str(args[0]))
            ev["asserted"] = [norm(a) for a in ev["asserted"] if norm(a)]
            out.append(ev)
        return out


# ======================================================================== items from the development knowledge
def element_key(e):
    return e.get("id") or e.get("testid") or e.get("name") or (("text:" + e["text"]) if e.get("text") else None)


def element_tokens(e):
    out = []
    for k in ("id", "testid", "name"):
        if e.get(k):
            out.append(("any", str(e[k]).lower()))
    if e.get("name") and "." in str(e["name"]):
        out.append(("any", str(e["name"]).split(".")[-1].lower()))
    for k in ("text", "label", "placeholder"):
        if e.get(k) and e.get("kind") in ("button", "link", "tab") or (k in ("label", "placeholder") and e.get(k)):
            out.append(("text", norm(e[k])))
    return out


def human(name):
    """customerName / req.lei / txt_first_name -> Customer name / Lei / First name"""
    n = str(name or "").split(".")[-1]
    n = re.sub(r"^(txt|ddl|chk|btn|lbl|rb|cmb|sel|inp|fld)(?=[A-Z_])", "", n)
    n = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", n).replace("_", " ").replace("-", " ").strip()
    return (n[:1].upper() + n[1:].lower()) if n else ""


def label_of(e):
    return e.get("label") or e.get("text") or e.get("placeholder") or human(e.get("name") or e.get("id") or e.get("testid")) or "element"


def build_items(dev):
    screens = jload(os.path.join(dev, "dev-screens.json"), [])
    api = jload(os.path.join(dev, "dev-api.json"), {})
    biz = jload(os.path.join(dev, "dev-business.json"), {})
    items, ep_screens = {}, defaultdict(set)

    def add(iid, **kw):
        kw.setdefault("area", "")
        kw["id"] = iid
        kw["type"] = iid.split(":", 1)[0]
        kw["fingerprint"] = sha(json.dumps({k: v for k, v in kw.items() if k in ("what", "detail", "src_file", "rule")}, sort_keys=True, default=str))
        items.setdefault(iid, kw)
        return items[iid]
    for s in screens:
        sid = str(s.get("route") or s.get("id"))
        area = sid
        title = next((t["text"] for t in s.get("texts", []) if t.get("kind") not in ("label", "FormLabel", "InputLabel")), "")
        add(f"SCR:{sid}", area=area, what=f"Screen {sid}" + (f" ({title})" if title else ""), category="Happy path",
            src_file=s.get("file"), src_line=1, repo=s.get("repo"), screen=sid, route=s.get("route"), files=s.get("files", []))
        by_field = defaultdict(list)
        for v in s.get("validations", []):
            by_field[norm(v.get("field")).replace(" ", "")].append(v)
        for e in s.get("elements", []):
            key = element_key(e)
            if not key:
                continue
            kind = e.get("kind")
            lab = label_of(e)
            base = dict(area=area, screen=sid, element=key, tokens=element_tokens(e), label=lab, src_file=e.get("file"),
                        src_line=e.get("line"), repo=s.get("repo"), sensitive=bool(SENSITIVE.search(f"{lab} {key}")))
            if kind in ("input", "dropdown", "checkbox"):
                add(f"FLD:{sid}#{key}", what=f"{TYPE_NAMES['FLD']} '{lab}'", category="Happy path", field_kind=kind, **base)
                rules = []
                if e.get("required"):
                    rules.append(("required", "Negative", f"'{lab}' is required"))
                for r in e.get("rules") or []:
                    rk = r.split("=")[0].lower()
                    if rk in ("maxlength", "minlength", "max", "min"):
                        rules.append((rk + "=" + r.split("=", 1)[1], "Boundary", f"'{lab}' {rk} {r.split('=', 1)[1]}"))
                    elif rk in ("pattern",):
                        rules.append(("pattern", "Negative", f"'{lab}' must match a pattern"))
                fv = by_field.get(norm(e.get("name") or key).replace(" ", "").split(".")[-1]) or by_field.get(norm(key).replace(" ", ""))
                messages = []
                for v in fv or []:
                    for i, r in enumerate(v.get("rules") or []):
                        msg = (v.get("messages") or [None] * 99)[i] if i < len(v.get("messages") or []) else None
                        rk = re.split(r"[(\s]", r, maxsplit=1)[0].lower()
                        cat = "Boundary" if re.search(r"max|min|length|size|range", rk) else "Negative"
                        rules.append((rk, cat, f"'{lab}': {r[:60]}"))
                        if msg:
                            messages.append((rk, msg))
                for rk, cat, what in rules:
                    rid = f"RULE:{sid}#{key}:{slug(rk, 24)}"
                    msg = next((m for k_, m in messages if k_ == rk.split("=")[0]), None)
                    add(rid, what=what, category=cat, rule=rk, message=msg, **base)
                if e.get("options") and len(e["options"]) >= 2:
                    add(f"OPT:{sid}#{key}", what=f"Options of '{lab}' ({len(e['options'])})", category="Data variation",
                        options=[str(o.get("text") or o.get("value")) for o in e["options"]][:40],
                        option_values=[str(o.get("value") or o.get("text")) for o in e["options"]][:40], **base)
            elif kind in ("button", "link", "tab"):
                add(f"ACT:{sid}#{key}", what=f"{TYPE_NAMES['ACT']} '{lab}'", category="Happy path", **base)
            if e.get("visible_when") and not re.match(r"(?i)^\s*!?\s*(this\.|\$ctrl\.|vm\.)?(is)?(loading|busy|pending|spinner|saving|submitting)\w*\s*$", e["visible_when"]):
                add(f"COND:{sid}#{key}:shown", what=f"'{lab}' is shown only when {e['visible_when'][:80]}", category="Conditional",
                    condition=e["visible_when"], cond_kind="shown", **base)
            if e.get("disabled_when") and not e.get("depends_on_role"):
                add(f"COND:{sid}#{key}:enabled", what=f"'{lab}' is disabled when {e['disabled_when'][:80]}", category="Conditional",
                    condition=e["disabled_when"], cond_kind="enabled", **base)
            if e.get("required_when"):
                add(f"COND:{sid}#{key}:required", what=f"'{lab}' is required when {e['required_when'][:80]}", category="Conditional",
                    condition=e["required_when"], cond_kind="required", **base)
            if e.get("depends_on_role"):
                add(f"ROLE:{sid}#{key}", what=f"'{lab}' depends on the user's role ({(e.get('disabled_when') or e.get('visible_when') or '')[:60]})",
                    category="Roles / security", **base)
        for a in s.get("apis", []):
            ep = a.get("endpoint") or f"{a['method']} {a['url']}"
            ep_screens[ep].add(sid)
            it = add(f"API:{ep}", area=area, screen=sid, what=f"{TYPE_NAMES['API']} {ep}", category="Happy path", endpoint=ep,
                     src_file=a.get("file"), src_line=a.get("line"), repo=s.get("repo"), triggers=[], on_load=False,
                     integrations=a.get("integrations") or [], calls=[])
            it["triggers"] = sorted(set(it["triggers"]) | set(a.get("triggered_by") or []))
            it["on_load"] = it["on_load"] or bool(a.get("on_load"))
            it["calls"].append({"screen": sid, "on_load": bool(a.get("on_load")), "triggered_by": a.get("triggered_by") or []})
            after = a.get("after") or {}
            for kind_, cat in (("success_messages", "Happy path"), ("error_messages", "Negative")):
                for m in after.get(kind_) or []:
                    add(f"MSG:{ep}:{slug(m, 40)}", area=area, screen=sid, what=f"Message '{m[:70]}'", category=cat, message=m,
                        endpoint=ep, src_file=a.get("file"), src_line=a.get("line"), repo=s.get("repo"), msg_kind=kind_)
            for sysname in a.get("integrations") or []:
                it_ = add(f"INT:{sysname}", area="Outside systems", what=f"{TYPE_NAMES['INT']} {sysname}", category="Integration",
                          system=sysname, endpoints=[], screens=[])
                if ep not in it_["endpoints"]:
                    it_["endpoints"].append(ep)
                if sid not in it_["screens"]:
                    it_["screens"].append(sid)
    for x in api.get("integrations") or []:
        it_ = add(f"INT:{x['system']}", area="Outside systems", what=f"{TYPE_NAMES['INT']} {x['system']}", category="Integration",
                  system=x["system"], endpoints=[], screens=[])
        it_.setdefault("src_file", x.get("file"))
        it_.setdefault("src_line", x.get("line"))
        it_.setdefault("repo", x.get("repo"))
        it_.setdefault("client", f"{x.get('kind')} in {x.get('class')}")
    for e in api.get("endpoints") or []:
        ep = f"{e['method']} {e['path']}"
        if ep not in ep_screens:
            add(f"API:{ep}", area="API only (no screen)", what=f"{TYPE_NAMES['API']} {ep} (no screen calls it)", category="Happy path",
                endpoint=ep, src_file=e.get("file"), src_line=e.get("line"), repo=e.get("repo"), api_only=True,
                integrations=e.get("integrations") or [], triggers=[], on_load=False, calls=[])
        for f_ in e.get("request_fields") or []:
            for r in f_.get("rules") or []:
                add(f"SRV:{ep}#{f_['field']}:{slug(r, 24)}", area=sorted(ep_screens.get(ep, {"API only (no screen)"}))[0],
                    what=f"Server check on '{f_['field']}': {r}", category="Boundary" if re.search(r"size|max|min|length|range|digits", r, re.I) else "Negative",
                    endpoint=ep, field=f_["field"], rule=r, src_file=e.get("request_body_file") or e.get("file"), src_line=f_.get("line"), repo=e.get("repo"))
    for c in biz.get("checks") or []:
        eps = c.get("endpoints") or []
        area = sorted({s_ for ep in eps for s_ in ep_screens.get(ep, ())} or {"Business rules"})[0]
        add(f"BR:{c.get('class')}.{c.get('method')}:{slug(c.get('message') or c.get('condition'), 40)}", area=area,
            what=f"Business rule: {c.get('message') or c.get('condition')}"[:140], category="Negative" if c.get("kind") != "status rule" else "Status flow",
            message=c.get("message"), condition=c.get("condition"), endpoints=eps, src_file=c.get("file"), src_line=c.get("line"), repo=c.get("repo"),
            rule=c.get("condition"))
    for r in biz.get("roles") or []:
        eps = r.get("endpoints") or []
        area = sorted({s_ for ep in eps for s_ in ep_screens.get(ep, ())} or {"Business rules"})[0]
        add(f"ROLE:{','.join(r.get('roles') or [])}@{r.get('class')}.{r.get('method')}", area=area,
            what=f"Only {', '.join(r.get('roles') or ['some roles'])} may {r.get('method')} ({', '.join(eps)[:60]})", category="Roles / security",
            endpoints=eps, src_file=r.get("file"), src_line=r.get("line"), repo=r.get("repo"), rule=r.get("rule"))
    for t in biz.get("transitions") or []:
        eps = t.get("endpoints") or []
        area = sorted({s_ for ep in eps for s_ in ep_screens.get(ep, ())} or {"Business rules"})[0]
        add(f"TRN:{t.get('class')}.{t.get('method')}:{slug(t.get('to'), 24)}", area=area,
            what=f"Status becomes {t.get('to')}" + (f" (only from {', '.join(t.get('statuses_checked_before') or [])})" if t.get("statuses_checked_before") else ""),
            category="Status flow", to=t.get("to"), endpoints=eps, src_file=t.get("file"), src_line=t.get("line"), repo=t.get("repo"))
    return items, screens


# ======================================================================== status per item
REQ_INTENT = re.compile(r"(?i)empty|blank|missing|required|mandatory|without")
FMT_INTENT = re.compile(r"(?i)invalid|format|pattern|wrong|special char|not valid|bad")


def rule_intent(it, h, tests):
    """Tests that really break this rule: an empty value (or a test about empty/required fields) for a required
    rule; an invalid value (or a test about invalid formats) for a pattern rule."""
    out = []
    for i, kinds in h:
        t = tests[i]
        vals = [v for (k_, tok), vs in t["set_values"].items() if ("any", tok.lower()) in (it.get("tokens") or []) for v in vs]
        if "required" in (it.get("rule") or ""):
            if any(v.strip() in ("", "${EMPTY}", "''", '""') for v in vals) or (t["negative"] and REQ_INTENT.search(t["test"])):
                out.append(i)
        elif t["negative"] and FMT_INTENT.search(t["test"]):
            out.append(i)
    return out


def build_status(items, screens, tests):
    tok_tests = defaultdict(list)                      # token -> [(test index, kinds)]
    text_tests = defaultdict(list)
    for i, ev in enumerate(tests):
        for (kind, tok), kinds in ev["touch"].items():
            if kind == "text":
                text_tests[norm(tok)].append((i, kinds))
            elif kind == "idpart":
                tok_tests[("idpart", tok.lower())].append((i, kinds))
            else:
                tok_tests[("any", tok.lower())].append((i, kinds))
                if kind == "model":
                    tok_tests[("any", tok.lower().split(".")[-1])].append((i, kinds))
    idparts = [(k[1], v) for k, v in tok_tests.items() if k[0] == "idpart"]

    def hits(it):
        """[(test index, kinds)] of tests acting on this element."""
        out = []
        for kind, tok in it.get("tokens") or []:
            if kind == "any":
                out += tok_tests.get(("any", tok), [])
                out += [h for part, hs in idparts if part and (tok.endswith(part.lower()) or part.lower() in tok) for h in hs]
            elif kind == "text":
                out += text_tests.get(tok, [])
        return out

    def asserted(msg):
        m = norm(msg)
        if len(m) < 5:
            return []
        return [i for i, ev in enumerate(tests) if any(m in a or (len(a) >= 8 and a in m) for a in ev["asserted"])]
    screen_of = {}
    for it in items.values():
        if it["type"] in ("FLD", "ACT", "COND", "ROLE", "RULE", "OPT") and it.get("screen"):
            it["_hits"] = hits(it)
            screen_of.setdefault(it["screen"], set()).update(i for i, _ in it["_hits"])
    for s in screens:
        sid = str(s.get("route") or s.get("id"))
        if s.get("route") and s["route"] not in ("/", "*"):
            rx = re.compile("^" + re.sub(r"\\\{[^}]+\\\}|\\:\w+|:\w+", "[^/]+", re.escape(s["route"]).replace("\\{", "{").replace("\\}", "}")) + "/?$")
            for i, ev in enumerate(tests):
                if any(rx.match(re.sub(r"\$\{[^}]+\}", "x", p)) for p in ev["nav"]):
                    screen_of.setdefault(sid, set()).add(i)

    def names(idx):
        idx = sorted(set(idx))
        return [f"{tests[i]['test']}" + (f" [{', '.join(tests[i]['ids'][:2])}]" if tests[i]["ids"] else "") for i in idx]

    def put(it, status, why, ev_idx=()):
        it["status"], it["why"], it["tests"] = status, why, names(ev_idx)
        it["_idx"] = set(ev_idx)

    def via(eps):
        """The tests that make these calls (for rules and messages behind them: the tests to run when they change)."""
        return set().union(*[by_ep[e].get("_idx", set()) for e in eps if e in by_ep]) if eps else set()
    for it in items.values():
        t = it["type"]
        h = it.get("_hits", [])
        kinds = set().union(*[k for _, k in h]) if h else set()
        who = [i for i, _ in h]
        if t == "SCR":
            reached = screen_of.get(it["screen"], set())
            own = [x for x in items.values() if x.get("screen") == it["screen"] and x["type"] in ("FLD", "ACT")]
            touched = [x for x in own if x.get("_hits")]
            if not reached:
                put(it, "Gap", "No test opens this screen or acts on any of its elements.")
            elif own and len(touched) < max(1, len(own) // 2):
                put(it, "Partial", f"Tests reach it, but act on only {len(touched)} of its {len(own)} fields and buttons.", reached)
            else:
                put(it, "Covered", f"Reached by {len(reached)} test(s)" + (f"; {len(touched)} of {len(own)} fields and buttons used." if own else "."), reached)
        elif t == "FLD":
            if "set" in kinds or (it.get("field_kind") == "checkbox" and "click" in kinds):
                put(it, "Covered", "A test enters or selects a value in it.", [i for i, k in h if "set" in k or "click" in k])
            elif kinds:
                put(it, "Partial", "Tests only look at it; no test enters a value.", who)
            else:
                put(it, "Gap", "No test uses this field.")
        elif t == "ACT":
            if "click" in kinds:
                put(it, "Covered", "A test clicks it.", [i for i, k in h if "click" in k])
            elif kinds:
                put(it, "Partial", "Tests only check it is there; no test clicks it.", who)
            else:
                put(it, "Gap", "No test uses this button or link.")
        elif t == "RULE":
            setters = [i for i, k in h if "set" in k or "click" in k]
            if it.get("message") and asserted(it["message"]):
                put(it, "Covered", f"A test checks the message '{it['message'][:60]}'.", asserted(it["message"]))
            elif it["category"] == "Boundary" and setters:
                lim = re.search(r"(\d+)", it.get("rule") or "")
                lens = [len(v) for i, _ in h for (k_, tok), vals in tests[i]["set_values"].items()
                        for v in vals if (("any", tok.lower()) in it["tokens"])]
                if lim and lens and max(lens) >= int(lim.group(1)):
                    put(it, "Covered", f"A test enters a value of the limit's length ({max(lens)} characters).", setters)
                else:
                    put(it, "Partial", "Tests fill the field, but none tries the limit or one past it.", setters)
            elif it["category"] == "Negative" and rule_intent(it, h, tests):
                put(it, "Covered", "A negative test breaks this rule on this field (" + ("empty value" if "required" in (it.get("rule") or "") else "invalid value") + ").",
                    rule_intent(it, h, tests))
            elif setters or h:
                put(it, "Partial", "Only the valid path is tested: no test breaks this rule" + (f" and checks '{it['message'][:50]}'." if it.get("message") else "."), who)
            else:
                put(it, "Gap", "No test uses this field.")
        elif t == "COND":
            shown = kinds & {"vis", "set", "click", "assert"}
            hidden = kinds & {"notvis"} if it.get("cond_kind") == "shown" else kinds & {"disabled"}
            if shown and hidden:
                put(it, "Covered", "Tests check both sides: when it applies and when it does not.", who)
            elif shown or hidden:
                put(it, "Partial", "Only one side is tested (" + ("shown / enabled" if shown else "hidden / disabled") + "); the other side is not checked.", who)
            else:
                put(it, "Gap", "No test checks this condition.")
        elif t == "ROLE" and it.get("screen"):
            users = {u for i in who for u in tests[i]["users"]}
            if who and (len(users) >= 2 or any(tests[i]["role_negative"] for i in who)):
                put(it, "Covered", "Tested with more than one user or with a user who lacks the right.", who)
            elif who:
                put(it, "Partial", "Tested with one user only: nobody checks what a user without the role sees.", who)
            else:
                put(it, "Gap", "No test uses it.")
        elif t == "OPT":
            vals = {norm(v) for i, k in h for (k_, tok), vs in tests[i]["set_values"].items() if ("any", tok.lower()) in it["tokens"] for v in vs}
            opts = [o for o in it["options"]]
            used = [o for o, v in zip(opts, it["option_values"]) if norm(o) in vals or norm(v) in vals]
            it["options_missing"] = [o for o in opts if o not in used]
            if used and not it["options_missing"]:
                put(it, "Covered", "Every option is used by some test.", who)
            elif used or h:
                put(it, "Partial", f"{len(used)} of {len(opts)} options are used.", who)
            else:
                put(it, "Gap", "No test selects any option.")
    by_ep = {}
    for it in items.values():
        if it["type"] == "API":
            if it.get("api_only"):
                put(it, "N/A", "No screen calls this endpoint: an API test is needed, not a UI test.")
                by_ep[it["endpoint"]] = it
                continue
            trig, reached = [], set()
            for c in it.get("calls", []):
                reached |= screen_of.get(c["screen"], set())
                for k in c["triggered_by"]:
                    a = items.get(f"ACT:{c['screen']}#{k}")
                    if a and a.get("status") == "Covered":
                        trig += [i for i, kk in a.get("_hits", []) if "click" in kk]
            if trig:
                put(it, "Covered", "A test clicks the button that makes this call.", trig)
            elif it.get("on_load") and reached:
                put(it, "Covered", "Called when the screen opens, and tests open it.", reached)
            elif reached:
                put(it, "Partial", "Tests reach the screen, but no test clicks what makes this call" + (
                    f" ({', '.join(it['triggers'][:3])})." if it.get("triggers") else "."), reached)
            else:
                put(it, "Gap", "No test reaches a screen that makes this call.")
            by_ep[it["endpoint"]] = it
    for it in items.values():
        if it["type"] == "MSG":
            a = asserted(it["message"])
            api = by_ep.get(it["endpoint"])
            if a:
                put(it, "Covered", "A test checks this message.", a)
            elif api and api.get("status") in ("Covered", "Partial"):
                put(it, "Partial", "The call is made by a test, but no test checks this message.", via([it["endpoint"]]))
            else:
                put(it, "Gap", "No test reaches this message.")
        elif it["type"] in ("BR", "TRN", "SRV") or (it["type"] == "ROLE" and not it.get("screen")):
            eps = it.get("endpoints") or ([it["endpoint"]] if it.get("endpoint") else [])
            st_ = [by_ep.get(e) for e in eps if by_ep.get(e)]
            a = asserted(it.get("message") or "") if it.get("message") else []
            if it["type"] == "TRN" and it.get("to"):
                a = asserted(str(it["to"]).replace("_", " "))
            if a:
                put(it, "Covered", "A test checks " + ("its message." if it["type"] != "TRN" else f"the new status {it.get('to')}."), a)
            elif any(x.get("status") == "Covered" for x in st_):
                put(it, "Partial", "Tests make the call, but only the allowed path: nobody checks what happens when this rule blocks it.", via(eps))
            elif all(x.get("api_only") for x in st_) and st_:
                put(it, "N/A", "Only reachable through an API with no screen: an API test is needed.")
            else:
                put(it, "Gap", "No test makes the call this rule protects.")
    for it in items.values():
        if it["type"] == "INT":
            eps = [by_ep.get(e) for e in it.get("endpoints", []) if by_ep.get(e)]
            cov = [e for e in eps if e.get("status") == "Covered"]
            outcome = [x for x in items.values() if x["type"] in ("MSG", "BR") and x.get("status") == "Covered" and
                       (x.get("endpoint") in it.get("endpoints", []) or set(x.get("endpoints") or []) & set(it.get("endpoints", [])))]
            failure = [x for x in outcome if x["category"] == "Negative"]
            it["failure_tested"] = bool(failure)
            users_ = via(it.get("endpoints", []))
            if cov and outcome:
                put(it, "Covered" if failure else "Partial",
                    "Tests reach it and check the outcome" + (" of success and of failure." if failure else
                                                             "; nobody tests what the screen does when this system fails or is slow."), users_)
            elif cov:
                put(it, "Partial", "Tests reach it, but none checks the outcome or what happens when it fails.", users_)
            elif eps:
                put(it, "Gap", "No test reaches a call that uses this system.")
            else:
                put(it, "Gap", "No screen call is linked to it (found in the code, used by background or API-only calls).")
    for it in items.values():
        it.pop("_hits", None)
        it.pop("_idx", None)
    return items


# ======================================================================== decisions, priority, suggested scenarios
def read_decisions(path):
    out = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                parts = [p.strip() for p in line.strip().strip("|").split("|")]
                if len(parts) >= 2 and ":" in parts[0] and parts[1] in STATUSES + ("N/A",):
                    out[parts[0]] = (parts[1], parts[2] if len(parts) > 2 else "")
    except OSError:
        pass
    return out


BASE = {"BR": 32, "ROLE": 32, "INT": 30, "TRN": 26, "SCR": 26, "API": 18, "RULE": 18, "SRV": 14, "COND": 16, "MSG": 14,
        "ACT": 12, "FLD": 12, "OPT": 6}


def churn(repo_path, since_days=180):
    counts = defaultdict(int)
    if not repo_path or not os.path.isdir(os.path.join(repo_path, ".git")):
        return counts
    try:
        total = subprocess.run(["git", "-C", repo_path, "rev-list", "--count", "HEAD"], capture_output=True, text=True, timeout=60).stdout.strip()
        if not total.isdigit() or int(total) <= 1:
            counts["__shallow__"] = 1                  # one commit only (a shallow clone): no change history to use
            return counts
    except Exception:
        return counts
    try:
        out = subprocess.run(["git", "-C", repo_path, "log", f"--since={since_days}.days", "--name-only", "--pretty=format:",
                              "--min-parents=1", "--max-parents=1"],      # real changes: no merges, not the first import
                             capture_output=True, text=True, timeout=60).stdout
    except Exception:
        return counts
    for line in out.splitlines():
        if line.strip():
            counts[line.strip()] += 1
    return counts


def prioritise(items, churns):
    for it in items.values():
        if it["status"] in ("Covered", "N/A"):
            it["priority"], it["score"], it["risk"] = "", 0, ""
            continue
        risky_side = it["type"] in ("INT", "BR", "ROLE", "TRN")      # their untested side is the one that hurts
        score = BASE.get(it["type"], 10) * (1.0 if it["status"] == "Gap" else 0.8 if risky_side else 0.55)
        why = [f"{TYPE_NAMES.get(it['type'], it['type']).lower()} {it['status'].lower()}"]
        c = churns.get(it.get("repo"), {}).get(it.get("src_file"), 0)
        if c:
            score += min(20, 4 * c)
            why.append(f"code changed {c} time(s) in 180 days")
        if it.get("sensitive"):
            score += 8
            why.append("money or personal data")
        if it.get("integrations") or it["type"] == "INT":
            score += 6
            if it["type"] != "INT":
                why.append("uses " + ", ".join(it.get("integrations") or []))
        if it["type"] == "SCR":
            n_int = len([x for x in items.values() if x["type"] == "API" and x.get("screen") == it["screen"] and x.get("integrations")])
            if n_int:
                score += 4 * n_int
                why.append(f"{n_int} call(s) to outside systems")
        it["score"] = round(score, 1)
        it["priority"] = "P1" if score >= 30 else "P2" if score >= 18 else "P3"
        it["risk"] = "; ".join(why)


def scenario(it):
    lab = it.get("label") or ""
    scr = it.get("screen") or it.get("area")
    t = it["type"]
    if t == "SCR":
        return f"Open {scr} and complete its main task end to end, checking the result."
    if t == "FLD":
        return f"On {scr}, enter a valid value in '{lab}', save, and check it is kept."
    if t == "ACT":
        return f"On {scr}, use '{lab}' and check what it leads to."
    if t == "RULE":
        r = it.get("rule") or ""
        if it["category"] == "Boundary":
            n = re.search(r"(\d+)", r)
            n = int(n.group(1)) if n else None
            if n and re.search(r"max", r, re.I):
                return f"On {scr}, enter {n} characters in '{lab}' (accepted), then {n + 1} (rejected or cut to {n})" + (f"; expect '{it['message']}'." if it.get("message") else ".")
            if n and re.search(r"min", r, re.I):
                return f"On {scr}, enter {max(0, n - 1)} characters in '{lab}' (rejected) and {n} (accepted)" + (f"; expect '{it['message']}'." if it.get("message") else ".")
            return f"On {scr}, try the limits of '{lab}' ({r})."
        if "required" in r:
            return f"On {scr}, leave '{lab}' empty and save; expect " + (f"'{it['message']}'." if it.get("message") else "the field to be marked as required and nothing saved.")
        return f"On {scr}, enter a value in '{lab}' that breaks the rule ({r}); expect " + (f"'{it['message']}'." if it.get("message") else "an error and nothing saved.")
    if t == "COND":
        c = it.get("condition") or ""
        if it.get("cond_kind") == "shown":
            return f"On {scr}: make '{c}' true and check '{lab}' appears; make it false and check '{lab}' is not shown."
        if it.get("cond_kind") == "enabled":
            return f"On {scr}: make '{c}' true and check '{lab}' is disabled; otherwise it is enabled and works."
        return f"On {scr}: make '{c}' true and check '{lab}' becomes required; otherwise it is optional."
    if t == "ROLE":
        return f"Log in as a user without the right ({it.get('rule') or it['what']}) and check the action is not allowed; then as a user with it."
    if t == "API":
        if it.get("api_only"):
            return f"API test (no screen): call {it['endpoint']} and check the answer, including an invalid request."
        return f"Use the screen action that calls {it['endpoint']} and check its result" + (f" ({', '.join(it['triggers'][:2])})." if it.get("triggers") else ".")
    if t == "MSG":
        return ("Make the call fail (" + it["endpoint"] + ") and check the message '" + it["message"] + "'.") if it["category"] == "Negative" \
            else f"Complete the action ({it['endpoint']}) and check the message '{it['message']}'."
    if t == "BR":
        return f"Make this true: {it.get('condition') or '(see the rule)'}; try the action ({', '.join(it.get('endpoints') or [])[:60]}) and expect '{it.get('message')}'."
    if t == "TRN":
        return f"Move a record to {it.get('to')} the allowed way and check the new status; try it from a status that is not allowed and expect it to be refused."
    if t == "SRV":
        return f"Send a value for '{it.get('field')}' that breaks '{it.get('rule')}' through the screen or API ({it.get('endpoint')}); expect it to be refused."
    if t == "INT":
        return (f"{it['system']} answers: the action succeeds and the screen shows the success result. {it['system']} fails or is slow: "
                f"the screen shows a clear error and nothing half-saved (needs a test double or a test-environment switch for {it['system']}).")
    if t == "OPT":
        return f"On {scr}, select each option of '{lab}' not tested yet: {', '.join(it.get('options_missing', [])[:8])}."
    return it["what"]


# ======================================================================== outputs
def summary_counts(items):
    real = [i for i in items.values() if i["status"] != "N/A"]
    c = {s: sum(1 for i in real if i["status"] == s) for s in STATUSES}
    pct = round(100.0 * (c["Covered"] + 0.5 * c["Partial"]) / max(1, len(real)), 1)
    return c, pct, len(real)


def area_table(items):
    rows = defaultdict(lambda: {s: 0 for s in STATUSES})
    for it in items.values():
        if it["status"] != "N/A":
            rows[it["area"] or "-"][it["status"]] += 1
    out = []
    for a, c in rows.items():
        n = sum(c.values())
        out.append((a, n, c["Covered"], c["Partial"], c["Gap"], round(100.0 * (c["Covered"] + 0.5 * c["Partial"]) / max(1, n), 1)))
    return sorted(out, key=lambda r: (r[5], -r[1]))


def write_csv(items, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["ID", "Area", "Type", "Item", "Category", "Status", "Priority", "Why", "Tests (evidence)", "Suggested scenario",
                    "Risk", "Source", "Decision"])
        for it in sorted(items.values(), key=lambda i: (i["area"], i["type"], i["id"])):
            w.writerow([it["id"], it["area"], TYPE_NAMES.get(it["type"], it["type"]), it["what"], it["category"], it["status"],
                        it.get("priority", ""), it["why"], "; ".join(it["tests"][:10]) + (f" (+{len(it['tests']) - 10})" if len(it["tests"]) > 10 else ""),
                        it.get("scenario", ""), it.get("risk", ""), f"{it.get('repo') or ''}/{it.get('src_file') or ''}:{it.get('src_line') or ''}".strip("/:"),
                        it.get("decision", "")])


def md_escape(s):
    return str(s).replace("|", "/").replace("\n", " ")


def write_map(items, meta, path, trend):
    c, pct, n = summary_counts(items)
    na = sum(1 for i in items.values() if i["status"] == "N/A")
    gaps = sorted([i for i in items.values() if i["status"] in ("Gap", "Partial")], key=lambda i: (-i["score"], i["id"]))
    p = {k: sum(1 for i in gaps if i["priority"] == k) for k in ("P1", "P2", "P3")}
    out = [f"# Automation coverage map", "",
           f"Built {meta['built']} from {meta['tests']} automated tests and the development code ({meta['dev_repos']}). "
           "Every number below comes from evidence: what the tests really do, matched to what the code really contains.", "",
           "## At a glance", "",
           f"- **Coverage: {pct}%** of {n} testable items (Covered counts 1, Partial counts half).",
           f"- **Covered {c['Covered']}**, **Partial {c['Partial']}**, **Gap {c['Gap']}**" + (f"; {na} need API tests instead of UI tests." if na else "."),
           f"- **Gaps by priority:** P1 {p['P1']}, P2 {p['P2']}, P3 {p['P3']}."]
    if trend:
        out.append(f"- **Since the last build ({trend['since']}):** coverage {trend['pct_before']}% -> {pct}%; "
                   f"{trend['newly_covered']} item(s) newly covered, {trend['new_items']} new item(s) in the code, "
                   f"{trend['changed_items']} changed, {trend['removed_items']} removed.")
    ints = [i for i in items.values() if i["type"] == "INT"]
    if ints:
        out.append(f"- **Outside systems:** {', '.join(f'{i['system']} ({i['status']})' for i in sorted(ints, key=lambda i: i['system']))}.")
    out += ["", "## Coverage by kind of check", "", "| Kind | Items | Covered | Partial | Gap |", "|---|---|---|---|---|"]
    for cat in CATEGORIES:
        xs = [i for i in items.values() if i["category"] == cat and i["status"] != "N/A"]
        if xs:
            out.append(f"| {cat} | {len(xs)} | {sum(1 for i in xs if i['status'] == 'Covered')} | {sum(1 for i in xs if i['status'] == 'Partial')} | "
                       f"{sum(1 for i in xs if i['status'] == 'Gap')} |")
    out += ["", "## Coverage by area (lowest first)", "", "| Area | Items | Covered | Partial | Gap | Coverage |", "|---|---|---|---|---|---|"]
    for a, n_, cv, pa, ga, pc in area_table(items):
        out.append(f"| {md_escape(a)} | {n_} | {cv} | {pa} | {ga} | {pc}% |")
    out += ["", "## Top gaps to automate next", "", "| # | Priority | Item | Area | Why it matters | Suggested test |", "|---|---|---|---|---|---|"]
    for k, it in enumerate(gaps[:25], 1):
        out.append(f"| {k} | {it['priority']} | {md_escape(it['what'])} ({it['status']}) | {md_escape(it['area'])} | {md_escape(it['risk'])} | {md_escape(it['scenario'])} |")
    if meta.get("manual"):
        m = meta["manual"]
        out += ["", "## Manual test cases and automation", "",
                f"{m['total']} manual test case(s) read; {m['automated']} have an automated test (matched by ID or title); "
                f"{m['total'] - m['automated']} are not automated yet. See gaps.md for the list."]
    out += ["", "## How to read this", "",
            "- **Covered:** a test exercises the item the way it matters (enters a value, clicks, breaks the rule and checks the message, checks both sides of a condition).",
            "- **Partial:** a test touches the item, but only the easy path (for example a field is filled, but no test leaves it empty).",
            "- **Gap:** no automated test touches it.",
            "- Priority comes from the kind of item (business and role rules, outside systems and unreached screens first), money or personal-data fields, and how often its code changed recently.",
            "- Files: gaps.md (every gap with a suggested test), coverage-matrix.csv (all items, for Excel), coverage.html (interactive), "
            "gap-test-cases.md (the top gaps as test cases the script generator can automate).",
            *(["- Change history was not used for " + ", ".join(meta["shallow"]) + ": the clone has one commit only. "
                "Clone it with history (or `git fetch --unshallow`) for change-based priority and regression analysis."] if meta.get("shallow") else []),
            "- Limits: items come from what the code shows statically (screens built entirely at run time, or rules only in a database, are not seen); "
            "evidence comes from locators and checked texts, so a test that acts through generic XPath without ids or texts may be under-counted. "
            "Corrections go in decisions.md and are kept on every rebuild."]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")


def write_gaps(items, meta, path):
    gaps = [i for i in items.values() if i["status"] in ("Gap", "Partial")]
    out = ["# Coverage gaps", "", f"{len(gaps)} item(s) are not fully covered, grouped by the kind of test that is missing, highest priority first.", ""]
    for cat in CATEGORIES:
        xs = sorted([i for i in gaps if i["category"] == cat], key=lambda i: (-i["score"], i["id"]))
        if not xs:
            continue
        out += [f"## {cat} ({len(xs)})", "", "| Priority | ID | Item | Status | Why | Suggested test | Source |", "|---|---|---|---|---|---|---|"]
        for it in xs:
            out.append(f"| {it['priority']} | `{it['id']}` | {md_escape(it['what'])} | {it['status']} | {md_escape(it['why'])} | {md_escape(it['scenario'])} | "
                       f"{md_escape((it.get('src_file') or '') + (':' + str(it['src_line']) if it.get('src_line') else ''))} |")
        out.append("")
    na = [i for i in items.values() if i["status"] == "N/A"]
    if na:
        out += [f"## Needs API tests, not UI tests ({len(na)})", ""] + [f"- `{i['id']}`: {i['why']}" for i in sorted(na, key=lambda i: i["id"])] + [""]
    m = meta.get("manual")
    if m and m["not_automated"]:
        out += [f"## Manual test cases not automated yet ({len(m['not_automated'])})", "", "| Test case | File | Dev items it would cover |", "|---|---|---|"]
        for r in m["not_automated"]:
            out.append(f"| {md_escape(r['label'])} | {md_escape(r['file'])} | {md_escape(', '.join(r['items'][:6]) or '-')} |")
        out.append("")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")


def write_gap_cases(items, path, top):
    gaps = sorted([i for i in items.values() if i["status"] in ("Gap", "Partial") and not i.get("api_only")], key=lambda i: (-i["score"], i["id"]))[:top]
    out = ["# Test cases for the top coverage gaps", "",
           "Written from the coverage analysis (coverage.py). Each test case closes one gap; read and adjust them, then ask the script generator to automate them.",
           "", "## Test case index", "", "| ID | Title |", "|---|---|"]
    for k, it in enumerate(gaps, 1):
        out.append(f"| GAP-{k:03d} | {md_escape(it['what'])} |")
    out.append("")
    for k, it in enumerate(gaps, 1):
        sc = it["scenario"]
        steps = [s.strip() for s in re.split(r"(?<=[.;])\s+(?=[A-Z])|;\s+", sc) if s.strip()]
        out += [f"### GAP-{k:03d}: {it['what']}", f"**Priority:** {it['priority']}", f"**Covers:** `{it['id']}` ({it['category']})",
                f"**Source:** {it.get('src_file') or '-'}" + (f":{it['src_line']}" if it.get("src_line") else ""), "", "**Steps:**"]
        if it.get("screen"):
            out.append(f"1. Open the screen {it['screen']}.")
        for s in steps:
            exp = ""
            m = re.search(r"(?i)(?:;?\s*(?:expect|check)\s+)(.+)$", s)
            if m:
                exp, s = m.group(1).rstrip("."), s[:m.start()].rstrip(" ;,")
            n = len([l for l in out[-12:] if re.match(r"^\d+\.", l)]) + 1
            out.append(f"{n}. {s.rstrip('.')}." if s else f"{n}. Do the action.")
            if exp:
                out.append(f"   - Expected: {exp}.")
        out.append("")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    return len(gaps)


HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Automation Coverage</title><style>
:root{--bg:#f7f7f5;--card:#fff;--ink:#1d1d1b;--mute:#6b6b66;--line:#e4e3de;--cov:#2f7d4f;--par:#c48a12;--gap:#c0392b;--na:#8a8a85;--acc:#2b5fb4}
@media (prefers-color-scheme:dark){:root{--bg:#161615;--card:#1f1f1e;--ink:#ecebe6;--mute:#a3a29c;--line:#34332f;--cov:#4fae78;--par:#e0aa3a;--gap:#e5645a;--na:#8a8a85;--acc:#7aa5ee}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
main{max-width:1180px;margin:0 auto;padding:20px 16px 60px}h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:28px 0 10px}
.mute{color:var(--mute)}.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:16px 0}
.tile{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}.tile b{display:block;font-size:24px}
.bar{display:flex;height:10px;border-radius:5px;overflow:hidden;background:var(--line);min-width:120px}.bar i{display:block}
.c{background:var(--cov)}.p{background:var(--par)}.g{background:var(--gap)}table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:7px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{font-size:12px;color:var(--mute);font-weight:600;background:var(--card);position:sticky;top:0}
.pill{display:inline-block;padding:1px 8px;border-radius:9px;font-size:12px;color:#fff}.pill.Covered{background:var(--cov)}.pill.Partial{background:var(--par)}.pill.Gap{background:var(--gap)}.pill.NA{background:var(--na)}
.pr{font-weight:700}.P1{color:var(--gap)}.P2{color:var(--par)}.P3{color:var(--mute)}.filters{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
select,input{background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:7px;padding:6px 8px;font:inherit}input{flex:1;min-width:160px}
.wrap{overflow-x:auto}.small{font-size:12px}code{font-size:12px}.tabs button{background:var(--card);border:1px solid var(--line);color:var(--ink);border-radius:7px;padding:5px 10px;margin:0 6px 6px 0;cursor:pointer}
.tabs button.on{border-color:var(--acc);color:var(--acc)}details{margin:6px 0}
</style></head><body><main>
<h1>Automation coverage</h1><div class="mute" id="meta"></div>
<div class="tiles" id="tiles"></div>
<h2>Coverage by area</h2><div class="wrap"><table id="areas"><thead><tr><th>Area</th><th>Items</th><th>Covered</th><th>Partial</th><th>Gap</th><th style="width:30%">Coverage</th></tr></thead><tbody></tbody></table></div>
<h2>Gaps to automate next</h2><div class="tabs" id="cats"></div><div class="wrap"><table id="gaps"><thead><tr><th>Priority</th><th>Item</th><th>Area</th><th>Why</th><th>Suggested test</th></tr></thead><tbody></tbody></table></div>
<div id="regr"></div>
<h2>All items</h2><div class="filters"><input id="q" placeholder="Search items, areas, tests"><select id="fs"><option value="">Any status</option><option>Covered</option><option>Partial</option><option>Gap</option><option>N/A</option></select><select id="ft"><option value="">Any type</option></select><select id="fa"><option value="">Any area</option></select></div>
<div class="wrap"><table id="all"><thead><tr><th>Status</th><th>Item</th><th>Area</th><th>Why</th><th>Tests</th><th>Source</th></tr></thead><tbody></tbody></table></div>
<p class="small mute" id="more"></p>
<script id="data" type="application/json">__DATA__</script>
<script>
const D=JSON.parse(document.getElementById('data').textContent);const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const pill=s=>`<span class="pill ${s==='N/A'?'NA':s}">${s}</span>`;
$('#meta').textContent=D.meta.line;
$('#tiles').innerHTML=D.tiles.map(t=>`<div class="tile"><span class="mute small">${esc(t[0])}</span><b>${esc(t[1])}</b><span class="small mute">${esc(t[2]||'')}</span></div>`).join('');
$('#areas tbody').innerHTML=D.areas.map(a=>`<tr><td>${esc(a[0])}</td><td>${a[1]}</td><td>${a[2]}</td><td>${a[3]}</td><td>${a[4]}</td><td><div style="display:flex;gap:8px;align-items:center"><div class="bar" style="flex:1"><i class="c" style="width:${100*a[2]/a[1]}%"></i><i class="p" style="width:${100*a[3]/a[1]}%"></i><i class="g" style="width:${100*a[4]/a[1]}%"></i></div><span class="small">${a[5]}%</span></div></td></tr>`).join('');
const gaps=D.items.filter(i=>i.status==='Gap'||i.status==='Partial').sort((a,b)=>b.score-a.score);
const cats=['All'].concat([...new Set(gaps.map(g=>g.category))]);let cat='All';
function drawGaps(){const rows=gaps.filter(g=>cat==='All'||g.category===cat).slice(0,60);
$('#gaps tbody').innerHTML=rows.map(g=>`<tr><td class="pr ${g.priority}">${g.priority}</td><td>${esc(g.what)} ${pill(g.status)}<div class="small mute"><code>${esc(g.id)}</code></div></td><td>${esc(g.area)}</td><td class="small">${esc(g.risk)}<br>${esc(g.why)}</td><td class="small">${esc(g.scenario)}</td></tr>`).join('');
$('#cats').innerHTML=cats.map(c=>`<button class="${c===cat?'on':''}" data-c="${esc(c)}">${esc(c)} (${c==='All'?gaps.length:gaps.filter(g=>g.category===c).length})</button>`).join('');
document.querySelectorAll('#cats button').forEach(b=>b.onclick=()=>{cat=b.dataset.c;drawGaps()});}
drawGaps();
const types=[...new Set(D.items.map(i=>i.type_name))].sort(),areas=[...new Set(D.items.map(i=>i.area))].sort();
$('#ft').innerHTML+=types.map(t=>`<option>${esc(t)}</option>`).join('');$('#fa').innerHTML+=areas.map(t=>`<option>${esc(t)}</option>`).join('');
let shown=200;function drawAll(){const q=$('#q').value.toLowerCase(),s=$('#fs').value,t=$('#ft').value,a=$('#fa').value;
const rows=D.items.filter(i=>(!s||i.status===s)&&(!t||i.type_name===t)&&(!a||i.area===a)&&(!q||(i.what+' '+i.area+' '+i.id+' '+i.tests.join(' ')).toLowerCase().includes(q)));
$('#all tbody').innerHTML=rows.slice(0,shown).map(i=>`<tr><td>${pill(i.status)}${i.decision?'<div class="small mute">decision</div>':''}</td><td>${esc(i.what)}<div class="small mute"><code>${esc(i.id)}</code></div></td><td>${esc(i.area)}</td><td class="small">${esc(i.why)}</td><td class="small">${i.tests.slice(0,4).map(esc).join('<br>')}${i.tests.length>4?'<br>+'+(i.tests.length-4):''}</td><td class="small"><code>${esc(i.src)}</code></td></tr>`).join('');
$('#more').innerHTML=rows.length>shown?`Showing ${shown} of ${rows.length}. <a href="#" id="mm">Show more</a>`:`${rows.length} item(s).`;const mm=$('#mm');if(mm)mm.onclick=e=>{e.preventDefault();shown+=400;drawAll()};}
['#q','#fs','#ft','#fa'].forEach(s=>$(s).addEventListener('input',()=>{shown=200;drawAll()}));drawAll();
if(D.regression){const r=D.regression;$('#regr').innerHTML=`<h2>Regression: ${esc(r.range)}</h2><div class="tiles">${r.tiles.map(t=>`<div class="tile"><span class="mute small">${esc(t[0])}</span><b>${esc(t[1])}</b></div>`).join('')}</div>
<details open><summary>Changed items without full coverage (${r.gaps.length})</summary><div class="wrap"><table><thead><tr><th>Priority</th><th>Item</th><th>Status</th><th>Suggested test</th></tr></thead><tbody>${r.gaps.map(g=>`<tr><td class="pr ${g.priority}">${g.priority}</td><td>${esc(g.what)}<div class="small mute"><code>${esc(g.id)}</code></div></td><td>${pill(g.status)}</td><td class="small">${esc(g.scenario)}</td></tr>`).join('')}</tbody></table></div></details>
<details><summary>Tests to run for this change (${r.tests.length})</summary><p class="small">${r.tests.map(esc).join('<br>')}</p></details>`;}
</script></main></body></html>"""


def write_html(items, meta, path, regression=None):
    c, pct, n = summary_counts(items)
    gaps = [i for i in items.values() if i["status"] in ("Gap", "Partial")]
    ints = [i for i in items.values() if i["type"] == "INT"]
    tiles = [("Coverage", f"{pct}%", f"{n} testable items"), ("Covered", c["Covered"], ""), ("Partial", c["Partial"], ""), ("Gap", c["Gap"], ""),
             ("P1 gaps", sum(1 for i in gaps if i["priority"] == "P1"), "fix first"),
             ("Outside systems covered", f"{sum(1 for i in ints if i['status'] == 'Covered')}/{len(ints)}", ", ".join(i["system"] for i in ints)[:60])]
    data = {"meta": {"line": f"Built {meta['built']} from {meta['tests']} automated tests and {meta['dev_repos']}. Coverage = Covered + half of Partial."},
            "tiles": tiles, "areas": area_table(items),
            "items": [{"id": i["id"], "what": i["what"], "area": i["area"], "type_name": TYPE_NAMES.get(i["type"], i["type"]), "category": i["category"],
                       "status": i["status"], "priority": i.get("priority", ""), "score": i.get("score", 0), "why": i["why"], "risk": i.get("risk", ""),
                       "scenario": i.get("scenario", ""), "tests": i["tests"][:20], "decision": bool(i.get("decision")),
                       "src": f"{i.get('src_file') or ''}" + (f":{i['src_line']}" if i.get("src_line") else "")}
                      for i in sorted(items.values(), key=lambda i: ({"Gap": 0, "Partial": 1, "Covered": 2, "N/A": 3}[i["status"]], -i.get("score", 0), i["id"]))],
            "regression": regression}
    text = HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


# ======================================================================== manual test cases
def manual_cases(paths, tests, items):
    sys.path.insert(0, os.path.join(os.path.dirname(HERE), "test-cases"))
    try:
        import tc_reader
    except Exception:
        return None
    files = []
    for p in paths:
        if os.path.isdir(p):
            for dp, _, fns in os.walk(p):
                files += [os.path.join(dp, f) for f in fns if f.lower().endswith((".md", ".csv"))]
        elif os.path.isfile(p):
            files.append(p)
    auto_ids = {str(x).upper() for t in tests for x in t["ids"]}
    auto_titles = {norm(t["test"]) for t in tests}
    labels = {}
    for it in items.values():
        if it["type"] in ("FLD", "ACT", "SCR") and it.get("label") and len(norm(it["label"])) >= 4:
            labels.setdefault(norm(it["label"]), []).append(it["id"])
    res = {"total": 0, "automated": 0, "not_automated": []}
    for f in files:
        try:
            idx = tc_reader.get_index(f)[0]
        except Exception:
            continue
        for t in idx.get("tests", []):
            res["total"] += 1
            tid, title = (t.get("id") or "").upper(), norm(t.get("title"))
            if (tid and tid in auto_ids) or (title and any(title in a or a in title for a in auto_titles if len(a) >= 8)):
                res["automated"] += 1
                continue
            text = norm(" ".join([t.get("title") or ""] + [s.get("text", "") + " " + s.get("expected", "") for s in t.get("steps", [])]))
            hit = sorted({i for lab, ids in labels.items() if re.search(r"\b" + re.escape(lab) + r"\b", text) for i in ids})
            res["not_automated"].append({"label": f"{t.get('id') or ''} {t.get('title') or ''}".strip(), "file": os.path.relpath(f), "items": hit})
    return res


# ======================================================================== build
def paths(root="."):
    k = os.path.join(ai_home(root), "knowledge")
    return {"k": k, "x": os.path.join(k, ".extract"), "dev": os.path.join(k, ".extract", "dev"), "out": os.path.join(k, "coverage")}


def analyse(root=".", cases=None):
    p = paths(root)
    if not os.path.isfile(os.path.join(p["dev"], "dev-screens.json")):
        raise SystemExit("No development knowledge yet (knowledge/.extract/dev). Build it first: @qa-knowledge-setup with the development repo.")
    if not os.path.isfile(os.path.join(p["x"], "tests.json")):
        raise SystemExit("No QA extract yet (knowledge/.extract/tests.json). Run the knowledge setup first.")
    ev = Evidence(p["x"])
    tests = ev.per_test()
    items, screens = build_items(p["dev"])
    build_status(items, screens, tests)
    decisions = read_decisions(os.path.join(p["out"], "decisions.md"))
    for iid, (st_, why) in decisions.items():
        if iid in items:
            items[iid]["status"], items[iid]["decision"] = st_, why or "decided by a person"
            items[iid]["why"] = f"Decision: {why}" if why else "Decision recorded in decisions.md"
    summ = jload(os.path.join(p["dev"], "dev-summary.json"), {})
    repos = {}
    for r in summ.get("repos", []):
        for cand in (r.get("path"), os.path.join(root, r.get("path") or "")):
            if cand and os.path.isdir(cand):
                repos[r["path"]] = cand
                break
    churns = {k: churn(v) for k, v in repos.items()}
    shallow = sorted(os.path.basename(k.rstrip("/")) for k, v in churns.items() if v.get("__shallow__"))
    prioritise(items, churns)
    for it in items.values():
        it["scenario"] = scenario(it) if it["status"] in ("Gap", "Partial", "N/A") else ""
    meta = {"built": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "tests": len(tests),
            "dev_repos": ", ".join(sorted({os.path.basename(str(r.get("path") or "").rstrip("/")) for r in summ.get("repos", [])})) or "the development repos"}
    if shallow:
        meta["shallow"] = shallow
    if cases:
        meta["manual"] = manual_cases(cases, tests, items)
    return items, tests, meta, repos


def trend_of(prev, items, pct):
    if not prev:
        return None
    old = {i["id"]: i for i in prev.get("items", [])}
    return {"since": prev.get("built", "?"), "pct_before": prev.get("pct", "?"),
            "newly_covered": sum(1 for i in items.values() if i["status"] == "Covered" and old.get(i["id"], {}).get("status") not in (None, "Covered")),
            "new_items": sum(1 for i in items.values() if i["id"] not in old),
            "changed_items": sum(1 for i in items.values() if i["id"] in old and old[i["id"]].get("fingerprint") != i["fingerprint"]),
            "removed_items": sum(1 for k in old if k not in items)}


def cmd_build(a, root="."):
    items, tests, meta, _ = analyse(root, a.cases)
    p = paths(root)
    os.makedirs(p["out"], exist_ok=True)
    prev = jload(os.path.join(p["out"], "coverage.json"), None)
    c, pct, n = summary_counts(items)
    trend = trend_of(prev, items, pct)
    write_map(items, meta, os.path.join(p["out"], "coverage-map.md"), trend)
    write_gaps(items, meta, os.path.join(p["out"], "gaps.md"))
    write_csv(items, os.path.join(p["out"], "coverage-matrix.csv"))
    k = write_gap_cases(items, os.path.join(p["out"], "gap-test-cases.md"), a.top)
    write_html(items, meta, os.path.join(p["out"], "coverage.html"))
    if not os.path.isfile(os.path.join(p["out"], "decisions.md")):
        with open(os.path.join(p["out"], "decisions.md"), "w", encoding="utf-8") as fh:
            fh.write("# Coverage decisions\n\nOne line per item checked by hand; these win over the computed status on every build.\n"
                     "Format: `<item ID> | <Covered|Partial|Gap|N/A> | <reason, with the test or evidence>`\n\n")
    with open(os.path.join(p["out"], "coverage.json"), "w", encoding="utf-8") as fh:
        json.dump({"built": meta["built"], "pct": pct, "counts": c, "items": sorted(items.values(), key=lambda i: i["id"])}, fh, indent=1, default=list)
    gaps = [i for i in items.values() if i["status"] in ("Gap", "Partial")]
    print(f"Coverage {pct}% of {n} items: Covered {c['Covered']}, Partial {c['Partial']}, Gap {c['Gap']}; "
          f"gaps P1 {sum(1 for i in gaps if i['priority'] == 'P1')}, P2 {sum(1 for i in gaps if i['priority'] == 'P2')}, "
          f"P3 {sum(1 for i in gaps if i['priority'] == 'P3')}" + (f"; since last build {trend['pct_before']}% -> {pct}%" if trend else "") + ".")
    if meta.get("manual"):
        m = meta["manual"]
        print(f"Manual test cases: {m['total']}, automated {m['automated']}, not automated {m['total'] - m['automated']}.")
    print(f"Written to {os.path.relpath(p['out'])}: coverage-map.md, gaps.md, coverage-matrix.csv, coverage.html, gap-test-cases.md ({k} test cases), coverage.json")


# ======================================================================== regression gap analysis
def changed_lines(repo, base, head):
    """{file: [(start, end)]} of lines changed between base and head (head lines), plus deleted files."""
    def git(*args):
        return subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True, timeout=120)
    for ref in (base, head):
        if git("rev-parse", "--verify", "--quiet", ref + "^{commit}").returncode != 0:
            raise SystemExit(f"{repo}: '{ref}' is not in this clone. Fetch it first (read-only for the source): "
                             f"git -C {repo} fetch --depth=500 origin {ref}   (or --unshallow)")
    out = git("diff", "--unified=0", "--no-color", "-M", f"{base}..{head}").stdout
    files, cur = defaultdict(list), None
    for line in out.splitlines():
        if line.startswith("+++ "):
            cur = None if line[4:] == "/dev/null" else re.sub(r"^b/", "", line[4:])
        elif line.startswith("--- ") and line[4:] != "/dev/null":
            files.setdefault(re.sub(r"^a/", "", line[4:]), [])
        elif line.startswith("@@") and cur:
            m = re.search(r"\+(\d+)(?:,(\d+))?", line)
            st_, n_ = int(m.group(1)), int(m.group(2) or 1)
            files[cur].append((st_, st_ + max(n_, 1) - 1))
    return files


def cmd_regression(a, root="."):
    items, tests, meta, repos = analyse(root, None)
    if not repos:
        raise SystemExit("No development repo found on disk for the regression analysis (see dev-summary.json paths).")
    impacted = {}
    for rp, path in repos.items():
        ch = changed_lines(path, a.base, a.head)
        for it in items.values():
            if it.get("repo") != rp or not it.get("src_file"):
                continue
            f = it["src_file"]
            if f not in ch:
                continue
            ranges = ch[f]
            line = it.get("src_line") or 0
            near = (not ranges) or any(s - 3 <= line <= e + 3 for s, e in ranges) or it["type"] in ("SCR", "INT")
            if near:
                impacted[it["id"]] = it
        for it in items.values():                  # screens whose own files changed, outside systems whose clients changed
            if it["type"] == "SCR" and it.get("repo") == rp and any(f in ch for f in it.get("files") or []):
                impacted[it["id"]] = it
        for it in list(impacted.values()):
            if it["type"] == "INT":
                for x in items.values():
                    if x["type"] == "API" and it["system"] in (x.get("integrations") or []):
                        impacted[x["id"]] = x
    imp = sorted(impacted.values(), key=lambda i: (-i.get("score", 0), i["id"]))
    run = sorted({t for i in imp for t in i["tests"]})
    reached = sorted({t for i in imp if i["type"] == "SCR" for t in i["tests"]})
    gaps = [i for i in imp if i["status"] in ("Gap", "Partial")]
    rng = f"{a.base}..{a.head}"
    p = paths(root)
    os.makedirs(p["out"], exist_ok=True)
    name = f"regression-{slug(a.base, 30)}-{slug(a.head, 30)}"
    out = [f"# Regression gap analysis: {rng}", "",
           f"The change touches {len(imp)} item(s) the development knowledge knows. {len(imp) - len(gaps)} are covered by existing tests; "
           f"**{len(gaps)} are not fully covered** (regression gaps).", "",
           "## Tests to run for this change", "",
           (f"{len(run)} test(s) exercise the changed items:" if run else "No existing test exercises the changed items.")]
    out += [f"- {t}" for t in run]
    if reached and set(reached) - set(run):
        out += ["", "Also reaching the changed screens:"] + [f"- {t}" for t in sorted(set(reached) - set(run))]
    out += ["", "## Regression gaps (changed and not fully covered)", "", "| Priority | ID | Item | Status | Suggested test |", "|---|---|---|---|---|"]
    for i in sorted(gaps, key=lambda i: (-i["score"], i["id"])):
        out.append(f"| {i['priority']} | `{i['id']}` | {md_escape(i['what'])} | {i['status']} | {md_escape(i['scenario'])} |")
    out += ["", "## Changed and covered", ""] + [f"- `{i['id']}`: {md_escape(i['what'])} ({len(i['tests'])} test(s))" for i in imp if i["status"] == "Covered"]
    with open(os.path.join(p["out"], name + ".md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    regression = {"range": rng, "tiles": [("Changed items", len(imp)), ("Regression gaps", len(gaps)), ("Tests to run", len(run)),
                                          ("P1 regression gaps", sum(1 for g in gaps if g["priority"] == "P1"))],
                  "gaps": [{"id": g["id"], "what": g["what"], "status": g["status"], "priority": g["priority"], "scenario": g["scenario"]} for g in gaps],
                  "tests": run}
    write_html(items, meta, os.path.join(p["out"], name + ".html"), regression)
    print(f"Regression {rng}: {len(imp)} changed item(s); {len(gaps)} regression gap(s) "
          f"(P1 {sum(1 for g in gaps if g['priority'] == 'P1')}); {len(run)} existing test(s) to run.")
    print(f"Written: {os.path.relpath(os.path.join(p['out'], name))}.md and .html")


# ======================================================================== self-test
def self_test():
    ok = {}
    tmp = tempfile.mkdtemp(prefix="coverage_selftest_")
    cwd = os.getcwd()
    try:
        os.chdir(tmp)
        sys.path.insert(0, HERE)
        import extract_dev as X
        for n, c in X.LEGACY_SAMPLE.items():
            if n.startswith("ajs/"):
                pth = os.path.join("dev", n)
                os.makedirs(os.path.dirname(pth), exist_ok=True)
                with open(pth, "w", encoding="utf-8") as fh:
                    fh.write(c)
        subprocess.run(["git", "-C", "dev/ajs", "init", "-q"], capture_output=True)
        subprocess.run(["git", "-C", "dev/ajs", "-c", "user.email=a@b", "-c", "user.name=t", "add", "-A"], capture_output=True)
        subprocess.run(["git", "-C", "dev/ajs", "-c", "user.email=a@b", "-c", "user.name=t", "commit", "-qm", "base"], capture_output=True)
        k = os.path.join("qa-ai-skills", "knowledge", ".extract")
        os.makedirs(k)
        import io as _io, contextlib as _cl
        with _cl.redirect_stdout(_io.StringIO()):
            X.run([], [], os.path.join(k, "dev"), repos=["dev/ajs"])
        locs = [{"variable": "${CUSTOMER_NAME}", "value": "id:customerName", "file": "res/req.resource", "line": 2},
                {"variable": "${BRANCH}", "value": "id:branch", "file": "res/req.resource", "line": 3},
                {"variable": "${SAVE_BTN}", "value": "css:#saveBtn", "file": "res/req.resource", "line": 4},
                {"variable": "${LEI}", "value": "xpath://input[@ng-model='req.lei']", "file": "res/req.resource", "line": 5},
                {"variable": "${REQ_TYPE}", "value": "id:reqType", "file": "res/req.resource", "line": 6}]
        kws = [{"name": "Fill Request", "file": "res/req.resource", "line": 10, "arguments": ["${name}", "${type}=PERSONAL"], "steps": [
                    {"keyword": "Input Text", "args": ["${CUSTOMER_NAME}", "${name}"], "resolved": []},
                    {"keyword": "Select From List By Value", "args": ["${REQ_TYPE}", "${type}"], "resolved": []},
                    {"keyword": "Select From List By Label", "args": ["${BRANCH}", "Main"], "resolved": []}]},
               {"name": "Save Request", "file": "res/req.resource", "line": 20, "arguments": [], "steps": [
                    {"keyword": "Click Element", "args": ["${SAVE_BTN}"], "resolved": []}]},
               {"name": "Login To Portal", "file": "res/common.resource", "line": 1, "arguments": ["${user}"], "steps": [
                    {"keyword": "Input Text", "args": ["id:username", "${user}"], "resolved": []}]}]
        tests = [{"file": "tests/req.robot", "name": "Create personal request", "tags": ["TC-101"], "steps": [
                    {"keyword": "Login To Portal", "args": ["${MAKER}"], "resolved": ["res/common.resource::Login To Portal"]},
                    {"keyword": "Go To", "args": ["${URL}/#/requests/new"], "resolved": []},
                    {"keyword": "Fill Request", "args": ["Ann Lee"], "resolved": ["res/req.resource::Fill Request"]},
                    {"keyword": "Save Request", "args": [], "resolved": ["res/req.resource::Save Request"]},
                    {"keyword": "Page Should Contain", "args": ["Request saved"], "resolved": []},
                    {"keyword": "Element Should Not Be Visible", "args": ["${LEI}"], "resolved": []}]},
                 {"file": "tests/req.robot", "name": "Customer name too long is rejected", "tags": ["TC-102"], "steps": [
                    {"keyword": "Login To Portal", "args": ["${MAKER}"], "resolved": ["res/common.resource::Login To Portal"]},
                    {"keyword": "Fill Request", "args": ["A" * 40], "resolved": ["res/req.resource::Fill Request"]}]}]
        for name, data in (("locators.json", locs), ("keywords.json", kws), ("tests.json", tests), ("variables.json", [])):
            with open(os.path.join(k, name), "w") as fh:
                json.dump(data, fh)
        with open("manual.md", "w") as fh:
            fh.write("# Manual\n\n### TC-101: Create personal request\n1. Fill Customer name\n   - Expected: saved\n\n"
                     "### TC-150: Corporate request needs LEI\n1. Choose Corporate and leave the LEI empty\n2. Press Save\n   - Expected: error\n")
        with _cl.redirect_stdout(_io.StringIO()) as buf:
            cmd_build(argparse.Namespace(cases=["manual.md"], top=10))
        printed = buf.getvalue()
        out = os.path.join("qa-ai-skills", "knowledge", "coverage")
        data = jload(os.path.join(out, "coverage.json"), {})
        it = {i["id"]: i for i in data.get("items", [])}
        g = lambda iid: it.get(iid, {}).get("status")
        ok["fields and buttons: covered when a test types into or clicks them (through keywords and arguments)"] = \
            g("FLD:/requests/new#customerName") == "Covered" and g("ACT:/requests/new#saveBtn") == "Covered" and g("FLD:/requests/list#search") in (None, "Gap") \
            and g("FLD:/requests/new#branch") == "Covered"
        ok["API call covered through the button that makes it; message covered when a test checks it"] = \
            g("API:POST /api/requests") == "Covered" and g("MSG:POST /api/requests:request-saved") == "Covered" and \
            g("MSG:POST /api/requests:could-not-save-the-request") == "Partial"
        ok["boundary rule covered by a value of the limit's length; required rule only Partial (no empty-field test)"] = \
            g("RULE:/requests/new#customerName:maxlength-40") == "Covered" and g("RULE:/requests/new#customerName:required") == "Partial"
        ok["condition: only the hidden side tested -> Partial with the reason"] = \
            g("COND:/requests/new#lei:shown") == "Partial" and "one side" in it["COND:/requests/new#lei:shown"]["why"]
        ok["outside systems: BMC and Alfresco reached but failure not tested -> Partial; business rule message never checked -> Partial"] = \
            g("INT:BMC") == "Partial" and g("INT:Alfresco") == "Partial" and \
            g("BR:RequestService.submit:bmc-validation-failed-for-this-request") == "Partial"
        ok["data variation: dropdown options not used are listed"] = g("OPT:/requests/new#reqType") == "Partial" and \
            it["OPT:/requests/new#reqType"]["options_missing"] == ["Corporate"]
        gaps_md = open(os.path.join(out, "gaps.md"), encoding="utf-8").read()
        map_md = open(os.path.join(out, "coverage-map.md"), encoding="utf-8").read()
        ok["gaps grouped by Negative / Conditional / Integration ..., with priority and a suggested test"] = \
            "## Negative" in gaps_md and "## Conditional" in gaps_md and "## Integration" in gaps_md and "leave 'Customer name' empty" in gaps_md \
            and bool(re.search(r"\| P1 \| `INT:BMC`", gaps_md))
        ok["manager map: coverage %, by kind, by area, top gaps; manual cases automated vs not"] = \
            "**Coverage:" in map_md and "## Coverage by area" in map_md and "## Top gaps to automate next" in map_md and \
            "1 have an automated test" in map_md and "TC-150" in gaps_md
        rows = list(csv.reader(open(os.path.join(out, "coverage-matrix.csv"), encoding="utf-8-sig")))
        ok["matrix CSV for Excel and an offline HTML report (no outside links)"] = rows[0][0] == "ID" and len(rows) == len(it) + 1 and \
            "http" not in re.sub(r"https?://[^\"' ]*w3\.org[^\"' ]*", "", open(os.path.join(out, "coverage.html"), encoding="utf-8").read().split('<script id="data"')[0])
        gc = open(os.path.join(out, "gap-test-cases.md"), encoding="utf-8").read()
        sys.path.insert(0, os.path.join(os.path.dirname(HERE), "test-cases"))
        import tc_reader
        gi = tc_reader.get_index(os.path.join(out, "gap-test-cases.md"))[0]
        ok["top gaps written as test cases the test case reader understands"] = len(gi["tests"]) == 10 and gi["tests"][0]["id"] == "GAP-001" and \
            any(s.get("expected") for t in gi["tests"] for s in t["steps"])
        with open(os.path.join(out, "decisions.md"), "a") as fh:
            fh.write("INT:BMC | Covered | BMC failure tested by the API suite (TC-900)\n")
        with _cl.redirect_stdout(_io.StringIO()) as buf2:
            cmd_build(argparse.Namespace(cases=None, top=10))
        it2 = {i["id"]: i for i in jload(os.path.join(out, "coverage.json"), {})["items"]}
        ok["decisions win over the computed status; the next build reports the trend"] = it2["INT:BMC"]["status"] == "Covered" and \
            it2["INT:BMC"].get("decision") and "since last build" in buf2.getvalue()
        svc = os.path.join("dev", "ajs", "src", "main", "java", "com", "bank", "RequestService.java")
        txt = open(svc).read().replace("BMC validation failed for this request", "BMC rejected this request")
        open(svc, "w").write(txt)
        subprocess.run(["git", "-C", "dev/ajs", "-c", "user.email=a@b", "-c", "user.name=t", "commit", "-qam", "change"], capture_output=True)
        with _cl.redirect_stdout(_io.StringIO()):
            X.run([], [], os.path.join(k, "dev"), repos=["dev/ajs"])
        with _cl.redirect_stdout(_io.StringIO()) as buf3:
            cmd_regression(argparse.Namespace(base="HEAD~1", head="HEAD"))
        reg = open(os.path.join(out, "regression-head-1-head.md"), encoding="utf-8").read()
        ok["regression: the changed rule is found, the tests to run listed, the uncovered change reported as a regression gap"] = \
            "BR:RequestService.submit:bmc-rejected-this-request" in reg and "Regression gaps" in reg and "regression gap" in buf3.getvalue() \
            and os.path.isfile(os.path.join(out, "regression-head-1-head.html"))
        ok["build prints one line a manager can read"] = printed.startswith("Coverage ") and "P1" in printed
    finally:
        os.chdir(cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    ok = {k_: bool(v) for k_, v in ok.items()}
    for k_, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k_}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] == ["--self-test"]:
        return self_test()
    ap = argparse.ArgumentParser(description="Automation coverage map, gap analysis and regression gap analysis.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--cases", nargs="+", help="manual test case files or folders (Markdown or CSV), to compare with the automated tests")
    b.add_argument("--top", type=int, default=25, help="how many top gaps to write as test cases (default 25)")
    r = sub.add_parser("regression")
    r.add_argument("--base", required=True, help="the older commit, tag or branch of the development repos (for example the last release tag)")
    r.add_argument("--head", default="HEAD")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        cmd_build(a)
    else:
        cmd_regression(a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
