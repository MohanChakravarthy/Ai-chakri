# Tester quick guide

0. Once per computer, from the QA repo root: `.\qa-ai-skills\qa-ai-setup install` (Windows) or
   `sh qa-ai-skills/qa-ai-setup.sh install` (macOS / Linux), then restart the editor as it says.
   After that, `qa-ai-setup install` or `qa-ai-setup check` works from any folder in the repo.
1. One time: `@qa-knowledge-setup build` (or `build <folder | .robot file | topic>`). It asks whether to
   include the development repo; if yes, pick the repo and branch and it reads the code (read-only).
   Add it later with `@qa-knowledge-setup dev`.
2. After pulling new changes: `@qa-knowledge-setup refresh`
3. Generate a script: `@robot-script-generator TC-1234` (local files), `@robot-script-generator qtest TC-1234` (from qTest), a test case `.md` file, or one plain sentence
   - many test cases at once: `@robot-script-generator <file.md> all` (or `first 10`, `next 10`,
     `failed`, `5-20`, `TC-101 TC-102`, `test case 3`); one prompt for the unclear ones, then a
     tick per test case and a batch report
   - new feature on a mock screen: add `mock <mock link>`
4. It asks only which environment to use (click to choose), then works. Watch the numbered checklist tick (1 of 9 ... 9 of 9) and the "AI assistant is ..." badge in the browser (blue: existing steps, purple: reading a new
   screen, yellow: final test run). The generator reuses your existing
   keywords, explores only what is new, proves every new locator, runs the test and fixes it itself.
5. It asks only before adding the test to the suite and before committing.
6. If it says the environment is the problem (database, login, data), fix that, run the existing test
   it names yourself, then reply "fixed, proceed".
7. Rerun a passed test with the command it gives you: that is a normal run, with no badge.
8. Ask "how are the AI scripts doing?" for the numbers (pass rate, time, reuse).

In VS Code Copilot and Claude Code, type `/qa-knowledge-setup` or `/robot-script-generator` instead of `@...`.
Works the same for SeleniumLibrary and Browser library suites. New to this? See `qa-ai-skills/setup/SETUP-GUIDE.md`.
