# QA AI Skills

AI skills that learn a Robot Framework repository and turn test cases (AIDLC, hand-written, or
exported from qTest and other tools) into proven Robot Framework scripts, including new features
shown only on mock screens. Works with **SeleniumLibrary** and the **Browser library**, in
**Devin**, **VS Code (GitHub Copilot)** and **Claude Code**.

**New team? Start with `setup/SETUP-GUIDE.md`.**

## What is in this folder
Two folders at the root of your QA repo: **`qa-ai-skills/`** is the package (code and skills only, safe
to replace with a newer version at any time) and **`qa-ai-data/`** is your data (knowledge, generated
tests, results). Replacing the package never touches your data. The AI creates nothing anywhere else;
your tests, resources and config are never changed without your approval.

**Updating to a newer package:** replace the `qa-ai-skills` folder with the new one, then run
`qa-ai-setup install`. Coming from a version that kept the knowledge *inside* `qa-ai-skills/`: unzip
the new package **over** the old folder (do not delete it first), run `qa-ai-setup install` once (it
moves your knowledge and tests out to `qa-ai-data/`), and from then on the folder can simply be replaced.
```
<your QA repo>/
  qa-ai-skills/
    qa-ai-setup.cmd / .sh        the setup command (see Install below)
    README.md                    this file
    skills/                      the skills and their helper scripts (shared with the team)
      robot-script-generator.md (the core: rules, fast path, checklist; always read) and generator/
      (stage files read only when that stage starts: understand, reach, locators, write-run, and
      qtest, mock, batch only when used), qa-knowledge-setup/ (extract, split, knowledge_build.py renders the
      keyword and locator knowledge), app-, keyword-, locator-, dev-knowledge-builder.md,
      knowledge-reviewer.md, test-cases/ (tc_reader.py: reads test case files, runs batches),
      qtest/ (read-only qTest MCP), qa_ai_setup.py (the setup engine), mcp_launch.py,
      ai_session.py, ai_run.py (step timing, pass counting per test, promote to verified, run summary, one-call handover), bg_job.py (long steps in the background, so the editor never hangs), ai_activity_indicator.py/.js, editor-commands.json (the /robot-script-generator and /qa-knowledge-setup commands the setup installs for the chosen editor only)
    setup/                       SETUP-GUIDE.md, shared-browser-check.md, MCP examples, qtest.env.example
  qa-ai-data/                    YOUR DATA (outside the package; created by the setup and the skills)
    knowledge/                   created by /qa-knowledge-setup (commit it to share with the team;
                                 its .extract/ and .tmp/ folders are git-ignored); meaning/ holds the AI's short
                                 meaning lines the keyword and locator files are rendered from; also step-cache.json
                                 and test-links.json: steps and catalog names proven in passing runs
                                 (keyword and locator names only, never data values)
    ai_generated_tests/          drafts/ (never committed) and verified/ tests; test_cases/ copies from qTest
    results/                     run summaries, metrics, setup log (git-ignored)
    session/                     temporary login and screen files of the AI's own runs (git-ignored)
    backup/                      older copies the setup moved aside (git-ignored)
  .vscode/mcp.json, .mcp.json, .devin/mcp_config.local.json
                                 MCP settings written by the setup for this computer (git-ignored)
  .github/prompts/, .claude/commands/
                                 the /robot-script-generator and /qa-knowledge-setup commands (installed by the setup)
```
Self-tests (the setup runs them as one configuration check; the development code parts only once development repos are added): extract_repo 16, extract_dev 48, dev_repos 32, script_check 26,
split_extract 23, knowledge_build 28, qtest_mcp 15, tc_reader 48, ai_run 24, ai_session 8, bg_job 6, coverage 13, qa_ai_setup 45 OK.

## Install (once per computer) - one command
Prerequisites: Python (the one that runs `robot`) and Node.js 18+. Everything else is automatic.
1. Copy the `qa-ai-skills/` folder into the root of your QA repo. Everything the AI creates (knowledge,
   generated tests, results) goes into `qa-ai-data/` next to it, never into the package, so the package can
   be replaced later without losing anything. Older AI folders are moved into `qa-ai-data/` automatically.
2. In a terminal at the root of your QA repo, run the setup. The first time, give the folder:

   | System | First time | After that, from any folder in the QA repo |
   |---|---|---|
   | Windows (PowerShell or Command Prompt) | `.\qa-ai-skills\qa-ai-setup install` | `qa-ai-setup install` |
   | macOS / Linux | `sh qa-ai-skills/qa-ai-setup.sh install` | `qa-ai-setup install` |

   The first run registers the `qa-ai-setup` command for you (no admin rights needed; open a new
   terminal, or restart the editor, to use it). `qa-ai-setup check` checks everything without
   changing anything; `qa-ai-setup help` lists every option. It picks the Python that has Robot Framework by itself: the active virtual environment, else the
   repo's `.venv` / `venv` folder, else the system Python. It asks which editor you use (Devin Desktop, VS Code with GitHub Copilot, or VS Code with Claude Code: arrow keys and Enter) and sets up only that one (files an earlier install added for another editor are removed; yours are never touched), installs rf-mcp
   and the Playwright MCP only if they are missing, and writes the MCP settings **inside this
   project** (git-ignored, because they hold paths of this computer): `.vscode/mcp.json` for GitHub
   Copilot, `.mcp.json` for Claude Code (it asks once to approve them), `.devin/mcp_config.local.json`
   for Devin Desktop. Your own MCP settings are not touched. Only if the team commits one of those
   files is your user settings file used instead; and in any file, only our five entries are added:
   your other servers, comments and formatting stay exactly as they were, an entry of yours with
   one of our names is never replaced, and every changed file is backed up. It also adds the slash
   commands and the git-ignore lines, optionally connects qTest, then starts every MCP server once
   and runs one configuration check to prove it works. Run it again any time: it only redoes what is missing.
   `check` only checks; `help` lists every option; `--user-settings` also writes your user settings (if an editor does not
   pick up the project file).
   Each line shows a coloured status: `[ OK ]` green, `[WARN]` amber, `[FAIL]` red, `[SKIP]` grey;
   every warning and failure says its cause and the fix, and the summary lists them again under
   *Action required*. A qTest token you paste shows as `*` and is never shown or logged.
3. Restart the editor as the installer tells you (its *Next steps*).
4. Build the knowledge: `/qa-knowledge-setup build` (new repo) or `/qa-knowledge-setup refresh`
   (existing knowledge). Then read `qa-ai-data/knowledge/run-config.md`.
5. Run `setup/shared-browser-check.md` once (15 minutes).
Manual setup (if the script cannot be used): `setup/SETUP-GUIDE.md` sections 2-4.

## Use
- `/robot-script-generator TC-1234`   (from your local test case files)
- `/robot-script-generator qtest TC-1234`   (straight from qTest)
- `/robot-script-generator log in, open a customer, go to Customer Addresses and tick Preferred Contact`
- `/robot-script-generator <test cases file> all` - also `first 10`, `next 10`, `failed`, `5-20`,
  `TC-101 TC-102`, `test case 3` or words from a title. Any size of file (AIDLC files with catalogs
  and an index, hand-written files, qTest copies, CSV exports). Each test case is understood once,
  the unclear ones are shown in one prompt, then they run one by one with a tick per test case,
  reusing every keyword and locator proven before, and a batch report at the end.
- `/robot-script-generator <test cases file> all mock <mock link>`   (batch + mock mode)
In VS Code Copilot and Claude Code type `/robot-script-generator` or `/qa-knowledge-setup` instead.

## Key capabilities
- **Coverage map, gap analysis and regression gap analysis, measured against the code.**
  `/qa-knowledge-setup coverage` matches every automated test (expanded through its keywords down to
  what it really clicks, types and checks) with what the development code contains: screens, fields,
  buttons, validation rules, conditions, role rules, business rules, status changes, API calls,
  outside systems (BMC, Alfresco ...), messages and dropdown options. Each item is Covered, Partial or
  Gap with the reason and the proving tests; gaps are grouped (negative, conditional, boundary,
  roles/security, integration, status flow, happy path, data variation) and ranked P1-P3 by risk.
  Output: a manager summary, an interactive offline HTML report, an Excel-ready matrix, the trend
  since the last build, and the top gaps written as test cases the script generator can automate.
  `/qa-knowledge-setup regression <release tag>` shows what a code change touched, the existing
  tests to run, and the changed items no test covers.
- **Runs that never hang.** Every AI Robot run is watched: slow is not stuck, nothing is stopped on
  a fixed time. A step silent far beyond its learned time and its own wait limit is stopped safely
  (teardowns still run) and reported as an environment problem, naming the service behind it.
- **Old and new code alike.** The development-code reader understands React, Angular, Vue and Next.js,
  and also AngularJS 1.x, plain HTML with jQuery, JSP (Spring form tags, JSTL), JSF and PrimeFaces,
  Thymeleaf, Struts 1 and 2, ASP.NET Web Forms and MVC Razor, FreeMarker, Velocity and Grails, with
  back ends in Spring Boot, older Spring MVC, Struts, ASP.NET, Node and Python. Pages are found even
  without a `package.json`; a front end that gives no screens is reported by name, never called "back
  end only". On the QA side, `.txt`, `.tsv` and pipe-separated suites, `Selenium2Library` and Robot
  Framework 3.2 and newer are read, and new scripts use the syntax the repo's Robot version runs.
- **Built for any size, from one suite to tens of thousands of tests.** The extractor parses changed
  files in parallel and saves its progress every 250 files; long steps run in the background
  (`bg_job.py`), so the editor never waits on one command. The knowledge is built in batches, most-used
  areas first, saved after every batch, with "12 of 340 areas done, about 25 min left"; a stopped build
  continues where it was, and finished areas can be used before the whole build is done.
- **Fast scripts without lower quality.** Test cases whose steps are all known are written straight
  from the knowledge and proven by the Robot run, with no page exploration; only new screens are
  inspected live. Each test needs two passes on the same code, and a rerun holds only the tests that
  still need one. `ai_run.py finish` hands over in one call: proven tests moved to `verified/`, the rest
  left in drafts with a note, and the summary with faster-code suggestions.
- **Development repo knowledge (optional, read-only).** On `build` or `rebuild` the AI asks for your
  development repo links (up to 10 at a time; a branch page link also gives the branch), asks for
  the branches it still needs in one prompt, clones each repo as it is into a `dev` folder next to
  your QA repo (never inside it), and adds `dev` to the window you have open (VS Code, Devin
  Desktop/Windsurf, Cursor), with a workspace file as a backup. You never have to say which repo is
  front end or back end: it is worked out from the code. A script reads the code (no AI tokens) and records each
  screen's fields, test IDs, dropdown options, validation rules, fields that appear only in some
  cases, the data each screen waits for, and the API endpoints. Development screens are linked to
  your tests by evidence (same IDs, URLs, labels), not by name. Nothing is ever changed, built or
  committed in the development repo.
- **Stronger scripts from it:** your existing keywords and locators are always used first; the
  development knowledge gives new elements stable locators, the right waits, conditional fields and
  valid data, and flags team locators that may be stale (suggestions only). Every locator is still
  proven on the live page.
- **Business behaviour from the development code:** business checks with the message the user
  sees, which role may do what, status flows (for example Submitted to Approved), data that must
  exist first, and what the screen does after Save or Submit. The data model is recorded for
  understanding only: database steps always use your existing queries, because test databases
  differ.
- **Test cases understood like an experienced tester would:** the goal first, then every step
  backed by evidence: your closest existing tests (found automatically), the application map and
  the development knowledge. Missing steps (log in as the right role, open the client, get the
  case to Submitted, press Manage...) are added, vague ones ("any subscriber", "should be saved")
  are made concrete, and anything uncertain or conflicting is marked for you to check, all shown
  in one prompt together with the environment choice. Corrections are learned for next time.
- **Fast knowledge build:** scripts write every fact (all keywords, all locators with stability,
  duplicates and screens, the run configuration facts) in seconds; the AI writes only the meaning,
  one short line per keyword, saved in `knowledge/meaning/`, so a refresh redoes only changed areas.
  The application map's routes, proof elements and transitions are rendered from the code too; the AI
  names the screens and writes preconditions, flows and journeys, one pass per area. A coverage check
  proves nothing from the code is missing, and `knowledge_build.py compare <old knowledge folder>`
  shows, in numbers, that a rebuild lost nothing.
- **Fast script generation:** one login for the whole request; the known route in one call; new
  locators from the development code first, then the screen's controls, then Playwright only if
  needed, each proven live in one call; all test cases of a request in the same two full runs; fix
  rounds rerun only the failed tests. Every step is timed, and the summary shows where the time went,
  where each locator came from, and faster code for slow team keywords (existing and suggested).
- **Large test case files, few tokens:** a script cuts the file and indexes it (no AI tokens); the AI
  reads each test case once, with only the catalog rows it uses (verbatim) and the file's reading
  rules. Catalog names such as data aliases and UI element names are linked to how this application
  does them (a keyword, query or locator) once, proven, and saved; repeated steps ("Open the client
  page for ...") are remembered after their first passing run and reused by every later test case.
- **Quality gate before every run:** no Sleep, no secrets, URLs or client data, no AI helpers,
  locators as variables and not fragile, existing keywords and locators reused (also those created
  earlier in the same batch), every test checks a result,
  and a Robot dry run.
- **Metrics for management:** every script is recorded (pass rate, passed without any fix, time,
  keyword reuse, weak locators, how often the understanding needed a correction); ask the AI "how
  are the AI scripts doing?" for the summary.
- **Browser library at the same level as SeleniumLibrary.** The locator check and rating, saved
  screens (page, frames, controls list, screenshot), the badge and the live view now work for both.
  Browser library suites get a live view through a **shared login**: the AI saves the login of the
  browser rf-mcp opened, and Playwright opens the same page in a second window
  (`playwright-session`). The same route is used for SeleniumLibrary when the shared browser is
  not possible (for example Firefox).
- **Suites that use both libraries** are handled: the library with the open browser is used, and
  new locators are written in the syntax of the keyword that uses them. The knowledge records each
  suite's library, even when it comes through a shared resource file.
- **Claude Code support** (`.claude/commands/`, `claude-code-mcp.json`) and a **setup guide** for
  new teams.
- **Any test case format:** AIDLC, hand-written `.md`/`.txt`, or `.csv` exports (qTest and others).
- **Custom checkboxes** (MUI and similar) are read correctly by the locator check.
- **Faster, clearer start:** the plan appears within seconds; the only question is which environment
  to use, as clickable choices (Devin, Copilot and Claude); everything else is decided and listed as
  notes in the summary; the environment check happens during the one login the AI needs anyway
  (no separate check run, no second login) and is not repeated for later tests in the same chat.
- **Numbered checklists in the chat:** 9 steps for script generation, 7 for the knowledge setup,
  each ticked with its result as it finishes and shown again, so nothing scrolls away unread.
- The knowledge records how each project loads secrets (vault, `.env`, environment variables,
  variable files, command-line variables).

- Start-up check of environment, secrets, variables, database, login, browser and rf-mcp (now done inside the one login).
- rf-mcp imports exactly what the suite imports, in the same order; the secrets loader is traced
  through nested resource files.
- Locator strategy: test IDs, then stable id/name, then labels and visible text; auto-generated
  IDs rejected; every new locator proven and rated Strong / Good / Weak.
- Two-run rule: a new test counts as passed only after two passing runs in a row.
- Data changed by the run is reported, with the existing reset step if there is one.
- Badge by tool (blue rf-mcp, purple Playwright, yellow final run), and no badge when a person runs a test.
- Suggested locator fixes for stale team locators, suite setups copied faithfully, no hard-coded environment.

## Safety
Read-only on your tests until you approve. Drafts in `qa-ai-data/ai_generated_tests/drafts/` (never
committed), passing tests in `qa-ai-data/ai_generated_tests/verified/`. Asks before adding to a suite,
branching or committing. No secrets or client data in code. `ai_session.py` and the indicator are
never added to the generated tests, team files or CI. Shared login cookies stay in `qa-ai-data/session/`
(git-ignored) and are deleted at the end of the run. The development repo is only read: never
changed, built, installed or committed, and repo URLs are stored without any user name or token.
