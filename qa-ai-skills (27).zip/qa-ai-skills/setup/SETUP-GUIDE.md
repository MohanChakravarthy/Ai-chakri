# Setup guide for a new team (about 30 minutes)

These AI skills learn your Robot Framework repository from its own code, then turn test cases into
proven Robot Framework scripts that reuse your existing keywords and locators. They work with
**SeleniumLibrary** and the **Browser library**, and in **Devin**, **VS Code (GitHub Copilot)**
and **Claude Code** (terminal or VS Code extension). Nothing is changed in your tests without your
approval.

---


> **Two folders:** `qa-ai-skills/` is the package (replace it freely with a newer version) and `qa-ai-data/` holds your knowledge, generated tests and results. Upgrading from a version that kept the knowledge inside `qa-ai-skills/`: unzip the new package over the old folder (do not delete it first) and run `qa-ai-setup install` once; it moves your data out to `qa-ai-data/`.

## Quick setup: one command (recommended)
Copy the `qa-ai-skills/` folder into your QA repo root, open a terminal there and run:
- Windows (PowerShell or Command Prompt): `.\qa-ai-skills\qa-ai-setup install`
- macOS / Linux: `sh qa-ai-skills/qa-ai-setup.sh install`

The first run registers the `qa-ai-setup` command; from then on (in a new terminal) use
`qa-ai-setup install` or `qa-ai-setup check` from any folder inside the QA repo.

The installer picks the Python that has Robot Framework (active virtual environment, else the repo's
`.venv` / `venv`, else the system Python). It does sections 2-4 of this guide for you on Windows, macOS or Linux: checks the tools, installs
rf-mcp and the Playwright MCP only if missing, writes the MCP settings for the one editor you choose (Devin Desktop,
VS Code with GitHub Copilot, or VS Code with Claude Code; nothing for the others) inside the project - `.vscode/mcp.json`, `.mcp.json`,
`.devin/mcp_config.local.json`, all git-ignored - adds the slash commands and git-ignore lines,
optionally connects qTest (type B at any qTest question to go back and skip it), and proves every MCP server answers. Your own MCP settings, other
servers and comments are never changed; an entry of yours with one of our names is left as it is
and reported. If an editor does not show the servers after a restart, run the installer again with
`--user-settings`. Each line shows `[ OK ]` (green), `[WARN]` (amber), `[FAIL]` (red) or `[SKIP]`
(grey); every warning and failure gives its cause and the exact fix, repeated in the summary under
*Action required*. The sections below are the manual way and the reference.

---

## 1. Before you start (checklist)

| Item | How to check | Notes |
|---|---|---|
| A Robot Framework repo whose tests you can run from the command line | `robot --version` and one normal test run passes | Robot Framework 6.1 or 7.x |
| SeleniumLibrary and/or the Browser library | your `requirements.txt` | Browser library: `rfbrowser init` already done |
| rf-mcp (Robot Framework MCP) | `pip install rf-mcp`, using the **same Python** that runs `robot` | Started as `python -m robotmcp.server` (step 3) |
| Node.js 18 or newer | `node --version` | Needed for Playwright MCP (`npx @playwright/mcp@latest`) |
| Chrome or Edge | installed on the machine | SeleniumLibrary live view needs Chrome or Edge; Playwright MCP uses Chrome by default (add `--browser msedge` to its args to use Edge) |
| Network access to npm and PyPI | the two installs above work | If your company uses a proxy or internal registry, set it up for npm and pip first |
| An AI editor with MCP support | Devin, VS Code with Copilot agent mode, or Claude Code | |
| git, signed in (only if you include the development repo) | `git --version`, and `git clone <dev repo url>` works for you | The AI uses your normal git sign-in; never put a token in the URL |

---

## 2. Copy the files into your repo root

Copy the whole `qa-ai-skills/` folder into the root of your QA repo. Everything the AI uses and
creates stays inside it (skills, setup guides, knowledge, generated tests, results, session files).
The setup script also copies the slash commands; to do it by hand:

| Copy from | To | Needed for |
|---|---|---|
| `qa-ai-skills/skills/editor-commands.json` (Devin part) | `.devin/skills/<name>/SKILL.md` | Devin Desktop (`/robot-script-generator`, `/qa-knowledge-setup`) |
| `qa-ai-skills/skills/editor-commands.json` (Copilot part) | `.github/prompts/` | VS Code with Copilot (`/robot-script-generator`, `/qa-knowledge-setup`) |
| `qa-ai-skills/skills/editor-commands.json` (Claude part) | `.claude/commands/` | Claude Code (`/robot-script-generator`, `/qa-knowledge-setup`) |

Only the chosen editor's files are written. The command templates live in one JSON file, so an editor's `@` file search shows each skill once. Running the installer again when nothing changed prints "Setup is already complete ... Nothing to do". After a newer package is unzipped it updates in seconds with no questions (the editor and the qTest connection in `.env` are kept). `--force` sets everything up again; `--qtest` connects or changes qTest; `--editor` switches editor.

Add the lines from `qa-ai-skills/setup/gitignore-additions.txt` to your `.gitignore`. Do **not** add
`qa-ai-data/ai_generated_tests/drafts/` to it (some AI tools cannot write into ignored folders; drafts are
never committed anyway).

---

## 3. Connect the AI tools (MCP settings)

Use the example for your editor and change the placeholders.

| Editor | Example file | Where it goes |
|---|---|---|
| Devin | `qa-ai-skills/setup/mcp-config-examples/devin-mcp.json` | Devin's MCP settings |
| VS Code with Copilot | `qa-ai-skills/setup/mcp-config-examples/vscode-mcp.json` | `.vscode/mcp.json` in the repo |
| Claude Code | `qa-ai-skills/setup/mcp-config-examples/claude-code-mcp.json` | `.mcp.json` in the repo root (approve the servers when asked; check with `/mcp`) |

**Change these placeholders:**
1. `"command": "python"` must start the same Python that runs `robot`. If several Pythons are
   installed, use the full path to that `python.exe`.
2. `C:\path\to\your-repo` -> your repo's full path, with double backslashes (Devin and Claude Code files).
   VS Code uses `${workspaceFolder}` and needs no change. Each entry also sets `"cwd": "${workspaceFolder}"`, so the tools start in the QA repo folder even when you open the workspace with the development repos.
3. Keep `"PYTHONUTF8": "1"` (prevents text-encoding crashes on Windows).
4. If your normal run needs environment variables (for example a vault address), add them to the
   `robotmcp` `"env"` block by name. Never put passwords in this file.

**The four entries and what they are for:**
| Entry | Job |
|---|---|
| `robotmcp` | runs your existing keywords live (login, navigation), and checks new locators |
| `playwright` | reads mock screens and standalone pages in its own browser |
| `playwright-attach` | reads a new screen in the **same** browser rf-mcp opened (SeleniumLibrary, Chrome/Edge) |
| `playwright-session` | reads a new screen in a second window that uses the same login (Browser library, or when attach is not possible) |
| `qtest` (optional) | reads test cases from your company's qTest by ID, read-only (section 4b) |

Restart the editor and confirm the servers show as connected (all four, plus `qtest` if you set it up).

---

## 4. First-time checks (do these once per machine)
1. **Self-test of each part** (the installer runs all of these for you as one "configuration test"; run them by hand only to see details), with the Python that runs `robot`:
   `python qa-ai-skills/skills/qa-knowledge-setup/extract_repo.py --self-test` -> `SELF-TEST PASSED` and 16 OK lines.
   `python qa-ai-skills/skills/qa-knowledge-setup/extract_dev.py --self-test` -> `SELF-TEST PASSED` and 48 OK lines.
   `python qa-ai-skills/skills/qa-knowledge-setup/script_check.py --self-test` -> `SELF-TEST PASSED` and 26 OK lines.
   `python qa-ai-skills/skills/qa-knowledge-setup/split_extract.py --self-test` -> `SELF-TEST PASSED` and 23 OK lines.
   `python qa-ai-skills/skills/qtest/qtest_mcp.py --self-test` -> `SELF-TEST PASSED` and 15 OK lines (uses a pretend qTest; your real qTest is checked with `--check`, section 4b).
   `python qa-ai-skills/skills/qa-knowledge-setup/dev_repos.py --self-test` -> `SELF-TEST PASSED` and 32 OK lines (needs git).
   `python qa-ai-skills/skills/test-cases/tc_reader.py --self-test` -> `SELF-TEST PASSED` and 48 OK lines.
   `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py --self-test` -> `SELF-TEST PASSED` and 28 OK lines.
   `python qa-ai-skills/skills/ai_run.py --self-test` -> `SELF-TEST PASSED` and 24 OK lines.
   `python qa-ai-skills/skills/bg_job.py --self-test` -> `SELF-TEST PASSED` and 6 OK lines.
   `python qa-ai-skills/skills/qa-knowledge-setup/coverage.py --self-test` -> `SELF-TEST PASSED` and 13 OK lines (needs git).
   `python qa-ai-skills/skills/ai_session.py --self-test` -> `SELF-TEST PASSED` and 8 OK lines.
   `python qa-ai-skills/skills/qa_ai_setup.py --self-test` -> `SELF-TEST PASSED` and 45 OK lines.
   (`qa-ai-setup check` runs all of these for you.)
2. **Build the knowledge**: `/qa-knowledge-setup build` (whole repo) or `/qa-knowledge-setup build <suite file or folder>`.
   In VS Code and Claude Code type `/qa-knowledge-setup build ...`.
3. **Read `qa-ai-data/knowledge/run-config.md`** and confirm: the normal run command, the list of environments,
   the library per suite, how secrets are loaded (and through which file), and the suite setup
   order. Answer anything listed under "Open questions"; the generator relies on this file.
4. **15-minute check**: `qa-ai-skills/setup/shared-browser-check.md` (Part A for SeleniumLibrary, Part B for the
   Browser library). If it fails, nothing breaks: the generator uses a fallback.

---

## 4b. Connect qTest (optional)
With this, `/robot-script-generator qtest TC-1328` reads the test case straight from qTest. It is
read-only: nothing is ever created or changed in qTest. It uses qTest's normal REST API, so it works
even when your qTest site has no MCP of its own.
1. Copy the lines from `qa-ai-skills/setup/qtest.env.example` into the `.env` file in your QA repo root (create it
   if needed; `.env` must be in `.gitignore`). Fill in `QTEST_URL` (your qTest address, without
   `/api`) and `QTEST_PROJECT_ID`.
2. The token, either way:
   - in `.env`: `QTEST_TOKEN=<your own token>` (qTest > Resources > API & SDK); or
   - in the vault: leave `QTEST_TOKEN` out. The qTest MCP then loads the vault exactly the way your
     tests do (the loader recorded by the knowledge setup) and reads the token named
     `QTEST_VAULT_NAME` (default `QTEST_TOKEN`). If your loader needs a variable such as the
     environment, add `QTEST_VAULT_ROBOT_ARGS=--variable ENV:QA`.
   `.env` is read first; the vault is the fallback. The token is never written anywhere else or shown.
3. Check it from a terminal in the QA repo: `python qa-ai-skills/skills/qtest/qtest_mcp.py --check`
   -> `"ok": true` with your project's name, and where the token came from.
4. Restart the editor: the `qtest` entry from `qa-ai-skills/setup/mcp-config-examples/` (already in the examples)
   shows as connected.

## 5. Everyday use
| Task | Devin | VS Code Copilot / Claude Code |
|---|---|---|
| Generate a test from a test case | `/robot-script-generator TC-1234` | `/robot-script-generator TC-1234` |
| All test cases in a file | `/robot-script-generator path/to/cases.md all` | `/robot-script-generator path/to/cases.md all` |
| New feature on a mock screen | add `mock <link or .html file>` | same |
| Plain request | `/robot-script-generator log in, open a client, check address type HOME exists` | same with `/` |
| After pulling new changes | `/qa-knowledge-setup refresh` | `/qa-knowledge-setup refresh` |

The knowledge setup shows a 7-step checklist that ticks as it goes (analysing files, development code, application, keywords, locators, review, summary). On `build` and `rebuild` it first asks, in one prompt, for your development repo links (up to 10 at a time; it asks for the rest afterwards), then, in one more prompt and only for links that do not already name the branch (a `.../tree/<branch>` link does), the branches, with every branch listed. You never say which repo is front end or back end: that is worked out from the code. It uses your normal git sign-in, clones each repo into `dev/<repo name>` next to the QA repo, only reads it, and at the very end adds the `dev` folder to the window you have open (a window with only one folder may reload once). A `<qa repo>.code-workspace` file next to the QA repo is kept as a backup. After that it asks no questions while it works.

**What happens:** a 9-step checklist appears in the chat and ticks as it goes. Within seconds it
shows its plan (which steps reuse your keywords and which are new). If you have not said which
environment to use, it asks that one question with clickable choices (for example QA, Dev, UAT);
otherwise it starts straight away. It decides everything else itself and lists those decisions as
"Notes for you" in the summary. It checks the environment during the one login it needs, reaches the
screen with your own keywords, reads only the new parts, proves every new locator, writes the test,
runs it twice in a visible browser and fixes it up to three times. It stops only if something needs
you (an environment problem, a missing feature) and at the end for your approval.

**Where the files go:** `qa-ai-data/ai_generated_tests/drafts/` while it works (never committed), then
`qa-ai-data/ai_generated_tests/verified/` once it passed both runs. It asks before adding the test to your
suite, before creating a branch and before committing.

**Rerunning a test yourself:** use the command it gives you. That is a normal run with no badge.

---

## 6. Test cases it accepts
- AIDLC test case files, hand-written `.md` or `.txt` files, or a `.csv` export from qTest or
  another test tool. Steps can be numbered, in a table, or in Given/When/Then form.
- Steps you did not write but the application needs (for example logging in before opening a
  client) are added automatically from the knowledge and shown in the plan.
- A plain sentence works too; it restates your request as steps and asks you to confirm.

---

## 7. Your project's setup is read, not assumed
Every team runs tests differently. The knowledge build records yours from your code and files:
vault loaders, `.env` files, environment variables, variable files with arguments, command-line
variables (such as the environment), argument files, folder `__init__` files and suite setups.
If your normal command uses options that are not written in any file (for example a script on
your machine), tell the AI once; it records them in `run-config.md`.

---

## 8. Troubleshooting
| What you see | Likely cause | Fix |
|---|---|---|
| "Variable '${...}' not found" when the AI starts rf-mcp | A command-line variable is missing, or a file that defines it was not loaded | Check `run-config.md` (command-line variables, secrets loader path); run `/qa-knowledge-setup refresh`. The AI names the file and import line |
| rf-mcp crashes with a text-encoding error | Windows code page | Keep `"PYTHONUTF8": "1"` in the `robotmcp` entry |
| `qtest TC-...` says the test case was not found | Wrong ID or project | Check the ID in qTest and `QTEST_PROJECT_ID` in `.env` |
| qTest "refused the token" | Token expired or for another qTest site | Create a new token in qTest > Resources > API & SDK and update `.env` (or the vault) |
| qTest certificate "not trusted" | Your qTest uses an internal company certificate | Set `QTEST_CA_BUNDLE` in `.env` to the company certificate file |
| The `dev` folder did not appear in your window | The editor's command line is not installed (VS Code: Command Palette > Shell Command: Install 'code' command in PATH; Devin Desktop: Shell Command: Install 'devin-desktop' command in PATH) | Install the command, or use File > Add Folder to Workspace and pick `dev`, or open the backup `.code-workspace` file |
| The AI tools are missing or start in the wrong folder after the `dev` folder was added | In a workspace with several folders, your VS Code version does not resolve `${workspaceFolder}` to the QA repo | In `.vscode/mcp.json` replace every `${workspaceFolder}` with `${workspaceFolder:<your QA repo folder name>}` (for example `${workspaceFolder:qa-automation}`), then MCP: List Servers > restart each server |
| Claude Code asks before reading the `dev` folder | Claude Code only reads its own folder without approval | Approve it, or run `/add-dir ../dev` once |
| In Devin, the `dev` folder is gone in a new session | Each Devin session starts from the saved machine | Nothing to do: the next knowledge setup command clones it again from `qa-ai-data/knowledge/dev-config.md` |
| Cloning the development repo fails | No access to that repo, or git is not signed in (in Devin: the repo is not connected to Devin's git integration) | Check you can clone it yourself with `git clone <url>` (in Devin, ask your admin to give Devin access to that repo); the QA knowledge is still built without it |
| rf-mcp cannot find your resource files | rf-mcp is not running from the repo root | Open the editor in the repo root; set a working folder (`cwd`) for `robotmcp` if your editor supports it |
| Playwright opens a blank new browser instead of your page | `playwright-attach` is missing `--cdp-endpoint` | Fix the entry and restart the editor |
| The second window shows a sign-in page | Your app keeps the sign-in in session storage or asks for single sign-on again | Nothing to do: the AI reads the saved screen instead |
| Port 9222 is busy | Another program uses it | Change `door_port` in the `Library ai_session.py` import and in `playwright-attach` |
| Knowledge build is slow on a large repo | Whole-repo build | Build by suite or folder: `/qa-knowledge-setup build <suite>` |
| A test fails at login or a database step | Environment, not the script | The AI runs one of your existing tests to prove it, then tells you what to check |

---

## 9. Safety rules (built in)
- Read-only on your tests, keywords and locators until you approve a change.
- Test environments only; it stops if the target looks like production.
- Passwords and tokens come only from your vault or configuration; they are never typed, shown or
  written into code, comments, tags or knowledge files.
- While exploring a screen it never clicks Save, Submit, Delete or Approve.
- Login cookies shared with the second window stay on your machine in `qa-ai-data/session/`
  (git-ignored) and are deleted at the end of the run.
- Nothing is committed or pushed without your answer.
