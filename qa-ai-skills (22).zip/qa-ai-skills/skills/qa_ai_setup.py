#!/usr/bin/env python3
r"""
qa_ai_setup.py - the engine of the qa-ai-setup command (Windows, macOS, Linux).

    First time, from the QA repo root:   .\qa-ai-skills\qa-ai-setup install    (Windows)
                                         sh qa-ai-skills/qa-ai-setup.sh install  (macOS / Linux)
    After that, anywhere in the repo:    qa-ai-setup install | qa-ai-setup check | qa-ai-setup help

The launchers pick the Python that has Robot Framework. install asks which editor you use
(Devin Desktop or VS Code), then:
  1. checks Python, Robot Framework, Node.js, npm and git (and moves older AI folders into qa-ai-skills)
  2. installs rf-mcp and the Playwright MCP only if they are missing
  3. writes the MCP settings inside the project (git-ignored); your own settings are never changed
  4. optionally connects qTest (.env; a pasted token shows as *)
  5. adds the git-ignore lines and registers the qa-ai-setup command
  6. starts every MCP server once to prove it answers, and runs all self-tests
and ends with a summary, the actions required (cause and fix) and the next steps.

Options: --editor vscode|devin   --yes (no questions: qTest is skipped)   --no-install
         --user-settings          --no-self-tests   --move-only   --self-test
Python 3.8+, standard library only.
"""
import argparse, datetime, glob, importlib.util, json, os, platform, re, shutil, subprocess, sys, tempfile, threading, time

HERE = os.path.dirname(os.path.abspath(__file__))          # .../qa-ai-skills/skills
BASE = os.path.dirname(HERE)                               # .../qa-ai-skills
NEW_LAYOUT = os.path.basename(BASE).lower() == "qa-ai-skills"
REPO = os.path.dirname(BASE) if NEW_LAYOUT else BASE       # the QA repo
AI_HOME = BASE if NEW_LAYOUT else REPO                     # where knowledge, generated tests, results and session live
OS = "windows" if os.name == "nt" else ("mac" if sys.platform == "darwin" else "linux")
SERVER_NAMES = ["robotmcp", "playwright", "playwright-attach", "playwright-session", "qtest"]
LOG_LINES = []
RESULTS = []          # (status, text)

# ======================================================================== screen output
PRODUCT = "QA AI Skills"
VERSION = "0.1"
FIRST_RUN = r".\qa-ai-skills\qa-ai-setup" if os.name == "nt" else "sh qa-ai-skills/qa-ai-setup.sh"
RERUN = FIRST_RUN + " install"          # becomes "qa-ai-setup install" once the command is registered
TERM = {"color": False, "unicode": False, "width": 72}


def _vt_on():
    """Windows: switch the console to ANSI mode (colours and cursor moves). Elsewhere always on."""
    if os.name != "nt":
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not k.GetConsoleMode(h, ctypes.byref(mode)):
            return False
        return bool(mode.value & 4) or bool(k.SetConsoleMode(h, mode.value | 4))
    except Exception:
        return False


def _enable_vt():
    _vt_on()


def init_terminal():
    """Colours only in a real terminal (never in logs or pipes; NO_COLOR turns them off). The dotted spinner
    and lines need Unicode: on Windows they are used in Windows Terminal and VS Code-based terminals
    (Devin Desktop too); the classic console gets the plain fallback."""
    env = os.environ
    is_tty = False
    try:
        is_tty = sys.stdout.isatty()
    except Exception:
        pass
    TERM["color"] = bool(env.get("FORCE_COLOR")) or (is_tty and not env.get("NO_COLOR") and env.get("TERM") != "dumb" and _vt_on())
    uni = True
    try:
        "⠋─".encode(sys.stdout.encoding or "ascii")
    except Exception:
        uni = False
    if os.name == "nt" and not (env.get("WT_SESSION") or env.get("TERM_PROGRAM") or env.get("ConEmuANSI") == "ON"):
        uni = False
    if env.get("AI_QA_ASCII"):
        uni = False
    TERM["unicode"] = uni and is_tty
    try:
        TERM["width"] = max(60, min(84, shutil.get_terminal_size((80, 24)).columns - 2))
    except Exception:
        pass


_CODES = {"green": "32", "red": "31", "amber": "38;5;214", "cyan": "36", "grey": "90", "bold": "1", "dim": "2",
          "green_b": "1;32", "red_b": "1;31", "amber_b": "1;38;5;214", "cyan_b": "1;36"}
_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def c(text, style):
    return f"\x1b[{_CODES[style]}m{text}\x1b[0m" if TERM["color"] and style else text


def rule():
    return c(("─" if TERM["unicode"] else "-") * TERM["width"], "grey")


def tty():
    try:
        return sys.stdout.isatty() and sys.stdin.isatty()
    except Exception:
        return False


def out(text=""):
    """Prints to the screen (with colour) and keeps a plain copy for the log file."""
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        print(_ANSI.sub("", text).encode("ascii", "replace").decode(), flush=True)
    LOG_LINES.append(_ANSI.sub("", text))


TAGS = {"OK": ("[ OK ]", "green_b"), "SKIP": ("[SKIP]", "grey"), "WARN": ("[WARN]", "amber_b"),
        "FAIL": ("[FAIL]", "red_b"), "INFO": ("[INFO]", "cyan")}


def log_only(text):
    """Technical detail (paths, commands, file names): the setup log only, never the screen."""
    LOG_LINES.append(f"          {text}")


def status(st, text, fix=None, cause=None, detail=None):
    """One result line: OK, SKIP, WARN, FAIL or INFO, in plain words. A WARN or FAIL says why (cause) and what to do (fix).
    detail (paths, file names, commands) goes to the setup log only."""
    tag, style = TAGS[st]
    body = c(text, "grey") if st == "SKIP" else text
    out(f"  {c(tag, style)}  {body}")
    if detail:
        log_only(detail)
    pad = " " * 10
    if cause:
        for i, line in enumerate(str(cause).split("\n")):
            out(f"{pad}{c('Cause', 'dim') if i == 0 else '     '}  {line}")
    if fix:
        for i, line in enumerate(str(fix).split("\n")):
            out(f"{pad}{c('Fix  ', 'amber' if st != 'INFO' else 'dim') if i == 0 else '     '}  {line}")
    RESULTS.append((st, text, cause, fix))


class Spinner:
    """A dotted spinner with elapsed time, replaced by the result line when the work is done."""
    FRAMES_U = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    FRAMES_A = [".  ", ".. ", "...", " ..", "  .", "   "]

    def __init__(self, text, pct=None):
        self.text, self.stop_evt, self.th, self.t0, self.pct = text, threading.Event(), None, time.time(), pct

    def __enter__(self):
        self.t0 = time.time()
        if tty():
            self.th = threading.Thread(target=self._spin, daemon=True)
            self.th.start()
        LOG_LINES.append(f"  ...   {self.text}")
        return self

    def _spin(self):
        """Redraws ONE line in place. The line is always cut to the terminal's width: a line that wraps would
        make every redraw start a new line (the 'keeps printing' effect in narrow editor terminals)."""
        frames = self.FRAMES_U if TERM["unicode"] else self.FRAMES_A
        vt = TERM["color"]
        i = 0
        while not self.stop_evt.is_set():
            secs = int(time.time() - self.t0)
            tail = (f"  {int(self.pct)}%" if self.pct is not None else "") + (f"  {secs}s" if secs >= 2 else "")
            mark = frames[i % len(frames)].center(4)
            try:
                cols = shutil.get_terminal_size((80, 24)).columns
            except Exception:
                cols = 80
            room = max(10, cols - 1 - len(mark) - 4 - len(tail))
            text = self.text if len(self.text) <= room else self.text[:room - 1] + "…" if TERM["unicode"] else self.text[:room - 3] + "..."
            if vt:
                sys.stdout.write(f"\r\x1b[2K  {c(mark, 'cyan_b')}  {text}{c(tail, 'grey')}")
            else:
                line = f"  {mark}  {text}{tail}"
                sys.stdout.write("\r" + line.ljust(min(cols - 1, len(line) + 4)))
            sys.stdout.flush()
            i += 1
            self.stop_evt.wait(0.1 if TERM["unicode"] else 0.3)

    def __exit__(self, *a):
        self.stop_evt.set()
        if self.th:
            self.th.join()
            try:
                cols = shutil.get_terminal_size((80, 24)).columns
            except Exception:
                cols = 80
            sys.stdout.write("\r\x1b[2K" if TERM["color"] else "\r" + " " * (cols - 1) + "\r")
            sys.stdout.flush()
        return False


def banner(rows):
    w = TERM["width"]
    out("")
    title = f"  {c(PRODUCT, 'cyan_b')}  {c('|', 'grey')}  {c('Setup', 'bold')}"
    ver = c(f"v{VERSION}", "grey")
    out(title + " " * max(2, w - len(_ANSI.sub('', title)) - len(f"v{VERSION}")) + ver)
    out("  " + rule())
    for k, v in rows:
        out(f"  {c(k.ljust(12), 'dim')}{v}")


def heading(n, total, text):
    out("")
    out(f"  {c(f'[{n}/{total}]', 'cyan_b')}  {c(text, 'bold')}")
    out("  " + rule())


# ======================================================================== questions
def menu(question, options, default=0):
    """Pick one option with the up and down arrows and Enter (or type its number)."""
    if not tty():
        return default
    _enable_vt()
    out("")
    out(f"  {c('?', 'cyan_b')} {c(question, 'bold')}")
    hint = "  " + c("  Up/Down to move, Enter to select", "grey")
    print(hint, flush=True)
    sel = default

    def draw(first=False):
        if not first:
            sys.stdout.write(f"\x1b[{len(options)}A")
        for i, o in enumerate(options):
            line = f"    {c('>', 'cyan_b')} {c(o, 'cyan_b')}" if i == sel else f"      {c(o, 'grey') if TERM['color'] else o}"
            sys.stdout.write("\r\x1b[2K" + line + "\n")
        sys.stdout.flush()
    try:
        draw(True)
        while True:
            k = _key()
            if k == "up":
                sel = (sel - 1) % len(options)
            elif k == "down":
                sel = (sel + 1) % len(options)
            elif k == "enter":
                break
            elif k and k.isdigit() and 1 <= int(k) <= len(options):
                sel = int(k) - 1
                draw()
                break
            elif k == "quit":
                raise KeyboardInterrupt
            draw()
        if TERM["color"]:
            sys.stdout.write(f"\x1b[{len(options) + 2}A\r\x1b[J")
            sys.stdout.write(f"  {c('?', 'cyan_b')} {c(question, 'bold')}  {c(options[sel].split('  (')[0], 'cyan')}\n")
            sys.stdout.flush()
        LOG_LINES.append(f"  ? {question} -> {options[sel]}")
        return sel
    except KeyboardInterrupt:
        raise
    except Exception:
        for i, o in enumerate(options, 1):
            out(f"    {i}. {o}")
        while True:
            a = input(f"    Type a number (1-{len(options)}) and press Enter: ").strip()
            if a.isdigit() and 1 <= int(a) <= len(options):
                return int(a) - 1


def _key():
    if os.name == "nt":
        import msvcrt
        c = msvcrt.getwch()
        if c in ("\x00", "\xe0"):
            c2 = msvcrt.getwch()
            return {"H": "up", "P": "down"}.get(c2)
        if c in ("\r", "\n"):
            return "enter"
        if c == "\x03":
            return "quit"
        return c
    import termios, tty as _tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        _tty.setcbreak(fd)
        c = sys.stdin.read(1)
        if c == "\x1b":
            seq = sys.stdin.read(2)
            return {"[A": "up", "[B": "down", "OA": "up", "OB": "down"}.get(seq)
        if c in ("\r", "\n"):
            return "enter"
        if c in ("k",):
            return "up"
        if c in ("j",):
            return "down"
        if c == "\x03":
            return "quit"
        return c
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def ask_text(label, default="", example=""):
    """A labelled question; the default is used when Enter is pressed."""
    if not tty():
        return default
    out("")
    extra = c(f"  (e.g. {example})", "grey") if example else ""
    dflt = c(f"  [{default}]", "grey") if default else ""
    print(f"  {c('?', 'cyan_b')} {c(label, 'bold')}{extra}{dflt}", flush=True)
    a = input(f"    {c('>', 'cyan_b')} ").strip()
    LOG_LINES.append(f"  ? {label} -> {a or default}")
    return a or default


def _read_masked():
    """Reads a line without showing it: one * per character, Backspace works, paste works."""
    chars = []
    if os.name == "nt":
        import msvcrt
        while True:
            ch = msvcrt.getwch()
            if ch in ("\r", "\n"):
                break
            if ch == "\x03":
                raise KeyboardInterrupt
            if ch in ("\x00", "\xe0"):
                msvcrt.getwch()
                continue
            if ch == "\x08":
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            if ch < " ":
                continue
            chars.append(ch)
            sys.stdout.write("*")
            sys.stdout.flush()
        return "".join(chars)
    import termios, tty as _tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        _tty.setcbreak(fd)                       # no echo; Ctrl+C still stops the script
        while True:
            ch = sys.stdin.read(1)
            if ch in ("\r", "\n", ""):
                break
            if ch in ("\x7f", "\x08"):
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            if ch == "\x1b" or ch < " ":
                continue
            chars.append(ch)
            sys.stdout.write("*")
            sys.stdout.flush()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    return "".join(chars)


def ask_secret(label, hint=""):
    """Asks for a secret; each character shows as *, the value never appears on screen or in the log."""
    if not tty():
        return ""
    out("")
    print(f"  {c('?', 'cyan_b')} {c(label, 'bold')}" + (c(f"  ({hint})", "grey") if hint else ""), flush=True)
    sys.stdout.write(f"    {c('>', 'cyan_b')} ")
    sys.stdout.flush()
    try:
        val = _read_masked()
    except KeyboardInterrupt:
        raise
    except Exception:
        import getpass
        val = getpass.getpass("")
    sys.stdout.write("\n")
    sys.stdout.flush()
    LOG_LINES.append(f"  ? {label} -> (hidden)")
    return val.strip()


# ======================================================================== small helpers
def run(cmd, cwd=None, timeout=900, env=None):
    """Runs a command; .cmd/.bat files on Windows go through cmd. Returns (code, output)."""
    if os.name == "nt" and cmd and str(cmd[0]).lower().endswith((".cmd", ".bat")):
        cmd = ["cmd", "/c"] + list(cmd)
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env,
                           encoding="utf-8", errors="replace")
        text = (r.stdout or "") + (r.stderr or "")
        LOG_LINES.append(f"$ {' '.join(map(str, cmd))}\n{text[-4000:]}")
        return r.returncode, text
    except FileNotFoundError:
        return 127, f"{cmd[0]} not found"
    except subprocess.TimeoutExpired:
        return 124, f"{' '.join(map(str, cmd[:3]))} took longer than {timeout} seconds"


def last_lines(text, n=3):
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    return "\n".join(lines[-n:])


def read_jsonc(path):
    """JSON that may contain // or /* */ comments and trailing commas (VS Code files)."""
    with open(path, encoding="utf-8-sig") as fh:
        txt = fh.read()
    if not txt.strip():
        return {}
    txt = re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", txt, flags=re.S)
    txt = re.sub(r",\s*([}\]])", r"\1", txt)
    return json.loads(txt)


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp-qa-ai"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    os.replace(tmp, path)


def backup(path):
    """A copy before any change. Files inside the QA repo are backed up into qa-ai-skills/backup/ (git-ignored),
    so no backup files are left next to the team's files; files outside it are backed up next to themselves."""
    if not os.path.isfile(path):
        return None
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    try:
        inside = os.path.commonpath([os.path.abspath(path), os.path.abspath(REPO)]) == os.path.abspath(REPO) and NEW_LAYOUT
    except ValueError:
        inside = False
    if inside:
        b = os.path.join(REPO, "qa-ai-skills", "backup", os.path.relpath(path, REPO) + f".backup-{stamp}")
        os.makedirs(os.path.dirname(b), exist_ok=True)
    else:
        b = f"{path}.backup-{stamp}"
    shutil.copy2(path, b)
    return b


def remove_empty_dirs(d):
    """Removes d and its parents while they are empty, never the QA repo itself."""
    d = os.path.abspath(d)
    while d != os.path.abspath(REPO) and d.startswith(os.path.abspath(REPO)) and os.path.isdir(d) and not os.listdir(d):
        os.rmdir(d)
        d = os.path.dirname(d)


# ======================================================================== locations per OS
def locations(env=None, osname=None):
    env = os.environ if env is None else env
    osname = osname or OS
    home = env.get("HOME") if osname != "windows" else (env.get("USERPROFILE") or env.get("HOME"))
    home = home or os.path.expanduser("~")
    appdata = env.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
    xdg = env.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    if osname == "windows":
        vs_users = [os.path.join(appdata, "Code", "User"), os.path.join(appdata, "Code - Insiders", "User")]
        devin = os.path.join(appdata, "devin", "mcp_config.json")
    elif osname == "mac":
        sup = os.path.join(home, "Library", "Application Support")
        vs_users = [os.path.join(sup, "Code", "User"), os.path.join(sup, "Code - Insiders", "User")]
        devin = os.path.join(xdg, "devin", "mcp_config.json")
    else:
        vs_users = [os.path.join(xdg, "Code", "User"), os.path.join(xdg, "Code - Insiders", "User")]
        devin = os.path.join(xdg, "devin", "mcp_config.json")
    return {
        "home": home,
        "vscode_user_dirs": vs_users,
        "vscode_ext_dirs": [os.path.join(home, ".vscode", "extensions"), os.path.join(home, ".vscode-insiders", "extensions")],
        "copilot_config": os.path.join(env.get("COPILOT_HOME") or os.path.join(home, ".copilot"), "mcp-config.json"),
        "claude_json": os.path.join(env.get("CLAUDE_CONFIG_DIR") or home, ".claude.json"),
        "devin_config": devin,
        "devin_old_user": os.path.join(os.path.dirname(devin), "config.json"),   # Devin before v3000.3 kept mcpServers here
        "devin_legacy": os.path.join(home, ".codeium", "windsurf", "mcp_config.json"),
        "devin_app_dirs": [os.path.join(appdata, "Devin Desktop"), os.path.join(appdata, "Windsurf"),
                           os.path.join(home, "Library", "Application Support", "Devin Desktop"),
                           os.path.join(xdg, "Devin Desktop"), os.path.join(home, ".codeium")],
        "tools_prefix": os.path.join(home, ".qa-ai-tools"),
    }


def find_extension(loc, prefix):
    for d in loc["vscode_ext_dirs"]:
        hits = sorted(glob.glob(os.path.join(d, prefix + "*")))
        if hits:
            return hits[-1]
    return None


def detect_editors(loc):
    vscode = bool(shutil.which("code") or shutil.which("code-insiders") or any(os.path.isdir(d) for d in loc["vscode_user_dirs"]))
    devin = bool(shutil.which("devin-desktop") or shutil.which("windsurf") or os.path.isfile(loc["devin_config"]) or
                 os.path.isfile(loc["devin_legacy"]) or any(os.path.isdir(d) for d in loc["devin_app_dirs"]))
    copilot = find_extension(loc, "github.copilot-chat-")
    claude_ext = find_extension(loc, "anthropic.claude-code-")
    return {"vscode": vscode, "devin": devin, "copilot": copilot, "claude_ext": claude_ext,
            "claude_cli": shutil.which("claude")}


def find_claude_cli(det):
    if det.get("claude_cli"):
        return det["claude_cli"]
    ext = det.get("claude_ext")
    if ext:
        names = ("claude.exe",) if os.name == "nt" else ("claude",)
        for root, dirs, files in os.walk(ext):
            if root[len(ext):].count(os.sep) > 4:
                dirs[:] = []
                continue
            for n in names:
                if n in files and os.access(os.path.join(root, n), os.X_OK):
                    return os.path.join(root, n)
    return None


# ======================================================================== checks
def check_python():
    v = sys.version_info
    if v < (3, 8):
        status("FAIL", f"Python {v.major}.{v.minor} is too old",
               cause="The QA AI skills need Python 3.8 or newer.",
               fix=f"Install Python 3.10 or newer (or ask IT), use it for Robot Framework, then run {RERUN} again.")
        return False
    status("OK", f"Python {v.major}.{v.minor}.{v.micro}", detail=f"Python used: {sys.executable}")
    return True


def check_robot():
    try:
        import robot
        from robot.version import VERSION
        status("OK", f"Robot Framework {VERSION}")
        return True
    except Exception:
        status("FAIL", "Robot Framework was not found in this Python",
               cause=f"The setup runs with {sys.executable}, which has no Robot Framework.",
               fix=f"Activate the virtual environment you run robot with (for example .venv), then run {RERUN} again.\n"
                   "The installer uses the active virtual environment, or the repo's .venv / venv folder, automatically.")
        return False


def check_node():
    node, npm = shutil.which("node"), shutil.which("npm")
    if not node:
        status("FAIL", "Node.js was not found",
               cause="Node.js is not installed, or it is not on the PATH of this terminal.",
               fix=f"Install Node.js 18 LTS or newer (nodejs.org, or ask IT), open a new terminal, then run {RERUN} again.")
        return None, None
    code, txt = run([node, "--version"], timeout=60)
    ver = txt.strip().lstrip("v")
    major = int(ver.split(".")[0]) if ver.split(".")[0].isdigit() else 0
    if major and major < 18:
        status("WARN", f"Node.js {ver} is older than supported",
               cause="The Playwright MCP needs Node.js 18 or newer; older versions can fail to start it.",
               fix="Update Node.js to the current LTS version (nodejs.org, or ask IT).")
    else:
        status("OK", f"Node.js {ver}")
    if not npm:
        status("FAIL", "npm was not found",
               cause="npm is part of Node.js, but it is missing from this installation or from the PATH.",
               fix=f"Reinstall Node.js 18 LTS or newer (it includes npm), open a new terminal, then run {RERUN} again.")
    else:
        code, txt = run([npm, "--version"], timeout=120)
        status("OK" if code == 0 else "WARN", f"npm {txt.strip().splitlines()[-1] if txt.strip() else ''}".strip())
    return node, npm


def check_git():
    g = shutil.which("git")
    if g:
        code, txt = run([g, "--version"], timeout=60)
        status("OK", re.sub(r"(?i)^git version", "Git", txt.strip()) or "Git")
    else:
        status("WARN", "Git was not found",
               cause="Git is only needed to connect the development repositories.",
               fix="Install Git for your system (or ask IT) if you plan to include the development repos; otherwise ignore this.")
    return g


# ======================================================================== installs
def rf_mcp_installed():
    if importlib.util.find_spec("robotmcp") is None:
        return None
    try:
        from importlib.metadata import version
        return version("rf-mcp")
    except Exception:
        return "installed"


def install_rf_mcp(allow):
    v = rf_mcp_installed()
    if v:
        status("OK", f"Robot Framework MCP {v} is installed")
        return True
    if not allow:
        status("FAIL", "Robot Framework MCP is not installed",
               cause="Installs were turned off for this run (--no-install).",
               fix=f"Install it: \"{sys.executable}\" -m pip install rf-mcp   (or run {RERUN} without --no-install)")
        return False
    with Spinner("Please wait: installing the Robot Framework MCP"):
        code, txt = run([sys.executable, "-m", "pip", "install", "rf-mcp"], timeout=1200)
        if code != 0 and re.search(r"externally-managed|Permission denied|access is denied", txt, re.I):
            code, txt = run([sys.executable, "-m", "pip", "install", "--user", "rf-mcp"], timeout=1200)
    importlib.invalidate_caches()
    if code == 0 and rf_mcp_installed():
        status("OK", f"Robot Framework MCP {rf_mcp_installed()} installed")
        return True
    blocked = re.search(r"proxy|SSL|certificate|connection|timed out|Could not fetch", txt, re.I)
    status("FAIL", "Robot Framework MCP could not be installed",
           cause=("The download from pypi.org was blocked (company proxy or certificate).\n" if blocked else "") + last_lines(txt, 1),
           fix=("Set your company proxy for pip (pip config set global.proxy http://proxy:port) or ask IT to allow pypi.org, then run "
                f"{RERUN} again." if blocked else f"Run it yourself to see the full message: \"{sys.executable}\" -m pip install rf-mcp"))
    return False


def playwright_cli(npm, loc):
    """Path of the Playwright MCP's cli.js: the global npm install, or our own user folder."""
    roots = []
    if npm:
        code, txt = run([npm, "root", "-g"], timeout=120)
        if code == 0 and txt.strip():
            roots.append(txt.strip().splitlines()[-1].strip())
    roots.append(os.path.join(loc["tools_prefix"], "node_modules"))
    for r in roots:
        pkg = os.path.join(r, "@playwright", "mcp", "package.json")
        if os.path.isfile(pkg):
            try:
                meta = json.load(open(pkg, encoding="utf-8"))
            except Exception:
                continue
            b = meta.get("bin")
            rel = b if isinstance(b, str) else (b or {}).get("mcp-server-playwright") or next(iter((b or {}).values()), "cli.js")
            cli = os.path.normpath(os.path.join(os.path.dirname(pkg), rel))
            if os.path.isfile(cli):
                return cli, meta.get("version", "")
    return None, None


def install_playwright_mcp(npm, loc, allow):
    cli, ver = playwright_cli(npm, loc)
    if cli:
        status("OK", f"Playwright MCP {ver} is installed")
        return cli
    if not npm:
        status("FAIL", "Playwright MCP is not installed",
               cause="npm is missing, so it cannot be installed.",
               fix=f"Install Node.js 18 LTS or newer (it includes npm), then run {RERUN} again.")
        return None
    if not allow:
        status("FAIL", "Playwright MCP is not installed",
               cause="Installs were turned off for this run (--no-install).",
               fix=f"Install it: npm install -g @playwright/mcp@latest   (or run {RERUN} without --no-install)")
        return None
    with Spinner("Please wait: installing the Playwright MCP"):
        code, txt = run([npm, "install", "-g", "@playwright/mcp@latest"], timeout=1200)
        if code != 0:            # no rights for the global folder: install for this user only, no admin needed
            os.makedirs(loc["tools_prefix"], exist_ok=True)
            code, txt = run([npm, "install", "--prefix", loc["tools_prefix"], "@playwright/mcp@latest"], timeout=1200)
    cli, ver = playwright_cli(npm, loc)
    if cli:
        status("OK", f"Playwright MCP {ver} installed")
        return cli
    blocked = re.search(r"proxy|SSL|certificate|ECONN|ETIMEDOUT|self.signed|UNABLE_TO", txt, re.I)
    status("FAIL", "Playwright MCP could not be installed",
           cause=("The download from registry.npmjs.org was blocked (company proxy or certificate).\n" if blocked else "") + last_lines(txt, 1),
           fix=("Set your company proxy for npm (npm config set proxy http://proxy:port) or ask IT to allow registry.npmjs.org, then run "
                f"{RERUN} again." if blocked else "Run it yourself to see the full message: npm install -g @playwright/mcp@latest"))
    return None


def find_browser(env=None, osname=None):
    """Chrome is the Playwright MCP's default; Edge is used when Chrome is missing."""
    env = os.environ if env is None else env
    osname = osname or OS
    if osname == "windows":
        bases = [env.get("PROGRAMFILES", r"C:\Program Files"), env.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"), env.get("LOCALAPPDATA", "")]
        chrome = any(os.path.isfile(os.path.join(b, "Google", "Chrome", "Application", "chrome.exe")) for b in bases if b)
        edge = any(os.path.isfile(os.path.join(b, "Microsoft", "Edge", "Application", "msedge.exe")) for b in bases if b)
    elif osname == "mac":
        chrome = os.path.isdir("/Applications/Google Chrome.app") or os.path.isdir(os.path.expanduser("~/Applications/Google Chrome.app"))
        edge = os.path.isdir("/Applications/Microsoft Edge.app")
    else:
        chrome = os.path.isfile("/opt/google/chrome/chrome") or bool(shutil.which("google-chrome") or shutil.which("google-chrome-stable"))
        edge = os.path.isfile("/opt/microsoft/msedge/msedge") or bool(shutil.which("microsoft-edge") or shutil.which("microsoft-edge-stable"))
    if chrome:
        return "chrome", []
    if edge:
        return "msedge", ["--browser", "msedge"]
    return None, []


# ======================================================================== MCP entries
def server_defs(repo, py, node, pw_cli, browser_args, with_qtest=True, skills=None, ai_home=None):
    skills = skills or HERE
    ai_home = ai_home or (os.path.join(repo, "qa-ai-skills") if NEW_LAYOUT or os.path.isdir(os.path.join(repo, "qa-ai-skills")) else repo)
    sk = lambda *p: os.path.join(skills, *p)
    utf8 = {"PYTHONUTF8": "1"}
    d = {"robotmcp": {"command": py, "args": [sk("mcp_launch.py"), "--cwd", repo, "--module", "robotmcp.server"], "env": utf8}}
    session = os.path.join(ai_home, "session" if os.path.basename(ai_home) == "qa-ai-skills" else ".ai_session", "storage-state.json")
    if node and pw_cli:
        init = ["--init-script", sk("ai_activity_indicator.js")]
        d["playwright"] = {"command": node, "args": [pw_cli] + browser_args + init}
        d["playwright-attach"] = {"command": node, "args": [pw_cli, "--cdp-endpoint", "http://127.0.0.1:9222"] + init}
        d["playwright-session"] = {"command": node, "args": [pw_cli] + browser_args +
                                   ["--isolated", "--storage-state", session] + init}
    if with_qtest:
        d["qtest"] = {"command": py, "args": [sk("qtest", "qtest_mcp.py"), "--root", repo], "env": utf8}
    return d


def as_format(defs, fmt, repo):
    res = {}
    for name, x in defs.items():
        if fmt == "vscode":
            res[name] = dict({"type": "stdio", "command": x["command"], "args": x["args"]}, **({"env": x["env"]} if x.get("env") else {}), cwd=repo)
        elif fmt == "copilot":
            res[name] = dict({"type": "stdio", "command": x["command"], "args": x["args"]}, **({"env": x["env"]} if x.get("env") else {}),
                             cwd=repo, tools=["*"])
        elif fmt == "claude":
            res[name] = dict({"type": "stdio", "command": x["command"], "args": x["args"]}, **({"env": x["env"]} if x.get("env") else {}))
        else:                                                  # devin
            res[name] = dict({"command": x["command"], "args": x["args"]}, **({"env": x["env"]} if x.get("env") else {}))
    return res


# ---------------------------------------------------------------- editing JSON text in place
# Settings files are changed by inserting or replacing only our entries in the existing text, so
# the user's other servers, comments and formatting stay exactly as they were.
OUR_MARKERS = ("mcp_launch.py", "qtest_mcp.py", "ai_activity_indicator.js")


def is_ours(entry):
    return isinstance(entry, dict) and any(m in json.dumps(entry) for m in OUR_MARKERS)


def _skip(text, i):
    n = len(text)
    while i < n:
        if text[i] in " \t\r\n\ufeff":
            i += 1
        elif text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j == -1 else j + 1
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j == -1 else j + 2
        else:
            break
    return i


def _string_end(text, i):
    j = i + 1
    while j < len(text):
        if text[j] == "\\":
            j += 2
            continue
        if text[j] == '"':
            return j + 1
        j += 1
    raise ValueError("unterminated string")


def _value_end(text, i):
    c = text[i]
    if c == '"':
        return _string_end(text, i)
    if c in "{[":
        depth, j = 0, i
        while j < len(text):
            j = _skip(text, j)
            ch = text[j]
            if ch == '"':
                j = _string_end(text, j)
                continue
            if ch in "{[":
                depth += 1
            elif ch in "}]":
                depth -= 1
                if depth == 0:
                    return j + 1
            j += 1
        raise ValueError("unbalanced brackets")
    m = re.match(r"[^,}\]\s/]+", text[i:])
    return i + (m.end() if m else 1)


def _members(text, start):
    """Top-level members of the object at text[start] == '{': [(key, key_start, value_start, value_end)], close."""
    out, i = [], _skip(text, start + 1)
    while True:
        if text[i] == "}":
            return out, i
        if text[i] != '"':
            raise ValueError(f"unexpected {text[i]!r} at {i}")
        ks = i
        ke = _string_end(text, i)
        key = json.loads(text[i:ke])
        i = _skip(text, ke)
        if text[i] != ":":
            raise ValueError("missing ':'")
        vs = _skip(text, i + 1)
        ve = _value_end(text, vs)
        out.append((key, ks, vs, ve))
        i = _skip(text, ve)
        if text[i] == ",":
            i = _skip(text, i + 1)


def _indent_at(text, pos):
    line_start = text.rfind("\n", 0, pos) + 1
    m = re.match(r"[ \t]*", text[line_start:])
    return m.group(0)


def _dump(value, base):
    return json.dumps(value, indent=2, ensure_ascii=False).replace("\n", "\n" + base)


def _root(text):
    i = _skip(text, 0)
    if i >= len(text) or text[i] != "{":
        raise ValueError("the file is not a JSON object")
    return i


def _insert_member(text, obj_start, key, value):
    members, close = _members(text, obj_start)
    if members:
        last_end = members[-1][3]
        ind = _indent_at(text, members[-1][1])
        piece = f',\n{ind}{json.dumps(key)}: {_dump(value, ind)}'
        return text[:last_end] + piece + text[last_end:]
    outer = _indent_at(text, obj_start)
    ind = outer + "  "
    return text[:obj_start + 1] + f'\n{ind}{json.dumps(key)}: {_dump(value, ind)}\n{outer}' + text[close:]


def edit_servers(text, top_key, entries, remove=()):
    """Returns (new_text, report). Adds missing entries, updates entries that are ours, never touches
    any other entry (same name but not ours = kept and reported), removes `remove` names if ours."""
    report = {"added": [], "updated": [], "unchanged": [], "kept_yours": [], "removed": []}
    if not text.strip():
        text = "{\n}\n"
    root = _root(text)
    members, _ = _members(text, root)
    if top_key not in [m[0] for m in members]:
        text = _insert_member(text, root, top_key, {})
    for name, value in entries.items():
        root = _root(text)
        blk = next(m for m in _members(text, root)[0] if m[0] == top_key)
        if text[blk[2]] != "{":
            raise ValueError(f'"{top_key}" is not an object')
        cur = next((m for m in _members(text, blk[2])[0] if m[0] == name), None)
        if cur is None:
            text = _insert_member(text, blk[2], name, value)
            report["added"].append(name)
            continue
        old = json.loads(re.sub(r",\s*([}\]])", r"\1", re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", text[cur[2]:cur[3]], flags=re.S)))
        if old == value:
            report["unchanged"].append(name)
        elif is_ours(old):
            text = text[:cur[2]] + _dump(value, _indent_at(text, cur[1])) + text[cur[3]:]
            report["updated"].append(name)
        else:
            report["kept_yours"].append(name)
    for name in remove:
        root = _root(text)
        blk = next((m for m in _members(text, root)[0] if m[0] == top_key), None)
        if not blk or text[blk[2]] != "{":
            continue
        mem, close = _members(text, blk[2])
        idx = next((k for k, m in enumerate(mem) if m[0] == name), None)
        if idx is None:
            continue
        old = json.loads(re.sub(r",\s*([}\]])", r"\1", re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", text[mem[idx][2]:mem[idx][3]], flags=re.S)))
        if not is_ours(old):
            continue
        if idx > 0:
            start, end = mem[idx - 1][3], mem[idx][3]                     # from the previous value: removes ", name: {...}"
        elif len(mem) > 1:
            start, end = mem[idx][1], mem[idx + 1][1]                      # first of several: up to the next key
        else:
            start, end = blk[2] + 1, close                                 # the only one: empty the object
        text = text[:start] + ("" if len(mem) > 1 else "\n" + _indent_at(text, blk[1])) + text[end:]
        report["removed"].append(name)
    read_jsonc_text(text)                                                  # must still be valid
    return text, report


def read_jsonc_text(txt):
    if not txt.strip():
        return {}
    txt = re.sub(r'("(?:\\.|[^"\\])*")|//[^\n]*|/\*.*?\*/', lambda m: m.group(1) or "", txt, flags=re.S)
    return json.loads(re.sub(r",\s*([}\]])", r"\1", txt))


def git_tracked(path):
    """True when the file is committed in the QA repo's git (then it is shared with the team and never edited)."""
    if not shutil.which("git") or not os.path.isfile(path):
        return False
    code, _ = run(["git", "-C", REPO, "ls-files", "--error-unmatch", os.path.relpath(path, REPO)], timeout=60)
    return code == 0


def shown(path):
    """A path as the user should read it: relative inside the QA repo, full outside it."""
    try:
        rel = os.path.relpath(path, REPO)
        return path if rel.startswith("..") else rel.replace("\\", "/")
    except ValueError:
        return path


def merge_into(path, top_key, entries, label, remove=()):
    """Adds our entries (and updates entries that are ours) in one settings file; nothing else in it changes."""
    try:
        text = open(path, encoding="utf-8-sig").read() if os.path.isfile(path) else ""
        new, rep = edit_servers(text, top_key, entries, remove)
    except Exception as e:
        side = path + ".qa-ai-proposed.json"
        write_json(side, {top_key: entries})
        status("FAIL", f"{label}: settings file left unchanged",
               cause=f"{path} could not be read ({type(e).__name__}); it may contain a syntax error.",
               fix=f"Fix the file, or copy the entries from {side} into its \"{top_key}\" section, then run {RERUN} again.")
        return None
    if rep["kept_yours"]:
        status("WARN", f"{label}: kept your existing {', '.join(rep['kept_yours'])} entr{'y' if len(rep['kept_yours']) == 1 else 'ies'}",
               cause="Entries with these names already exist and were not created by this setup, so they were not changed.",
               fix="If they are your own manual copies of the QA AI servers, delete them and run the installer again; "
                   "if they are other tools, rename them.")
    if new == text:
        if not rep["kept_yours"]:
            status("SKIP", f"{label}: already up to date")
        return rep
    b = backup(path)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp-qa-ai"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(new)
    os.replace(tmp, path)
    parts = [f"{len(rep[k])} {w}" for k, w in (("added", "added"), ("updated", "updated"), ("removed", "old removed")) if rep[k]]
    status("OK", f"{label}: AI tools set up ({', '.join(parts)})",
           detail=f"file {shown(path)}" + (f"; backup {b}" if b else ""))
    return rep


def project_target(rel_path, label):
    """A settings file inside the QA repo, unless the team commits that file (then None: use the fallback)."""
    path = os.path.join(REPO, *rel_path.split("/"))
    if git_tracked(path):
        status("INFO", f"{label}: the team shares this settings file, so your own user settings are used instead", detail=f"{rel_path} is tracked in git")
        return None
    return path


def ignore_line(rel_path):
    gi = os.path.join(REPO, ".gitignore")
    have = [l.strip() for l in open(gi, encoding="utf-8")] if os.path.isfile(gi) else []
    if rel_path in have or "/" + rel_path in have:
        return
    with open(gi, "a", encoding="utf-8") as fh:
        if have and have[-1] != "":
            fh.write("\n")
        fh.write(f"{rel_path}\n")
    status("OK", "Git will ignore this computer's own AI settings", detail=f".gitignore: added {rel_path}")


def cleanup_user_entries(loc, kinds):
    """Earlier versions of this script wrote our entries into the user settings. For the editors whose
    project file is now used (kinds), those copies - ours only, for this QA repo only - are removed so the
    servers do not show twice. The user's own entries are never touched."""
    mine = lambda e: is_ours(e) and json.dumps(REPO)[1:-1] in json.dumps(e)
    files = []
    if "copilot" in kinds:
        files += [(loc["copilot_config"], "mcpServers", "GitHub Copilot user settings")]
        files += [(os.path.join(d, "mcp.json"), "servers", "VS Code user settings") for d in loc["vscode_user_dirs"]]
    if "devin" in kinds:
        files += [(loc["devin_config"], "mcpServers", "Devin Desktop user settings")]
    if "claude" in kinds and os.path.isfile(loc["claude_json"]):
        # entries an earlier version added for this project (local scope) would win over .mcp.json
        try:
            data = json.load(open(loc["claude_json"], encoding="utf-8"))
            norm = lambda p: os.path.normcase(os.path.normpath(p)).replace("\\", "/").rstrip("/")
            proj = next((v for k, v in (data.get("projects") or {}).items() if norm(k) == norm(REPO)), None)
            servers = (proj or {}).get("mcpServers") or {}
            names = [n for n, e in servers.items() if n in SERVER_NAMES and mine(e)]
            if names:
                b = backup(loc["claude_json"])
                for n in names:
                    del servers[n]
                write_json(loc["claude_json"], data)
                status("OK", f"Claude Code user settings: {len(names)} old entr{'y' if len(names) == 1 else 'ies'} of this project removed "
                             f"(.mcp.json is used now); backup {os.path.basename(b)}")
        except Exception as e:
            status("WARN", "Claude Code user settings could not be checked for older entries",
                   cause=f"{loc['claude_json']} could not be read ({type(e).__name__}).",
                   fix="Close VS Code and run the installer again. If tools show twice in Claude Code, remove the older ones with /mcp.")
    for path, key, label in files:
        if not os.path.isfile(path):
            continue
        try:
            block = (read_jsonc(path).get(key) or {})
        except Exception:
            continue
        names = [n for n, e in block.items() if n in SERVER_NAMES and mine(e)]
        if names:
            merge_into(path, key, {}, label, remove=names)


def write_settings(editor, det, loc, defs, user_settings=False):
    """Project files first (inside this QA repo, git-ignored, one per editor); the user's own settings files
    only when a project file is shared in git, or when asked with --user-settings. Only our entries change."""
    project_used = set()
    editor = pick_vscode(editor, det)
    if editor in ("copilot", "claude"):
        if not det["vscode"]:
            status("WARN", "VS Code was not found on this computer",
                   cause="The settings are written anyway, ready for when VS Code is installed.",
                   fix="If VS Code is installed in a custom folder, ignore this.")
        want_copilot = editor == "copilot"                 # only the editor the user chose: nothing for the other one
        want_claude = editor == "claude"
        if want_copilot:
            p = project_target(".vscode/mcp.json", "GitHub Copilot")
            if p:
                if merge_into(p, "servers", as_format(defs, "vscode", REPO), "GitHub Copilot (this project, .vscode/mcp.json)") is not None:
                    ignore_line(".vscode/mcp.json")
                    project_used.add("copilot")
            if not p or user_settings:
                merge_into(loc["copilot_config"], "mcpServers", as_format(defs, "copilot", REPO), "GitHub Copilot (your user settings)")
                for d in [d for d in loc["vscode_user_dirs"] if os.path.isdir(d)] or loc["vscode_user_dirs"][:1]:
                    merge_into(os.path.join(d, "mcp.json"), "servers", as_format(defs, "vscode", REPO), "VS Code (your user settings)")
            if not det["copilot"]:
                status("INFO", "GitHub Copilot Chat was not found; its settings are ready for when you install it")
        if want_claude:
            p = project_target(".mcp.json", "Claude Code")
            if p:
                if merge_into(p, "mcpServers", as_format(defs, "claude", REPO), "Claude Code (this project, .mcp.json)") is not None:
                    ignore_line(".mcp.json")
                    project_used.add("claude")
                    status("INFO", "Claude Code asks once to approve this project's MCP servers: approve all of them")
            if not p or user_settings:
                setup_claude(det, loc, defs, REPO)
            if not (det["claude_ext"] or det["claude_cli"]):
                status("INFO", "Claude Code was not found in VS Code; its settings are ready for when you install it")
    else:
        if not det["devin"]:
            status("WARN", "Devin Desktop was not found on this computer",
                   cause="The settings are written anyway, ready for when Devin Desktop is installed.",
                   fix="If Devin Desktop is installed in a custom folder, ignore this.")
        p = project_target(".devin/mcp_config.local.json", "Devin Desktop")
        if p:
            if merge_into(p, "mcpServers", as_format(defs, "devin", REPO), "Devin Desktop (this project, .devin/mcp_config.local.json)") is not None:
                ignore_line(".devin/mcp_config.local.json")
                project_used.add("devin")
        if not p or user_settings:
            merge_into(loc["devin_config"], "mcpServers", as_format(defs, "devin", REPO), "Devin Desktop (your user settings)")
        if devin_is_old(loc):                        # older Devin reads mcpServers from .devin/config.local.json
            lp = project_target(".devin/config.local.json", "Devin Desktop (older version)")
            if lp and merge_into(lp, "mcpServers", as_format(defs, "devin", REPO),
                                 "Devin Desktop, older version (this project, .devin/config.local.json)") is not None:
                ignore_line(".devin/config.local.json")
    if not user_settings:
        cleanup_user_entries(loc, project_used)


EDITOR_NAMES = {"devin": "Devin Desktop", "copilot": "VS Code with GitHub Copilot", "claude": "VS Code with Claude Code"}


def pick_vscode(editor, det):
    """'vscode' (older option) means the one assistant found in VS Code: GitHub Copilot unless only Claude Code is there."""
    if editor != "vscode":
        return editor
    return "claude" if (det.get("claude_ext") or det.get("claude_cli")) and not det.get("copilot") else "copilot"


def remove_other_editors(editor, loc):
    """Only the chosen editor keeps our files. What an earlier install added for the other editors is removed:
    our MCP entries for this QA repo (the user's own entries stay) and our slash command files (only when they
    are exactly ours). Nothing else is touched; a removed command file is kept as a backup."""
    mine = lambda e: is_ours(e) and json.dumps(REPO)[1:-1] in json.dumps(e)
    others = [k for k in ("devin", "copilot", "claude") if k != editor]
    project = {"copilot": (".vscode/mcp.json", "servers"), "claude": (".mcp.json", "mcpServers"),
               "devin": (".devin/mcp_config.local.json", "mcpServers")}
    removed = 0
    for k in others:
        rel, key = project[k]
        targets = [(os.path.join(REPO, rel), key)]
        if k == "devin":
            targets.append((os.path.join(REPO, ".devin", "config.local.json"), "mcpServers"))
        for path, key_ in targets:
            if not os.path.isfile(path) or git_tracked(path):
                continue
            try:
                data = read_jsonc(path)
            except Exception:
                continue
            names = [n for n, e in (data.get(key_) or {}).items() if n in SERVER_NAMES and mine(e)]
            if not names:
                continue
            merge_into(path, key_, {}, f"{EDITOR_NAMES[k]} (not your chosen editor)", remove=names)
            removed += len(names)
            try:
                left = read_jsonc(path)
                if left == {key_: {}} or left == {}:            # the file held only our entries: remove it too
                    os.remove(path)
                    remove_empty_dirs(os.path.dirname(path))
            except Exception:
                pass
        sub = {"copilot": ("copilot", os.path.join(REPO, ".github", "prompts")), "claude": ("claude", os.path.join(REPO, ".claude", "commands"))}.get(k)
        if sub:
            src = os.path.join(HERE, "editor-commands", sub[0])
            for f in sorted(glob.glob(os.path.join(src, "*.md"))):
                d = os.path.join(sub[1], os.path.basename(f))
                if not os.path.isfile(d) or git_tracked(d):
                    continue
                try:
                    body = open(d, encoding="utf-8").read()
                except OSError:
                    continue
                if body == open(f, encoding="utf-8").read() or "qa-ai-skills/skills/" in body:
                    b = backup(d)
                    os.remove(d)
                    removed += 1
                    status("OK", f"Removed {os.path.relpath(d, REPO)} ({EDITOR_NAMES[k]} is not your chosen editor)"
                           + (f"; backup {os.path.basename(b)}" if b else ""))
            try:
                remove_empty_dirs(sub[1])
            except OSError:
                pass
    if not removed:
        status("SKIP", f"Nothing installed for other editors (only {EDITOR_NAMES[editor]} is set up)")


def devin_is_old(loc):
    """True when this computer's Devin is a version before v3000.3, which reads MCP servers from config.json
    instead of mcp_config.json: the old file holds servers and the new one does not exist, or the project
    already has the old file. QA_AI_DEVIN_LEGACY=1 forces it."""
    if os.environ.get("QA_AI_DEVIN_LEGACY") == "1" or os.path.isfile(os.path.join(REPO, ".devin", "config.local.json")):
        return True
    old = loc.get("devin_old_user")
    if old and os.path.isfile(old) and not os.path.isfile(loc["devin_config"]):
        try:
            return "mcpServers" in open(old, encoding="utf-8").read()
        except OSError:
            return False
    return False


def claude_command(cli):
    """The claude command as a list. An npm-installed claude on Windows is a .cmd file; calling it through cmd
    can garble the JSON argument, so its own cli.js is run with node instead when it can be found."""
    if os.name == "nt" and cli.lower().endswith((".cmd", ".bat")):
        js = os.path.join(os.path.dirname(cli), "node_modules", "@anthropic-ai", "claude-code", "cli.js")
        node = shutil.which("node")
        if os.path.isfile(js) and node:
            return [node, js]
    return [cli]


def setup_claude(det, loc, defs, repo):
    entries = as_format(defs, "claude", repo)
    cli = find_claude_cli(det)
    if cli:
        base = claude_command(cli)
        failed = []
        for name, e in entries.items():
            code, cur = run(base + ["mcp", "get", name], cwd=repo, timeout=120)
            if code == 0 and cur.strip() and not any(m in cur for m in OUR_MARKERS):
                status("WARN", f"Claude Code: kept your existing {name} entry",
                       cause="An entry with this name already exists and was not created by this setup.",
                       fix="If it is your own manual copy, remove it (claude mcp remove " + name + ") and run the installer again.")
                continue
            run(base + ["mcp", "remove", "--scope", "local", name], cwd=repo, timeout=120)
            code, txt = run(base + ["mcp", "add-json", "--scope", "local", name, json.dumps(e)], cwd=repo, timeout=120)
            if code != 0:
                failed.append((name, last_lines(txt, 1)))
        if not failed:
            status("OK", "Claude Code: AI tools set up for this project", detail=f"{len(entries)} entries via claude mcp add-json --scope local")
            return True
        status("WARN", f"Claude Code: the claude command could not add {', '.join(n for n, _ in failed)}",
               cause=failed[0][1] or "The claude command returned an error.",
               fix="Nothing to do: the entries are written into Claude Code's settings file instead.")
    # no claude command: the project's local entries in ~/.claude.json (where `claude mcp add --scope local` puts them)
    path = loc["claude_json"]
    try:
        data = json.load(open(path, encoding="utf-8")) if os.path.isfile(path) else {}
    except Exception as e:
        status("FAIL", "Claude Code: settings file left unchanged",
               cause=f"{path} could not be read ({type(e).__name__}); VS Code may have it open.",
               fix=f"Close VS Code completely, then run {RERUN} again.")
        return False
    projects = data.setdefault("projects", {})
    norm = lambda p: os.path.normcase(os.path.normpath(p)).replace("\\", "/").rstrip("/")
    key = next((k for k in projects if norm(k) == norm(repo)), None) or \
        (repo.replace("\\", "/") if os.name == "nt" else repo)
    proj = projects.setdefault(key, {})
    servers = proj.setdefault("mcpServers", {})
    yours = [n for n in entries if n in servers and servers[n] != entries[n] and not is_ours(servers[n])]
    if yours:
        status("WARN", f"Claude Code: kept your existing {', '.join(yours)} entr{'y' if len(yours) == 1 else 'ies'}",
               cause="Entries with these names already exist and were not created by this setup.",
               fix="If they are your own manual copies, remove them with /mcp in Claude Code and run the installer again.")
        entries = {n: v for n, v in entries.items() if n not in yours}
    if all(servers.get(n) == v for n, v in entries.items()):
        status("OK", "Claude Code: AI tools already set up", detail=f"file {path}")
        return True
    b = backup(path)
    servers.update(entries)
    write_json(path, data)
    status("OK", "Claude Code: AI tools set up for this project", detail=f"{len(entries)} entries in {path}" + (f"; backup {b}" if b else ""))
    return True


# ======================================================================== proving the servers
def probe(name, cmd, args, env=None, cwd=None, timeout=90):
    """Starts an MCP server, sends initialize and tools/list, and waits for the answers."""
    full_env = dict(os.environ, **(env or {}))
    try:
        p = subprocess.Popen([cmd] + list(args), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             cwd=cwd, env=full_env)
    except Exception as e:
        return False, f"could not start: {e}"
    lines, err = [], []
    def rd(stream, sink):
        try:
            for raw in iter(stream.readline, b""):
                sink.append(raw.decode("utf-8", "replace"))
        except Exception:
            pass
    threading.Thread(target=rd, args=(p.stdout, lines), daemon=True).start()
    threading.Thread(target=rd, args=(p.stderr, err), daemon=True).start()
    try:
        for m in ({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "qa-ai-setup", "version": "1"}}},
                  {"jsonrpc": "2.0", "method": "notifications/initialized"},
                  {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}):
            p.stdin.write((json.dumps(m) + "\n").encode())
        p.stdin.flush()
    except Exception:
        pass
    end, tools = time.time() + timeout, None
    while time.time() < end and tools is None:
        for l in list(lines):
            try:
                msg = json.loads(l)
            except ValueError:
                continue
            if msg.get("id") == 2 and "result" in msg:
                tools = len(msg["result"].get("tools", []))
        if p.poll() is not None and tools is None:
            time.sleep(0.3)
            if not any('"id": 2' in l or '"id":2' in l for l in lines):
                break
        time.sleep(0.2)
    try:
        p.kill()
        p.wait(timeout=10)
    except Exception:
        pass
    if tools is not None:
        return True, f"answers ({tools} tools)"
    errs = [l.strip() for l in "".join(err).splitlines() if l.strip() and not l.startswith((" ", "\t", "Traceback"))]
    why = (errs[-1][:200] if errs else "") or ("it stopped" if p.poll() is not None else f"no answer within {timeout} seconds")
    return False, why


SERVER_ROLE = {"robotmcp": "Robot Framework MCP", "playwright": "Playwright MCP (own browser)",
               "playwright-attach": "Playwright MCP (attach to test browser)",
               "playwright-session": "Playwright MCP (logged-in second window)", "qtest": "qTest MCP"}


def prove_servers(defs, repo, skip=()):
    """Starts each AI tool once, under ONE progress line with a percentage; then one plain line per tool."""
    ok_all, results = True, []
    todo = [n for n in defs if n not in skip]
    with Spinner("Please wait: starting the AI tools", pct=0) as sp:
        for k, name in enumerate(todo):
            d = defs[name]
            ok, msg = probe(name, d["command"], d["args"], d.get("env"), repo)
            results.append((name, ok, msg))
            log_only(f"{name}: {'answers' if ok else 'failed'}: {msg}")
            sp.pct = 100 * (k + 1) / max(1, len(todo))
    for name in defs:
        if name in skip:
            status("SKIP", f"{SERVER_ROLE.get(name, name)}: not started ({skip[name]})")
    for name, ok, msg in results:
        role = SERVER_ROLE.get(name, name)
        if ok:
            status("OK", f"{role} is ready")
            continue
        ok_all = False
        py = sys.executable
        fix = {"robotmcp": f"Run it by hand in the repo root to see the error: \"{py}\" -m robotmcp.server\n"
                           f"If it says no module named robotmcp: \"{py}\" -m pip install rf-mcp",
               "qtest": f"Run: \"{py}\" qa-ai-skills/skills/qtest/qtest_mcp.py --check"}.get(
            name, f"Check Node.js with: node --version   (18 or newer). Then run {RERUN} again; it reinstalls the Playwright MCP if needed.")
        status("FAIL", f"{role} did not start", cause=msg, fix=fix)
    return ok_all


def skip_for(robot_ok):
    if not robot_ok:
        return {"robotmcp": "Robot Framework is needed first"}
    if not rf_mcp_installed():
        return {"robotmcp": "rf-mcp is not installed"}
    return {}


SELF_TESTS = [("extract_repo", ("qa-knowledge-setup", "extract_repo.py"), "reads your Robot tests, keywords and locators"),
              ("extract_dev", ("qa-knowledge-setup", "extract_dev.py"), "reads the development code"),
              ("dev_repos", ("qa-knowledge-setup", "dev_repos.py"), "clones and refreshes the development repos"),
              ("script_check", ("qa-knowledge-setup", "script_check.py"), "checks generated scripts"),
              ("split_extract", ("qa-knowledge-setup", "split_extract.py"), "splits the knowledge into modules"),
              ("qtest_mcp", ("qtest", "qtest_mcp.py"), "fetches test cases from qTest"),
              ("tc_reader", ("test-cases", "tc_reader.py"), "reads test case files and runs batches"),
              ("knowledge_build", ("qa-knowledge-setup", "knowledge_build.py"), "writes the keyword and locator knowledge"),
              ("ai_run", ("ai_run.py",), "times every step and writes the run summary"),
              ("ai_session", ("ai_session.py",), "suggests and checks locators in the live session"),
              ("bg_job", ("bg_job.py",), "runs long steps in the background so the editor never hangs"),
              ("coverage", ("qa-knowledge-setup", "coverage.py"), "builds the coverage map, gap and regression gap analysis")]


def parse_self_test(txt):
    """(passed, ok_count, total, failed_names) from any of the skills' self-test outputs."""
    m = re.search(r"SELF-TEST (PASSED|FAILED)\s*\((\d+) of (\d+) OK", txt)
    fails = [re.sub(r"^\[?FAIL\]?\s*", "", l.strip()) for l in txt.splitlines() if re.match(r"\s*\[?FAIL\b", l)]
    if m:
        return m.group(1) == "PASSED", int(m.group(2)), int(m.group(3)), fails
    oks = [l for l in txt.splitlines() if re.match(r"\s*\[?OK\b", l)]
    if re.search(r"SELF-TEST PASSED", txt) and oks and not fails:          # older output format
        return True, len(oks), len(oks), []
    return None, len(oks), len(oks) + len(fails), fails


DEV_PARTS = {"extract_dev", "dev_repos", "coverage"}     # need development repos: checked only once they are set up


def dev_repos_set_up():
    k = os.path.join(REPO, "qa-ai-skills", "knowledge")
    return os.path.isfile(os.path.join(k, "dev-config.md")) or os.path.isdir(os.path.join(k, ".extract", "dev"))


def run_self_tests(git_ok, robot_ok=True):
    """The configuration test: every part of the skills is checked on sample data, under ONE progress line.
    Only the overall result is shown; a part that fails is named in plain words with the command that shows why.
    Every detail still goes to the setup log."""
    ok_all, passed_parts, checks, skipped = True, 0, 0, []
    dev = dev_repos_set_up()
    parts = [x for x in SELF_TESTS if dev or x[0] not in DEV_PARTS]
    if not dev:
        log_only("Development repos are not set up: the development code parts are not checked (" + ", ".join(sorted(DEV_PARTS)) + ")")
    with Spinner("Please wait: checking the configuration", pct=0) as sp:
        for k, (name, rel, what) in enumerate(parts, 1):
            path = os.path.join(HERE, *rel)
            need = {"extract_repo": (robot_ok, "needs Robot Framework"), "dev_repos": (git_ok, "needs Git")}.get(name, (True, ""))
            sp.pct = 100 * (k - 1) / len(parts)
            if not os.path.isfile(path):
                ok_all = False
                LOG_LINES.append(f"  [FAIL] {name}: {path} missing")
                RESULTS.append(("FAIL", f"Configuration check: a part is missing ({what})",
                                f"{os.path.relpath(path, REPO)} is not there; the qa-ai-skills folder is incomplete.",
                                "Unzip the full qa-ai-skills package again into the repo root (replace the folder)."))
                continue
            if not need[0]:
                skipped.append(f"{what} ({need[1]})")
                LOG_LINES.append(f"  [SKIP] {name}: {need[1]}")
                continue
            code, txt = run([sys.executable, path, "--self-test"], cwd=REPO, timeout=900)
            passed, n_ok, n_all, fails = parse_self_test(txt)
            LOG_LINES.append(f"  {'[ OK ]' if passed else '[FAIL]'} {name}: {n_ok}/{n_all} checks" + (f"; failed: {'; '.join(fails[:6])}" if fails else ""))
            sp.pct = 100 * k / len(parts)
            if passed:
                passed_parts += 1
                checks += n_all
                continue
            ok_all = False
            why = ("Failed checks: " + "; ".join(fails[:3]) + (" ..." if len(fails) > 3 else "")) if (passed is False or fails) else \
                (last_lines(txt, 1) or f"exit code {code}") + (" (time limit reached)" if code == 124 else "")
            RESULTS.append(("FAIL", f"Configuration check: the part that {what} does not work", why,
                            f"See the details: \"{sys.executable}\" {os.path.relpath(path, REPO)} --self-test\n"
                            "Share that output and the setup log with the QA AI skills owner."))
    for st_, text, cause, fix in [r for r in RESULTS if r[1].startswith("Configuration check:")]:
        RESULTS.remove((st_, text, cause, fix))
        status(st_, text, fix=fix, cause=cause)
    if ok_all:
        status("OK", "Configuration check passed: everything is working" +
               ("" if dev else " (the development code parts are checked once development repos are added)"),
               detail=f"{passed_parts} parts, {checks} checks")
    for sk in skipped:
        status("SKIP", f"Not checked on this computer: {sk}")
    return ok_all


# ======================================================================== qTest and git-ignore
def set_env_values(path, values):
    lines = open(path, encoding="utf-8").read().splitlines() if os.path.isfile(path) else []
    done = set()
    for i, l in enumerate(lines):
        m = re.match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=", l)
        if m and m.group(1) in values:
            lines[i] = f"{m.group(1)}={values[m.group(1)]}"
            done.add(m.group(1))
    for k, v in values.items():
        if k not in done:
            lines.append(f"{k}={v}")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def setup_qtest(interactive):
    env_path = os.path.join(REPO, ".env")
    if not interactive:
        status("SKIP", f"qTest not connected in a non-interactive run (run {RERUN} in a terminal to connect it)")
        return
    if menu("Connect qTest now?", ["Yes, connect qTest", "Skip for now (you can connect it later by running the installer again)"]) == 1:
        status("SKIP", "qTest connection skipped")
        return
    back = lambda x: x.strip().lower() in ("b", "back")
    skipped = lambda: status("SKIP", f"qTest skipped for now; nothing was saved (connect it later with {RERUN})")
    out(f"    {c('Type B and press Enter at any qTest question to go back and skip qTest.', 'grey')}")
    while True:
        url = ask_text("qTest URL", example="https://yourcompany.qtestnet.com, or B to go back").rstrip("/")
        if back(url):
            return skipped()
        if re.match(r"^https?://[^\s/]+", url):
            break
        out(f"    {c('Enter the full address, starting with https:// (or B to go back)', 'amber')}")
    while True:
        pid = ask_text("qTest project ID", example="12345, the number in the project's URL, or B to go back")
        if back(pid):
            return skipped()
        if pid.isdigit():
            break
        out(f"    {c('The project ID is a number only (or B to go back).', 'amber')}")
    where = menu("Where should the qTest API token come from?",
                 ["Paste it now  (saved only in this repo's .env file, which git ignores)",
                  "Read it from the vault  (by its key name, for example QTEST_TOKEN)",
                  "Back: skip qTest for now  (nothing is saved)"])
    if where == 2:
        return skipped()
    values = {"QTEST_URL": url, "QTEST_PROJECT_ID": pid}
    if where == 0:
        tok = ask_secret("qTest API token", "qTest > Resources > API & SDK; characters show as *; press Enter alone to go back")
        if not tok:
            return skipped()
        values["QTEST_TOKEN"] = tok
        status("OK", f"API token received ({len(tok)} characters); it is never shown or logged")
    else:
        while True:
            name = ask_text("Vault key name of the qTest token", default="QTEST_TOKEN",
                            example="QTEST_TOKEN, which your vault loader sets as ${QTEST_TOKEN}, or B to go back")
            if back(name):
                return skipped()
            name = re.sub(r"^[$@&%]\{(.*)\}$", r"\1", name.strip())
            if re.match(r"^[A-Za-z_][A-Za-z0-9_ ]*$", name):
                break
            out(f"    {c('Use the name only, for example QTEST_TOKEN (letters, digits and _).', 'amber')}")
        values["QTEST_VAULT_NAME"] = name
        extra = ask_text("Robot options your vault loader needs (press Enter if none)", example="--variable ENV:QA")
        if extra:
            values["QTEST_VAULT_ROBOT_ARGS"] = extra
    set_env_values(env_path, values)
    status("OK", f"qTest settings saved in {os.path.relpath(env_path, REPO)}")
    with Spinner("Connecting to qTest"):
        code, txt = run([sys.executable, os.path.join(HERE, "qtest", "qtest_mcp.py"), "--root", REPO, "--check"], cwd=REPO, timeout=240)
    try:
        res = json.loads(txt[txt.index("{"):])
    except Exception:
        res = {}
    err0 = res.get("error") or res.get("note") or ""
    if not res.get("ok") and "QTEST_VAULT_NAME" in values and "not known yet" in err0:
        status("INFO", f"Vault key {values['QTEST_VAULT_NAME']} saved. qTest is connected automatically after the knowledge setup "
                       f"finds your vault loader; check it then with {RERUN} check")
        return
    if res.get("ok"):
        status("OK", f"qTest connected: project \"{res.get('project_name')}\" (token from {res.get('token_from')})")
    else:
        err = res.get("error") or res.get("note") or last_lines(txt, 1)
        fix = "Check the URL, project ID and token, then run the installer again."
        if re.search(r"cannot reach|tunnel|proxy|SSL|certificate|resolve|timed out|connection|getaddrinfo", err or "", re.I):
            fix = "qTest could not be reached from this computer: check the URL, your VPN and the company proxy, then run the installer again."
        elif re.search(r"vault", err or "", re.I):
            fix = "Check the vault key name and the Robot options your vault loader needs, then run the installer again."
        elif re.search(r"\b40[13]\b|unauthori|forbidden", err or "", re.I):
            fix = "The token was refused: create a new API token in qTest (Resources > API & SDK) and run the installer again."
        elif re.search(r"\b404\b|not found", err or "", re.I):
            fix = "The project was not found: check the project ID (the number in the project's URL in qTest)."
        status("FAIL", "qTest connection failed", cause=err, fix=fix)


def install_commands(det, editor):
    """The /robot-script-generator and /qa-knowledge-setup commands, from skills/editor-commands."""
    src = os.path.join(HERE, "editor-commands")
    targets = []
    editor = pick_vscode(editor, det)
    if editor == "copilot":
        targets.append(("copilot", os.path.join(REPO, ".github", "prompts"), "GitHub Copilot"))
    elif editor == "claude":
        targets.append(("claude", os.path.join(REPO, ".claude", "commands"), "Claude Code"))
    for sub, dest, label in targets:
        files = sorted(glob.glob(os.path.join(src, sub, "*.md")))
        if not files:
            status("WARN", f"{label} slash commands not installed",
                   cause=f"qa-ai-skills/skills/editor-commands/{sub} is missing; the folder is incomplete.",
                   fix="Unzip the full qa-ai-skills package again into the repo root (replace the folder).")
            continue
        new = upd = 0
        for f in files:
            d = os.path.join(dest, os.path.basename(f))
            body = open(f, encoding="utf-8").read()
            if os.path.isfile(d):
                if open(d, encoding="utf-8").read() == body:
                    continue
                backup(d)
                upd += 1
            else:
                new += 1
            os.makedirs(dest, exist_ok=True)
            with open(d, "w", encoding="utf-8") as fh:
                fh.write(body)
        rel = os.path.relpath(dest, REPO).replace("\\", "/")
        if new or upd:
            status("OK", f"{label}: /robot-script-generator and /qa-knowledge-setup commands ready", detail=f"{new} added, {upd} updated in {rel}")
        else:
            status("OK", f"{label}: /robot-script-generator and /qa-knowledge-setup commands ready", detail=f"already in {rel}")


def _tracked_files(path):
    if not shutil.which("git"):
        return False
    code, txt = run(["git", "-C", REPO, "ls-files", "--", os.path.relpath(path, REPO)], timeout=60)
    return code == 0 and bool(txt.strip())


def _move(src, dst):
    """Moves a folder; files committed in git are moved with git mv so their history is kept."""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if _tracked_files(src):
        code, txt = run(["git", "-C", REPO, "mv", os.path.relpath(src, REPO), os.path.relpath(dst, REPO)], timeout=300)
        if code == 0:
            if os.path.exists(src):                        # untracked leftovers that git mv did not take
                for name in os.listdir(src):
                    if not os.path.exists(os.path.join(dst, name)):
                        shutil.move(os.path.join(src, name), os.path.join(dst, name))
                try:
                    os.rmdir(src)
                except OSError:
                    pass
            return "git"
    shutil.move(src, dst)
    return "move"


def move_into_ai_folder():
    """Older versions put the AI files at the root of the QA repo. Everything goes into qa-ai-skills/ now."""
    if not NEW_LAYOUT:
        status("SKIP", "Moving files into qa-ai-skills (the skills are not inside a qa-ai-skills folder)")
        return
    # the folder was called ai-qa-skills before: its data moves in, its old code goes to backup/
    prev = os.path.join(REPO, "ai-qa-skills")
    moves = [("knowledge", "knowledge"), ("ai_generated_tests", "ai_generated_tests"),
             (os.path.join("results", "ai-scriptgen"), "results"), (".ai_session", "session")]
    if os.path.isdir(prev) and os.path.realpath(prev) != os.path.realpath(BASE):
        moves = [(os.path.join("ai-qa-skills", d), d) for d in ("knowledge", "ai_generated_tests", "results", "session", "backup")] + moves
    moved, kept = [], []
    for old, new in moves:
        src, dst = os.path.join(REPO, old), os.path.join(AI_HOME, new)
        if not os.path.isdir(src):
            continue
        if old == "knowledge" and not (os.path.isfile(os.path.join(src, "knowledge-status.md")) or
                                       os.path.isdir(os.path.join(src, ".extract")) or os.path.isfile(os.path.join(src, "app-map.md"))):
            kept.append(f"{old}/ (does not look like the AI knowledge, so it was left where it is)")
            continue
        if os.path.exists(dst) and os.listdir(dst):
            done = 0
            for name in sorted(os.listdir(src)):
                if not os.path.exists(os.path.join(dst, name)):
                    _move(os.path.join(src, name), os.path.join(dst, name))
                    done += 1
                else:
                    kept.append(f"{old}/{name} (qa-ai-skills/{new}/{name} already exists)")
            try:
                os.rmdir(src)
            except OSError:
                pass
            if done:
                moved.append(f"{old}/ -> qa-ai-skills/{new}/ ({done} item(s))")
        else:
            if os.path.isdir(dst):
                os.rmdir(dst)
            how = _move(src, dst)
            moved.append(f"{old}/ -> qa-ai-skills/{new}/" + (" (with git mv)" if how == "git" else ""))
    results = os.path.join(REPO, "results")
    if os.path.isdir(results) and not os.listdir(results):
        os.rmdir(results)
    old_skills = os.path.join(REPO, "skills")
    if os.path.isfile(os.path.join(old_skills, "robot-script-generator.md")) and \
            os.path.realpath(old_skills) != os.path.realpath(HERE):
        dst = os.path.join(AI_HOME, "backup", "skills-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
        _move(old_skills, dst)
        moved.append(f"skills/ (the older copy) -> qa-ai-skills/backup/{os.path.basename(dst)}/")
    if os.path.isdir(prev) and os.path.realpath(prev) != os.path.realpath(BASE):
        left = [n for n in os.listdir(prev) if n not in ("__pycache__",)]
        if left:
            dst = os.path.join(AI_HOME, "backup", "ai-qa-skills-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
            _move(prev, dst)
            moved.append(f"ai-qa-skills/ (the older copy, renamed to qa-ai-skills) -> qa-ai-skills/backup/{os.path.basename(dst)}/")
        else:
            shutil.rmtree(prev, ignore_errors=True)
    for m in moved:
        status("OK", f"Moved {m}")
    for k in kept:
        status("WARN", f"Not moved: {k}",
               fix="If it belongs to the AI skills, move it into qa-ai-skills yourself; otherwise ignore this.")
    if not moved and not kept:
        status("SKIP", "No older AI folders to move into qa-ai-skills/")
    elif moved:
        status("INFO", "Nothing was committed. If these folders were in git, commit the move when you are ready.")


WIN_SHIM = r"""@echo off
rem qa-ai-setup: finds the qa-ai-skills folder of the QA repo you are in and runs its setup.
rem Created by the QA AI Skills setup. Safe to delete; run .\qa-ai-skills\qa-ai-setup install to recreate.
setlocal
set "D=%CD%"
:up
if exist "%D%\qa-ai-skills\qa-ai-setup.cmd" goto found
for %%I in ("%D%\..") do set "P=%%~fI"
if /i "%P%"=="%D%" goto none
set "D=%P%"
goto up
:found
call "%D%\qa-ai-skills\qa-ai-setup.cmd" %*
exit /b %ERRORLEVEL%
:none
echo.
echo   [FAIL]  No qa-ai-skills folder found here
echo           Cause  qa-ai-setup works inside a QA repo that contains the qa-ai-skills folder.
echo           Fix    Open the terminal in your QA repo (or any folder inside it), then run qa-ai-setup install again.
echo.
exit /b 1
"""

SH_SHIM = """#!/bin/sh
# qa-ai-setup: finds the qa-ai-skills folder of the QA repo you are in and runs its setup.
# Created by the QA AI Skills setup. Safe to delete; run sh qa-ai-skills/qa-ai-setup.sh install to recreate.
d=$(pwd)
while :; do
    if [ -f "$d/qa-ai-skills/qa-ai-setup.sh" ]; then exec sh "$d/qa-ai-skills/qa-ai-setup.sh" "$@"; fi
    [ "$d" = "/" ] && break
    d=$(dirname "$d")
done
printf '\n  [FAIL]  No qa-ai-skills folder found here\n'
printf '          Cause  qa-ai-setup works inside a QA repo that contains the qa-ai-skills folder.\n'
printf '          Fix    Open the terminal in your QA repo (or any folder inside it), then run qa-ai-setup install again.\n\n'
exit 1
"""


def _win_user_path_add(folder):
    """Adds a folder to the user's PATH (no admin rights needed); new terminals see it."""
    import winreg, ctypes
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE) as k:
        try:
            cur, kind = winreg.QueryValueEx(k, "Path")
        except FileNotFoundError:
            cur, kind = "", winreg.REG_EXPAND_SZ
        parts = [x for x in cur.split(";") if x]
        if any(os.path.normcase(os.path.expandvars(x)).rstrip("\\") == os.path.normcase(folder).rstrip("\\") for x in parts):
            return False
        winreg.SetValueEx(k, "Path", 0, kind if kind in (winreg.REG_SZ, winreg.REG_EXPAND_SZ) else winreg.REG_EXPAND_SZ,
                          ";".join(parts + [folder]))
    try:
        ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x1A, 0, "Environment", 2, 5000, ctypes.byref(ctypes.c_ulong()))
    except Exception:
        pass
    return True


def register_command(env=None, osname=None, write_registry=True):
    """Makes `qa-ai-setup` a command for this user: a small launcher in a user folder on the PATH.
    Returns (status, message). Nothing needs admin rights."""
    env = os.environ if env is None else env
    osname = osname or OS
    home = env.get("USERPROFILE") or env.get("HOME") or os.path.expanduser("~")
    if osname == "windows":
        base = env.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
        bindir = os.path.join(base, "qa-ai-skills", "bin")
        target, body = os.path.join(bindir, "qa-ai-setup.cmd"), WIN_SHIM.replace("\n", "\r\n")
    else:
        bindir = os.path.join(home, ".local", "bin")
        target, body = os.path.join(bindir, "qa-ai-setup"), SH_SHIM
    os.makedirs(bindir, exist_ok=True)
    same = os.path.isfile(target) and open(target, encoding="utf-8", newline="").read() == body
    if not same:
        with open(target, "w", encoding="utf-8", newline="") as fh:
            fh.write(body)
        if osname != "windows":
            os.chmod(target, 0o755)
    path_added = []
    if osname == "windows":
        if write_registry:
            if _win_user_path_add(bindir):
                path_added.append("your user PATH")
    else:
        on_path = any(os.path.normpath(p) == os.path.normpath(bindir) for p in env.get("PATH", "").split(os.pathsep) if p)
        if not on_path:
            line = '\nexport PATH="$HOME/.local/bin:$PATH"   # added by qa-ai-setup\n'
            shell = os.path.basename(env.get("SHELL", ""))
            if shell == "zsh" or (osname == "mac" and shell != "bash"):
                rc = ".zshrc"
            else:
                rc = ".bashrc" if os.path.isfile(os.path.join(home, ".bashrc")) else ".profile"
            known = [os.path.join(home, f) for f in (".zshrc", ".bashrc", ".profile", ".bash_profile", ".zprofile")]
            if not any(os.path.isfile(f) and ".local/bin" in open(f, encoding="utf-8", errors="replace").read() for f in known):
                with open(os.path.join(home, rc), "a", encoding="utf-8") as fh:
                    fh.write(line)
                path_added.append("~/" + rc)
    if same and not path_added:
        return "SKIP", "qa-ai-setup command already available"
    where = f" ({' and '.join(path_added)} updated)" if path_added else ""
    return "OK", f"qa-ai-setup command ready{where}: open a new terminal, then use qa-ai-setup install / qa-ai-setup check"


def update_gitignore():
    src = os.path.join(HERE, "editor-commands", "gitignore-additions.txt")
    if not os.path.isfile(src):
        src = os.path.join(BASE, "setup", "gitignore-additions.txt")
    gi = os.path.join(REPO, ".gitignore")
    if not os.path.isfile(src):
        status("WARN", ".gitignore not updated",
               cause="qa-ai-skills/skills/editor-commands/gitignore-additions.txt is missing; the folder is incomplete.",
               fix="Unzip the full qa-ai-skills package again into the repo root (replace the folder).")
        return
    want = [l.rstrip() for l in open(src, encoding="utf-8") if l.strip() and not l.lstrip().startswith("#")]
    if os.path.isfile(gi):                       # lines an earlier version added for the old folder name are renamed in place
        old_lines = {l.replace("qa-ai-skills/", "ai-qa-skills/", 1): l for l in want if l.startswith("qa-ai-skills/")}
        text = open(gi, encoding="utf-8").read()
        new = "\n".join(old_lines.get(l.strip(), l) for l in text.split("\n")).replace(
            "# AI QA skills (added by ai-qa-skills/setup_ai_qa.py)", "# QA AI skills (added by the qa-ai-setup installer)")
        if new != text:
            with open(gi, "w", encoding="utf-8") as fh:
                fh.write(new)
    have = [l.strip() for l in open(gi, encoding="utf-8")] if os.path.isfile(gi) else []
    missing = [l for l in want if l.strip() not in have]
    if not missing:
        status("OK", "Git already ignores the AI work files and your .env")
        return
    with open(gi, "a", encoding="utf-8") as fh:
        if have and have[-1] != "":
            fh.write("\n")
        fh.write("# QA AI skills (added by the qa-ai-setup installer)\n" + "\n".join(missing) + "\n")
    status("OK", "Git will ignore the AI work files and your .env", detail=f".gitignore: {len(missing)} line(s) added: {', '.join(missing)}")


# ======================================================================== main
def main(argv=None):
    ap = argparse.ArgumentParser(prog="qa-ai-setup", description=f"{PRODUCT} installer: sets up the QA AI tools for this QA repo.",
                                 epilog="Run it again at any time: completed steps are not repeated, and your own settings are never changed.")
    ap.add_argument("command", nargs="?", default="install", choices=["install", "check", "help"],
                    help="install (default): install or update.  check: verify tools, MCP servers and self-tests only.")
    ap.add_argument("--editor", choices=["devin", "copilot", "claude", "vscode"],
                    help="skip the editor question: devin, copilot (VS Code with GitHub Copilot) or claude (VS Code with Claude Code)")
    ap.add_argument("--yes", action="store_true", help="no questions (qTest is skipped)")
    ap.add_argument("--no-install", action="store_true", help="do not download rf-mcp or the Playwright MCP")
    ap.add_argument("--user-settings", action="store_true", help="also write the editor's user settings (if the editor does not read the project file)")
    ap.add_argument("--no-self-tests", action="store_true", help="skip the self-tests at the end")
    ap.add_argument("--check", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--move-only", action="store_true", help="only move older AI folders into qa-ai-skills")
    ap.add_argument("--self-test", action="store_true", help="test this installer itself")
    a = ap.parse_args(argv)
    if a.command == "help":
        ap.print_help()
        return 0
    if a.command == "check":
        a.check = True
    if a.self_test:
        return self_test()
    if a.move_only:
        out("Moving the AI files into qa-ai-skills/")
        move_into_ai_folder()
        return 0
    init_terminal()
    global RERUN
    if shutil.which("qa-ai-setup"):
        RERUN = "qa-ai-setup " + ("check" if a.check else "install")
    elif a.check:
        RERUN = FIRST_RUN + " check"
    interactive = tty() and not a.yes
    loc = locations()
    det = detect_editors(loc)
    v = sys.version_info
    banner([("Repository", REPO)] + ([("AI folder", AI_HOME)] if NEW_LAYOUT else []) +
           [("System", f"{platform.system()} {platform.release()}  |  Python {v.major}.{v.minor}.{v.micro}"),
            ("Mode", "Check only" if a.check else "Install" + ("  (no downloads)" if a.no_install else ""))])
    def has_robot_files():
        for root, dirs, files in os.walk(REPO):
            dirs[:] = [d for d in dirs if d not in ("node_modules", ".git", "skills", "qa-ai-skills", "venv", ".venv", "results")]
            if any(f.endswith(".robot") for f in files):
                return True
        return False
    if not has_robot_files():
        status("WARN", "No .robot files found in this repository",
               cause=f"The setup uses {REPO} as the QA repo, and it has no Robot Framework tests.",
               fix="Put the qa-ai-skills folder directly in the root of your QA repo, then run the installer from there.")
    editor = a.editor
    if not editor and not a.check:
        found = lambda x: " (found on this computer)" if x else ""
        if interactive:
            editor = ["devin", "copilot", "claude"][menu("Which editor do you want to use? (only that one is set up)",
                                                         [f"Devin Desktop{found(det['devin'])}",
                                                          f"VS Code with GitHub Copilot{found(det['copilot'])}",
                                                          f"VS Code with Claude Code{found(det['claude_ext'] or det['claude_cli'])}"],
                                                         default=0)]
        else:
            editor = "vscode" if det["vscode"] and not det["devin"] else "devin"
    if editor:
        editor = pick_vscode(editor, det)
    total = 3 if a.check else 6
    try:
        if editor and not interactive:
            out(f"  {c('Editor'.ljust(12), 'dim')}{EDITOR_NAMES[editor]}")
        heading(1, total, "Checking your computer")
        if not a.check:
            move_into_ai_folder()
        py_ok = check_python()
        robot_ok = check_robot()
        node, npm = check_node()
        git = check_git()
        if a.check:
            pw_cli, _ = playwright_cli(npm, loc)
            browser, browser_args = find_browser()
            defs = server_defs(REPO, sys.executable, node, pw_cli, browser_args)
            heading(2, total, "Starting the AI tools")
            prove_servers(defs, REPO, skip_for(robot_ok))
            if not a.no_self_tests:
                heading(3, total, "Checking the configuration (please wait, about a minute)")
                run_self_tests(bool(git), robot_ok)
            return finish(None, det)
        heading(2, total, "Installing the AI tools (only what is missing)")
        install_rf_mcp(not a.no_install) if robot_ok else status("SKIP", "Robot Framework MCP (Robot Framework is needed first)")
        pw_cli = install_playwright_mcp(npm, loc, not a.no_install)
        browser, browser_args = find_browser()
        if browser == "chrome":
            status("OK", "Google Chrome found (the Playwright MCP uses it)")
        elif browser == "msedge":
            status("OK", "Microsoft Edge found (the Playwright MCP is set to use it)")
        else:
            status("WARN", "Neither Chrome nor Edge was found",
                   cause="The Playwright MCP opens pages in Chrome (or Edge).",
                   fix="Install Google Chrome (or ask IT), or run: npx playwright install chrome")
        heading(3, total, f"Setting up {EDITOR_NAMES[editor]}")
        defs = server_defs(REPO, sys.executable, node, pw_cli, browser_args)
        if not pw_cli:
            status("WARN", "Playwright servers were not added to the editor",
                   cause="The Playwright MCP is not installed (see step 2).",
                   fix=f"Fix the Playwright MCP step, then run {RERUN} again; the servers are added then.")
        write_settings(editor, det, loc, defs, a.user_settings)
        if editor != "devin":
            install_commands(det, editor)
        else:
            status("OK", "Devin Desktop: use @robot-script-generator and @qa-knowledge-setup in the chat")
        remove_other_editors(editor, loc)
        heading(4, total, "qTest connection (optional)")
        setup_qtest(interactive)
        heading(5, total, "Repository settings")
        update_gitignore()
        try:
            st, msg = register_command()
            status(st, msg)
        except Exception as e:
            status("WARN", "qa-ai-setup command could not be registered",
                   cause=f"{type(e).__name__}: {e}",
                   fix=f"Keep using {FIRST_RUN} install from the QA repo root; everything else works the same.")
        heading(6, total, "Final check (please wait, about a minute)")
        prove_servers(defs, REPO, skip_for(robot_ok))
        if not a.no_self_tests:
            run_self_tests(bool(git), robot_ok)
        return finish(editor, det)
    except KeyboardInterrupt:
        out("")
        out(f"  {c('Stopped.', 'amber_b')} Nothing was left half-written. Run {RERUN} again to continue.")
        return 130


def finish(editor, det):
    n = {k: sum(1 for x in RESULTS if x[0] == k) for k in ("OK", "SKIP", "WARN", "FAIL")}
    out("")
    out(f"  {c('Summary', 'bold')}")
    out("  " + rule())
    for label, k, style in (("Passed", "OK", "green_b"), ("Skipped", "SKIP", "grey"), ("Warnings", "WARN", "amber_b"), ("Failed", "FAIL", "red_b")):
        out(f"  {label.ljust(12)}{c(str(n[k]).rjust(3), style if n[k] else 'grey')}")
    issues = [x for x in RESULTS if x[0] in ("FAIL", "WARN")]
    if issues:
        out("")
        out(f"  {c('Action required', 'red_b' if n['FAIL'] else 'amber_b')}")
        for i, (st, text, cause, fix) in enumerate(sorted(issues, key=lambda x: x[0] != "FAIL"), 1):
            out(f"  {i}. {c(TAGS[st][0], TAGS[st][1])}  {text}")
            if cause:
                out(f"           {c('Cause', 'dim')}  {str(cause).splitlines()[0]}")
            if fix:
                for j, line in enumerate(str(fix).splitlines()):
                    out(f"           {c('Fix  ', 'amber') if j == 0 else '     '}  {line}")
    steps = []
    if editor in ("copilot", "claude", "vscode"):
        steps = ["Close VS Code completely (every window), then open it again with this QA repo."]
        if editor == "claude":
            steps.append("Claude Code: type /mcp in its chat; approve the project's servers when asked.")
        else:
            steps.append("GitHub Copilot: choose Agent mode in the chat; the servers appear under Configure Tools.")
        steps.append("Build the knowledge once: /qa-knowledge-setup")
        steps.append("Generate a script: /robot-script-generator TC-1234   (or: /robot-script-generator qtest TC-1234)")
    elif editor == "devin":
        steps = ["Close Devin Desktop completely, then open it again with this QA repo.",
                 "See the servers: open Customize (in the Agents window, or Customize in the agent sidebar) > MCPs tab > "
                 "'Install MCPs for: This computer'. robotmcp, playwright, playwright-attach, playwright-session and qtest are "
                 "listed; use Refresh if one is missing. (No Customize page means an older Devin: update it, or run "
                 "the setup again with QA_AI_DEVIN_LEGACY=1 so the servers are also written where older versions read them.)",
                 "Build the knowledge once: @qa-knowledge-setup",
                 "Generate a script: @robot-script-generator TC-1234   (or: @robot-script-generator qtest TC-1234)"]
    if steps:
        out("")
        out(f"  {c('Next steps', 'bold')}")
        for i, st in enumerate(steps, 1):
            out(f"  {i}. {st}")
    log = os.path.join(AI_HOME, "results", "setup-log.txt") if NEW_LAYOUT else os.path.join(REPO, "results", "ai-scriptgen", "setup-log.txt")
    out("")
    out("  " + rule())
    if n["FAIL"]:
        out(f"  {c('Setup needs attention', 'red_b')}: {n['FAIL']} item{'s' if n['FAIL'] != 1 else ''} to fix "
            f"(see Action required), then run {c(RERUN, 'bold')} again. Completed steps are not repeated.")
    elif n["WARN"]:
        out(f"  {c('Setup complete', 'green_b')} with {n['WARN']} warning{'s' if n['WARN'] != 1 else ''} to review.")
    else:
        out(f"  {c('Setup complete', 'green_b')}. Everything is ready and working.")
    try:
        os.makedirs(os.path.dirname(log), exist_ok=True)
        with open(log, "w", encoding="utf-8") as fh:
            fh.write("\n".join(re.sub(r"(QTEST_TOKEN=)\S+", r"\1***", l) for l in LOG_LINES) + "\n")
        out(f"  {c('Log', 'dim')}  {log}")
    except OSError:
        pass
    out("")
    return 1 if n["FAIL"] else 0


# ======================================================================== self-test
def self_test():
    ok = {}
    tmp = tempfile.mkdtemp(prefix="qa_ai_setup_selftest_")
    global REPO
    saved_repo = REPO
    try:
        home = os.path.join(tmp, "home")
        repo = os.path.join(tmp, "work", "qa-repo")
        os.makedirs(os.path.join(repo, "tests"))
        for osname in ("windows", "mac", "linux"):
            env = {"HOME": home, "USERPROFILE": home, "APPDATA": os.path.join(home, "AppData", "Roaming")}
            loc = locations(env, osname)
            want = {"windows": os.path.join(home, "AppData", "Roaming", "devin", "mcp_config.json"),
                    "mac": os.path.join(home, ".config", "devin", "mcp_config.json"),
                    "linux": os.path.join(home, ".config", "devin", "mcp_config.json")}[osname]
            vs = {"windows": os.path.join(home, "AppData", "Roaming", "Code", "User"),
                  "mac": os.path.join(home, "Library", "Application Support", "Code", "User"),
                  "linux": os.path.join(home, ".config", "Code", "User")}[osname]
            ok[f"{osname}: Devin Desktop and VS Code settings in the right place"] = loc["devin_config"] == want and loc["vscode_user_dirs"][0] == vs \
                and loc["copilot_config"] == os.path.join(home, ".copilot", "mcp-config.json")
        env = {"HOME": home, "USERPROFILE": home, "APPDATA": os.path.join(home, "AppData", "Roaming")}
        loc = locations(env, OS)
        sk_dir, home_dir = os.path.join(repo, "qa-ai-skills", "skills"), os.path.join(repo, "qa-ai-skills")
        defs = server_defs(repo, sys.executable, "/usr/bin/node", "/x/@playwright/mcp/cli.js", ["--browser", "msedge"], skills=sk_dir, ai_home=home_dir)
        ok["robotmcp starts in the QA repo through the launcher, with this Python"] = defs["robotmcp"]["command"] == sys.executable and \
            defs["robotmcp"]["args"][1:5] == ["--cwd", repo, "--module", "robotmcp.server"]
        ok["Playwright entries use node + the MCP's own file, Edge when Chrome is missing"] = defs["playwright"]["args"][:3] == ["/x/@playwright/mcp/cli.js", "--browser", "msedge"] \
            and "--cdp-endpoint" in defs["playwright-attach"]["args"] and "--isolated" in defs["playwright-session"]["args"]
        ok["every path points at this QA repo"] = all(repo in " ".join(d["args"]) for d in defs.values())
        ok["login state for the second window kept in qa-ai-skills/session"] = os.path.join(home_dir, "session", "storage-state.json") in defs["playwright-session"]["args"]
        # merging: only our entries change; comments, formatting and the user's own servers stay as they are
        vsfile = os.path.join(loc["vscode_user_dirs"][0], "mcp.json")
        os.makedirs(os.path.dirname(vsfile), exist_ok=True)
        original = ('{\n  // my own servers - keep this comment\n  "servers": {\n'
                    '    "github": {"type": "http", "url": "https://x"}, // inline note\n'
                    '    "playwright": {"command": "npx", "args": ["@playwright/mcp"]},\n  },\n}\n')
        open(vsfile, "w").write(original)
        merge_into(vsfile, "servers", as_format(defs, "vscode", repo), "VS Code")
        text = open(vsfile).read()
        data = read_jsonc(vsfile)
        ok["existing file: comments and formatting kept, our entries added"] = text.startswith('{\n  // my own servers - keep this comment\n  "servers": {\n    "github": {"type": "http", "url": "https://x"}, // inline note\n') \
            and {"robotmcp", "qtest", "playwright-attach"} <= set(data["servers"])
        ok["the user's own entry with one of our names is never replaced"] = data["servers"]["playwright"] == {"command": "npx", "args": ["@playwright/mcp"]} \
            and any(x[0] == "WARN" and "kept your existing" in x[1] for x in RESULTS)
        ok["backup made before changing a file"] = len(glob.glob(vsfile + ".backup-*")) == 1
        merge_into(vsfile, "servers", as_format(defs, "vscode", repo), "VS Code")
        ok["running again changes nothing"] = open(vsfile).read() == text and len(glob.glob(vsfile + ".backup-*")) == 1
        changed = server_defs(repo, sys.executable, "/usr/bin/node", "/y/@playwright/mcp/cli.js", [], skills=sk_dir, ai_home=home_dir)
        merge_into(vsfile, "servers", as_format(changed, "vscode", repo), "VS Code")
        d2 = read_jsonc(vsfile)["servers"]
        ok["our own entries are updated when something changed"] = d2["playwright-attach"]["args"][0] == "/y/@playwright/mcp/cli.js" and \
            d2["playwright"] == {"command": "npx", "args": ["@playwright/mcp"]}
        bad = os.path.join(tmp, "broken.json")
        open(bad, "w").write("{ this is not json")
        merge_into(bad, "mcpServers", {"x": {}}, "Broken")
        ok["unreadable file is never overwritten; entries go to a side file"] = open(bad).read() == "{ this is not json" and os.path.isfile(bad + ".qa-ai-proposed.json")
        # project files first: inside the QA repo, git-ignored; the user's settings are not touched
        REPO = repo
        write_json(loc["copilot_config"], {"mcpServers": {"mine": {"command": "x"}, "robotmcp": as_format(defs, "copilot", repo)["robotmcp"]}})
        det_vs = {"vscode": True, "devin": False, "copilot": "ext", "claude_ext": "ext", "claude_cli": None}
        old_claude = {"projects": {repo: {"mcpServers": {"robotmcp": as_format(defs, "claude", repo)["robotmcp"], "own": {"command": "o"}}}}, "x": 1}
        write_json(loc["claude_json"], old_claude)
        write_settings("copilot", det_vs, loc, defs)
        write_settings("claude", det_vs, loc, defs)
        cj_now = json.load(open(loc["claude_json"]))
        ok["Claude Code: old project entries in the user file removed (they would win over .mcp.json)"] = \
            cj_now["projects"][repo]["mcpServers"] == {"own": {"command": "o"}} and cj_now["x"] == 1
        vs_proj, cl_proj = os.path.join(repo, ".vscode", "mcp.json"), os.path.join(repo, ".mcp.json")
        ok["VS Code: Copilot or Claude Code settings written inside the project"] = \
            set(read_jsonc(vs_proj)["servers"]) == set(SERVER_NAMES) and read_jsonc(vs_proj)["servers"]["robotmcp"]["cwd"] == repo and \
            set(read_jsonc(cl_proj)["mcpServers"]) == set(SERVER_NAMES) and "cwd" not in read_jsonc(cl_proj)["mcpServers"]["robotmcp"]
        gi = open(os.path.join(repo, ".gitignore")).read()
        ok["project settings files are git-ignored (they hold paths of this computer)"] = ".vscode/mcp.json" in gi and ".mcp.json" in gi
        cp = read_jsonc(loc["copilot_config"])["mcpServers"]
        ok["old copies of our entries in the user settings removed; the user's own kept"] = cp == {"mine": {"command": "x"}}
        # a project file the team commits is never edited: the user settings are used instead
        if shutil.which("git"):
            run(["git", "init", "-q", repo], timeout=60)
            team = '{"servers": {"team-server": {"command": "team"}}}\n'
            open(vs_proj, "w").write(team)
            run(["git", "-C", repo, "add", "-f", ".vscode/mcp.json"], timeout=60)
            write_settings("vscode", dict(det_vs, claude_ext=None), loc, defs)   # older option: means Copilot here
            ok["project file shared in git: left unchanged, user settings used instead"] = open(vs_proj).read() == team and \
                {"robotmcp", "mine"} <= set(read_jsonc(loc["copilot_config"])["mcpServers"])
        write_settings("devin", {"vscode": False, "devin": True, "copilot": None, "claude_ext": None, "claude_cli": None}, loc, defs)
        dv_proj = os.path.join(repo, ".devin", "mcp_config.local.json")
        ok["Devin Desktop: settings in the project's local file, git-ignored"] = set(read_jsonc(dv_proj)["mcpServers"]) == set(SERVER_NAMES) and \
            all(set(v) <= {"command", "args", "env"} for v in read_jsonc(dv_proj)["mcpServers"].values()) and \
            ".devin/mcp_config.local.json" in open(os.path.join(repo, ".gitignore")).read()
        ok["Devin Desktop (new version): no file written for older versions"] = not os.path.isfile(os.path.join(repo, ".devin", "config.local.json"))
        write_json(loc["devin_old_user"], {"mcpServers": {"theirs": {"command": "t"}}, "theme": "dark"})
        if os.path.isfile(loc["devin_config"]):
            os.remove(loc["devin_config"])
        write_json(os.path.join(repo, ".devin", "config.local.json"), {"model": "x"})
        write_settings("devin", {"vscode": False, "devin": True, "copilot": None, "claude_ext": None, "claude_cli": None}, loc, defs)
        legacy = read_jsonc(os.path.join(repo, ".devin", "config.local.json"))
        ok["Devin Desktop (older version): servers also where it reads them; its other settings kept"] = \
            set(legacy["mcpServers"]) == set(SERVER_NAMES) and legacy["model"] == "x" and \
            ".devin/config.local.json" in open(os.path.join(repo, ".gitignore")).read()
        # Claude Code without the claude command (fallback): entries for this project only, the rest of the file kept
        cj = loc["claude_json"]
        write_json(cj, {"numStartups": 7, "projects": {"/other": {"mcpServers": {"a": {}}}}})
        setup_claude({"claude_cli": None, "claude_ext": None}, loc, defs, repo)
        c = json.load(open(cj))
        key = repo.replace("\\", "/") if os.name == "nt" else repo
        ok["Claude Code fallback: entries for this project only, rest kept"] = c["numStartups"] == 7 and "a" in c["projects"]["/other"]["mcpServers"] and \
            set(c["projects"][key]["mcpServers"]) == set(SERVER_NAMES)
        # proving a server: a real MCP server answers, a broken command is reported
        qt = os.path.join(HERE, "qtest", "qtest_mcp.py")
        good, msg = probe("qtest", sys.executable, [qt, "--root", repo], {"PYTHONUTF8": "1"}, repo, timeout=60)
        ok["a working MCP server is proven to answer"] = good and "3 tools" in msg
        badp, msg2 = probe("broken", sys.executable, ["-c", "import sys; sys.exit(3)"], None, repo, timeout=20)
        ok["a server that does not start is reported, not hung"] = not badp
        open(os.path.join(repo, "where_am_i.py"), "w").write("import os, sys\nprint(os.getcwd(), sys.argv[1:])\n")
        code, txt = run([sys.executable, os.path.join(HERE, "mcp_launch.py"), "--cwd", repo, "--module", "where_am_i", "x"], cwd=tmp, timeout=60)
        ok["launcher starts the module inside the QA repo (like python -m)"] = code == 0 and \
            os.path.normcase(os.path.realpath(txt.split(" [")[0].strip())) == os.path.normcase(os.path.realpath(repo)) and "['x']" in txt
        # .env values are updated in place, other lines kept
        envf = os.path.join(repo, ".env")
        open(envf, "w").write("DB_HOST=x\nQTEST_URL=old\n")
        set_env_values(envf, {"QTEST_URL": "https://q", "QTEST_PROJECT_ID": "9"})
        ok[".env updated in place, other lines kept"] = open(envf).read() == "DB_HOST=x\nQTEST_URL=https://q\nQTEST_PROJECT_ID=9\n"
        # git-ignore lines added once
        open(os.path.join(repo, ".gitignore"), "w").write("node_modules/\n")
        update_gitignore(); update_gitignore()
        gi = open(os.path.join(repo, ".gitignore")).read()
        ok[".gitignore lines added once, existing ones kept"] = gi.startswith("node_modules/\n") and gi.count("qa-ai-skills/session/") == 1
        install_commands({"claude_cli": "x"}, "claude"); install_commands({"claude_cli": "x"}, "claude")
        ok["slash commands installed only for the chosen editor, once"] = \
            os.path.isfile(os.path.join(repo, ".claude", "commands", "qa-knowledge-setup.md")) and RESULTS[-1][0] == "OK" and "already in" in LOG_LINES[-1] and \
            not os.path.isfile(os.path.join(repo, ".github", "prompts", "robot-script-generator.prompt.md"))
        install_commands({"copilot": "x"}, "copilot")
        os.makedirs(os.path.join(repo, ".claude", "commands"), exist_ok=True)
        open(os.path.join(repo, ".claude", "commands", "my-own.md"), "w").write("mine")
        write_json(os.path.join(repo, ".mcp.json"), {"mcpServers": as_format(defs, "claude", repo)})
        remove_other_editors("devin", loc)
        ok["switching to Devin removes only our files for the other editors"] = \
            not os.path.isfile(os.path.join(repo, ".claude", "commands", "qa-knowledge-setup.md")) and \
            not os.path.isfile(os.path.join(repo, ".github", "prompts", "robot-script-generator.prompt.md")) and \
            os.path.isfile(os.path.join(repo, ".claude", "commands", "my-own.md")) and not os.path.isfile(os.path.join(repo, ".mcp.json"))
        # older layout: AI folders at the repo root are moved into qa-ai-skills/ (committed ones with git mv)
        global AI_HOME, NEW_LAYOUT
        saved_home, saved_layout = AI_HOME, NEW_LAYOUT
        old = os.path.join(tmp, "old-layout-repo")
        for rel_, body in (("knowledge/app-map.md", "map"), ("knowledge/.extract/tests.json", "[]"), ("ai_generated_tests/drafts/x.robot", "*** Test Cases ***"),
                           ("results/ai-scriptgen/metrics.csv", "a"), (".ai_session/s.json", "{}"), ("skills/robot-script-generator.md", "old"),
                           ("tests/real.robot", "*** Test Cases ***")):
            os.makedirs(os.path.dirname(os.path.join(old, rel_)), exist_ok=True)
            open(os.path.join(old, rel_), "w").write(body)
        os.makedirs(os.path.join(old, "qa-ai-skills", "skills"))
        if shutil.which("git"):
            run(["git", "init", "-q", old], timeout=60)
            run(["git", "-C", old, "add", "knowledge/app-map.md", "tests/real.robot"], timeout=60)
            run(["git", "-C", old, "-c", "user.email=a@b", "-c", "user.name=a", "commit", "-qm", "team"], timeout=60)
        REPO, AI_HOME, NEW_LAYOUT = old, os.path.join(old, "qa-ai-skills"), True
        move_into_ai_folder()
        a_ = lambda *p: os.path.isfile(os.path.join(old, "qa-ai-skills", *p))
        ok["older layout: knowledge, tests, results and session moved into qa-ai-skills"] = \
            a_("knowledge", "app-map.md") and a_("knowledge", ".extract", "tests.json") and a_("ai_generated_tests", "drafts", "x.robot") and \
            a_("results", "metrics.csv") and a_("session", "s.json") and \
            sorted(x for x in os.listdir(old) if x != ".git") == ["qa-ai-skills", "tests"]
        ok["older copy of the skills moved to qa-ai-skills/backup, the team's tests untouched"] = \
            len(glob.glob(os.path.join(old, "qa-ai-skills", "backup", "skills-*", "robot-script-generator.md"))) == 1 and \
            open(os.path.join(old, "tests", "real.robot")).read() == "*** Test Cases ***"
        if shutil.which("git"):
            code, st = run(["git", "-C", old, "status", "--porcelain"], timeout=60)
            ok["committed knowledge moved with git mv (history kept, nothing committed)"] = "R  knowledge/app-map.md -> qa-ai-skills/knowledge/app-map.md" in st
        n0 = len(RESULTS); move_into_ai_folder()
        ok["moving again finds nothing to move"] = RESULTS[-1][0] == "SKIP"
        AI_HOME, NEW_LAYOUT = saved_home, saved_layout
        REPO = repo
        h2 = os.path.join(tmp, "home2")
        os.makedirs(h2)
        e2 = {"HOME": h2, "SHELL": "/bin/zsh", "PATH": "/usr/bin"}
        st1, _ = register_command(e2, "mac")
        st2, _ = register_command(e2, "mac")
        shim = os.path.join(h2, ".local", "bin", "qa-ai-setup")
        ok["qa-ai-setup command: launcher created, PATH line added once, second run changes nothing"] = st1 == "OK" and st2 == "SKIP" and \
            os.access(shim, os.X_OK) and open(os.path.join(h2, ".zshrc")).read().count(".local/bin") == 1
        if shutil.which("sh"):
            proj = os.path.join(tmp, "shimrepo", "qa-ai-skills")
            os.makedirs(os.path.join(proj, "x"))
            open(os.path.join(proj, "qa-ai-setup.sh"), "w").write('echo "ran:$*"\n')
            r1 = subprocess.run(["sh", shim, "check"], cwd=os.path.join(proj, "x"), capture_output=True, text=True)
            r2 = subprocess.run(["sh", shim, "check"], cwd=tmp, capture_output=True, text=True)
            ok["qa-ai-setup command finds the qa-ai-skills folder from any folder in the repo"] = "ran:check" in r1.stdout and \
                r2.returncode == 1 and "No qa-ai-skills folder" in r2.stdout
        st3, _ = register_command({"USERPROFILE": h2, "LOCALAPPDATA": os.path.join(h2, "AppData", "Local")}, "windows", write_registry=False)
        wshim = open(os.path.join(h2, "AppData", "Local", "qa-ai-skills", "bin", "qa-ai-setup.cmd"), newline="").read()
        ok["Windows launcher written with Windows line endings"] = st3 == "OK" and "\r\n" in wshim and "qa-ai-setup.cmd" in wshim
        old_fmt = "\nSELF-TEST PASSED (Robot Framework 7.1)\n  [OK] a\n  [OK] b\n"
        new_fmt = "  OK    a\n  FAIL  b broke\nSELF-TEST FAILED (1 of 2 OK)\n"
        ok["self-test results read in every format (extract_repo's too)"] = parse_self_test(old_fmt)[:3] == (True, 2, 2) and \
            parse_self_test(new_fmt) == (False, 1, 2, ["b broke"]) and parse_self_test("Traceback ...")[0] is None
        ok["every warning and failure says what to do"] = all(x[3] for x in RESULTS if x[0] in ("WARN", "FAIL"))
        ok["log file is plain text (no colour codes, no symbols)"] = all(ord(ch) < 128 and ch != "\x1b" for l in LOG_LINES for ch in l if not l.startswith("$ "))
    finally:
        REPO = saved_repo
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    print()
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
