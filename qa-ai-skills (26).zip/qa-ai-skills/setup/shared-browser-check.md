# 15-minute check: can Playwright see the screen rf-mcp reached?

Use **Part A** for SeleniumLibrary suites (Chrome or Edge) and **Part B** for Browser library suites.
A suite that uses both: run the part for the library that opens the browser.

# Part A - SeleniumLibrary: Playwright joins the same browser

This proves the one part that cannot be tested outside your machine. If it fails, nothing breaks:
the generator drops to fallback level 2 (saved screen files) and the rest still works.

## Before you start
1. `qa-ai-skills/skills/ai_session.py` and `qa-ai-skills/skills/ai_activity_indicator.js` are in your repo.
2. Devin (or VS Code) MCP settings contain `robotmcp`, `playwright` and `playwright-attach`
   (copy from `qa-ai-skills/setup/mcp-config-examples/`, change the paths, restart the editor).
   If your MCP settings allow a working folder for `robotmcp`, set it to your repo root.
3. An existing test that reaches the screen passes when you run it the normal way.
4. You know the command-line variables of that normal run (for example `--variable ENV:<env>`).
   After a knowledge build they are in `qa-ai-data/knowledge/run-config.md`.

## Paste this into a new chat (fill in the <...> parts)
```
Use only the robotmcp tools for this check. Do not create or change any repo files.
1. Start one session that reproduces my normal run:
   - first set these command-line variables with Set Global Variable: <e.g. ENV=UAT>
   - the working folder (${EXECDIR}) is the repo root: <repo root path>
   - then import exactly the Library, Resource and Variables lines of <your suite file>,
     in the same order and with the same arguments, plus Library qa-ai-skills/skills/ai_session.py last.
     Do not import any file that those resources import themselves (for example the
     password handler); it loads through them.
   Import the secrets / vault loader only once. If an import cannot be found, stop and tell me
   the file and the import line. Never type URLs, user names or passwords yourself.
2. Run the suite setups once: folder init files (__init__.robot or __init__.txt) from the top
   folder down (skip any without a setup, do not ask), then the suite's own Suite Setup.
3. Run the steps of the existing test <test name> one by one, in a visible browser, until its
   main screen is open, before any save step. Stop at the first failure and tell me the error.
4. Run: AI Open Door. Tell me the URL it returns, and the page title in qa-ai-data/session/state.json.
5. Use the playwright-attach tools: list the open tabs, pick the one whose URL matches
   page_url in qa-ai-data/session/state.json, confirm its title matches page_title, then take a
   snapshot and tell me the visible section names and buttons. Do not click anything.
6. Back in robotmcp, run: AI Close Door.
7. Close the browser and end the session, even if an earlier step failed.
8. Report which steps worked, and any locator that no longer matches the screen.
```

## What good looks like
- Step 4 returns `http://127.0.0.1:9222`.
- While rf-mcp runs your steps: a **blue** glow and badge, top right, labelled ROBOT FRAMEWORK MCP.
- **After step 4, look at the browser yourself:** the glow and badge turn **purple** (PLAYWRIGHT MCP)
  and say "AI assistant is reviewing this page (nothing will be saved)". The badge is drawn
  inside the page in a hidden layer, so Playwright's snapshot will not list it; that is expected.
- Step 5 sees the same logged-in page (same title, your sections). No new browser opens.
- After step 6 the badge is blue again and says "AI assistant is continuing with the existing steps".
- After step 7 no browser window is left open.

## If it fails
| What you see | Meaning | What happens |
|---|---|---|
| Step 1 cannot find an import, or says a variable is not found | The session is not running from the repo root, a command-line variable is missing, or the imports were not in the suite's order | Set the working folder, add the variable in step 1, or import in the suite's order |
| Step 2 says a URL or credential variable is missing | The secrets loader did not get the environment, or was not imported | Check the variables in step 1 and the loader's arguments |
| Step 4 returns `NONE` | No Chrome debug address (not Chrome/Edge, or Browser library), port 9222 busy, or the browser did not answer through the door; `qa-ai-data/session/state.json` says which | Generator uses level 2: saved screen files only |
| Step 5 finds no tab with the same URL or title | Playwright joined a different browser | Generator does not use it and reads the saved screen (level 2) |
| Step 5 cannot connect | Port 9222 blocked or busy | Change `door_port` in the Library import and in `playwright-attach`, or use level 2 |
| Step 5 opens a new blank browser | `playwright-attach` is missing `--cdp-endpoint` | Fix the MCP entry and restart |
| A step of your test fails on a missing element | The existing test's locator is out of date in this environment | Report it to the team; the generator never replaces it silently |

# Part B - Browser library: Playwright opens the same page with the shared login
The Browser library starts its own browser, which no other tool can join. Instead, the AI saves the
login of rf-mcp's browser and Playwright opens the same page, already logged in, in a second window.

Before you start: `playwright-session` is in your MCP settings (see `qa-ai-skills/setup/mcp-config-examples/`).

## Paste this into a new chat (fill in the <...> parts)
```
Use only the robotmcp tools for steps 1-4 and do not create or change any repo files.
1. Start one session that reproduces my normal run, exactly as Part A step 1 describes
   (command-line variables <e.g. ENV=UAT>, repo root <path>, the suite's imports in order,
   plus Library qa-ai-skills/skills/ai_session.py last). Import the secrets loader only through the suite.
2. Run the folder init setups and the Suite Setup of <your suite file> once.
3. Run the steps of the existing test <test name> one by one, in a visible browser, until its
   main screen is open, before any save step. Stop at the first failure and tell me the error.
4. Run: AI Save Screen, then AI Share Login. Tell me the page title in qa-ai-data/session/state.json.
5. Use the playwright-session tools: browser_close first, then open page_url from
   qa-ai-data/session/state.json. Tell me the page title and the visible section names and buttons.
   Do not click anything.
6. Close the playwright-session window, close the robotmcp browser and end the session.
7. Report which steps worked.
```

## What good looks like
- During steps 1-3: a **blue** badge (ROBOT FRAMEWORK MCP) in the rf-mcp browser.
- Step 5 opens a second window with a **purple** badge (PLAYWRIGHT MCP), already logged in, on the
  same page and title.

## If it fails
| What you see | Meaning | What happens |
|---|---|---|
| Step 5 shows the sign-in page | Your app keeps the sign-in in session storage or needs single sign-on again | The generator uses level 2 (saved screen + your library keywords); nothing else is affected |
| Step 5 opens the home page instead of the screen | The screen depends on what was clicked before (no deep link) | The generator uses level 2 for that screen |
| `playwright-session` will not start | The path to `qa-ai-data/session/storage-state.json` in your MCP settings is wrong | Fix the path (absolute path to your repo) and restart the editor |
