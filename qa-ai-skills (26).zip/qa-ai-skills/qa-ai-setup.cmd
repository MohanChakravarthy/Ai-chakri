@echo off
rem ---------------------------------------------------------------------------
rem  QA AI Skills setup (Windows)
rem
rem  First time, from the root of your QA repo (PowerShell or Command Prompt):
rem      .\qa-ai-skills\qa-ai-setup install
rem  After that, from any folder inside the QA repo:
rem      qa-ai-setup install      install or update
rem      qa-ai-setup check        check only: tools, MCP servers, self-tests
rem      qa-ai-setup help         all options
rem
rem  Uses the Python that has Robot Framework: the active virtual environment,
rem  else the repo's .venv / venv / env folder, else py -3, python or python3.
rem ---------------------------------------------------------------------------
setlocal EnableExtensions EnableDelayedExpansion
set "AIQA=%~dp0"
for %%I in ("%~dp0..") do set "REPO=%%~fI"
set "PY="

rem 1st pass: a Python that has Robot Framework
for %%P in ("!VIRTUAL_ENV!\Scripts\python.exe" "!REPO!\.venv\Scripts\python.exe" "!REPO!\venv\Scripts\python.exe" "!REPO!\env\Scripts\python.exe") do (
    if not defined PY if exist "%%~P" (
        "%%~P" -c "import robot" >nul 2>&1 && set "PY="%%~P""
    )
)
if not defined PY for %%C in ("py -3" "python" "python3") do (
    if not defined PY (
        %%~C -c "import robot" >nul 2>&1 && set "PY=%%~C"
    )
)
rem 2nd pass: any working Python 3.8+ (setup then explains what is missing)
if not defined PY for %%P in ("!VIRTUAL_ENV!\Scripts\python.exe" "!REPO!\.venv\Scripts\python.exe" "!REPO!\venv\Scripts\python.exe") do (
    if not defined PY if exist "%%~P" set "PY="%%~P""
)
if not defined PY for %%C in ("py -3" "python" "python3") do (
    if not defined PY (
        %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>&1 && set "PY=%%~C"
    )
)
if not defined PY (
    echo.
    echo   [FAIL]  Python was not found
    echo           Cause  No Python 3.8 or newer is installed, or it is not on the PATH.
    echo           Fix    Install Python 3.10 or newer ^(or ask IT^), open a new terminal, then run .\qa-ai-skills\qa-ai-setup install again.
    echo.
    exit /b 1
)
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
!PY! "!AIQA!skills\qa_ai_setup.py" %*
exit /b !ERRORLEVEL!
