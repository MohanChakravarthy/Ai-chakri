#!/bin/sh
# ---------------------------------------------------------------------------
#  QA AI Skills setup (macOS and Linux)
#
#  First time, from the root of your QA repo:
#      sh qa-ai-skills/qa-ai-setup.sh install
#  After that, from any folder inside the QA repo:
#      qa-ai-setup install      install or update
#      qa-ai-setup check        check only: tools, MCP servers, self-tests
#      qa-ai-setup help         all options
#
#  Uses the Python that has Robot Framework: the active virtual environment,
#  else the repo's .venv / venv / env folder, else python3 or python.
# ---------------------------------------------------------------------------
DIR=$(cd "$(dirname "$0")" && pwd)
REPO=$(dirname "$DIR")
PY=""
for c in "${VIRTUAL_ENV:+$VIRTUAL_ENV/bin/python}" "$REPO/.venv/bin/python" "$REPO/venv/bin/python" "$REPO/env/bin/python" python3 python; do
    [ -n "$c" ] || continue
    if "$c" -c "import robot" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
    for c in "${VIRTUAL_ENV:+$VIRTUAL_ENV/bin/python}" "$REPO/.venv/bin/python" "$REPO/venv/bin/python" python3 python; do
        [ -n "$c" ] || continue
        if "$c" -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >/dev/null 2>&1; then PY="$c"; break; fi
    done
fi
if [ -z "$PY" ]; then
    printf '\n  [FAIL]  Python was not found\n'
    printf '          Cause  No Python 3.8 or newer is installed, or it is not on the PATH.\n'
    printf '          Fix    Install Python 3.10 or newer (or ask IT), then run: sh qa-ai-skills/qa-ai-setup.sh install\n\n'
    exit 1
fi
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 exec "$PY" "$DIR/skills/qa_ai_setup.py" "$@"
