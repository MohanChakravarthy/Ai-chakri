---
name: dev-knowledge-builder
description: Builds or refreshes the development knowledge of a QA repo from the application's own front-end and back-end source code (read-only). Turns the facts collected by extract_dev.py into qa-ai-data/knowledge/dev/ files - screens, form sections, fields with their IDs and test IDs, dropdown options, validation and business rules, roles and permissions, status flows, data that must exist first, what happens after saving, fields that appear only under a condition, the data each screen waits for, API endpoints, the data model (for understanding only) and screen-to-screen workflows - and links each development screen to the QA screens and locators by evidence. Run by qa-knowledge-setup; use directly only when asked to build or refresh development knowledge.
version: 0.1.0
---

# Development Knowledge Builder

## 1. Purpose and principles
The QA knowledge says how the team **tests** the application. The development knowledge says how
the application is **built**: which fields each screen really has, their stable IDs, the options in
each dropdown, the rules behind each field, which fields appear only in some cases, and what data a
screen loads before it is ready. It also says how the application **behaves**: the business checks
that stop a request (with the message the user sees), which role may do what, which status a record
must be in before an action, which data must already exist, and what the screen does after Save or
Submit. The script generator uses it to understand test cases completely (filling the steps a short
or vague test case leaves out), for new screens and new elements, for the right waits and the right
checks after saving, and to spot broken team locators.

- **Read-only on the development code.** Never edit, format, build, install, run or commit anything
  in a development repo. Never copy source code into the knowledge; record identifiers, texts and
  rules only.
- **Facts come from the extract.** Use `qa-ai-data/knowledge/.extract/dev/*.json` (from `extract_dev.py`).
  Open a development source file only for a specific line range when a fact is unclear, never to
  collect facts again.
- **Every entry cites its source** as `<repo>/<file>:<line>` so anyone can check it.
- **Evidence, not names.** Testers and developers name screens differently, and many banking apps
  reuse words (KYC, client, account) everywhere. Link a development screen to a QA screen only by
  evidence: the same URL, IDs or test IDs used in QA locators, the same visible labels, titles,
  tabs and buttons, and the position in the flow. Never by name similarity alone.
- **No sensitive data.** Record option lists and enums (reference data). Never record anything that
  looks like real client data (names, account or card numbers, emails, phone numbers), secrets,
  keys, tokens, internal host names or connection strings, even if they appear in the code.
- **Plain English.** The files are read by testers and managers, not only by the AI.

## 2. Inputs
| File in `qa-ai-data/knowledge/.extract/dev/` | Content |
|---|---|
| `dev-summary.json` | repos, branches, commits, frameworks, counts, warnings; per front end `read_as` (the frameworks its pages were read as) and `page_files` |
| `dev-index.json` | every screen (route, component, file, titles) and every endpoint: the table of contents |
| `screens/<nnn>-<route>.json` | one file per screen (named in `dev-index.json`); open only the screen being written. `dev-screens.json` holds all of them, for scripts only. Per screen: files, elements (kind, label, text, id, testid, name, placeholder, type, required, rules, options, visible_when, disabled_when, depends_on_role, file, line), texts (headings, dialog titles, labels), validations, APIs (with `on_load`, the matched endpoint and, for calls that change data, `after`: success and error messages, next screen, reload), loaders, navigation, dialogs, `roles` (from the route) and `role_hints` (role checks in its files) |
| `dev-api.json` | endpoints (method, path, handler, request body type, request fields with rules, `roles` needed, methods it `calls`) |
| `dev-business.json` | `checks` (kind: business check, status rule, prerequisite or permission; the condition as written, the message, the error, method, endpoints), `roles` (role names, the rule as written, method or whole controller, endpoints), `transitions` (status a method sets, `statuses_checked_before`, `guards` = the checks in the same method with their messages, endpoints), `statuses` (status lists) |
| `dev-data-model.json` | **For understanding only.** Stored types (entity, table, fields, columns, keys, lengths), tables from migration files, and `field_map` (screen field → request field → stored column) |
| `dev-reference-data.json` | option lists from the front end and enums from the back end |
| `dev-links.json` | QA resource file ↔ development screen links with score, confidence and evidence; `coverage_gaps` (fields no QA locator uses yet); `missing_in_dev` (team locators in linked files whose id, test id or name is found nowhere in the development code) |
| `dev-scope.json` | (scoped builds only) the development screens the suite uses, and their neighbours |

**What each button does and which outside systems it reaches.** Each screen API call carries `triggered_by` (the button or link whose click handler leads to it, through up to three function calls; form submits by their submit button; on-load calls need none) and `integrations` (the outside systems the endpoint reaches: Feign and SOAP clients, RestTemplate/WebClient/HttpClient calls, JMS and Kafka messages, traced from the endpoint's handler through the services it calls). `dev-api.json` lists every integration found (`integrations`: system, kind, class, file). Write them on the screen page ("Save calls POST /api/requests, which uses BMC and Alfresco") and list each outside system in `index.md` with the screens that reach it: the script generator uses this to tell an environment or integration problem from a script failure, and the coverage map uses it for integration coverage.

**Old and new front ends are read the same way.** Besides React, Angular, Vue and Next.js, the extractor reads AngularJS 1.x (`$routeProvider`/ui-router routes, `ng-model`, `ng-options`, `ng-show`/`ng-if`, `$http`/`$resource`, `$scope` messages, `$location`), plain HTML with jQuery (`$.ajax`), JSP with Spring form tags and JSTL (`<c:if>`), JSF and PrimeFaces (`#{bean.field}`, `f:selectItem`, `rendered=`), Thymeleaf (`th:field`, `th:if`, `#{...}` labels), Struts 1 and 2 (actions in `struts.xml`/`struts-config.xml`), ASP.NET Web Forms (server controls; their rendered id gets a prefix unless `ClientIDMode="Static"`, marked `server_id`) and ASP.NET MVC Razor (`asp-for`), FreeMarker, Velocity and Grails pages. Labels come from `messages*.properties` bundles as well as JSON locale files. A page a controller renders takes the controller's URL as its route (`route_from`). Write about every screen the same way, whatever its framework, and name the framework in `index.md`. If `dev-summary.json` warns that a front end gave no screens, or that a framework builds screens in code (Vaadin, GWT, Wicket), say it plainly in `index.md` and the step result; never call a repo "back end only" when it has page files.

Also read `qa-ai-data/knowledge/dev-config.md` (repos, branches, commits), `qa-ai-data/knowledge/app-map.md` and the
locator knowledge (to name the QA screen behind each linked resource file).

## 3. Outputs: `qa-ai-data/knowledge/dev/`
| File | What it holds |
|---|---|
| `index.md` | Table of contents: repos, branch, commit and date, what each repo is (front end, back end or both, as `detected` from its code in `dev-summary.json`), frameworks, one row per screen (route, title, fields, buttons, linked QA screen, confidence), endpoint count, and what each file below contains |
| `app-overview.md` | One section per screen: route, titles and tabs, what it is for (one line, from its texts), dialogs it opens, screens it leads to and comes from, **data it loads on open and the loading indicator to wait for** |
| `form-sections.md` | Per screen, per section (nearest heading, tab or dialog title above the fields): table of fields: label, kind, id, test id, name, required, rules, shown when, source |
| `reference-data.md` | Dropdown and radio option lists (value → text) and back-end enums, with where each is used |
| `business-rules.md` | Part 1 **field rules**: validation rules and messages per field, front end and back end; **mismatches between them are flagged** (for example front end allows 30 characters, back end 20). Part 2 **business checks**: per action (endpoint and the button that calls it), every check that stops it, in plain English, with the message the user sees ("A corporate client must have an LEI" - shown when client type is Corporate and LEI is empty) |
| `roles-permissions.md` | Per role: the actions (endpoints, buttons) it may perform and the screens it may open; per action: the roles needed. Buttons and fields that depend on a role are listed under their screen |
| `status-flows.md` | Per record type: the statuses, and each change ("Submitted → Approved by the Approve button, role KYC approver"), with the conditions for it in plain English from its guards ("only when the case is Submitted"; "not when the account is already Closed") |
| `prerequisites.md` | Per action: the data that must already exist or be in a state first ("an existing KYC case", "the client has an approved KYC") with the message shown when it is missing |
| `after-save.md` | Per screen and action that changes data: the success message, the error message, the next screen, whether the list reloads, and the status the record moves to. These are the checks a test makes after Save or Submit |
| `data-model.md` | **For understanding only**: what each screen field is stored as (type, table, column) and how records relate. Test databases may differ: database steps in tests always use the QA repo's own keywords and queries, never this file |
| `form-variants.md` | Fields and sections that appear only under a condition, grouped by condition, in plain English ("Shown only when client type is Corporate") with the raw condition and source |
| `api-endpoints.md` | Method, path, handler, request fields and rules, which screens call it and whether on open (UI testing first; API testing later) |
| `workflows.md` | Screen-to-screen journeys from the navigation facts ("Client search → Manage subscriptions → Unsubscribe dialog") |
| `dev-qa-links.md` | For every development screen: the linked QA screen and resource files, confidence, evidence, **aliases**, and the fields no QA locator uses yet |

Large repos: write one screen at a time, at most 5 screens per batch, and append a checkpoint line
to `qa-ai-data/knowledge/dev/build-log.md` after each batch so an interrupted run resumes. Each screen has its
own small file (`screens/<nnn>-<route>.json`); read only the files of the screens being written. With
more than 30 screens in scope, sub-agents may each take a batch of screens: give each one only this
skill file, its list of screen files and the files to write, never the whole extract or the source code.
A scoped build (`dev-scope.json` exists) writes or updates only the screens in scope and their
neighbours, merged into the existing files without losing other screens.

## 4. How to write each part
### 4a. Screens and sections
- Screen name: the page title or main heading text when there is one; otherwise the route; the
  component name goes in the aliases, never as the only name.
- Group fields into sections by the nearest heading, tab, accordion or dialog title above them in
  the same file (by line number). Fields from a child dialog go under that dialog's title.
- Kind words for people: text field, dropdown, checkbox, radio, date, button, tab, link.
- Prefer the visible label; if the label is a translation key, the extract already resolved it; if
  it still looks like a key (`search.title`), write it as a key and mark "(translation key)".

### 4b. Waits (the data a screen waits for)
For each screen list the calls marked `on_load` and the loading indicators found
(`CircularProgress`, `Skeleton`, `mat-spinner`, `loading` flags...). Write the wait in testing
terms: "Wait until the loading spinner is gone and the Subscription type dropdown is enabled."
Name a proof element: a field or heading that appears only after the data arrives.

### 4c. Conditions
Translate `visible_when` into plain English where it is clear (`clientType === 'CORPORATE'` →
"client type is Corporate"); keep the raw condition next to it. If unclear, write the raw
condition and "(meaning not clear from the code)". Never guess the meaning.

### 4d. Rules
Combine the rules for the same field from the form schema, the field attributes and the back-end
request type. Show the message the user sees when there is one. Flag a mismatch as
`⚠ front end and back end differ` - a useful test idea, not an error to fix.

### 4e. Links to the QA knowledge (`dev-qa-links.md`)
- Name the QA screen from the app map or locator knowledge for each linked resource file.
- Confidence comes from the extract: **high** (several strong matches: same IDs or test IDs, or
  same URL plus IDs), **medium** (some IDs or several distinctive labels), **low** (only common
  words). Write the evidence in short form ("3 IDs, URL, 2 labels").
- **Low links are listed as "Possible - not used until confirmed".** The generator never uses a
  low link without asking.
- Two development screens strongly linked to the same QA resource file, or one development screen
  linked to two unrelated QA screens: write both and mark "⚠ ambiguous" with the evidence of each.
- **Aliases** per screen: page title, route, component name, QA screen name, the words in test
  case steps that led to it. Keep a "Learned aliases" list that the script generator adds to when
  a user confirms which screen a test case means (with the date). Never remove learned aliases on
  refresh.
- Team locators not found in the development code (`missing_in_dev`): list them under the screen
  with "possibly stale - check live". When one element on the linked screen has the same visible
  label or role as the locator, name it as the likely replacement. Never call a locator broken
  from the code alone: only a live check proves it.
- Coverage gaps: list the inputs, dropdowns, checkboxes, buttons and tabs of a linked screen that no
  QA locator uses yet. These are the fields new tests will need locators for.

### 4f. Business checks, roles, status flows, prerequisites (`business-rules.md` part 2, `roles-permissions.md`, `status-flows.md`, `prerequisites.md`)
- **Write each rule as a tester would say it, then the evidence.** "Approving a KYC case needs the
  KYC approver role, the case must be Submitted, and a corporate client must have an LEI." Under it:
  the condition as written, the message, the endpoint and the button that calls it (from the screens
  whose API calls match that endpoint), and `repo/file:line`.
- **Read the condition and the message together** to get the direction right. `status != SUBMITTED`
  with "Only submitted cases can be approved" means *must be Submitted*; `status == CLOSED` with
  "Account is already closed" means *must not be Closed*. When the condition and message do not make
  the meaning clear, write the raw condition and "(meaning not clear from the code)". Never guess.
- **Status flows**: build one chain per status list (`statuses`), from the `transitions`: which
  action moves a record from which status to which, with its guards and roles. Statuses no action
  sets are listed as "set outside this code (for example by a batch or another system)".
- **Roles**: list role names exactly as in the code (they are what the team's test users are set up
  with). A role on the whole controller applies to all its actions. A front-end-only check (a
  button disabled for a role) is listed too, marked "screen only".
- **Prerequisites**: "record must exist" checks (not found) and checks on other records ("client
  must have an approved KYC") become the data a test must have, or create, before the action.
- Rules found only in one place are still rules; the limit is what is in this code. Rules in
  database procedures or other teams' services cannot be seen; say so once in `index.md`.

### 4g. After saving (`after-save.md`)
From each screen's API calls with `after`: the success and error messages exactly as shown, the
next screen (route and its title), whether the data reloads, and from `transitions` the status the
record moves to. Write them as checks: "After Save: message 'Subscription saved', then the Clients
screen opens". These are hints for where to look; the expected results of a test still come from
the test case.

### 4h. Data model (`data-model.md`, understanding only)
Per screen: each field, its request field and its stored column (`field_map`), then per stored type
its table, key, required columns, lengths and links to other types. Columns named by "default
naming" are written as "probably <column>". Put this line at the top: "For understanding only. Test
databases may differ. Database steps in tests use the QA repo's own keywords and queries." Never
write SQL in this file.

## 5. Refresh
- If `dev-summary.json` shows a new commit for a repo, rewrite the screens whose files changed
  (compare `files` lists and lines with the previous build log) and keep the rest.
- Keep learned aliases and any note a person added under a "Notes" heading.
- Update `index.md` with the new commit and date.

## 6. Quality checks before finishing
- Every field row has a source `repo/file:line` that exists in the extract.
- Every screen in `dev-index.json` (or in `dev-scope.json` for a scoped build) has an
  `app-overview.md` section; none is invented.
- No code copied, no sensitive data (section 1), no locator written as "proven": development
  knowledge suggests locators; only a live check proves them.
- Every business check, role, status change and prerequisite cites its `repo/file:line`; none is
  written without a condition or message from the extract.
- Report counts: screens, fields, option lists, field rules, business checks, roles, status changes,
  prerequisites, after-save actions, conditional fields, endpoints, links by confidence, fields not
  yet covered by QA locators.

## 7. Example requests
- Run by `/qa-knowledge-setup build` when the user includes the development repo.
- `/qa-knowledge-setup dev` - add or change the development repo and build only this knowledge.
