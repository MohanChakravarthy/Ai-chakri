---
name: keyword-knowledge-builder
description: Builds or incrementally refreshes the keyword knowledge base of a Robot Framework QA automation repository. Catalogues every user keyword (and the library keywords in use), records arguments, return values, location and usage, links each keyword to the screen and flow IDs from app-knowledge-builder, and records the repo's coding conventions so robot-script-generator can reuse keywords and write code in the same style. Use when asked to build, refresh or rebuild keyword knowledge.
version: 0.1.0
---

# Keyword Knowledge Builder

## 1. Purpose and principles
Give robot-script-generator a reliable answer to: "Which existing keyword performs this business step, how do I call it, and where should a new keyword go?"

- **Evidence only.** Every keyword entry comes from a real definition in the repo, with file and line.
- **Read-only on the codebase.** Never modify, move, format or delete repo files. Write only inside `qa-ai-data/knowledge/`.
- **Linked by IDs.** Reuse screen and flow IDs exactly as defined in `qa-ai-data/knowledge/app-knowledge.md`. Never invent new screen or flow IDs; report unmatched keywords instead.
- **Stable IDs and deterministic output.** Sort entries alphabetically by keyword ID; use the templates below.
- **No secrets.** Never copy credential values; refer to variables by name only.

## 2. Prerequisites and inputs
**Primary source of facts: `qa-ai-data/knowledge/.extract/keywords.json`** (exact names, files, lines, arguments, returns, documentation, steps, calls with resolved targets, used_count) plus `summary.json` and `variables.json`. Copy these facts exactly; never re-derive them by reading raw files. If `.extract/` is missing or stale, run the extractor (`extract_repo.py` found under `qa-ai-skills/skills/`) first. Your job here is meaning: purpose in business language, level, screen and flow links, flow step mapping, preferred duplicates and conventions.

- `qa-ai-data/knowledge/app-knowledge.md` and `qa-ai-data/knowledge/app/` must exist. If missing, stop and ask the user to run app-knowledge-builder first.
- `qa-ai-data/knowledge/config.yaml` (optional): same paths and excludes as app-knowledge-builder.
- Sources: `.resource` files, `*** Keywords ***` sections in `.robot` files, Python keyword libraries in the repo (functions or methods decorated with `@keyword` or exposed via library classes), variable files, `requirements*.txt` / `pyproject.toml`.

## 3. Outputs
**You write only the meaning; the script writes the files.** For each changed module, run `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py worksheet keyword <MODULE>` (one line per keyword: ID, name, file:line, arguments, documentation, calls, callers, suggested level; plus the module's screens and flows) and write `qa-ai-data/knowledge/meaning/keyword/<MODULE>.md`:
```
# Keyword meaning: MOD-CLIENT
KW-OPEN-CLIENT | page | Searches a client and opens its page | SCREEN-CLIENT-SEARCH | FLOW-CLIENT-ADD-ADDRESS:2
KW-LOGIN-TO-PORTAL | flow | - | SCREEN-LOGIN | FLOW-COMMON-LOGIN:1
## Flow step mapping
FLOW-CLIENT-ADD-ADDRESS | Add an address
1 | Log in | KW-LOGIN-TO-PORTAL
2 | Open the client | KW-OPEN-CLIENT
3 | Select the new option | GAP
```
Columns: keyword ID (exactly as the worksheet shows it) | level (`step`, `page` or `flow`) | purpose in business language, or `-` when its documentation already says it | screen IDs | flow IDs with the step number. Every keyword of the module gets a line. Keep existing lines for keywords that did not change. Conventions only the code reading cannot show (where new keywords for each module belong) go once into `meaning/keyword/_conventions.md`.
Then `knowledge_build.py render keyword` writes, from the extract plus your meaning, exactly the files below (templates in section 6): every keyword with file, line, library, arguments, returns, calls, locator variables, callers, duplicates (same steps) with the preferred one, Sleep use and status; the registry, the library keywords in use, the coverage of flows and the quality findings. Never write or edit these files by hand; hand-written `## Notes` and `## Learned` sections in a module file are kept by every render.
```
qa-ai-data/knowledge/
  keyword-knowledge.md        # index, conventions, registry (rendered)
  keywords/MOD-<NAME>.md      # keywords grouped by the module that owns them (rendered)
  meaning/keyword/            # your meaning lines (kept; commit with the knowledge)
```

## 4. Procedure

### Step 1: Pre-flight
- Capture `git rev-parse HEAD` and branch; warn about uncommitted changes to keyword files.
- Read the app knowledge index: load the screen, flow and module registries.
- Inventory: count resource files, user keywords, Python library keywords. Show the inventory before heavy processing.

### Step 2: Full or incremental
The plan from `split_extract.py` decides (qa-knowledge-setup step 1): build the modules in this stage's `changed` list, keep `unchanged` ones. For `rebuild`, every module is in `changed`. Modules listed in `not_in_this_extract` are outside this run's scope: never delete or change their files. A module's keyword file covers the keywords it owns; shared keywords are in the `MOD-COMMON` module files.

### Step 3: Detect conventions (write to the index)
- Automation library per resource file: Browser or SeleniumLibrary (from `Library` imports).
- Resource file layout: e.g. one resource per page or module, a common resource, a locators file.
- Keyword naming style (e.g. Title Case verbs: "Navigate To Addresses Tab"), argument style (`${client_name}` vs `${CLIENT_NAME}`), embedded-argument usage.
- Documentation style: whether keywords use `[Documentation]`, `[Tags]`, `[Arguments]`, `[Return]` / `RETURN`.
- Wait and assertion patterns actually used (e.g. `Wait For Elements State`, `Wait Until Element Is Visible`, `Get Text ... ==`).
- Where locators are defined: in keywords inline, in variables sections, or in separate locator files.
- Test organisation (copied from app knowledge): one test per file or many tests per suite.

### Step 4: Write the meaning from the worksheet, one module at a time
The facts listed below are rendered by the script; you supply purpose (when undocumented), level, screens, flows and the flow step mapping. **Work from the worksheet** (the module briefs remain available for a fact the worksheet lacks). qa-knowledge-setup has already run `split_extract.py plan`, which cut the extract into one brief per module (`qa-ai-data/knowledge/.tmp/briefs/<MODULE>/brief.json`: the module's tests, the keywords and locators it owns, the shared keywords it calls by name only, its routes, messages and development links) and listed which modules to build for this stage (`changed`). Build only those; leave the files of `unchanged` modules exactly as they are. Take every fact from the brief; never read the `.robot`, `.resource` or development source files to collect facts again, and never read another module's brief. Open a source file only for one specific line range (at most 300 lines) when the brief lacks a fact. Keep the Notes and learned entries of the module's existing file. When you work as a sub-agent for one module, read only this skill file, your brief and your module's existing file, write only your module's files, and reply with the files written, the counts and any open questions; the main agent records the module and writes the index files.
For each user keyword record:
- Keyword ID `KW-<NAME>` (the file name is added only when two keywords share a name; the worksheet shows it), exact keyword name, file path and line number.
- Arguments with defaults, embedded arguments, return value.
- One-line purpose in business language (from `[Documentation]`, or inferred from its steps; mark inferred).
- Library keywords it calls (summarised) and user keywords it calls (by keyword ID), giving a call tree.
- Locator variables it uses (by variable name only; locator-knowledge-builder details them).
- **Links:** screen IDs it acts on and flow IDs or flow steps it performs, matched from the app knowledge flows and the tests that call it.
- **Usage:** number of tests calling it and 2-3 example tests (path::test name).
- **Level:** `step` (one UI action), `page` (a screen task), or `flow` (a complete business flow).
- Status: `active`, `unused` (no callers), or `deprecated` (removed from code).

Also record library keywords actually used in the repo, with usage counts, so the generator knows the accepted vocabulary.

### Step 5: Map flow steps to keywords
For every flow in the app knowledge, map each business step to the keyword that performs it (or `GAP` if none). Write this as the `## Flow step mapping` part of `meaning/keyword/<MODULE>.md`; the render turns it into the step-to-keyword table of the module file. This table is what robot-script-generator uses first.

### Step 6: Detect quality issues (report only, never fix)
- Duplicate or near-duplicate keywords (same steps, different names): list them and mark the most-used as **preferred**.
- Keywords with hard-coded waits (`Sleep`), hard-coded data or credentials-like literals.
- Unused keywords.

### Step 7: Self-validate
Run `knowledge_build.py render keyword`, then `knowledge_build.py check`; fix what they list (a meaning line for an unknown ID, a screen or flow ID not in the app knowledge, a keyword without purpose) in the meaning file and render again. Never write helper scripts.
- Every keyword ID unique; every file path and line exists.
- Every screen and flow ID used exists in the app knowledge registries.
- Counts in the index match the module files.
- No secrets in output.

### Step 8: Report
Run type, keywords catalogued, links made, flows fully covered vs with gaps, duplicates, unused, unmatched keywords, output paths. Do not commit.

## 5. ID rules
- `KW-<NAME>` (plus `-<FILE>` when two keywords share a name), uppercase, hyphenated, unique; made by the script from the keyword name, so it does not change when modules are regrouped. A keyword renamed in code gets a new ID; `render` lists meaning lines for IDs that no longer exist, so move those lines to the new ID.

## 6. Templates

### Module file: `qa-ai-data/knowledge/keywords/MOD-<NAME>.md`
```
# Keywords: <Module name> (MOD-<NAME>)
Last updated: <ISO date> | Commit: <hash>

## Flow step mapping
### FLOW-<...> | <Flow name>
| # | Business step | Keyword ID | Keyword call |
| 1 | Log in | KW-COMMON-LOGIN-TO-PORTAL | Login To Portal    ${USER}    ${PASSWORD} |
| 2 | Open client | KW-CLIENT-OPEN-CLIENT | Open Client    ${client_name} |
| 3 | Select new option | GAP | - |

## Keywords
### KW-<...> | <Exact Keyword Name>
- File: <path>:<line>
- Library: Browser | SeleniumLibrary
- Level: step | page | flow
- Arguments: ${arg1}, ${arg2}=default
- Returns: <value or none>
- Purpose: <business language> (inferred: yes|no)
- Screens: SCREEN-<...>
- Flows: FLOW-<...> (step n)
- Calls: KW-<...>, KW-<...>
- Locator variables: ${CROSS_REF_TAB}, ...
- Used by: <count> tests, e.g. <path>::<test>
- Preferred: yes | no (duplicate of KW-<...>)
- Status: active | unused | deprecated
```

### Index file: `qa-ai-data/knowledge/keyword-knowledge.md`
```
# Keyword Knowledge: <project_name>

## Metadata
- schema_version: 1
- generated_at / last_commit / branch
- linked_app_commit: <app knowledge commit>

## Conventions
- Automation library (per resource file if mixed)
- Resource layout and where new keywords for each module belong
- Naming, argument and documentation style (with one real example)
- Wait and assertion patterns in use
- Where locators live
- Test organisation

## Registry
| Keyword ID | Name | Module | Level | Used by | Status |

## Library keywords in use
| Library | Keyword | Uses |

## Coverage
- Flows fully mapped / flows with gaps (list gap steps)

## Quality findings
- Duplicates, Sleep usage, hard-coded data, unused keywords
```

## 7. Error handling
- Unparseable file: skip, log, continue.
- Keyword that matches no screen or flow: keep it, list it under "Unlinked" in the module or COMMON file.
- Ambiguous match (one keyword fits several flows): link all, note it.
- Large resource files: process in sections; never skim.

## 8. Example requests
- "@keyword-knowledge-builder build the keyword knowledge for this repo."
- "@keyword-knowledge-builder refresh keyword knowledge since the last run."
- "@keyword-knowledge-builder rebuild keyword knowledge for the Client module only."
