"""
ai_activity_indicator.py - AI status badge and timing report during AI Robot runs (a Robot listener).

Used ONLY by robot-script-generator for its own headed runs, and it does nothing unless the
run also passes the variable AI_RUN:
    robot --listener qa-ai-skills/skills/ai_activity_indicator.py --variable AI_RUN:final ... <draft>.robot
    AI_RUN:final  the AI's full test run      -> yellow badge, "ROBOT FRAMEWORK RUN"
    AI_RUN:steps  the AI's short "reach" run  -> blue badge, "ROBOT FRAMEWORK MCP" role
Without AI_RUN (for example a person rerunning the test, even with this listener left in the
command) there is no badge and no timing file. Never add this to test code, suites or CI.

1) Badge: a coloured glow around the page and a two-line badge a manager can follow:
       line 1 (bold):  "AI assistant is logging in"
       line 2 (grey):  "Keyword: Login To Portal"   (or "... (new, created by AI)")
   Business step names only, never arguments, client names, IDs or other data.

2) Timing report: writes ai-timing.json next to output.xml with, for every business
   (user) keyword: total time, time spent in fixed Sleep and in waits, and where it is
   defined. The generator uses it to suggest faster code to the team (it never edits it).

3) Heartbeat and safe stop (watchdog): writes ai-heartbeat.json next to output.xml with the
   running test and the open keywords (names, start times, their own wait limits, the locator
   a click or wait is acting on; never typed values), and the result of each finished test.
   `ai_run.py watch` reads it to tell a slow step from a stalled one. When the watch asks for a
   stop (ai-stop-request.json), this listener stops Robot the same way Ctrl+C does: the running
   test fails with "Execution terminated by signal", teardowns still run (shared data is
   restored) and output.xml is written. A second request forces the stop.

Safe by design: the overlay ignores the mouse, its text is invisible to locators and
"Page Should Contain" (closed shadow root), it works with strict CSP pages, it is re-drawn
after page navigation, and every error is swallowed so it can never fail a test.
Works with the Browser library (Playwright) and SeleniumLibrary. Robot Framework 4+.
"""
import json
import os
import re
import signal
import threading
import time

ROBOT_LISTENER_API_VERSION = 2

_HERE = os.path.dirname(os.path.abspath(__file__))
_JS_FILE = os.path.join(_HERE, "ai_activity_indicator.js")

LIBRARIES = {"builtin", "seleniumlibrary", "browser", "collections", "string", "operatingsystem",
             "datetime", "xml", "process", "screenshot", "dialogs", "telnet", "requestslibrary",
             "databaselibrary", "json", "jsonlibrary", "ai_session", "easter", "reserved"}

# Plain, professional wording by what a business step does (first match wins).
FRIENDLY = [
    (r"^(verify|validate|assert|ensure|expect|check that|confirm that)|should", "Checking the result"),
    (r"log ?in|sign ?in|authenticat", "Logging in"),
    (r"log ?out|sign ?out", "Logging out"),
    (r"open (the )?browser|launch|start (the )?app|new browser|open application", "Opening the application"),
    (r"vault|credential|config|load|setup|set up|initiali", "Preparing the test environment"),
    (r"(search|find|look ?up).*client|client.*(search|find|look ?up)", "Finding the client"),
    (r"search|find|look ?up|filter", "Finding the record"),
    (r"select (the )?client|choose (the )?client|open (the )?client", "Opening the client"),
    (r"navigate|go to|open|click .*tab|menu", "Opening the page"),
    (r"select|choose|pick", "Selecting an option"),
    (r"enter|fill|type|input|set ", "Entering the details"),
    (r"tick|check(box)?|uncheck|toggle", "Updating a setting"),
    (r"add|create|new ", "Adding a new item"),
    (r"save|submit|confirm", "Saving the changes"),
    (r"delete|remove", "Removing an item"),
    (r"close|teardown|clean", "Finishing up"),
]

INDICATOR_JS = None
_active = False      # True only when the run passes --variable AI_RUN:<final|steps>
_mode = "robot"
_busy = False
_label = ("AI assistant is preparing the test", "")
_stack = []          # open user keywords: {"name", "start", "sleep", "wait", "source", "line"}
_timing = {}         # name -> aggregated timing
_outdir = None
_hb = {"pid": os.getpid(), "started": None, "test": None, "test_started": None, "stack": [], "last_event": None,
       "events": 0, "results": [], "done": False, "stop_requests_seen": 0}
_hb_lock = threading.Lock()
_hb_last_write = 0.0
_watcher = None
TARGET_KW = re.compile(r"click|wait until|select|input|type|fill|submit|press|check|choose|go to|get text|element should", re.I)
WAIT_KW = re.compile(r"wait until|wait for", re.I)


def _secs(value):
    try:
        from robot.utils import timestr_to_secs
        return float(timestr_to_secs(value))
    except Exception:
        total, found = 0.0, False                   # "1 min 30 s", "45s", "2m", "10"
        for num, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(ms|milliseconds?|s|secs?|seconds?|m|mins?|minutes?|h|hours?)?", str(value), re.I):
            found = True
            u = (unit or "s").lower()
            total += float(num) * (0.001 if u.startswith("ms") or u.startswith("milli") else 60 if u.startswith("m") else 3600 if u.startswith("h") else 1)
        return total if found else None


def _own_timeout(name, args):
    """The wait limit a step sets for itself: timeout=..., or the time argument of Wait Until ... keywords."""
    args = [str(a) for a in (args or [])]
    for a in args:
        m = re.match(r"^\s*timeout\s*=\s*(.+)$", a, re.I)
        if m:
            return _secs(m.group(1))
    low = (name or "").lower()
    if "wait until keyword succeeds" in low and len(args) >= 2:
        retry, interval = args[0], args[1]
        m = re.match(r"^\s*(\d+)\s*x\s*$", retry, re.I)
        if m:
            iv = _secs(interval)
            return int(m.group(1)) * iv if iv is not None else None
        return _secs(retry)
    if WAIT_KW.search(low) and len(args) >= 2 and re.match(r"^\s*\d+(\.\d+)?\s*(ms|s|sec|secs|seconds?|m|min|mins|minutes?|h|hours?)?(\s+\d+(\.\d+)?\s*(ms|s|sec|secs|seconds?|m|min|mins|minutes?))*\s*$", args[1], re.I):
        return _secs(args[1])
    return None


def _hb_write(force=False):
    global _hb_last_write
    if not _active:
        return
    now = time.time()
    if not force and now - _hb_last_write < 0.5:
        return
    _hb_last_write = now
    try:
        folder = _outdir or os.getcwd()
        tmp = os.path.join(folder, "ai-heartbeat.json.part")
        with _hb_lock:
            data = dict(_hb, written=now)
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, os.path.join(folder, "ai-heartbeat.json"))
    except Exception:
        pass


def _watch_for_stop():
    """Stop requests from ai_run.py watch: the first one stops Robot gracefully (like Ctrl+C), a second forces it."""
    seen = 0
    while not _hb["done"]:
        time.sleep(1.0)
        try:
            folder = _outdir or os.getcwd()
            p = os.path.join(folder, "ai-stop-request.json")
            if not os.path.isfile(p):
                continue
            with open(p, encoding="utf-8") as fh:
                req = json.load(fh)
            n = int(req.get("count", 1))
            if n > seen:
                seen = n
                _hb["stop_requests_seen"] = n
                _hb_write(force=True)
                if hasattr(signal, "raise_signal"):
                    signal.raise_signal(signal.SIGINT)
                else:
                    os.kill(os.getpid(), signal.SIGINT)
        except Exception:
            pass
        try:
            _hb_write(force=True)                      # the watch also sees that the process is alive
        except Exception:
            pass


def _js():
    global INDICATOR_JS
    if INDICATOR_JS is None:
        try:
            INDICATOR_JS = open(_JS_FILE, encoding="utf-8").read()
        except Exception:
            INDICATOR_JS = ""
    return INDICATOR_JS


def friendly_label(keyword_name, new=False):
    """Returns (line1, line2) for the two-line badge, e.g.
    ('AI assistant is logging in', 'Login To Portal'); new AI keywords get ' (new, created by AI)'."""
    name = re.sub(r"\s+", " ", (keyword_name or "").replace("_", " ")).strip()
    low = name.lower()
    action = "running a test step"
    for pattern, text in FRIENDLY:
        if re.search(pattern, low):
            action = text[0].lower() + text[1:]
            break
    line2 = (name + (" (new, created by AI)" if new else ""))[:80] if name else ""
    return ("AI assistant is " + action)[:90], line2


KEYWORD_TYPES = {"KEYWORD", "SETUP", "TEARDOWN"}


def _is_real_keyword(attrs):
    """FOR, IF, ELSE, TRY, WHILE, ITERATION, VAR, RETURN ... are control structures, not
    keywords: listener API v2 reports them too, and their 'name' is e.g. '${x} IN [ a | b ]'."""
    return str(attrs.get("type") or "KEYWORD").upper() in KEYWORD_TYPES


def _readable(name):
    """A keyword name fit for the badge, or '' if it still contains an unresolved variable."""
    name = (name or "").strip()
    return "" if ("${" in name or "@{" in name or "&{" in name) else name


def _is_user_keyword(attrs):
    lib = (attrs.get("libname") or "").strip().lower()
    return lib not in LIBRARIES


SELENIUM_NAMES = ("SeleniumLibrary", "Selenium2Library", "ExtendedSelenium2Library", "ExtendedSeleniumLibrary")


def _family(libname):
    """Selenium2Library (3.x) and its extended variants are SeleniumLibrary underneath."""
    return "SeleniumLibrary" if libname in SELENIUM_NAMES else libname


def _library(class_name):
    try:
        from robot.libraries.BuiltIn import BuiltIn
        libs = BuiltIn().get_library_instance(all=True)
    except Exception:
        return None
    for lib in libs.values():
        if class_name in {c.__name__ for c in type(lib).__mro__} or _family(type(lib).__name__) == class_name:
            return lib
    return None


def _apply(libname):
    global _busy
    if not _active or _busy or not _js():
        return
    _busy = True
    l1, l2, m = json.dumps(_label[0]), json.dumps(_label[1]), json.dumps(_mode)
    script = ("window.__aiLabelText = %s; window.__aiKeywordText = %s; window.__aiMode = %s;\n"
              % (l1, l2, m)) + _js() + \
             "\ntry { window.__aiSetLabel && window.__aiSetLabel(%s, %s, %s) } catch (e) {}" % (l1, l2, m)
    try:
        if libname == "Browser":
            lib = _library("Browser")
            if lib is not None:
                lib.evaluate_javascript(None, "() => {" + script + "}")
        elif libname == "SeleniumLibrary":
            lib = _library("SeleniumLibrary")
            if lib is not None:
                lib.driver.execute_script(script)
    except Exception:
        pass      # no page yet, navigating, browser closed, inside a frame: ignore
    finally:
        _busy = False


# ------------------------------------------------------------------ listener methods
def start_suite(name, attrs):
    global _outdir, _active, _mode
    try:
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        _outdir = bi.get_variable_value("${OUTPUT DIR}")
        flag = str(bi.get_variable_value("${AI_RUN}", "") or "").strip().lower()
        _active = flag in ("final", "steps", "true", "1", "yes")
        _mode = "rf" if flag == "steps" else "robot"
    except Exception:
        _outdir, _active = None, False
    global _watcher
    if _active and _watcher is None:
        _hb["started"] = time.time()
        _hb["last_event"] = time.time()
        try:
            stale = os.path.join(_outdir or os.getcwd(), "ai-stop-request.json")
            if os.path.isfile(stale):
                os.remove(stale)
        except Exception:
            pass
        _watcher = threading.Thread(target=_watch_for_stop, name="ai-run-watch", daemon=True)
        _watcher.start()
        _hb_write(force=True)


def start_test(name, attrs):
    global _label
    _label = ("AI assistant is starting the test", (name or "")[:80])
    with _hb_lock:
        _hb["test"], _hb["test_started"], _hb["stack"] = name, time.time(), []
        _hb["last_event"] = time.time()
        _hb["events"] += 1
    _hb_write(force=True)


def end_test(name, attrs):
    with _hb_lock:
        _hb["results"].append({"name": name, "status": attrs.get("status"), "secs": round((attrs.get("elapsedtime") or 0) / 1000.0, 1),
                               "message": re.sub(r"\s+", " ", str(attrs.get("message") or ""))[:240]})
        _hb["test"], _hb["stack"] = None, []
        _hb["last_event"] = time.time()
        _hb["events"] += 1
    _hb_write(force=True)


def _hb_push(name, attrs, user):
    args = attrs.get("args") or []
    frame = {"name": (attrs.get("kwname") or name or "")[:120], "user": user, "started": time.time(),
             "own_timeout": _own_timeout(attrs.get("kwname") or name, args),
             "parent": next((f["name"] for f in reversed(_hb["stack"]) if f["user"]), None)}
    if not user and args and TARGET_KW.search(frame["name"]) and str(args[0]).startswith(("${", "id:", "css:", "xpath:", "//", "name:", "#", "[")):
        frame["target"] = str(args[0])[:160]          # the locator only; typed values are never written
    with _hb_lock:
        _hb["stack"].append(frame)
        _hb["last_event"] = time.time()
        _hb["events"] += 1
    _hb_write()


def _hb_pop():
    with _hb_lock:
        if _hb["stack"]:
            _hb["stack"].pop()
        _hb["last_event"] = time.time()
        _hb["events"] += 1
    _hb_write()


def start_keyword(name, attrs):
    global _label
    try:
        if _active and _is_real_keyword(attrs):
            _hb_push(name, attrs, _is_user_keyword(attrs))
    except Exception:
        pass
    try:
        if not _is_real_keyword(attrs):
            return                         # loops and conditions keep the current label
        if _is_user_keyword(attrs):
            kw = (attrs.get("kwname") or name or "").strip()
            _stack.append({"name": kw, "start": time.time(), "sleep": 0.0, "wait": 0.0, "swallowed": 0.0, "after_ready": 0.0,
                           "ready": False, "source": attrs.get("source"), "line": attrs.get("lineno")})
            shown = _readable(kw)
            if shown and len(_stack) <= 2:  # top-level business steps only, not inner helpers
                tags = [str(t).lower() for t in (attrs.get("tags") or [])]
                _label = friendly_label(shown, new="ai-generated" in tags)
        else:
            low = (attrs.get("kwname") or name or "").lower()
            if (_family(attrs.get("libname")) in ("SeleniumLibrary", "Browser")
                    and ("open browser" in low or "new browser" in low or "new page" in low)):
                _label = ("AI assistant is opening the application (this can take a minute)", "")
    except Exception:
        pass


def end_keyword(name, attrs):
    try:
        if _active and _is_real_keyword(attrs):
            _hb_pop()
            if not _is_user_keyword(attrs):         # slowest time of each library step inside each business step
                parent = next((k["name"] for k in reversed(_stack)), "")
                key = f"{parent} > {attrs.get('kwname') or name}"
                secs_ = (attrs.get("elapsedtime") or 0) / 1000.0
                t = _timing.setdefault("__steps__", {})
                t[key] = max(t.get(key, 0.0), round(secs_, 2))
    except Exception:
        pass
    try:
        if not _is_real_keyword(attrs):
            return
        libname = _family(attrs.get("libname"))
        low = (attrs.get("kwname") or name or "").lower()
        secs = (attrs.get("elapsedtime") or 0) / 1000.0
        if _is_user_keyword(attrs):
            if _stack:
                k = _stack.pop()
                t = _timing.setdefault(k["name"], {"keyword": k["name"], "calls": 0, "total_s": 0.0,
                                                   "sleep_s": 0.0, "wait_s": 0.0, "swallowed_wait_s": 0.0, "sleep_after_ready_s": 0.0,
                                                   "source": k["source"], "line": k["line"]})
                t["calls"] += 1
                took = time.time() - k["start"]
                t["total_s"] = round(t["total_s"] + took, 2)
                t["max_s"] = round(max(t.get("max_s", 0.0), took), 2)
                t["sleep_s"] = round(t["sleep_s"] + k["sleep"], 2)
                t["wait_s"] = round(t["wait_s"] + k["wait"], 2)
                if attrs.get("status") == "PASS":     # a wait that timed out inside a keyword that still passed was swallowed
                    t["swallowed_wait_s"] = round(t.get("swallowed_wait_s", 0.0) + k["swallowed"], 2)
                t["sleep_after_ready_s"] = round(t.get("sleep_after_ready_s", 0.0) + k["after_ready"], 2)
        else:
            if _stack and low == "sleep":
                for k in _stack:
                    k["sleep"] += secs
                if _stack[-1].get("ready"):              # the page had already answered a wait in this keyword
                    for k in _stack:
                        k["after_ready"] += secs
            elif _stack and (low.startswith("wait") or "wait until" in low or "wait for" in low):
                failed = attrs.get("status") == "FAIL"
                for k in _stack:
                    k["wait"] += secs
                    if failed:
                        k["swallowed"] += secs
                if not failed:
                    _stack[-1]["ready"] = True
            elif _stack and attrs.get("status") == "PASS" and re.search(r"should be visible|should contain|get element states|element should|get text", low):
                _stack[-1]["ready"] = True
            if libname in ("Browser", "SeleniumLibrary") and "close" not in low:
                _apply(libname)
    except Exception:
        pass


def close():
    if not _active:
        return
    _hb["done"] = True
    _hb_write(force=True)
    try:
        folder = _outdir or os.getcwd()
        steps = _timing.pop("__steps__", {})
        rows = sorted(_timing.values(), key=lambda r: -r["total_s"])
        with open(os.path.join(folder, "ai-timing.json"), "w", encoding="utf-8") as f:
            json.dump(rows + ([{"keyword": "__steps__", "max_s": steps}] if steps else []), f, indent=1)
    except Exception:
        pass
