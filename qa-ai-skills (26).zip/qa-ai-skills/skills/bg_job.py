#!/usr/bin/env python3
"""
bg_job.py - runs a long command in the background so the editor never waits on it, and answers
"how far is it?" in a short call. Part of the QA AI skills. Standard library only.

Why: an editor's agent (Devin, Copilot, Claude Code) stalls or times out when one command runs for many
minutes (a 50,000-test extract, a long Robot run). Every call here returns within --max seconds
(default 45), so the agent stays responsive, and shows the user real progress.

  python qa-ai-skills/skills/bg_job.py start <name> -- <command ...>   start it; returns at once
  python qa-ai-skills/skills/bg_job.py wait <name> [--max 45]          wait up to --max s, then the status
  python qa-ai-skills/skills/bg_job.py status <name>                   running / done / failed, time, last lines
  python qa-ai-skills/skills/bg_job.py stop <name>
  python qa-ai-skills/skills/bg_job.py --self-test

Output and state live in qa-ai-data/session/jobs/ (git-ignored). Starting a job whose name is
still running is refused, so a resumed session never starts the same work twice.
"""
import argparse, datetime, json, os, shutil, signal, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))


def jobs_dir(root="."):
    home = ai_home(root)
    d = os.path.join(home, "session", "jobs")
    os.makedirs(d, exist_ok=True)
    return d


def ai_home(root="."):
    """Your data (knowledge, generated tests, results, session) lives in <QA repo>/qa-ai-data/, OUTSIDE the
    qa-ai-skills package, so replacing the package never touches it. Older layouts are read until the installer
    moves them: <QA repo>/qa-ai-skills/<data>, and before that the repo root."""
    d = os.path.join(root, "qa-ai-data")
    if os.path.isdir(d):
        return d
    old = os.path.join(root, "qa-ai-skills")
    if any(os.path.isdir(os.path.join(old, x)) for x in ("knowledge", "ai_generated_tests", "results", "session")):
        return old
    return d if os.path.isdir(old) else root


def paths(name, root="."):
    d = jobs_dir(root)
    safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in name)[:60] or "job"
    return {"state": os.path.join(d, safe + ".json"), "log": os.path.join(d, safe + ".log"), "exit": os.path.join(d, safe + ".exit")}


def alive(pid):
    if not pid:
        return False
    if os.name == "nt":
        try:
            out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, timeout=10).stdout
            return str(pid) in out
        except Exception:
            return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:                                                    # a finished child that was never reaped is not running
        done, _ = os.waitpid(pid, os.WNOHANG)
        return done == 0
    except ChildProcessError:
        return True
    except OSError:
        return True


def load(p):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def elapsed(since):
    try:
        s = int((datetime.datetime.now() - datetime.datetime.fromisoformat(since)).total_seconds())
    except Exception:
        return "?"
    return f"{s // 60}m {s % 60:02d}s" if s >= 60 else f"{s}s"


def tail(path, n=3):
    try:
        with open(path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 8192))
            lines = fh.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []
    return [l for l in lines if l.strip()][-n:]


def state_of(name, root="."):
    p = paths(name, root)
    st = load(p["state"])
    if not st:
        return None, p
    code = None
    if os.path.isfile(p["exit"]):
        try:
            code = int(open(p["exit"]).read().strip() or "1")
        except ValueError:
            code = 1
    if code is not None:
        st["status"] = "done" if code == 0 else "failed"
        st["exit_code"] = code
    elif alive(st.get("pid")):
        st["status"] = "running"
    else:
        st["status"] = "stopped"                            # the computer or editor was restarted mid-run
    return st, p


def show(name, root="."):
    st, p = state_of(name, root)
    if not st:
        print(f"No job named {name}.")
        return 2
    label = {"running": "Running", "done": "Done", "failed": "Failed", "stopped": "Stopped (not finished)"}[st["status"]]
    print(f"{label}: {name} ({elapsed(st['started'])}" + (f", exit code {st['exit_code']}" if st.get("exit_code") else "") + ")")
    for l in tail(p["log"], 3 if st["status"] == "running" else 6):
        print("  " + l[:200])
    if st["status"] == "stopped":
        print("  Start it again with the same command: it continues from its last saved point where the command supports it.")
    if st["status"] in ("done", "failed"):
        print(f"  Full output: {os.path.relpath(p['log'])}")
    return {"running": 0, "done": 0, "failed": 1, "stopped": 3}[st["status"]]


def cmd_start(name, command, root="."):
    st, p = state_of(name, root)
    if st and st["status"] == "running":
        print(f"Already running: {name} ({elapsed(st['started'])}). Use: bg_job.py wait {name}")
        return 0
    for k in ("exit",):
        if os.path.isfile(p[k]):
            os.remove(p[k])
    runner = [sys.executable, os.path.abspath(__file__), "_run", p["exit"], "--"] + command
    log = open(p["log"], "w", encoding="utf-8")
    kw = {"stdout": log, "stderr": subprocess.STDOUT, "stdin": subprocess.DEVNULL, "cwd": os.path.abspath(root)}
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1")
    if os.name == "nt":
        kw["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        kw["start_new_session"] = True
    proc = subprocess.Popen(runner, env=env, **kw)
    log.close()
    with open(p["state"], "w", encoding="utf-8") as fh:
        json.dump({"name": name, "pid": proc.pid, "started": datetime.datetime.now().isoformat(timespec="seconds"),
                   "command": command}, fh, indent=1)
    print(f"Started in the background: {name}. Check it with: bg_job.py wait {name}")
    return 0


def cmd_wait(name, max_secs=45, root="."):
    end = time.time() + max(1, min(max_secs, 55))
    while time.time() < end:
        st, _ = state_of(name, root)
        if not st or st["status"] != "running":
            break
        time.sleep(1)
    return show(name, root)


def cmd_stop(name, root="."):
    st, p = state_of(name, root)
    if not st or st["status"] != "running":
        print(f"Not running: {name}")
        return 0
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(st["pid"]), "/T", "/F"], capture_output=True, timeout=20)
        else:
            os.killpg(st["pid"], signal.SIGTERM)
    except Exception:
        pass
    with open(p["exit"], "w") as fh:
        fh.write("143")
    print(f"Stopped: {name}")
    return 0


def run_child(exit_file, command):
    try:
        code = subprocess.call(command)
    except Exception as e:
        print(f"Could not start: {type(e).__name__}: {e}", flush=True)
        code = 127
    with open(exit_file, "w") as fh:
        fh.write(str(code))
    return code


def self_test():
    tmp = tempfile.mkdtemp(prefix="bg_job_selftest_")
    ok = {}
    try:
        os.makedirs(os.path.join(tmp, "qa-ai-skills"))
        prog = "import time,sys\nfor i in range(3):\n    print(f'step {i+1} of 3', flush=True); time.sleep(0.4)\n"
        cmd_start("demo", [sys.executable, "-c", prog], tmp)
        st, _ = state_of("demo", tmp)
        ok["start returns at once; the job runs in the background"] = st["status"] == "running"
        code = cmd_start("demo", [sys.executable, "-c", prog], tmp)
        ok["a running job is never started twice"] = code == 0 and state_of("demo", tmp)[0]["pid"] == st["pid"]
        t0 = time.time()
        cmd_wait("demo", 1, tmp)
        ok["wait returns within its limit"] = time.time() - t0 < 3
        cmd_wait("demo", 20, tmp)
        st, p = state_of("demo", tmp)
        ok["done with its output kept"] = st["status"] == "done" and "step 3 of 3" in open(p["log"]).read()
        cmd_start("bad", [sys.executable, "-c", "import sys; print('boom'); sys.exit(4)"], tmp)
        cmd_wait("bad", 20, tmp)
        st, _ = state_of("bad", tmp)
        ok["a failing job is reported with its exit code"] = st["status"] == "failed" and st["exit_code"] == 4
        cmd_start("long", [sys.executable, "-c", "import time; time.sleep(30)"], tmp)
        cmd_stop("long", tmp)
        ok["stop ends a running job"] = state_of("long", tmp)[0]["status"] == "failed"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] == ["--self-test"]:
        return self_test()
    if argv[:1] == ["_run"]:
        return run_child(argv[1], argv[3:])
    ap = argparse.ArgumentParser(description="Run long commands in the background; every call returns quickly.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("start"); s.add_argument("name"); s.add_argument("command", nargs=argparse.REMAINDER)
    w = sub.add_parser("wait"); w.add_argument("name"); w.add_argument("--max", type=int, default=45)
    sub.add_parser("status").add_argument("name")
    sub.add_parser("stop").add_argument("name")
    a = ap.parse_args(argv)
    if a.cmd == "start":
        command = a.command[1:] if a.command[:1] == ["--"] else a.command
        if not command:
            ap.error("give the command after --")
        return cmd_start(a.name, command)
    if a.cmd == "wait":
        return cmd_wait(a.name, a.max)
    if a.cmd == "status":
        return show(a.name)
    return cmd_stop(a.name)


if __name__ == "__main__":
    sys.exit(main())
