#!/usr/bin/env python3
"""
qtest_mcp.py - a small, read-only qTest MCP server for the QA AI skills.

It runs on the tester's machine (started by the editor from the MCP settings, like Playwright and
rf-mcp) and talks to the company's qTest through qTest's normal REST API (v3). It never creates,
changes or deletes anything in qTest.

Tools
  qtest_get_test_case      a test case by its ID as testers see it (TC-1328) or its internal number:
                           name, description, precondition, steps with expected results (called test
                           cases inlined), test data and other fields; saves a local copy for traceability
  qtest_search_test_cases  test cases whose name contains some words (to find the right ID)
  qtest_check_connection   checks the address, project and token (never shows the token)

Settings (looked up in this order: the .env file in the QA repo, then environment variables, then -
for the token - the vault, loaded exactly the way the tests load it):
  QTEST_URL            e.g. https://qtest.mybank.com          (no /api part)
  QTEST_PROJECT_ID     the qTest project number
  QTEST_TOKEN          the tester's own qTest API token (qTest > Resources > API & SDK)
  QTEST_VAULT_NAME     name of the token in the vault (default QTEST_TOKEN)
  QTEST_VAULT_SUITE    optional: the suite whose imports load the vault (default: found from the knowledge)
  QTEST_VAULT_ROBOT_ARGS optional: extra robot options for loading the vault, e.g. --variable ENV:QA
  QTEST_SAVE_DIR       where local copies go (default qa-ai-data/ai_generated_tests/test_cases/qtest)
  QTEST_CA_BUNDLE      optional: company certificate file, if qTest uses an internal certificate

Python 3.8+, standard library only. Run from the QA repo folder (the MCP entry sets cwd).
  python skills/qtest/qtest_mcp.py [--root <QA repo>]   start the MCP server (stdio)
  python skills/qtest/qtest_mcp.py --check       check the connection from a terminal
  python skills/qtest/qtest_mcp.py --get TC-1328 fetch one test case from a terminal
  python skills/qtest/qtest_mcp.py --self-test
"""
import datetime, html, json, os, re, shutil, ssl, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request
from html.parser import HTMLParser

SERVER_NAME, SERVER_VERSION = "qtest", "1.0.0"
TIMEOUT = 30
def ai_home(repo="."):
    """Your data (knowledge, generated tests, results, session) lives in <QA repo>/qa-ai-data/, OUTSIDE the
    qa-ai-skills package, so replacing the package never touches it. Older layouts are read until the installer
    moves them: <QA repo>/qa-ai-skills/<data>, and before that the repo root."""
    d = os.path.join(repo, "qa-ai-data")
    if os.path.isdir(d):
        return d
    old = os.path.join(repo, "qa-ai-skills")
    if any(os.path.isdir(os.path.join(old, x)) for x in ("knowledge", "ai_generated_tests", "results", "session")):
        return old
    return d if os.path.isdir(old) else repo



def log(msg):
    print(f"[qtest-mcp] {msg}", file=sys.stderr, flush=True)


# ----------------------------------------------------------------------------------- settings
def read_env_file(path):
    vals = {}
    try:
        with open(path, encoding="utf-8-sig") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                if k.startswith("export "):
                    k = k[7:].strip()
                v = v.strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
                    v = v[1:-1]
                else:
                    v = re.split(r"\s+#", v, maxsplit=1)[0].strip()
                vals[k] = v
    except OSError:
        pass
    return vals


class Settings:
    def __init__(self, root=None, environ=None):
        self.root = os.path.abspath(root or os.getcwd())
        self.environ = os.environ if environ is None else environ
        self.env_file = self.environ.get("QTEST_ENV_FILE") or os.path.join(self.root, ".env")
        self._token, self.token_source = None, None

    def get(self, key, default=None):
        """.env first, then the environment."""
        dot = read_env_file(self.env_file)
        if dot.get(key):
            return dot[key]
        if self.environ.get(key):
            return self.environ[key]
        return default

    def source_of(self, key):
        if read_env_file(self.env_file).get(key):
            return ".env"
        if self.environ.get(key):
            return "environment variable"
        return None

    @property
    def url(self):
        u = (self.get("QTEST_URL") or "").strip().rstrip("/")
        u = re.sub(r"/api(/v\d+)?(/.*)?$", "", u)
        if u and not re.match(r"^https?://", u):
            u = "https://" + u
        return u

    @property
    def project(self):
        return (self.get("QTEST_PROJECT_ID") or "").strip()

    def token(self):
        if self._token:
            return self._token
        t = self.get("QTEST_TOKEN")
        if t:
            self._token, self.token_source = t, self.source_of("QTEST_TOKEN")
        else:
            t, why = vault_token(self)
            if t:
                self._token, self.token_source = t, "vault"
            else:
                self.vault_note = why
        if self._token:
            self._token = re.sub(r"^\s*bearer\s+", "", self._token, flags=re.I).strip()
        return self._token

    def missing(self):
        out = []
        if not self.url:
            out.append("QTEST_URL")
        if not self.project:
            out.append("QTEST_PROJECT_ID")
        return out


# ----------------------------------------------------------------------------------- vault
SECRET_SETUP = re.compile(r"vault|secret|credential|password|token|key ?vault|load.*(config|env)", re.I)


def find_vault_suite(s):
    """The suite (or folder __init__.robot) whose imports load the secrets, from the QA knowledge."""
    chosen = s.get("QTEST_VAULT_SUITE")
    if chosen:
        return chosen
    summ = os.path.join(ai_home(s.root), "knowledge", ".extract", "summary.json")
    try:
        loaders = json.load(open(summ, encoding="utf-8")).get("secrets_loaders") or {}
    except Exception:
        loaders = {}
    if loaders:
        inits = sorted(k for k in loaders if k.endswith("__init__.robot"))
        return (inits or sorted(loaders))[0]
    return None


def settings_lines(path):
    """Library / Resource / Variables imports and a secrets-loading Suite Setup of a suite file."""
    rows, in_settings, last = [], False, None
    for raw in open(path, encoding="utf-8", errors="replace"):
        line = raw.rstrip("\n")
        if re.match(r"^\*+\s*settings?\b", line.strip(), re.I):
            in_settings = True
            continue
        if re.match(r"^\*+", line.strip()):
            in_settings = False
            continue
        if not in_settings or not line.strip() or line.strip().startswith("#"):
            continue
        cells = [c.strip() for c in re.split(r"\t+| {2,}|\s\|\s", line.strip()) if c.strip()]
        if cells and cells[0] == "..." and last is not None:
            last.extend(cells[1:])
            continue
        if cells and cells[0].lower() in ("library", "resource", "variables", "suite setup"):
            last = cells
            rows.append(cells)
        else:
            last = None
    return rows


def vault_token(s):
    """Load the vault the way the tests do: a temporary suite (outside the team's folders) with the
    same imports as a suite that loads the secrets, run by Robot itself; the token is read from the
    loaded variables (or environment) and kept only in memory. Nothing is written to logs."""
    name = s.get("QTEST_VAULT_NAME", "QTEST_TOKEN")
    suite = find_vault_suite(s)
    if not suite:
        return None, (f"no QTEST_TOKEN in .env or the environment, and the vault loader for {name} is not known yet "
                      "(it is found by the knowledge setup; or set QTEST_VAULT_SUITE)")
    suite_path = suite if os.path.isabs(suite) else os.path.join(s.root, suite)
    if not os.path.isfile(suite_path):
        return None, f"the vault suite {suite} was not found"
    try:
        import robot  # noqa: F401
    except Exception:
        return None, "Robot Framework is not installed in the Python that runs this MCP (use the same Python as robot)"
    base = os.path.dirname(suite_path)
    out = ["*** Settings ***"]
    for cells in settings_lines(suite_path):
        kind, args = cells[0].title(), cells[1:]
        if not args:
            continue
        if kind == "Suite Setup":
            if SECRET_SETUP.search(args[0]) or args[0] == s.get("QTEST_VAULT_SETUP"):
                out.append("Suite Setup    " + "    ".join(args))
            continue
        target = args[0]
        if kind in ("Resource", "Variables") or target.endswith(".py"):
            cand = os.path.normpath(os.path.join(base, target))
            if "${" not in target and os.path.exists(cand):
                target = cand.replace("\\", "/")
        out.append(f"{kind}    " + "    ".join([target] + args[1:]))
    out += ["", "*** Test Cases ***", "Read The qTest Token",
            "    ${v}=    Get Variable Value    \\${${QTEST_NAME}}    ${None}",
            "    IF    $v is None",
            "        ${v}=    Evaluate    os.environ.get($QTEST_NAME)    modules=os",
            "    END",
            "    Log To Console    @@QTEST@@${v}@@QTEST@@", ""]
    tmp = tempfile.mkdtemp(prefix="qtest_vault_")
    try:
        suite_file = os.path.join(tmp, "read_qtest_token.robot")
        open(suite_file, "w", encoding="utf-8").write("\n".join(out))
        cmd = [sys.executable, "-m", "robot", "--output", "NONE", "--log", "NONE", "--report", "NONE",
               "--outputdir", tmp, "--console", "verbose", "--variable", f"QTEST_NAME:{name}"] + \
              (s.get("QTEST_VAULT_ROBOT_ARGS") or "").split() + [suite_file]
        r = subprocess.run(cmd, cwd=s.root, capture_output=True, text=True, timeout=180)
        text = (r.stdout or "") + (r.stderr or "")
        m = re.search(r"@@QTEST@@(.*?)@@QTEST@@", text, re.S)
        if m and m.group(1).strip() and m.group(1).strip() != "None":
            return m.group(1).strip(), None
        miss = re.search(r"Variable '([$@&%]\{[^}]+\})' not found", text)
        if miss:
            v = miss.group(1)[2:-1]
            return None, (f"loading the vault through {suite} needs the variable {miss.group(1)}: add "
                          f"QTEST_VAULT_ROBOT_ARGS=--variable {v}:<value> to .env (the value you normally run with, e.g. QA)")
        if not m:
            return None, f"the vault could not be loaded through {suite} (robot exit code {r.returncode})"
        return None, f"the vault was loaded through {suite}, but it has no value named {name} (set QTEST_VAULT_NAME in .env if the name differs)"
    except subprocess.TimeoutExpired:
        return None, "loading the vault took more than 3 minutes"
    except Exception as e:
        return None, f"the vault could not be loaded: {type(e).__name__}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------------------- qTest API
class QTestError(Exception):
    pass


class QTest:
    def __init__(self, settings):
        self.s = settings

    def _ctx(self):
        ca = self.s.get("QTEST_CA_BUNDLE")
        return ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()

    def call(self, method, path, body=None, query=None):
        miss = self.s.missing()
        if miss:
            raise QTestError(f"Missing setting(s): {', '.join(miss)}. Add them to the .env file in your QA repo.")
        token = self.s.token()
        if not token:
            raise QTestError("No qTest token found: " + getattr(self.s, "vault_note", "add QTEST_TOKEN to .env"))
        url = self.s.url + path
        if query:
            url += "?" + "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in query.items() if v is not None)
        data = json.dumps(body).encode("utf-8") if body is not None else None
        for attempt in (1, 2):
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=TIMEOUT, context=self._ctx() if url.startswith("https") else None) as r:
                    raw = r.read().decode("utf-8", "replace")
                    return json.loads(raw) if raw.strip() else {}
            except urllib.error.HTTPError as e:
                if e.code in (429, 502, 503, 504) and attempt == 1:
                    time.sleep(2)
                    continue
                if e.code == 401:
                    raise QTestError("qTest refused the token (401). Check QTEST_TOKEN: it may be expired or for another qTest site.")
                if e.code == 403:
                    raise QTestError(f"No permission (403) for project {self.s.project}.")
                if e.code == 404:
                    return None
                raise QTestError(f"qTest answered {e.code} for {method} {path}.")
            except urllib.error.URLError as e:
                reason = str(getattr(e, "reason", e))
                if "CERTIFICATE" in reason.upper():
                    raise QTestError("The qTest certificate is not trusted. Set QTEST_CA_BUNDLE in .env to your company certificate file.")
                raise QTestError(f"Cannot reach {self.s.url}: {reason}")
        raise QTestError("qTest did not answer.")

    def project_path(self):
        return f"/api/v3/projects/{self.s.project}"

    def search(self, query, page_size=20):
        res = self.call("POST", self.project_path() + "/search", {"object_type": "test-cases", "fields": ["*"], "query": query},
                        {"pageSize": page_size, "page": 1}) or {}
        return res.get("items") or []

    def test_case(self, internal_id):
        return self.call("GET", f"{self.project_path()}/test-cases/{internal_id}", query={"expand": "teststep"})

    def find(self, ref):
        """TC-1328, tc 1328, 1328 -> the test case. Visible IDs first, then internal numbers."""
        ref = str(ref).strip()
        m = re.match(r"^([A-Za-z]{1,6})[-_ ]?(\d+)$", ref)
        tried = []
        if m:
            pids = [f"{m.group(1).upper()}-{m.group(2)}"]
        elif ref.isdigit():
            pids = [f"TC-{ref}"]
        else:
            pids = [ref]
        for pid in pids:
            for q in (f"'id' = '{pid}'", f"'pid' = '{pid}'"):
                tried.append(q)
                for item in self.search(q, 5):
                    if str(item.get("pid", "")).upper() == pid.upper():
                        return self.test_case(item["id"])
        if ref.isdigit():
            tc = self.test_case(ref)
            if tc:
                return tc
        return None


# ----------------------------------------------------------------------------------- text
class _Text(HTMLParser):
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "ul", "ol", "table"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []

    def handle_starttag(self, tag, attrs):
        if tag == "li":
            self.out.append("\n- ")
        elif tag in self.BLOCK:
            self.out.append("\n")
        elif tag in ("td", "th"):
            self.out.append(" | ")

    def handle_endtag(self, tag):
        if tag in self.BLOCK and tag != "br":
            self.out.append("\n")

    def handle_data(self, data):
        self.out.append(data)


def plain(text):
    if not text:
        return ""
    t = str(text)
    if "<" in t and ">" in t:
        p = _Text()
        p.feed(t)
        t = "".join(p.out)
    t = html.unescape(t).replace("\xa0", " ")
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return re.sub(r"[ \t]{2,}", " ", t).strip()


def normalise(api, tc, depth=0, seen=None):
    seen = seen or set()
    props = {}
    for p in tc.get("properties") or []:
        name = p.get("field_name") or str(p.get("field_id"))
        val = p.get("field_value_name") or p.get("field_value")
        if isinstance(val, list):
            val = ", ".join(str(v) for v in val)
        val = plain(val) if isinstance(val, str) else val
        if val not in (None, "", "[]"):
            props[name] = val
    steps = []
    for st in sorted(tc.get("test_steps") or [], key=lambda x: x.get("order") or 0):
        called = st.get("called_test_case_id")
        if called and depth < 2 and called not in seen:
            sub = api.test_case(called)
            if sub:
                inner = normalise(api, sub, depth + 1, seen | {called})
                for s2 in inner["steps"]:
                    steps.append(dict(s2, from_called_test_case=f"{inner['id']} {inner['name']}"))
                continue
        steps.append({"action": plain(st.get("description")), "expected": plain(st.get("expected")),
                      **({"attachments": [a.get("name") for a in st.get("attachments") or [] if a.get("name")]}
                         if st.get("attachments") else {})})
    for i, s in enumerate(steps, 1):
        s["step"] = i
    data_fields = {k: v for k, v in props.items() if re.search(r"data|input|parameter", k, re.I)}
    return {"id": tc.get("pid"), "internal_id": tc.get("id"), "name": plain(tc.get("name")),
            "version": tc.get("version"), "module_id": tc.get("parent_id"), "web_url": tc.get("web_url"),
            "description": plain(tc.get("description")), "precondition": plain(tc.get("precondition")),
            "test_data": data_fields, "steps": steps,
            "other_fields": {k: v for k, v in props.items() if k not in data_fields}}


def to_markdown(case, fetched):
    lines = [f"# {case['id']}: {case['name']}", "",
             f"Source: qTest{(' ' + case['web_url']) if case.get('web_url') else ''} (version {case.get('version') or '-'}), "
             f"fetched {fetched} by the qTest MCP. This is a copy: qTest is the master.", ""]
    for title, key in (("Description", "description"), ("Precondition", "precondition")):
        if case.get(key):
            lines += [f"## {title}", case[key], ""]
    if case.get("test_data"):
        lines += ["## Test data"] + [f"- **{k}:** {v}" for k, v in case["test_data"].items()] + [""]
    lines += ["## Steps", "", "| # | Action | Expected result |", "|---|---|---|"]
    for s in case["steps"]:
        cell = lambda x: (x or "").replace("|", "\\|").replace("\n", "<br>")
        src = f" *(from {s['from_called_test_case']})*" if s.get("from_called_test_case") else ""
        lines.append(f"| {s['step']} | {cell(s['action'])}{src} | {cell(s['expected'])} |")
    if case.get("other_fields"):
        lines += ["", "## Other fields"] + [f"- **{k}:** {v}" for k, v in case["other_fields"].items()]
    return "\n".join(lines) + "\n"


# ----------------------------------------------------------------------------------- tools
TOOLS = [
    {"name": "qtest_get_test_case",
     "description": "Read one test case from qTest (read-only) by its ID as testers see it, e.g. TC-1328, or its internal number. "
                    "Returns the name, description, precondition, steps with expected results (called test cases included), "
                    "test data and other fields, and saves a local copy for traceability.",
     "inputSchema": {"type": "object", "properties": {
         "test_case": {"type": "string", "description": "e.g. TC-1328"},
         "save": {"type": "boolean", "description": "save a local copy (default true)"}}, "required": ["test_case"]}},
    {"name": "qtest_search_test_cases",
     "description": "Find qTest test cases whose name contains the given words (read-only). Returns IDs and names.",
     "inputSchema": {"type": "object", "properties": {
         "text": {"type": "string"}, "max": {"type": "integer", "description": "at most this many (default 10, max 50)"}},
         "required": ["text"]}},
    {"name": "qtest_check_connection",
     "description": "Check the qTest address, project and token (the token itself is never shown).",
     "inputSchema": {"type": "object", "properties": {}}},
]


def tool_get(api, s, args):
    ref = (args.get("test_case") or "").strip()
    if not ref:
        raise QTestError("Give a test case ID, e.g. TC-1328.")
    tc = api.find(ref)
    if not tc:
        raise QTestError(f"Test case {ref} was not found in qTest project {s.project}.")
    case = normalise(api, tc)
    if args.get("save", True):
        folder = s.get("QTEST_SAVE_DIR", os.path.relpath(os.path.join(ai_home(s.root), "ai_generated_tests", "test_cases", "qtest"), s.root))
        folder = folder if os.path.isabs(folder) else os.path.join(s.root, folder)
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, re.sub(r"[^\w.-]+", "_", case["id"] or ref) + ".md")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(to_markdown(case, datetime.date.today().isoformat()))
        case["saved_copy"] = os.path.relpath(path, s.root).replace("\\", "/")
    return case


def tool_search(api, s, args):
    words = (args.get("text") or "").strip().replace("'", "")
    if not words:
        raise QTestError("Give some words from the test case name.")
    n = max(1, min(int(args.get("max") or 10), 50))
    items = api.search(f"'name' ~ '{words}'", n)
    return {"found": [{"id": i.get("pid"), "name": plain(i.get("name")), "web_url": i.get("web_url")} for i in items[:n]]}


def tool_check(api, s, args):
    miss = s.missing()
    res = {"url": s.url or None, "project_id": s.project or None, "missing_settings": miss}
    if miss:
        res["ok"] = False
        return res
    proj = api.call("GET", api.project_path())
    res.update({"ok": bool(proj), "project_name": (proj or {}).get("name"), "token_from": s.token_source})
    if not proj:
        res["note"] = f"Project {s.project} was not found with this token."
    return res


HANDLERS = {"qtest_get_test_case": tool_get, "qtest_search_test_cases": tool_search, "qtest_check_connection": tool_check}


# ----------------------------------------------------------------------------------- MCP (stdio)
def handle(msg, api, s):
    method, mid = msg.get("method"), msg.get("id")
    if mid is None:
        return None                                        # a notification: no answer
    if method == "initialize":
        ver = (msg.get("params") or {}).get("protocolVersion") or "2024-11-05"
        return {"jsonrpc": "2.0", "id": mid, "result": {
            "protocolVersion": ver, "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": "Read-only qTest access. Use qtest_get_test_case with the ID the user gives (e.g. TC-1328)."}}
    if method == "ping":
        return {"jsonrpc": "2.0", "id": mid, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": mid, "result": {"tools": TOOLS}}
    if method == "tools/call":
        p = msg.get("params") or {}
        fn = HANDLERS.get(p.get("name"))
        if not fn:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": f"Unknown tool {p.get('name')}"}}
        try:
            out, err = fn(api, s, p.get("arguments") or {}), False
        except QTestError as e:
            out, err = {"error": str(e)}, True
        except Exception as e:                             # never leak details such as the token
            out, err = {"error": f"Unexpected problem: {type(e).__name__}"}, True
        return {"jsonrpc": "2.0", "id": mid, "result": {
            "content": [{"type": "text", "text": json.dumps(out, indent=1, ensure_ascii=False)}], "isError": err}}
    if method in ("resources/list", "prompts/list"):
        return {"jsonrpc": "2.0", "id": mid, "result": {method.split("/")[0]: []}}
    return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Method not found: {method}"}}


def serve(root=None):
    s = Settings(root)
    api = QTest(s)
    inp, out = sys.stdin.buffer, sys.stdout.buffer
    log(f"started in {s.root}")
    for raw in inp:
        line = raw.decode("utf-8", "replace").strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            out.write((json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}) + "\n").encode())
            out.flush()
            continue
        for m in (msg if isinstance(msg, list) else [msg]):
            resp = handle(m, api, s)
            if resp is not None:
                out.write((json.dumps(resp, ensure_ascii=False) + "\n").encode("utf-8"))
                out.flush()


# ----------------------------------------------------------------------------------- self-test
def self_test():
    from http.server import BaseHTTPRequestHandler, HTTPServer
    ok = {}
    calls = []
    TOKEN = "tok-123-secret"
    CASES = {
        501: {"id": 501, "pid": "TC-1328", "name": "Approve a pending KYC case", "version": "3.0", "parent_id": 77,
              "web_url": "https://qtest.example/p/9/portal/project#tab=testdesign&object=1&id=501",
              "description": "<p>Approver approves a pending case.</p>", "precondition": "<p>A case in&nbsp;<b>Submitted</b> status</p>",
              "properties": [{"field_name": "Test Data", "field_value": "Client: any corporate client"},
                             {"field_name": "Priority", "field_value": "2", "field_value_name": "High"}],
              "test_steps": [{"order": 2, "description": "Click <b>Approve</b>", "expected": "<p>Case approved</p>"},
                             {"order": 1, "description": "", "expected": "", "called_test_case_id": 600}]},
        600: {"id": 600, "pid": "TC-90", "name": "Login as approver", "properties": [],
              "test_steps": [{"order": 1, "description": "Log in as KYC approver", "expected": "Dashboard shown"}]},
    }

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, obj=None):
            body = json.dumps(obj).encode() if obj is not None else b""
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)

        def _auth(self):
            calls.append((self.command, self.path, self.headers.get("Authorization")))
            if self.headers.get("Authorization") != f"Bearer {TOKEN}":
                self._send(401, {"message": "unauthorized"})
                return False
            return True

        def do_GET(self):
            if not self._auth():
                return
            m = re.match(r"^/api/v3/projects/9(?:/test-cases/(\d+))?(\?.*)?$", self.path)
            if not m:
                return self._send(404, {})
            if not m.group(1):
                return self._send(200, {"id": 9, "name": "KYC Portal"})
            tc = CASES.get(int(m.group(1)))
            return self._send(200, tc) if tc else self._send(404, {})

        def do_POST(self):
            if not self._auth():
                return
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            q = body.get("query", "")
            items = []
            m = re.match(r"^'id' = '([^']+)'$", q)
            if m:
                items = [{"id": c["id"], "pid": c["pid"], "name": c["name"]} for c in CASES.values() if c["pid"] == m.group(1)]
            m = re.match(r"^'name' ~ '([^']+)'$", q)
            if m:
                items = [{"id": c["id"], "pid": c["pid"], "name": c["name"]} for c in CASES.values() if m.group(1).lower() in c["name"].lower()]
            self._send(200, {"items": items, "total": len(items)})

    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp(prefix="qtest_mcp_selftest_")
    try:
        url = f"http://127.0.0.1:{srv.server_port}"
        open(os.path.join(tmp, ".env"), "w").write(f"QTEST_URL={url}/api/v3\nQTEST_PROJECT_ID=9\nQTEST_TOKEN=\"bearer {TOKEN}\"  \n")
        s = Settings(tmp, environ={"QTEST_TOKEN": "wrong-token-from-environment"})
        api = QTest(s)
        ok["settings read from .env (before the environment), /api part ignored"] = s.url == url and s.project == "9" and \
            s.token() == TOKEN and s.token_source == ".env"
        chk = tool_check(api, s, {})
        ok["connection check names the project, never the token"] = chk["ok"] and chk["project_name"] == "KYC Portal" and TOKEN not in json.dumps(chk)
        case = tool_get(api, s, {"test_case": "tc 1328"})
        ok["test case found by the ID testers see (TC-1328)"] = case["id"] == "TC-1328" and case["internal_id"] == 501
        ok["steps in order, called test case inlined"] = [x["action"] for x in case["steps"]] == ["Log in as KYC approver", "Click Approve"] and \
            case["steps"][0]["from_called_test_case"] == "TC-90 Login as approver"
        ok["HTML turned into plain text"] = case["precondition"] == "A case in Submitted status" and case["steps"][1]["expected"] == "Case approved"
        ok["test data and other fields separated"] = case["test_data"] == {"Test Data": "Client: any corporate client"} and case["other_fields"] == {"Priority": "High"}
        md = open(os.path.join(tmp, case["saved_copy"])).read()
        ok["local copy saved with steps table and source"] = case["saved_copy"] == "ai_generated_tests/test_cases/qtest/TC-1328.md" and \
            "| 2 | Click Approve | Case approved |" in md and "qTest is the master" in md
        ok["only reading calls are made (GET, and POST to search)"] = all(m == "GET" or p.split("?")[0].endswith("/search") for m, p, _ in calls)
        found = tool_search(api, s, {"text": "KYC"})
        ok["search by words in the name"] = [f["id"] for f in found["found"]] == ["TC-1328"]
        try:
            tool_get(api, s, {"test_case": "TC-9999"}); ok["unknown test case reported clearly"] = False
        except QTestError as e:
            ok["unknown test case reported clearly"] = "TC-9999 was not found" in str(e)
        bad = Settings(tmp, environ={})
        open(os.path.join(tmp, ".env"), "w").write(f"QTEST_URL={url}\nQTEST_PROJECT_ID=9\nQTEST_TOKEN=old-token-xyz\n")
        try:
            QTest(bad).call("GET", "/api/v3/projects/9"); ok["refused token explained (401)"] = False
        except QTestError as e:
            ok["refused token explained (401)"] = "refused the token" in str(e) and "old-token-xyz" not in str(e)
        open(os.path.join(tmp, ".env"), "w").write(f"QTEST_URL={url}\nQTEST_PROJECT_ID=9\n")
        env_only = Settings(tmp, environ={"QTEST_TOKEN": TOKEN})
        ok["token from the environment when .env has none"] = env_only.token() == TOKEN and env_only.token_source == "environment variable"
        nothing = Settings(tmp, environ={})
        t, why = vault_token(nothing)
        ok["no token anywhere: says where it looked"] = t is None and "vault loader for" in why and "not known yet" in why
        # the MCP protocol over stdio, as the editor uses it
        open(os.path.join(tmp, ".env"), "w").write(f"QTEST_URL={url}\nQTEST_PROJECT_ID=9\nQTEST_TOKEN={TOKEN}\n")
        msgs = [{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "t"}}},
                {"jsonrpc": "2.0", "method": "notifications/initialized"},
                {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
                {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "qtest_get_test_case", "arguments": {"test_case": "TC-1328", "save": False}}},
                {"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "qtest_get_test_case", "arguments": {"test_case": "TC-1"}}}]
        p = subprocess.run([sys.executable, os.path.abspath(__file__)], input="\n".join(json.dumps(m) for m in msgs) + "\n",
                           capture_output=True, text=True, cwd=tmp, timeout=60, env=dict(os.environ, QTEST_TOKEN=""))
        resp = {r["id"]: r for r in (json.loads(l) for l in p.stdout.splitlines() if l.strip())}
        ok["MCP: initialize, tools/list and tools/call answer correctly"] = resp[1]["result"]["serverInfo"]["name"] == "qtest" and \
            {t["name"] for t in resp[2]["result"]["tools"]} == set(HANDLERS) and \
            json.loads(resp[3]["result"]["content"][0]["text"])["id"] == "TC-1328" and resp[4]["result"]["isError"] is True and len(resp) == 4
        ok["MCP output carries no token"] = TOKEN not in p.stdout and TOKEN not in p.stderr
    finally:
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


def main():
    args = sys.argv[1:]
    root = None
    if "--root" in args:                       # the QA repo folder, for editors that cannot set the working folder
        i = args.index("--root")
        root = args[i + 1] if i + 1 < len(args) else None
        args = args[:i] + args[i + 2:]
    if args[:1] == ["--self-test"]:
        sys.exit(self_test())
    s = Settings(root)
    api = QTest(s)
    try:
        if args[:1] == ["--check"]:
            print(json.dumps(tool_check(api, s, {}), indent=1))
            return
        if args[:1] == ["--get"] and len(args) > 1:
            print(json.dumps(tool_get(api, s, {"test_case": args[1]}), indent=1, ensure_ascii=False))
            return
    except QTestError as e:
        print(json.dumps({"error": str(e)}, indent=1))
        sys.exit(1)
    serve(root)


if __name__ == "__main__":
    main()
