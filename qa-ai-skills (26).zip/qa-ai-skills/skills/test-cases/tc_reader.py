#!/usr/bin/env python3
"""
tc_reader.py - reads test case files for the robot-script-generator with as few AI tokens as possible.

The script never decides what anything means. It cuts the file into its sections and test cases,
finds which catalog names (data aliases, UI element names) each test case uses, and hands the AI
one small, complete packet per test case. The AI does all the understanding.

Files: AIDLC test case .md files (fields, reading rules, UI element catalog, test data catalog,
index, story sections, test cases), hand-written .md / .txt, qTest copies, and .csv exports.
Section titles are not fixed: sections are recognised by what they contain.

Commands (run from the QA repo root):
  index    <file>                  overview: sections, catalogs, test cases (small output)
  list     <file> [selection]      number, ID, title, priority of the selected test cases
  shared   <file>                  every section before the test cases, verbatim (rarely needed)
  packet   <file> <test case>      one test case, verbatim, with: the file's reading rules, its story
                                   section, only the catalog rows it uses, the saved links for those
                                   names, and the steps already known from earlier runs (step cache)
  plan     <file> <selection>      start a batch run: resolve the selection and save the order
  review   <file>                  the one confirmation: only test cases with steps added, resolved or to check
                                   (the AI first saves its understanding of each test case as
                                   qa-ai-data/session/batch/<file>/understanding/<number>.md)
  card     <file> <n|all>          the understanding cards, for information (steps added, made concrete or decided),
                                   in one fixed layout, from the saved understandings; or
           <understanding .md...>  cards for understanding files (a single test case run)
  next     <file>                  the next waiting test case (marks it running): its saved understanding,
                                   links and known steps; the full packet if it was not understood yet
  status   <file> <test case> passed|failed|blocked|skipped [--reason TEXT] [--script PATH] [--attempts N]
  progress <file> [--all]          the batch checklist (compact for big batches)
  report   <file>                  write the batch report to qa-ai-data/results/ and print its summary
  link     data|element <file> <name> --to "<how>" [--where FILE:LINE]
                                   save how a catalog name is done in this app (a keyword, query or
                                   locator variable), proven in a passing run; never a data value
  learn    <file> <test case> <generated .robot> [--resource <generated .resource>]
                                   after a passing run: record step -> keyword from the "# Step n"
                                   comments of the generated test (step cache)
  map      <file> [test case...]   vague or short steps -> the team's knowledge: the keyword (flow step mapping first),
                                   screen, elements, expected texts from the code, and where to get blank data
                                   (existing tests -> variables -> read-only database -> live search). Suggestions only.
  sql-check "<query>"              is this database query read-only? (one SELECT; nothing that writes or locks)
  lesson add "<rule>" [--about w] [--source user answer|correction|fix] [--tc ID]
                                   save what a user's answer taught, as a general rule (no data values; duplicates refused)
  lesson find "<topic>"            lessons that already answer this: check BEFORE asking the user anything
  lesson list [--new]              all lessons, or only what this run learned (for "What I learned" in the summary)
  combine  <out.md> <files...>     several single test case files (e.g. qTest copies) as one batch file
  --self-test

Selection: all | first N | next N | failed | 5-20 | 3 7 9 | TC-101 TC-102 | "test case 3" | "<title words>"
Python 3.8+, standard library only.
"""
import argparse, csv, datetime, hashlib, json, os, re, sys, tempfile, shutil

# ======================================================================== places
def ai_home(root="."):
    """Your data (knowledge, generated tests, results, session) lives in <QA repo>/qa-ai-data/, OUTSIDE the
    qa-ai-skills package, so replacing the package never touches it. Older layouts are read until the installer
    moves them: <QA repo>/qa-ai-skills/<data>, and before that the repo root."""
    d = os.path.join(root, "qa-ai-data")
    if os.path.isdir(d):
        return d
    old = os.path.join(root, "qa-ai-skills")
    if any(os.path.isdir(os.path.join(old, x)) for x in ("knowledge", "ai_generated_tests", "results", "session")):
        return old
    return d if os.path.isdir(old) else root


def paths(root="."):
    h = ai_home(root)
    return {"index": os.path.join(h, "session", "tc-index"), "batch": os.path.join(h, "session", "batch"),
            "links": os.path.join(h, "knowledge", "test-links.json"), "cache": os.path.join(h, "knowledge", "step-cache.json"),
            "results": os.path.join(h, "results")}


def load_json(p, default):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def save_json(p, data):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1, ensure_ascii=False)
    os.replace(tmp, p)


def sha(text):
    return hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:12]


def today():
    return datetime.date.today().isoformat()


# ======================================================================== markdown pieces
HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
FENCE = re.compile(r"^\s*(```|~~~)")
SEP_ROW = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
TC_HEAD = re.compile(
    r"^(?:\d+[.)]\s*)?(?:"
    r"(?P<id>[A-Z][A-Z0-9]*(?:[-_][A-Z0-9]+)*[-_]\d+)\b"
    r"|(?P<word>test\s*case|tc)\s*(?:no\.?|number|#)?\s*[:#.\-_ ]?\s*(?P<num>\d+)\b"
    r"|(?P<scen>(?:test\s+)?scenario(?:\s+outline)?)\s*(?P<snum>\d+)?\s*(?=[:.\-–—|])"     # Gherkin / "Test Scenario 3:"
    r")\s*[:.\-–—|)]*\s*(?P<title>.*)$", re.I)
FIELD = re.compile(r"^\s*(?:[-*]\s+)?\**\s*(priority|type|test\s*type|categor(?:y|ies)|story|user\s*story|feature|"
                   r"preconditions?|pre-conditions?|description|objective|id|test\s*case\s*id)\s*\**\s*:\s*\**\s*(.*?)\s*$", re.I)
STEPS_MARK = re.compile(r"^\s*(?:#{1,6}\s*)?\**\s*(?:test\s*)?steps?\s*(?:\(.*\))?\s*\**\s*:?\s*\**\s*$", re.I)
NUM_ITEM = re.compile(r"^\s*(\d+)[.)]\s+(.*)$")
EXPECTED = re.compile(r"^\s*(?:[-*]\s+)?\**\s*(?:expected(?:\s*result)?|then|result)\s*\**\s*[:\-]\s*\**\s*(.*)$", re.I)
ARROW = re.compile(r"\s+(?:→|->|=>)\s+")


def cells(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|") and not s.endswith("\\|"):
        s = s[:-1]
    return [c.strip().replace("\\|", "|") for c in re.split(r"(?<!\\)\|", s)]


def clean(name):
    return re.sub(r"^[`*_\"']+|[`*_\"']+$", "", (name or "").strip()).strip()


def is_matchable(name, backticked=False):
    """Names safe to look for in the steps: identifiers, multi-word names, or names written in backticks."""
    if not name or len(name) < 3 or name.upper() in ("TBD", "N/A", "NA", "NONE"):
        return False
    if backticked:
        return True
    if re.fullmatch(r"[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+|[A-Z]{3,}\d*", name):     # CLIENT_NO_VID, VID2
        return True
    if "_" in name or re.search(r"[a-z][A-Z]", name) or re.search(r"\d", name):
        return True
    return len(name.split()) >= 2


def name_regex(name):
    if re.fullmatch(r"[\w.\-]+", name):
        return re.compile(r"(?<![A-Za-z0-9_])" + re.escape(name) + r"(?![A-Za-z0-9_])", re.I)
    words = [re.escape(w) for w in name.split()]
    return re.compile(r"(?<![A-Za-z0-9_])" + r"\s+".join(words) + r"(?![A-Za-z0-9_])", re.I)


# ======================================================================== parsing a markdown file
def parse_md(text, rel):
    lines = text.splitlines()
    n = len(lines)
    heads, fenced = [], False
    for i, l in enumerate(lines):
        if FENCE.match(l):
            fenced = not fenced
            continue
        if fenced:
            continue
        m = HEADING.match(l)
        if m:
            heads.append({"line": i + 1, "level": len(m.group(1)), "title": m.group(2).strip()})
    for k, h in enumerate(heads):                       # own body: to the next heading; subtree: to the next of same or higher level
        h["own_end"] = heads[k + 1]["line"] - 1 if k + 1 < len(heads) else n
        h["end"] = next((x["line"] - 1 for x in heads[k + 1:] if x["level"] <= h["level"]), n)

    def body(a, b):                                     # 1-based inclusive
        return lines[a - 1:b]

    def tables_in(a, b):
        out, cur = [], []
        for i in range(a, b + 1):
            l = lines[i - 1] if 0 < i <= n else ""
            if l.strip().startswith("|"):
                cur.append(i)
            else:
                if len(cur) >= 2:
                    out.append(cur)
                cur = []
        if len(cur) >= 2:
            out.append(cur)
        res = []
        for t in out:
            rows = [(i, cells(lines[i - 1])) for i in t if not SEP_ROW.match(lines[i - 1])]
            if len(rows) >= 2:
                res.append({"header": rows[0][1], "header_line": rows[0][0], "rows": rows[1:], "lines": t})
        return res

    # ---- test case boundaries
    tcs = []
    head_tcs = []
    for h in heads:
        t = re.sub(r"^\*+|\*+$", "", h["title"]).strip()
        m = TC_HEAD.match(t)
        if m and (m.group("word") or m.group("id") or m.group("scen")):
            if m.group("id") and not re.search(r"\d", m.group("id")):
                continue
            head_tcs.append((h, m))
    if head_tcs:                                        # keep the headings that really hold steps (not e.g. "REQ-12 Requirements")
        stepsy = lambda h: bool(re.search(r"(?im)^\s*(\d+[.)]\s|\|.*\|)|^\s*(#{1,6}\s*)?\**\s*(test\s*)?steps?\b|^\s*\**\s*(given|when|then)\b",
                                          "\n".join(body(h["line"] + 1, h["end"]))))
        real = [(h, m) for h, m in head_tcs if stepsy(h)]
        head_tcs = real or head_tcs
        # a matched heading that holds other matched headings is a story or group ("## US-003 ..." over "### TC-021 ..."):
        # keep the innermost ones, at any level, so test cases under different stories or levels are all found
        own_steps = lambda h: bool(re.search(r"(?im)^\s*(\d+[.)]\s|\|.*\|)|^\s*(#{1,6}\s*)?\**\s*(test\s*)?steps?\b|^\s*\**\s*(given|when|then)\b",
                                             "\n".join(body(h["line"] + 1, h["own_end"]))))
        leaves = [(h, m) for h, m in head_tcs
                  if own_steps(h) or not any(o is not h and h["line"] < o["line"] <= h["end"] for o, _ in head_tcs)]
        head_tcs = leaves or head_tcs
        testish = [(h, m) for h, m in head_tcs if m.group("word") or m.group("scen") or re.match(r"(?i)(tc|test|t|qa|tst)[-_]", m.group("id") or "")]
        if testish and len(testish) < len(head_tcs):    # mixed prefixes: drop non-test IDs only if they hold no steps of their own
            head_tcs = [(h, m) for h, m in head_tcs if (h, m) in testish or own_steps(h)]
        for h, m in head_tcs:
            tcs.append({"start": h["line"], "end": h["end"], "num_in_title": int(m.group("num") or m.group("snum")) if (m.group("num") or m.group("snum")) else None,
                        "id": m.group("id"), "title": (m.group("title") or "").strip(" *:-") or h["title"], "level": h["level"]})
    else:                                               # bold lines: **Test case 3: ...** or **TC-12** ...
        starts = []
        fenced = False
        for i, l in enumerate(lines):
            if FENCE.match(l):
                fenced = not fenced
            if fenced:
                continue
            m0 = re.match(r"^\s*\*\*(.+?)\*\*\s*(.*)$", l)
            if m0:
                m = TC_HEAD.match(m0.group(1).strip())
                if m and (m.group("word") or (m.group("id") and re.search(r"\d", m.group("id")))):
                    title = (m.group("title") or m0.group(2) or "").strip(" *:-")
                    starts.append((i + 1, m, title))
        for k, (ln, m, title) in enumerate(starts):
            nxt = starts[k + 1][0] - 1 if k + 1 < len(starts) else n
            parent_end = next((h["line"] - 1 for h in heads if h["line"] > ln and h["level"] <= 2), n)
            tcs.append({"start": ln, "end": min(nxt, parent_end), "num_in_title": int(m.group("num")) if m.group("num") else None,
                        "id": m.group("id"), "title": title, "level": 7})
    if not tcs:                                         # headings whose body holds steps and expected results
        by_level = {}
        for h in heads:
            txt = "\n".join(body(h["line"] + 1, h["end"]))
            if re.search(r"(?im)^\s*\**\s*(test\s*)?steps?\b", txt) and re.search(r"(?i)expected", txt):
                own = "\n".join(body(h["line"] + 1, h["own_end"]))
                if re.search(r"(?im)^\s*(\d+[.)]\s|\|)", own) or re.search(r"(?im)^\s*\**\s*steps?", own):
                    by_level.setdefault(h["level"], []).append(h)
        if by_level:
            lvl = max(by_level, key=lambda k: (len(by_level[k]), k))
            for h in by_level[lvl]:
                tcs.append({"start": h["line"], "end": h["end"], "num_in_title": None, "id": None, "title": h["title"], "level": lvl})
    if not tcs:                                         # Spec Kit spec.md: every acceptance scenario of every user story
        sk = speckit_tests(lines, rel)
        if sk:
            return sk
    if not tcs:                                         # one table holds every test case: a row each, steps in one cell
        tbl = table_tests(lines, rel)
        if tbl:
            return tbl
    single = False
    if not tcs and (re.search(r"(?im)^\s*\**\s*(test\s*)?steps?\b", text) or sum(1 for l in lines if NUM_ITEM.match(l)) >= 2):
        first = heads[0] if heads else None
        tcs.append({"start": first["line"] if first else 1, "end": n, "num_in_title": None, "id": None,
                    "title": first["title"] if first else os.path.splitext(os.path.basename(rel))[0], "level": 1})
        single = True

    first_tc = tcs[0]["start"] if tcs else n + 1
    # ---- sections before the test cases: metadata, rules, catalogs, index, other
    sections, catalogs, index_rows, metadata = [], [], [], {}
    for h in heads:
        if h["line"] >= first_tc or single or (h["end"] >= first_tc and h["level"] > 1 and
                                                any(h["line"] < t["start"] <= h["end"] for t in tcs) and h["own_end"] < first_tc and
                                                not tables_in(h["line"] + 1, h["own_end"])):
            continue                                    # a story section that holds test cases is context, not shared
        a, b = h["line"] + 1, min(h["own_end"], first_tc - 1)
        tbls = tables_in(a, b)
        kind = "text"
        title_l = h["title"].lower()
        for t in tbls:
            hdr = [clean(x).lower() for x in t["header"]]
            if any(re.fullmatch(r"(test\s*case\s*)?(id|key|#|no\.?)", x) for x in hdr) and any(re.search(r"title|name|summary|test\s*case", x) for x in hdr) \
                    and len(t["rows"]) >= 1 and not re.search(r"catalog|alias", title_l):
                kind = "index"
                for ln, row in t["rows"]:
                    rec = {"line": ln}
                    for col, val in zip(hdr, row):
                        key = ("id" if re.fullmatch(r"(test\s*case\s*)?(id|key)", col) else "title" if re.search(r"title|name|summary", col)
                               else "priority" if "prior" in col else "type" if "type" in col else "category" if "categor" in col
                               else "story" if re.search(r"story|feature|epic|requirement", col) else "num" if col in ("#", "no", "no.") else None)
                        if key and key not in rec:
                            rec[key] = clean(val)
                    if rec.get("id") or rec.get("title"):
                        index_rows.append(rec)
            elif len(hdr) == 2 and re.fullmatch(r"field|property|attribute|item|key", hdr[0]) and re.search(r"value|detail", hdr[1]):
                kind = "metadata" if kind == "text" else kind
                for _, row in t["rows"]:
                    if len(row) >= 2 and clean(row[0]):
                        metadata[clean(row[0])] = clean(row[1])
            else:
                name_col = next((i for i, x in enumerate(hdr) if re.fullmatch(r"(data\s*)?alias|name|key|element|element\s*name|variable|label|identifier|id|record|entity", x)), 0)
                ckind = ("data" if re.search(r"data|alias|record|seed|fixture|account|client", title_l + " " + " ".join(hdr))
                         else "element" if re.search(r"\bui\b|element|locator|control|widget|screen|field|button", title_l + " " + " ".join(hdr))
                         else "other")
                rows = []
                for ln, row in t["rows"]:
                    if name_col < len(row):
                        raw = row[name_col]
                        nm = clean(raw)
                        if nm:
                            rows.append({"name": nm, "line": ln, "backticked": "`" in raw})
                if rows:
                    kind = "catalog"
                    catalogs.append({"title": h["title"], "kind": ckind, "header_line": t["header_line"],
                                     "sep_line": t["lines"][1] if len(t["lines"]) > 1 else None, "rows": rows})
        if kind == "text":                              # bullet catalogs: - `NAME` - meaning / - **NAME**: meaning
            rows = []
            for i in range(a, b + 1):
                m = re.match(r"^\s*[-*]\s+(`[^`]+`|\*\*[^*]+\*\*)\s*[:\-–—]\s*\S", lines[i - 1])
                if m:
                    rows.append({"name": clean(m.group(1)), "line": i, "backticked": m.group(1).startswith("`")})
            if len(rows) >= 2 and re.search(r"catalog|alias|data|element|glossary|legend", title_l):
                kind = "catalog"
                ckind = "data" if re.search(r"data|alias|record", title_l) else "element" if re.search(r"ui|element|control", title_l) else "other"
                catalogs.append({"title": h["title"], "kind": ckind, "header_line": None, "sep_line": None, "rows": rows, "bullets": True})
        if kind == "text" and re.search(r"read|rule|convention|notation|legend|how\s*to|format|guide|instruction|glossary", title_l):
            kind = "rules"
        sections.append({"title": h["title"], "level": h["level"], "start": h["line"], "end": min(h["own_end"], first_tc - 1), "kind": kind})
    # text before the first heading (a file title block) counts as metadata text
    # ---- group (story) sections that hold test cases: their own intro text
    groups = []
    for h in heads:
        inner = [t for t in tcs if h["line"] < t["start"] <= h["end"]]
        if inner and not any(t["start"] == h["line"] for t in tcs) and h["line"] >= (sections[-1]["start"] if sections else 0):
            intro_end = min(inner[0]["start"] - 1, h["own_end"])
            groups.append({"title": h["title"], "level": h["level"], "start": h["line"], "intro_end": intro_end, "end": h["end"]})
    # ---- each test case: fields, steps, names used, index row
    names = []
    for c_i, cat in enumerate(catalogs):
        for r in cat["rows"]:
            if is_matchable(r["name"], r.get("backticked")):
                names.append((r["name"], cat["kind"], c_i, r["line"], name_regex(r["name"])))
    names.sort(key=lambda x: -len(x[0]))
    tests = []
    for k, t in enumerate(tcs):
        if k + 1 < len(tcs):
            t["end"] = min(t["end"], tcs[k + 1]["start"] - 1)
        while t["end"] > t["start"] and not lines[t["end"] - 1].strip():
            t["end"] -= 1
        blines = body(t["start"], t["end"])
        txt = "\n".join(blines)
        fields = {}
        for l in blines[1:] if not single else blines:
            m = FIELD.match(l)
            if m:
                key = re.sub(r"\s+", "_", m.group(1).lower())
                key = {"test_type": "type", "categories": "category", "user_story": "story", "feature": "story", "pre-conditions": "preconditions",
                       "pre-condition": "preconditions", "precondition": "preconditions", "objective": "description", "test_case_id": "id"}.get(key, key)
                if key not in fields and m.group(2):
                    fields[key] = clean(m.group(2))
            else:
                tm = re.match(r"^\s*\|\s*\**(priority|type|categor(?:y|ies)|story|id|test case id)\**\s*\|\s*(.*?)\s*\|\s*$", l, re.I)
                if tm:
                    key = {"categories": "category", "test case id": "id"}.get(tm.group(1).lower(), tm.group(1).lower())
                    fields.setdefault(key, clean(tm.group(2)))
        steps = parse_steps(blines)
        used = {"data": [], "element": [], "other": []}
        seen = set()
        g0 = next((g for g in groups if g["start"] < t["start"] <= g["end"]), None)
        intro = "\n".join(body(g0["start"], g0["intro_end"])) if g0 and g0["intro_end"] >= g0["start"] else ""
        masked = txt + "\n" + intro                   # names in the story section's introduction count too
        for nm, kind, c_i, ln, rx in names:
            if rx.search(masked) and nm.lower() not in seen:
                seen.add(nm.lower())
                used[kind].append(nm)
                masked = rx.sub(" ", masked)
        grp = next((g["title"] for g in groups if g["start"] < t["start"] <= g["end"]), None)
        tests.append({"n": k + 1, "id": t.get("id") or fields.get("id"), "title": t["title"], "start": t["start"], "end": t["end"],
                      "num_in_title": t.get("num_in_title"), "priority": fields.get("priority"), "type": fields.get("type"),
                      "category": fields.get("category"), "story": fields.get("story"), "group": grp,
                      "steps": steps, "uses": {k2: v for k2, v in used.items() if v}, "hash": sha(txt)})
    link_index(tests, index_rows)
    warnings = []
    if index_rows and len(index_rows) != len(tests):
        warnings.append(f"The index lists {len(index_rows)} test cases but {len(tests)} were found in the file; IDs were matched by title.")
    unmatched = [t["n"] for t in tests if not t["id"]]
    if index_rows and unmatched:
        warnings.append(f"{len(unmatched)} test case(s) have no ID in the index (numbers: {', '.join(map(str, unmatched[:10]))}).")
    if index_rows:                                      # IDs the index lists that no test case carries: name them so a missed layout is visible
        found = {(t["id"] or "").upper() for t in tests}
        missing = [r["id"] for r in index_rows if r.get("id") and r["id"].upper() not in found]
        if missing:
            where = []
            for mid in missing[:10]:
                ln = next((i + 1 for i, l in enumerate(lines) if re.search(r"(?<![\w-])" + re.escape(mid) + r"(?![\w-])", l)
                           and i + 1 not in [r2["line"] for r2 in index_rows]), None)
                where.append(f"{mid} (line {ln})" if ln else f"{mid} (not in the file)")
            warnings.append(f"Not read: {len(missing)} ID(s) from the index — {', '.join(where)}"
                            + (" …" if len(missing) > 10 else "") + ". Check how those test cases are written.")
    tc_lines = {t["start"] for t in tests}
    look = [h for h in heads if h["line"] not in tc_lines and not any(g["start"] == h["line"] for g in groups)
            and h["line"] > first_tc and re.search(r"(?im)^\s*\d+[.)]\s", "\n".join(body(h["line"] + 1, h["own_end"])))
            and re.search(r"(?i)expect", "\n".join(body(h["line"] + 1, h["own_end"])))
            and not STEPS_MARK.match(h["title"]) and not any(t["start"] < h["line"] <= t["end"] for t in tests)]
    if look:
        warnings.append(f"{len(look)} heading(s) look like test cases but were not read: "
                        + ", ".join(f"line {h['line']} \"{h['title'][:40]}\"" for h in look[:8]) + (" …" if len(look) > 8 else "") + ".")
    return {"format": "single" if single else ("aidlc" if catalogs and index_rows else "markdown"), "lines": n,
            "metadata": metadata, "sections": sections, "catalogs": catalogs, "groups": groups,
            "index_rows": len(index_rows), "tests": tests, "warnings": warnings}


def parse_steps(blines):
    """Step texts with their expected results, from a Steps list or table (any common layout)."""
    start = next((i for i, l in enumerate(blines) if STEPS_MARK.match(l)), None)
    region = blines[start + 1:] if start is not None else blines
    steps = []
    tbl = [l for l in region if l.strip().startswith("|")]
    if tbl and len(tbl) >= 3:
        rows = [cells(l) for l in tbl if not SEP_ROW.match(l)]
        hdr = [clean(x).lower() for x in rows[0]]
        a_col = next((i for i, x in enumerate(hdr) if re.search(r"step|action|description|do", x) and not re.fullmatch(r"#|no\.?|step\s*(no|#)", x)), None)
        e_col = next((i for i, x in enumerate(hdr) if re.search(r"expect|result|then", x)), None)
        if a_col is not None:
            for r in rows[1:]:
                if a_col < len(r) and r[a_col].strip():
                    steps.append({"no": len(steps) + 1, "text": r[a_col].strip(),
                                  "expected": r[e_col].strip() if e_col is not None and e_col < len(r) else ""})
            if steps:
                return steps
    cur = None
    for l in region:
        if start is not None and re.match(r"^\s*(#{1,6}\s|\*\*(expected|postcondition|notes?|test data)\b)", l, re.I) and steps:
            break
        m = NUM_ITEM.match(l)
        if m:
            text = m.group(2).strip()
            exp = ""
            parts = ARROW.split(text, maxsplit=1)
            if len(parts) == 2:
                text, exp = parts[0].strip(), parts[1].strip()
            cur = {"no": int(m.group(1)), "text": text, "expected": exp}
            steps.append(cur)
            continue
        e = EXPECTED.match(l)
        if e and cur is not None:
            cur["expected"] = (cur["expected"] + " " + e.group(1)).strip()
    if not steps:                                       # Gherkin: Given/When/And are steps, Then (and its And) the expected result
        mode = None
        for l in region:
            g = re.match(r"^\s*[-*]?\s*\**\s*(given|when|then|and|but)\b\**\s*(.*)$", l, re.I)
            if not g:
                continue
            word, text = g.group(1).lower(), g.group(2).strip()
            if word in ("given", "when") or (word in ("and", "but") and mode != "then"):
                mode = "do"
                steps.append({"no": len(steps) + 1, "text": f"{g.group(1).capitalize()} {text}", "expected": ""})
            else:
                mode = "then"
                if not steps:
                    steps.append({"no": 1, "text": "(no action before Then)", "expected": ""})
                steps[-1]["expected"] = (steps[-1]["expected"] + "; " if steps[-1]["expected"] else "") + text
    return steps


def norm_title(s):
    return re.sub(r"[^a-z0-9 ]+", " ", (s or "").lower()).split()


def link_index(tests, rows):
    if not rows:
        return
    by_id = {r["id"].lower(): r for r in rows if r.get("id")}
    used = set()
    for t in tests:
        r = by_id.get((t["id"] or "").lower())
        if not r:
            tw = set(norm_title(t["title"]))
            best, score = None, 0.0
            for i, cand in enumerate(rows):
                if i in used or not cand.get("title"):
                    continue
                cw = set(norm_title(cand["title"]))
                s = len(tw & cw) / max(1, len(tw | cw))
                if s > score:
                    best, score = i, s
            if best is not None and score >= 0.6:
                r = rows[best]
        if not r and len(rows) == len(tests):
            r = rows[t["n"] - 1]
        if r:
            used.add(rows.index(r))
            for k in ("id", "priority", "type", "category", "story"):
                if r.get(k) and not t.get(k):
                    t[k] = r[k]
            if not t["title"] and r.get("title"):
                t["title"] = r["title"]


def split_cell(cell):
    parts = re.split(r"<br\s*/?>|\\n|;\s+(?=\d+[.)]\s)|(?<=[^\s\d])\s+(?=\d+[.)]\s)", cell)
    return [re.sub(r"^\s*\d+[.)]\s*", "", p).strip() for p in parts if p and p.strip()]


GWT_BOLD = re.compile(r"\*\*\s*(Given|When|Then|And|But)\s*\*\*", re.I)
GWT_PLAIN = re.compile(r"(?:^|[,;]\s*)(Given|When|Then|And|But)\b")        # capitalised keywords that start a clause


def speckit_tests(lines, rel):
    """Spec Kit feature specs (specs/<feature>/spec.md): '### User Story 1 - <title> (Priority: P1)' with numbered
    '**Acceptance Scenarios**' written as '**Given** ..., **When** ..., **Then** ...'. Each scenario is one test case:
    Given lines are the precondition steps, When lines the actions, Then lines the expected result of the last action."""
    if not any(re.search(r"(?i)acceptance\s+scenarios", l) for l in lines):
        return None
    n = len(lines)
    stories = [(i, re.match(r"^#{2,4}\s+(.*)$", l).group(1).strip()) for i, l in enumerate(lines)
               if re.match(r"^#{2,4}\s+user\s+story\b", l, re.I)]
    tests, groups = [], []
    for k, (si, title) in enumerate(stories):
        end = next((i for i, l in enumerate(lines[si + 1:], si + 1) if re.match(r"^#{1,4}\s", l)), n)
        sid = re.match(r"(?i)user\s+story\s+(\d+)", title)
        sid = f"US{sid.group(1)}" if sid else f"US{k + 1}"
        prio = re.search(r"(?i)priority:\s*(P\d)", title)
        story = re.sub(r"(?i)^user\s+story\s+\d+\s*[-:–]\s*", "", re.sub(r"\s*\((?i:priority)[^)]*\)", "", title)).strip()
        acc = next((i for i in range(si + 1, end) if re.search(r"(?i)acceptance\s+scenarios", lines[i])), None)
        groups.append({"title": title, "start": si + 1, "end": end, "intro_end": (acc or end)})
        if acc is None:
            continue
        a_n = 0
        for i in range(acc + 1, end):
            m = re.match(r"^\s*(\d+)[.)]\s+(.*\b[Gg]iven\b.*|.*\b[Ww]hen\b.*)$", lines[i])
            if not m or not re.search(r"\bThen\b|\*\*then\*\*", m.group(2), re.I if "**" in m.group(2) else 0):
                continue
            a_n += 1
            parts = [p_ for p_ in (GWT_BOLD if "**" in m.group(2) else GWT_PLAIN).split(m.group(2)) if p_ is not None]
            steps, mode, pre = [], None, []
            for p_ in parts:
                w = p_.strip().strip(",;").strip()
                if not w:
                    continue
                if w.lower() in ("given", "when", "then", "and", "but"):
                    mode = w.lower() if w.lower() in ("given", "when", "then") else mode
                    continue
                w = clean(w)
                if mode == "then":
                    if not steps:
                        steps.append({"no": 1, "text": "(no action before Then)", "expected": ""})
                    steps[-1]["expected"] = (steps[-1]["expected"] + "; " + w).strip("; ")
                elif mode == "given":
                    pre.append(w)
                    steps.append({"no": len(steps) + 1, "text": f"Given {w}", "expected": ""})
                else:
                    steps.append({"no": len(steps) + 1, "text": f"When {w}", "expected": ""})
            tests.append({"n": len(tests) + 1, "id": f"{sid}-AS{a_n}", "title": f"{story} (scenario {a_n})", "start": i + 1, "end": i + 1,
                          "num_in_title": None, "priority": prio.group(1) if prio else None, "type": "acceptance", "category": None,
                          "story": f"{sid} {story}", "group": title, "steps": steps, "uses": {}, "precondition": "; ".join(pre),
                          "hash": sha(lines[i])})
    if not tests:
        return None
    warnings = []
    ec = next((i for i, l in enumerate(lines) if re.match(r"^#{2,4}\s+edge\s+cases", l, re.I)), None)
    if ec is not None:
        cnt = sum(1 for l in lines[ec + 1:] if re.match(r"^\s*[-*]\s+\S", l) and not l.lstrip().startswith("#"))
        cnt = min(cnt, sum(1 for l in lines[ec + 1:next((i for i, l in enumerate(lines[ec + 1:], ec + 1) if re.match(r"^#{1,4}\s", l)), n)]
                            if re.match(r"^\s*[-*]\s+\S", l)))
        if cnt:
            warnings.append(f"{cnt} edge case(s) under 'Edge Cases' are not test cases yet; generate them on request, one test case each.")
    return {"format": "speckit", "lines": n, "metadata": {}, "sections": [], "catalogs": [], "groups": groups,
            "index_rows": 0, "tests": tests, "warnings": warnings}


def table_tests(lines, rel):
    """A markdown table with one test case per row (ID or title, steps, expected result), as exported from
    test tools and spreadsheets. Rows without an ID or title continue the test case above (one step per row)."""
    i, n = 0, len(lines)
    while i < n - 2:
        if lines[i].strip().startswith("|") and SEP_ROW.match(lines[i + 1]):
            hdr = [clean(x).lower() for x in cells(lines[i])]
            col = lambda *pats: next((k for k, h in enumerate(hdr) if any(re.search(p_, h) for p_ in pats)), None)
            c_id = col(r"^(test\s*case\s*)?(id|key)$", r"^tc\s*(id|#|no\.?)?$")
            c_title = col(r"title|name|summary|scenario|description$")
            c_step = col(r"step|action|procedure")
            c_exp = col(r"expect|result")
            c_pre = col(r"pre-?condition")
            if c_step is not None and (c_id is not None or c_title is not None) and c_step not in (c_id, c_title):
                tests, cur, j = [], None, i + 2
                while j < n and lines[j].strip().startswith("|"):
                    r = cells(lines[j])
                    g = lambda c: clean(r[c]) if c is not None and c < len(r) else ""
                    if g(c_id) or g(c_title):
                        cur = {"n": len(tests) + 1, "id": g(c_id) or None, "title": g(c_title) or g(c_id), "start": j + 1, "end": j + 1,
                               "num_in_title": None, "priority": None, "type": None, "category": None, "story": None, "group": None,
                               "steps": [], "uses": {}, "precondition": g(c_pre)}
                        tests.append(cur)
                    if cur is not None:
                        cur["end"] = j + 1
                        st, ex = split_cell(r[c_step] if c_step < len(r) else ""), split_cell(r[c_exp]) if c_exp is not None and c_exp < len(r) else []
                        for k, t_ in enumerate(st):
                            cur["steps"].append({"no": len(cur["steps"]) + 1, "text": t_,
                                                 "expected": ex[k] if len(ex) == len(st) else ("; ".join(ex) if k == len(st) - 1 else "")})
                    j += 1
                if len(tests) >= 2 or (tests and tests[0]["steps"]):
                    for t in tests:
                        t["hash"] = sha(json.dumps(t["steps"]) + t["title"])
                    return {"format": "markdown table", "lines": n, "metadata": {}, "sections": [], "catalogs": [], "groups": [],
                            "index_rows": 0, "tests": tests, "warnings": []}
                i = j
                continue
        i += 1
    return None


# ======================================================================== csv files (qTest and other exports)
def parse_csv(text, rel):
    rows = list(csv.reader(text.splitlines()))
    if not rows:
        return {"format": "csv", "lines": 0, "metadata": {}, "sections": [], "catalogs": [], "groups": [], "index_rows": 0, "tests": [], "warnings": []}
    hdr = [h.strip().lower() for h in rows[0]]
    col = lambda *pats: next((i for i, h in enumerate(hdr) if any(re.search(p, h) for p in pats)), None)
    c_id, c_title = col(r"^id$", r"test\s*case\s*id", r"^key$", r"^pid$"), col(r"^name$", r"title", r"summary")
    c_step, c_exp = col(r"step\s*desc", r"^step", r"action"), col(r"expect")
    c_pri, c_pre = col(r"priority"), col(r"precondition")
    tests, cur = [], None
    for i, r in enumerate(rows[1:], start=2):
        g = lambda c: r[c].strip() if c is not None and c < len(r) else ""
        if g(c_id) or (g(c_title) and not cur) or (g(c_title) and cur and g(c_title) != cur["title"] and not g(c_id) and c_id is None):
            cur = {"n": len(tests) + 1, "id": g(c_id) or None, "title": g(c_title), "start": i, "end": i, "num_in_title": None,
                   "priority": g(c_pri) or None, "type": None, "category": None, "story": None, "group": None, "steps": [], "uses": {},
                   "precondition": g(c_pre)}
            tests.append(cur)
        if cur is None:
            continue
        cur["end"] = i
        if g(c_step):
            cur["steps"].append({"no": len(cur["steps"]) + 1, "text": g(c_step), "expected": g(c_exp)})
    for t in tests:
        t["hash"] = sha(json.dumps(t["steps"]) + t["title"])
    return {"format": "csv", "lines": len(rows), "metadata": {}, "sections": [], "catalogs": [], "groups": [], "index_rows": 0,
            "tests": tests, "warnings": [], "csv_header": rows[0]}


# ======================================================================== index (cached by content)
def read_text(path):
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        return fh.read()


def _parser_version():
    try:
        with open(os.path.abspath(__file__), encoding="utf-8") as fh:
            return sha(fh.read())
    except Exception:
        return "0"


PARSER = _parser_version()


def get_index(path, root="."):
    text = read_text(path)
    h = sha(text)
    rel = os.path.relpath(path, root).replace("\\", "/")
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", os.path.splitext(os.path.basename(path))[0])
    cache = os.path.join(paths(root)["index"], f"{stem}-{h}.json")
    idx = load_json(cache, None)
    if idx and idx.get("version") == PARSER:
        return idx, text, True
    idx = parse_csv(text, rel) if path.lower().endswith(".csv") else parse_md(text, rel)
    idx.update({"version": PARSER, "file": rel, "sha": h, "stem": stem})
    save_json(cache, idx)
    return idx, text, False


# ======================================================================== selection
def resolve(idx, spec, batch=None):
    """Returns (list of test numbers, problems)."""
    tests = idx["tests"]
    total = len(tests)
    s = " ".join(spec).strip()
    if not s or s.lower() == "all":
        return [t["n"] for t in tests], []
    out, problems = [], []
    st = (batch or {}).get("status", {})
    m = re.fullmatch(r"(?i)(first|top)\s*(\d+)", s)
    if m:
        return [t["n"] for t in tests[:int(m.group(2))]], []
    m = re.fullmatch(r"(?i)next\s*(\d+)", s)
    if m:
        done = {int(k) for k, v in st.items() if v.get("state") in ("passed", "skipped")}
        return [t["n"] for t in tests if t["n"] not in done][:int(m.group(1))], []
    if s.lower() in ("failed", "failures"):
        return [int(k) for k, v in sorted(st.items(), key=lambda x: int(x[0])) if v.get("state") in ("failed", "blocked")], \
               ([] if st else ["no earlier batch run for this file"])
    by_id = {(t["id"] or "").lower(): t["n"] for t in tests if t["id"]}
    by_title_num = {t["num_in_title"]: t["n"] for t in tests if t.get("num_in_title")}
    rest = s
    for m in re.finditer(r"(?i)\b(?:test\s*case|tc)\s*#?\s*(\d+)\b", s):
        num = int(m.group(1))
        n = by_title_num.get(num, num)
        out.append(n) if 1 <= n <= total else problems.append(f"test case {num} does not exist (the file has {total})")
        rest = rest.replace(m.group(0), " ")
    for tok in re.split(r"[\s,;]+", rest):
        if not tok:
            continue
        if tok.lower() in by_id:
            out.append(by_id[tok.lower()])
            continue
        m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", tok)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            out += [n for n in range(min(a, b), max(a, b) + 1) if 1 <= n <= total]
            continue
        if tok.isdigit():
            n = int(tok)
            out.append(n) if 1 <= n <= total else problems.append(f"test case {n} does not exist (the file has {total})")
            continue
        if re.fullmatch(r"(?i)[A-Z][A-Z0-9]*([-_][A-Z0-9]+)*[-_]\d+", tok):
            problems.append(f"{tok} is not in this file")
            continue
        out.append(tok)                                 # words: title search below
    words = [w for w in out if isinstance(w, str)]
    nums = [w for w in out if isinstance(w, int)]
    if words:
        q = [w.lower() for w in words]
        hits = [t["n"] for t in tests if all(w in (t["title"] or "").lower() for w in q)]
        if len(hits) == 1:
            nums.append(hits[0])
        elif hits:
            problems.append(f"\"{' '.join(words)}\" matches {len(hits)} titles: " +
                            "; ".join(f"{n}. {tests[n - 1]['title']}" for n in hits[:8]) + (" ..." if len(hits) > 8 else ""))
        else:
            problems.append(f"no title contains \"{' '.join(words)}\"")
    seen, res = set(), []
    for n in nums:
        if n not in seen:
            seen.add(n)
            res.append(n)
    return res, problems


def find_one(idx, ref):
    nums, probs = resolve(idx, [ref] if isinstance(ref, str) else ref)
    if len(nums) != 1:
        raise SystemExit("Test case not found: " + (", ".join(probs) if probs else f"'{' '.join(ref) if not isinstance(ref, str) else ref}' matches {len(nums)}"))
    return idx["tests"][nums[0] - 1]


def label(t):
    return f"{t['id'] + ' | ' if t.get('id') else ''}{t['title']}"


# ======================================================================== packet
RULES_MAX = 4000
GROUP_MAX = 2500


def rows_text(lines, cat, names):
    keep = [r for r in cat["rows"] if r["name"] in names]
    if not keep:
        return ""
    out = []
    if cat.get("header_line"):
        out.append(lines[cat["header_line"] - 1])
        if cat.get("sep_line"):
            out.append(lines[cat["sep_line"] - 1])
    out += [lines[r["line"] - 1] for r in keep]
    return "\n".join(out)


def step_key(text, idx, generalise):
    """The step with quoted text and numbers as slots; with generalise, catalog names too (<DATA>, <ELEMENT>)."""
    s = text
    if generalise:
        for cat in idx.get("catalogs", []):
            for r in sorted(cat["rows"], key=lambda r: -len(r["name"])):
                if is_matchable(r["name"], r.get("backticked")):
                    s = name_regex(r["name"]).sub(f" <{cat['kind'].upper()}> ", s)
        s = re.sub(r"`[^`]+`", " <ELEMENT> ", s)
    s = re.sub(r"[\"“”'][^\"“”']{1,80}[\"“”']", " <TEXT> ", s)
    s = re.sub(r"\b\d+(\.\d+)?\b", " <N> ", s)
    s = re.sub(r"[^\w<> ]+", " ", s.lower().replace("`", ""))
    return re.sub(r"\s+", " ", s).strip()


def step_names(text, idx):
    """The catalog names a step mentions, in order (they are the step's data and elements)."""
    found = []
    for cat in idx.get("catalogs", []):
        for r in cat["rows"]:
            if is_matchable(r["name"], r.get("backticked")):
                m = name_regex(r["name"]).search(text)
                if m:
                    found.append((m.start(), r["name"]))
    found.sort()
    out, last_end = [], -1
    for pos, nm in found:                               # longest name wins where names overlap
        if not any(nm.lower() in o.lower() and nm != o for o in out):
            out.append(nm)
    return [n for n in out if not any(n != o and n.lower() in o.lower() for o in out)]


def lookup_step(cache, idx, text, team=None, links=None):
    """(kind, entry, note): kind is 'exact' (this very step proved before), 'param' (the same keyword was
    proven with different arguments for different data, so it takes this step's data as its argument),
    'hint' (a similar step was proven with other data; check before use), 'stale' or None."""
    e = cache.get("x:" + step_key(text, idx, False))
    kind = "exact" if e else None
    if not e:
        g = cache.get("g:" + step_key(text, idx, True))
        if g and g.get("variants"):
            vs = list(g["variants"].values())
            kws = {v["calls"][0].split("    ")[0].lower() for v in vs}
            args = {v["calls"][0] for v in vs}
            e = max(vs, key=lambda v: v.get("uses", 1))
            kind = "param" if len(vs) >= 2 and len(kws) == 1 and len(args) == len(vs) else "hint"
    if not e:
        return None, None, ""
    if e.get("in_extract") and team and e["calls"][0].split("    ")[0].lower() not in team:
        return "stale", e, ""
    note = ""
    if kind == "param" and links:
        names = step_names(text, idx)
        got = [f"{n}: {links.get('data', {}).get(n, links.get('element', {}).get(n, {})).get('how')}" for n in names
               if links.get("data", {}).get(n) or links.get("element", {}).get(n)]
        note = "; linked: " + ", ".join(got) if got else ""
    return kind, e, note


def packet(idx, text, t, root=".", full_rules=False):
    lines = text.splitlines()
    P = paths(root)
    out = [f"# Test case {t['n']} of {len(idx['tests'])}: {label(t)}"]
    meta = [f"{idx['file']} lines {t['start']}-{t['end']}"] + [f"{k.title()}: {t[k]}" for k in ("priority", "type", "category", "story") if t.get(k)]
    if t.get("group"):
        meta.append(f"Section: {t['group']}")
    out.append(" | ".join(meta))
    if idx["format"] == "csv":
        out.append("\n## Test case (from the CSV rows, verbatim)")
        if t.get("precondition"):
            out.append(f"Preconditions: {t['precondition']}")
        for s in t["steps"]:
            out.append(f"{s['no']}. {s['text']}" + (f"  -> Expected: {s['expected']}" if s["expected"] else ""))
    else:
        rules = [s for s in idx["sections"] if s["kind"] == "rules"]
        if rules:
            body = "\n".join("\n".join(lines[s["start"] - 1:s["end"]]).rstrip() for s in rules)
            if len(body) > RULES_MAX and not full_rules:
                body = body[:RULES_MAX] + f"\n[... cut: read the rest with: tc_reader.py packet {idx['file']} {t['n']} --full-rules]"
            out += ["\n## Reading rules of this file (verbatim)", body]
        meta_lines = [f"{k}: {v}" for k, v in idx.get("metadata", {}).items() if re.search(r"step|format|convention|notation", k, re.I)]
        if meta_lines:
            out += ["\n## File details", "\n".join(meta_lines)]
        g = next((g for g in idx["groups"] if g["title"] == t.get("group")), None)
        if g and g["intro_end"] >= g["start"]:
            intro = "\n".join(lines[g["start"] - 1:g["intro_end"]]).strip()
            if intro and len(intro.splitlines()) > 1:
                out += [f"\n## Section context (verbatim)", intro[:GROUP_MAX] + ("\n[... cut]" if len(intro) > GROUP_MAX else "")]
        out += ["\n## Test case (verbatim)", "\n".join(lines[t["start"] - 1:t["end"]]).rstrip()]
        used_names = set(sum(t["uses"].values(), []))
        cat_txt = []
        for cat in idx["catalogs"]:
            rt = rows_text(lines, cat, used_names)
            if rt:
                cat_txt += [f"### {cat['title']}", rt]
        if cat_txt:
            out += ["\n## Catalog rows this test case uses (verbatim)"] + cat_txt
    # saved links
    links = load_json(P["links"], {"data": {}, "element": {}})
    lk = []
    for kind in ("data", "element"):
        for nm in t["uses"].get(kind, []):
            meaning = catalog_meaning(idx, text, nm)
            e = links.get(kind, {}).get(nm)
            if e and e.get("meaning_hash") == sha(meaning):
                lk.append(f"- {nm} -> {e['how']}" + (f" ({e['where']})" if e.get("where") else "") + f"  [proven {e.get('proven')}]")
            elif e:
                lk.append(f"- {nm} -> was linked to {e['how']}, but the catalog meaning changed since: check it again before use")
            else:
                lk.append(f"- {nm} -> not linked yet" + (" (find how the team gets such data; prove it; then: link data)" if kind == "data"
                                                          else " (find or create the locator on the page; prove it; then: link element)"))
    if lk:
        out += ["\n## Links to this application (saved from earlier passing runs)"] + lk
    # step cache
    cache = load_json(P["cache"], {})
    team = team_keywords(root) if cache else set()
    known, rows = 0, []
    for s in t["steps"]:
        kind, e, note = lookup_step(cache, idx, s["text"], team, links)
        more = f"  (+{len(e['calls']) - 1} more)" if e and len(e["calls"]) > 1 else ""
        if kind == "stale":
            rows.append(f"{s['no']}. was {e['calls'][0].split('    ')[0]}, but that keyword is no longer in the repo: work this step out again")
        elif kind == "exact":
            known += 1
            rows.append(f"{s['no']}. {e['calls'][0]}{more}  [{e['source']} keyword; this same step passed {e.get('uses', 1)}x]")
        elif kind == "param":
            known += 1
            kw = e["calls"][0].split("    ")[0]
            rows.append(f"{s['no']}. {kw}  with this step's data or element as its argument{note}  "
                        f"[{e['source']} keyword; proven with different data; e.g. {e['calls'][0]}]")
        elif kind == "hint":
            rows.append(f"{s['no']}. similar step passed with other data as: {e['calls'][0]}{more}  (not proven for this step: check it fits)")
        else:
            rows.append(f"{s['no']}. not known yet")
    if t["steps"] and known:
        out += [f"\n## Steps already known from earlier passing runs: {known} of {len(t['steps'])}"] + rows
    elif t["steps"]:
        out.append(f"\n## Steps already known from earlier passing runs: none of {len(t['steps'])}")
    else:
        out.append("\n(No numbered steps were found: read the steps from the test case text above.)")
    return "\n".join(out)


def catalog_meaning(idx, text, name):
    lines = text.splitlines()
    for cat in idx.get("catalogs", []):
        for r in cat["rows"]:
            if r["name"] == name:
                return lines[r["line"] - 1].strip()
    return ""


# ======================================================================== links and step cache
def team_keywords(root="."):
    """Names of the team's keywords from the knowledge extract (empty when the knowledge is not built)."""
    ks = load_json(os.path.join(ai_home(root), "knowledge", ".extract", "keywords.json"), [])
    return {str(k.get("name", "")).lower() for k in ks if isinstance(k, dict)}


def cmd_link(args, root="."):
    idx, text, _ = get_index(args.file, root)
    meaning = catalog_meaning(idx, text, args.name)
    if not meaning:
        raise SystemExit(f"'{args.name}' is not in a catalog of {args.file}.")
    if re.search(r"\b\d{6,}\b|@", args.to):
        raise SystemExit("A link says HOW the data or element is found (a keyword, query or locator variable), never a data value.")
    P = paths(root)
    links = load_json(P["links"], {"data": {}, "element": {}})
    links.setdefault(args.kind, {})[args.name] = {"how": args.to, "where": args.where or "", "meaning_hash": sha(meaning),
                                                 "file": idx["file"], "proven": today()}
    save_json(P["links"], links)
    print(f"Linked {args.kind} {args.name} -> {args.to}")


CALL = re.compile(r"^(?:\s{2,}|\t)(?!#)(?:[$@&]\{[^}]+\}=?\s{2,})*(\S.*?)$")


def robot_tests(path):
    """Test name -> list of (line, cells) of its body, from a .robot file."""
    tests, cur, sect = {}, None, None
    for i, l in enumerate(read_text(path).splitlines(), 1):
        m = re.match(r"^\*{3}\s*(.+?)\s*\*{3}", l)
        if m:
            sect = m.group(1).lower()
            cur = None
            continue
        if sect not in ("test cases", "test case", "tasks"):
            continue
        if l and not l[0].isspace():
            if not l.startswith("#"):
                cur = l.strip()
                tests[cur] = []
            continue
        if cur is not None and l.strip():
            tests[cur].append((i, [c for c in re.split(r"\s{2,}|\t+", l.strip()) if c]))
    return tests


def defined_keywords(path):
    names, sect = set(), None
    if not path or not os.path.isfile(path):
        return names
    for l in read_text(path).splitlines():
        m = re.match(r"^\*{3}\s*(.+?)\s*\*{3}", l)
        if m:
            sect = m.group(1).lower()
            continue
        if sect == "keywords" and l and not l[0].isspace() and not l.startswith("#"):
            names.add(l.strip().lower())
    return names


def cmd_learn(args, root="."):
    idx, text, _ = get_index(args.file, root)
    t = find_one(idx, args.tc)
    tests = robot_tests(args.robot)
    keys = [x for x in (t.get("id"), f"test case {t['n']}", t["title"]) if x]
    name = next((n for n in tests for k in keys if k.lower() in n.lower()), None)
    if not name:
        body_has = lambda n: any(any(k.lower() in " ".join(c).lower() for k in keys) for _, c in tests[n] if c and c[0].lower() == "[documentation]")
        name = next((n for n in tests if body_has(n)), None)
    if not name:
        raise SystemExit(f"No test for {label(t)} in {args.robot} (name or [Documentation] must contain the ID, 'test case {t['n']}' or the title).")
    team = team_keywords(root)
    ai_kw = set()
    for res in (args.resource or []):
        ai_kw |= defined_keywords(res)
    by_step, cur = {}, None
    for _, c in tests[name]:
        if c[0].startswith("#"):
            m = re.match(r"#\s*step\s*(\d+)", " ".join(c), re.I)
            if m:
                cur = int(m.group(1))
            continue
        if cur is None or c[0].startswith("["):
            continue
        cc = list(c)
        while cc and re.fullmatch(r"[$@&]\{[^}]+\}\s*=?", cc[0]):
            cc.pop(0)
        if not cc or cc[0].upper() in ("IF", "ELSE", "ELSE IF", "END", "FOR", "WHILE", "TRY", "EXCEPT", "FINALLY", "VAR"):
            continue
        kw, argv = cc[0], [a if re.fullmatch(r"[$@&%]\{[^}]+\}(\[[^\]]+\])?", a) or "=" in a and a.split("=", 1)[1].startswith("${") else "<value>" for a in cc[1:]]
        by_step.setdefault(cur, []).append((kw + ("    " + "    ".join(argv) if argv else "")).strip())
    if not by_step:
        raise SystemExit(f"'{name}' has no '# Step <n>' comments; add them above each step's keywords (coding standards).")
    P = paths(root)
    cache = load_json(P["cache"], {})
    added = 0
    for s in t["steps"]:
        calls = by_step.get(s["no"])
        if not calls:
            continue
        first_kw = calls[0].split("    ")[0].lower()
        entry = {"calls": calls[:4], "source": "AI-created" if first_kw in ai_kw else "team", "resource": "", "example": s["text"][:120],
                 "proven": today(), "in_extract": first_kw in team}
        xk = "x:" + step_key(s["text"], idx, False)
        cache[xk] = dict(entry, uses=(cache.get(xk) or {}).get("uses", 0) + 1)
        names = step_names(s["text"], idx)
        if names:                                       # the same kind of step with other data: one variant per data
            gk = "g:" + step_key(s["text"], idx, True)
            g = cache.setdefault(gk, {"variants": {}, "example": s["text"][:120]})
            sig = "|".join(names)
            old = g["variants"].get(sig) or {}
            g["variants"][sig] = dict(entry, uses=old.get("uses", 0) + 1)
        added += 1
    save_json(P["cache"], cache)
    print(f"Step cache: {added} step(s) of {label(t)} recorded from '{name}'.")


# ======================================================================== batch
CHUNK = 10                                              # test cases per full Robot run
MARK = {"waiting": "\u2b1c", "running": "\u23f3", "ready": "\U0001f537", "passed": "\u2705", "failed": "\u274c", "blocked": "\u26d4", "skipped": "\u23ed"}


def batch_path(idx, root):
    return os.path.join(paths(root)["batch"], idx["stem"] + ".json")


def cmd_plan(args, root="."):
    idx, _, _ = get_index(args.file, root)
    old = load_json(batch_path(idx, root), None)
    nums, probs = resolve(idx, args.selection, old)
    if probs:
        print("Check the selection: " + " | ".join(probs))
    if not nums:
        raise SystemExit("Nothing selected.")
    b = {"file": idx["file"], "sha": idx["sha"], "selection": " ".join(args.selection) or "all", "order": nums,
         "started": datetime.datetime.now().isoformat(timespec="seconds"),
         "hashes": {str(t["n"]): t["hash"] for t in idx["tests"]},
         "status": {str(n): {"state": "waiting"} for n in nums}}
    if old and old.get("file") == idx["file"]:
        for n in nums:                                  # keep results of unchanged test cases from the last run
            o = old.get("status", {}).get(str(n))
            if o and o.get("state") in ("passed", "skipped") and old.get("hashes", {}).get(str(n)) == b["hashes"][str(n)] \
                    and args.selection and args.selection[0].lower() not in ("all", "failed") and not args.fresh:
                pass
    save_json(batch_path(idx, root), b)
    total_steps = sum(len(idx["tests"][n - 1]["steps"]) for n in nums)
    print(f"Batch ready: {len(nums)} of {len(idx['tests'])} test cases from {idx['file']} ({total_steps} steps).")
    print(f"Save each understanding to: {os.path.dirname(understanding_path(idx, 1, root))}{os.sep}<number>.md")
    print("First: " + label(idx["tests"][nums[0] - 1]) + (f" | Last: {label(idx['tests'][nums[-1] - 1])}" if len(nums) > 1 else ""))


def load_batch(idx, root):
    b = load_json(batch_path(idx, root), None)
    if not b:
        raise SystemExit(f"No batch for {idx['file']}; start one with: tc_reader.py plan {idx['file']} <selection>")
    if b.get("sha") != idx["sha"]:
        changed = [n for n in b["order"] if b.get("hashes", {}).get(str(n)) != (idx["tests"][n - 1]["hash"] if n <= len(idx["tests"]) else None)]
        if changed:
            print(f"Note: the file changed since the batch started; test cases changed: {', '.join(map(str, changed[:15]))}"
                  + (" ..." if len(changed) > 15 else "") + ". They are read from the current file.")
    return b


def understanding_path(idx, n, root="."):
    return os.path.join(paths(root)["batch"], idx["stem"], "understanding", f"{n}.md")


MARKS = {"added": ("\u2795", "[added]"), "resolved": ("\u2248", "[resolved]"), "check": ("\u26a0", "[check]")}


UNDERSTANDING_FORMAT = """title: TC-101 | Approve a submitted KYC case
goal: an approver can approve a submitted KYC case; the case then shows Approved
data: a submitted KYC case (CASE_SUBMITTED), found with the team's "Get Submitted Case" keyword
1 | + | Log in as the KYC approver | Home page shows | approving needs this role
2 | + | Open the client's KYC case | Case page shows | app map
3 |   | Click Approve | "Case approved" is shown | test case
4 | ~ | Check the status | Status reads Approved | after-save behaviour
check: step 5 mentions an audit tab, but no screen shows one"""
MARK_SYM = {"+": "\u2795", "~": "\u2248", "!": "\u26a0", "\u2795": "\u2795", "\u2248": "\u2248", "\u26a0": "\u26a0"}


def parse_understanding(text):
    """The structured understanding (UNDERSTANDING_FORMAT): title, goal, data, step rows, checks."""
    u = {"title": "", "goal": "", "data": [], "steps": [], "checks": [], "other": [], "original": ""}
    for line in text.splitlines():
        t = line.strip()
        if not t:
            continue
        m = re.match(r"^(title|goal|data|check|original)\s*:\s*(.*)$", t, re.I)
        if m:
            k = m.group(1).lower()
            if k in ("data", "check"):
                u["data" if k == "data" else "checks"].append(m.group(2).strip())
            else:
                u[k] = m.group(2).strip()
            continue
        parts = [x.strip() for x in t.strip("|").split("|")]
        if len(parts) >= 3 and re.fullmatch(r"\d+[a-z]?", parts[0]):
            parts += [""] * (5 - len(parts))
            mark = parts[1] if parts[1] in MARK_SYM or parts[1] == "" else ""
            rest = parts[2:] if mark or parts[1] == "" else parts[1:]
            rest += [""] * 3
            u["steps"].append({"no": parts[0], "mark": MARK_SYM.get(mark, ""), "step": rest[0], "expected": rest[1], "source": rest[2]})
        else:
            u["other"].append(t)
    return u


def count_marks(u):
    return {"added": sum(1 for s in u["steps"] if s["mark"] == "\u2795"),
            "resolved": sum(1 for s in u["steps"] if s["mark"] == "\u2248"),
            "check": sum(1 for s in u["steps"] if s["mark"] == "\u26a0") + len(u["checks"])}


def render_card(u, i, total, fallback_title=""):
    """One test case card in a fixed layout, for a normal chat message (never inside a question box)."""
    cell = lambda x: (x or "-").replace("|", "/").replace("\n", " ")
    head = u["title"] or fallback_title
    tid, _, name = head.partition("|") if "|" in head else ("", "", head)
    changed = any(s_["mark"] for s_ in u["steps"]) or u["checks"]
    out = [f"### Test case {i} of {total}" + (f" \u00b7 {tid.strip()}" if tid.strip() else "") + (" \u00b7 completed from the knowledge" if changed else ""),
           f"**{(name or head).strip()}**", ""]
    if u.get("original") and changed:
        orig = u["original"] if len(u["original"]) <= 400 else u["original"][:397] + "..."
        out.append(f"**As written in the test case:** _{orig}_  ")
        out.append("")
    if u["goal"]:
        out.append(f"**Goal:** {u['goal']}  ")
    for d in u["data"]:
        out.append(f"**Data:** {d}  ")
    if u["steps"]:
        out += ["", "| # | Step | Expected result | From |", "|---|---|---|---|"]
        out += [f"| {s['no']} | {(s['mark'] + ' ') if s['mark'] else ''}{cell(s['step'])} | {cell(s['expected'])} | {cell(s['source'])} |" for s in u["steps"]]
    elif u["other"]:
        out += [""] + u["other"]
    for c in u["checks"]:
        if c.startswith(CHANGE_TAG):
            out += ["", f"\u26a0 **Changed check, needs your OK:** {c[len(CHANGE_TAG) + 2:]}"]
        else:
            out += ["", f"\u26a0 **Decided from the evidence:** {c}"]
    m = count_marks(u)
    n_chg = sum(1 for c in u["checks"] if c.startswith(CHANGE_TAG))
    parts = [f"\u2795 {m['added']} added from the knowledge" if m["added"] else "", f"\u2248 {m['resolved']} made concrete" if m["resolved"] else "",
             f"\u26a0 {m['check'] - n_chg} decided from the evidence" if m["check"] - n_chg > 0 else "",
             f"\u26a0 {n_chg} changed check{'s' if n_chg != 1 else ''} waiting for your OK" if n_chg else ""]
    out += ["", " \u00b7 ".join(p for p in parts if p) or "Clear as written: nothing added or changed."]
    return "\n".join(out)


def read_understanding(idx, n, root="."):
    p = understanding_path(idx, n, root)
    if not os.path.isfile(p):
        return None, {}
    txt = read_text(p).strip()
    u = parse_understanding(txt)
    marks = count_marks(u) if u["steps"] else {k: sum(txt.count(x) for x in v) for k, v in MARKS.items()}
    return txt, marks


def cmd_card(args, root="."):
    """Cards from saved understandings: batch numbers of a test case file, or understanding files."""
    if args.file.endswith(".md") and os.path.isfile(args.file) and parse_understanding(read_text(args.file))["steps"] and not args.which:
        files = [args.file] + (args.more or [])
        for i, f in enumerate(files, 1):
            print(render_card(parse_understanding(read_text(f)), i, len(files), os.path.splitext(os.path.basename(f))[0]))
            print()
        return
    idx, _, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    need = [n for n in b["order"] if (lambda m: m and (m["added"] or m["resolved"] or m["check"]))(read_understanding(idx, n, root)[1])]
    which = args.which or "1"
    pick = need if which == "all" else [need[int(which) - 1]] if which.isdigit() and 0 < int(which) <= len(need) else []
    if not pick:
        print(f"No card {which}: {len(need)} test case(s) need a look." if need else "Every test case is clear as written: no cards to show.")
        return
    for n in pick:
        u = parse_understanding(read_understanding(idx, n, root)[0])
        print(render_card(u, need.index(n) + 1, len(need), label(idx["tests"][n - 1])))
        print()


def compact(idx, text, t, root="."):
    """What the next test case needs once it is understood: the saved understanding, links and known steps."""
    u, _ = read_understanding(idx, t["n"], root)
    if not u:
        return packet(idx, text, t, root)
    full = packet(idx, text, t, root)
    tail = full[full.find("\n## Links to this application"):] if "\n## Links to this application" in full else \
        full[full.find("\n## Steps already known"):] if "\n## Steps already known" in full else ""
    head = full.split("\n", 2)
    return "\n".join([head[0], head[1], "", "## Your saved understanding (confirmed)", u, ""]) + tail + \
        f"\n(Exact wording of the test case if needed: tc_reader.py packet {idx['file']} {t['n']})"


def cmd_review(args, root="."):
    """The batch overview (information, not a question): what was added, made concrete or decided per test case."""
    idx, _, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    missing, warn, changed, clear = [], [], [], []
    for n in b["order"]:
        u, m = read_understanding(idx, n, root)
        if u is None:
            missing.append(n)
        elif m["check"]:
            warn.append((n, u, m))
        elif m["added"] or m["resolved"]:
            changed.append((n, u, m))
        else:
            clear.append(n)
    if missing:
        print(f"Not understood yet: {len(missing)} test case(s) ({', '.join(map(str, missing[:20]))}{' ...' if len(missing) > 20 else ''}). "
              f"Write each understanding to {os.path.dirname(understanding_path(idx, missing[0], root))}{os.sep}<number>.md first.")
        return
    out = os.path.join(paths(root)["results"], f"understanding-{idx['stem']}.md")
    full = [f"# How the test cases of {idx['file']} were understood", ""]
    for n, u, _ in warn + changed:
        full += [f"## {n}. {label(idx['tests'][n - 1])}", u, ""]
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(full) + "\n")
    print(f"{len(b['order'])} test cases understood: {len(clear)} clear as written, {len(changed)} with steps added or made concrete, "
          f"{len(warn)} with points decided from the evidence (see the notes).")
    rows = warn + changed
    if rows:
        print("Understood for you (shown for information; work continues; full details in " + out + "):")
        for n, _, m in rows[:30]:
            extra = f", {m['check']} decided from the evidence" if m["check"] else ""
            print(f"  {n}. {label(idx['tests'][n - 1])[:70]} - {m['added']} added, {m['resolved']} made concrete{extra}")
        if len(rows) > 30:
            print(f"  ... {len(rows) - 30} more")


def cmd_next(args, root="."):
    idx, text, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    ready = [n for n in b["order"] if b["status"][str(n)]["state"] == "ready"]
    waiting = [n for n in b["order"] if b["status"][str(n)]["state"] in ("waiting", "running")]
    if ready and (len(ready) >= CHUNK or not waiting):
        print(f"Full run due: {len(ready)} test case(s) are written and proven live: " +
              ", ".join(f"{n}. {label(idx['tests'][n - 1])[:60]}" for n in ready))
        print("Run them together now (one Robot run, one login; section 1a), record each result with status, then call next again.")
        return
    for n in b["order"]:
        st = b["status"][str(n)]
        if st["state"] in ("waiting", "running"):
            st["state"] = "running"
            st["began"] = datetime.datetime.now().isoformat(timespec="seconds")
            save_json(batch_path(idx, root), b)
            done = sum(1 for x in b["status"].values() if x["state"] not in ("waiting", "running"))
            print(f"[Batch {done + 1} of {len(b['order'])}]")
            print(compact(idx, text, idx["tests"][n - 1], root))
            return
    print("All test cases of this batch are finished. Write the report: tc_reader.py report " + idx["file"])


def cmd_status(args, root="."):
    idx, _, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    t = find_one(idx, args.tc)
    st = b["status"].setdefault(str(t["n"]), {})
    if str(t["n"]) not in map(str, b["order"]):
        b["order"].append(t["n"])
    began = st.get("began")
    if getattr(args, "checked", None):
        st["checked"] = args.checked[:400]
    if getattr(args, "needed", None):
        st["needed"] = args.needed[:300]
    st.update({"state": args.state, "reason": (args.reason or "")[:300], "script": args.script or st.get("script", ""),
               "attempts": args.attempts or st.get("attempts"), "finished": datetime.datetime.now().isoformat(timespec="seconds")})
    if began:
        try:
            st["seconds"] = int((datetime.datetime.fromisoformat(st["finished"]) - datetime.datetime.fromisoformat(began)).total_seconds())
        except Exception:
            pass
    save_json(batch_path(idx, root), b)
    c = counts(b)
    print(f"{MARK[args.state]} {t['n']}. {label(t)} - {args.state}" + (f": {args.reason}" if args.reason else "") +
          f"   ({c['passed']} passed, {c['failed'] + c['blocked']} need attention, {c['ready']} waiting for the full run, {c['waiting'] + c['running']} to go)")


CHANGE_TAG = "changed check"


def cmd_change(args, root="."):
    """Record that the script checks something other than the test case's exact expected result (never decided quietly).
    The line goes on the test case's card as a check line, and the test waits for the user's OK before it counts as passed."""
    if args.file.endswith(".md") and os.path.isfile(args.file) and not args.tc:
        upath, idx, n = args.file, None, None
    else:
        idx, _, _ = get_index(args.file, root)
        n = find_one(idx, args.tc)["n"]
        upath = understanding_path(idx, n, root)
    if not os.path.isfile(upath):
        raise SystemExit(f"No saved understanding at {upath}: save it first (Stage 1b).")
    line = (f"check: {CHANGE_TAG}, step {args.step}: the test case expects \"{args.was}\"; the script checks \"{args.now}\""
            + (f" because {args.why}" if args.why else "") + ". Your OK is needed.")
    txt = read_text(upath).rstrip("\n")
    if line not in txt:
        with open(upath, "w", encoding="utf-8") as fh:
            fh.write(txt + "\n" + line + "\n")
    if idx is not None:
        b = load_batch(idx, root)
        st = b["status"].setdefault(str(n), {})
        st["changes"] = st.get("changes", 0) + 1
        save_json(batch_path(idx, root), b)
    print("\u26a0 " + line[len("check: "):])


def open_changes(upath):
    if not upath or not os.path.isfile(upath):
        return []
    return [c for c in parse_understanding(read_text(upath))["checks"] if c.startswith(CHANGE_TAG)]


def counts(b):
    c = {k: 0 for k in MARK}
    for n in b["order"]:
        c[b["status"].get(str(n), {}).get("state", "waiting")] += 1
    return c


def cmd_progress(args, root="."):
    idx, _, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    c = counts(b)
    print(f"Batch: {idx['file']} | {len(b['order'])} test cases | {c['passed']} passed, {c['failed']} failed, {c['blocked']} blocked, "
          f"{c['skipped']} skipped, {c['ready']} proven live and waiting for the full run, {c['waiting'] + c['running']} to go")
    order = b["order"]
    show = range(len(order))
    if len(order) > 25 and not args.all:
        cur = next((i for i, n in enumerate(order) if b["status"][str(n)]["state"] in ("running", "waiting")), len(order))
        bad = [i for i, n in enumerate(order) if b["status"][str(n)]["state"] in ("failed", "blocked")]
        show = sorted(set(bad[-5:]) | set(range(max(0, cur - 3), min(len(order), cur + 4))))
    last = -1
    for i in show:
        if i != last + 1:
            print("   ...")
        n = order[i]
        st = b["status"][str(n)]
        t = idx["tests"][n - 1]
        print(f"{MARK[st['state']]} {n}. {label(t)[:90]}" + (f" - {st['reason'][:80]}" if st.get("reason") and st["state"] != "passed" else ""))
        last = i
    if last != len(order) - 1:
        print("   ...")


def cmd_report(args, root="."):
    idx, _, _ = get_index(args.file, root)
    b = load_batch(idx, root)
    c = counts(b)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    out = os.path.join(paths(root)["results"], f"batch-{idx['stem']}-{stamp}.md")
    secs = sum(b["status"][str(n)].get("seconds") or 0 for n in b["order"])
    lines = [f"# Batch report: {idx['file']}", "",
             f"Selection: {b['selection']} | Started: {b['started']} | Finished: {datetime.datetime.now().isoformat(timespec='seconds')}", "",
             "| Result | Count |", "|---|---|"]
    for k, lbl in (("passed", "Passed"), ("failed", "Failed"), ("blocked", "Blocked"), ("skipped", "Skipped"), ("waiting", "Not run")):
        lines.append(f"| {lbl} | {c[k] + (c['running'] + c['ready'] if k == 'waiting' else 0)} |")
    lines += ["", f"Total time: {secs // 60} min {secs % 60} s" if secs else "", "",
              "| # | Test case | Result | Attempts | Script | Reason |", "|---|---|---|---|---|---|"]
    for n in b["order"]:
        st, t = b["status"][str(n)], idx["tests"][n - 1]
        lines.append(f"| {n} | {label(t).replace('|', '/')} | {st['state']} | {st.get('attempts') or ''} | {st.get('script', '')} | "
                     f"{(st.get('reason') or '').replace('|', '/')} |")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    rate = round(100 * c["passed"] / max(1, len(b["order"])), 1)
    print(f"Batch report: {out}")
    print(f"{c['passed']} of {len(b['order'])} passed ({rate}%), {c['failed']} failed, {c['blocked']} blocked, {c['skipped']} skipped, "
          f"{c['waiting'] + c['running'] + c['ready']} not run.")
    for n in b["order"]:
        st = b["status"][str(n)]
        if st["state"] in ("failed", "blocked"):
            print(f"  {MARK[st['state']]} {n}. {label(idx['tests'][n - 1])[:80]} - {st.get('reason', '')[:100]}")
    na = not_automated_report(idx, b, stamp, root)
    if na:
        print(f"Not automated: {na[1]} test case(s), each with its reason, what was checked and what is needed: {na[0]}")
    ch = [(n, c) for n in b["order"] for c in open_changes(understanding_path(idx, n, root))]
    if ch:
        print(f"\u26a0 {len(ch)} changed check(s) need your OK before those tests count as verified (on their cards: tc_reader.py card <file> <n>):")
        for n, c in ch:
            print(f"  {n}. {label(idx['tests'][n - 1])[:60]}: {c[len(CHANGE_TAG) + 2:][:160]}")
        with open(out, "a", encoding="utf-8") as fh:
            fh.write("\n## Changed checks waiting for your OK\n" + "\n".join(f"- {n}. {label(idx['tests'][n - 1]).replace('|', '/')}: "
                                                                          f"{c[len(CHANGE_TAG) + 2:]}" for n, c in ch) + "\n")


NA_TITLE = {"failed": "Failed", "blocked": "Blocked", "skipped": "Set aside", "waiting": "Not run", "running": "Not finished", "ready": "Waiting for the full run"}


def not_automated_report(idx, b, stamp, root="."):
    """One readable file for the testers: every test case that did not become a verified script, one after the other,
    with the main reason in one sentence, what was checked, and what is needed to finish it."""
    rows = [(n, b["status"][str(n)]) for n in b["order"] if b["status"][str(n)].get("state") != "passed"]
    if not rows:
        return None
    out = os.path.join(paths(root)["results"], f"not-automated-{idx['stem']}-{stamp}.md")
    L = [f"# Test cases not automated: {idx['file']}", "",
         f"{len(rows)} of {len(b['order'])} test cases did not become a verified script. Each one below says why, what was "
         "checked, and what is needed to finish it. Fix the cause, then run the same command with `failed` to retry only these.", ""]
    by_state = {}
    for n, st in rows:
        by_state.setdefault(st.get("state", "waiting"), []).append(n)
    L += ["| Result | Test cases |", "|---|---|"] + [f"| {NA_TITLE.get(k, k)} | {', '.join(map(str, v))} |" for k, v in by_state.items()] + [""]
    for n, st in rows:
        t = idx["tests"][n - 1]
        state = st.get("state", "waiting")
        L += [f"## {n}. {label(t)}", "",
              f"- **Result:** {NA_TITLE.get(state, state)}",
              f"- **Main reason:** {st.get('reason') or ('It was not run in this batch.' if state in ('waiting', 'running') else 'Not recorded.')}",
              f"- **What was checked:** {st.get('checked') or 'Not recorded.'}",
              f"- **What is needed to finish it:** {st.get('needed') or 'See the main reason.'}"]
        if st.get("script"):
            L.append(f"- **Draft script:** `{st['script']}` (kept in drafts; never added to the suite)")
        if st.get("attempts"):
            L.append(f"- **Fix attempts:** {st['attempts']}")
        L.append("")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))
    return out, len(rows)


# ======================================================================== lessons: every answer makes the next run smarter
DATA_LIKE = re.compile(r"\b\d{5,}\b|[\w.+-]+@[\w-]+\.[\w.]+|\b[0-9a-f]{24,}\b|(?i:password|passwd|secret|token)\s*[:=]", re.I)


def lessons_path(root="."):
    return os.path.join(ai_home(root), "knowledge", "lessons.md")


def read_lessons(root="."):
    """Every lesson line of lessons.md: [{'id', 'rule', 'about', 'line'}]. Free-form older lines are lessons too."""
    out = []
    lp = lessons_path(root)
    for i, l in enumerate(read_text(lp).splitlines() if os.path.isfile(lp) else [], 1):
        m = re.match(r"^\s*[-*]\s+(.*\S)", l)
        if not m:
            continue
        body = m.group(1)
        mid = re.match(r"\*\*(L-\d+)\*\*\s+(.*)$", body)
        lid, rest = (mid.group(1), mid.group(2)) if mid else (f"line {i}", body)
        about = re.search(r"_\(about: ([^;)]*)", rest)
        rule = re.sub(r"\s*_\(about:.*\)_\s*$", "", rest).strip()
        out.append({"id": lid, "rule": rule, "about": about.group(1).strip() if about else "", "line": i})
    return out


def find_lessons(text, root=".", top=5, lessons=None):
    q = set(toks(text))
    if not q:
        return []
    res = []
    for les in lessons if lessons is not None else read_lessons(root):
        lt = set(toks(les["rule"] + " " + les["about"]))
        hit = len(q & lt)
        if hit >= 2 or (hit and hit >= len(q) * 0.5):
            res.append((hit + (1 if q & set(toks(les["about"])) else 0), les))
    return [l for _, l in sorted(res, key=lambda x: -x[0])[:top]]


def cmd_lesson(args, root="."):
    p = lessons_path(root)
    if args.action == "add":
        rule = " ".join(args.text).strip()
        if len(rule) < 12:
            raise SystemExit("Write the lesson as a general rule in one sentence, e.g. \"'No VID' means the VID column of the client is empty\".")
        if DATA_LIKE.search(rule):
            raise SystemExit("Not saved: a lesson says how to find or do something, never a data value, an e-mail or a secret. Write the rule without it.")
        old = read_lessons(root)
        rt = set(toks(rule))
        for les in old:
            lt = set(toks(les["rule"]))
            if rt and lt and len(rt & lt) / len(rt | lt) >= 0.8:
                print(f"Already known as {les['id']}: {les['rule']}")
                return
        nums = [int(l["id"][2:]) for l in old if l["id"].startswith("L-")]
        lid = f"L-{(max(nums) + 1 if nums else 1):03d}"
        src = args.source + (f", {args.tc}" if args.tc else "")
        line = f"- **{lid}** {rule} _(about: {args.about or ', '.join(sorted(rt)[:6])}; from: {src}; {today()})_"
        os.makedirs(os.path.dirname(p), exist_ok=True)
        head = "" if os.path.isfile(p) else ("# Lessons\n\nRules learned from the users' answers, corrections and proven fixes. "
                                             "Every run checks them before asking anything. No data values.\n\n")
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(head + line + "\n")
        newp = os.path.join(ai_home(root), "session", "lessons-new.json")
        new = load_json(newp, [])
        new.append(lid)
        save_json(newp, new)
        print(f"Learned {lid}: {rule}")
    elif args.action == "find":
        hits = find_lessons(" ".join(args.text), root)
        if not hits:
            print("No lesson matches: decide by the knowledge, or ask (and save the answer as a lesson).")
        for les in hits:
            print(f"{les['id']}: {les['rule']}" + (f"  (about: {les['about']})" if les["about"] else ""))
    else:                                                            # list --new: what this run learned, for the summary
        newp = os.path.join(ai_home(root), "session", "lessons-new.json")
        ids = set(load_json(newp, []))
        rows = [l for l in read_lessons(root) if (l["id"] in ids or not args.new)]
        if args.new:
            save_json(newp, [])
        if not rows:
            print("Nothing new learned in this run." if args.new else "No lessons yet.")
        for les in rows:
            print(f"- {les['id']}: {les['rule']}")


# ======================================================================== overview commands
def cmd_index(args, root="."):
    idx, _, cached = get_index(args.file, root)
    T = idx["tests"]
    print(f"{idx['file']}: {len(T)} test case(s), {idx['lines']} lines, layout: {idx['format']}" + (" (cached)" if cached else ""))
    if idx.get("metadata"):
        print("Details: " + "; ".join(f"{k}: {v}" for k, v in list(idx["metadata"].items())[:8]))
    if idx["sections"]:
        print("Sections before the test cases: " + "; ".join(f"{s['title']} [{s['kind']}, lines {s['start']}-{s['end']}]" for s in idx["sections"]))
    for cat in idx["catalogs"]:
        print(f"Catalog '{cat['title']}' ({cat['kind']}): {len(cat['rows'])} names")
    if idx["groups"]:
        print("Groups: " + "; ".join(f"{g['title']} ({sum(1 for t in T if t.get('group') == g['title'])})" for g in idx["groups"][:12]))
    if T:
        with_steps = sum(1 for t in T if t["steps"])
        uses = sum(1 for t in T if t["uses"])
        ids = sum(1 for t in T if t.get("id"))
        print(f"Test cases: {ids} with an ID, {with_steps} with numbered steps, {uses} using catalog names; "
              f"steps in total: {sum(len(t['steps']) for t in T)}")
        cache = load_json(paths(root)["cache"], {})
        if cache:
            team = team_keywords(root)
            known = sum(1 for t in T for s in t["steps"] if lookup_step(cache, idx, s["text"], team)[0] in ("exact", "param"))
            print(f"Steps already known from earlier runs: {known} of {sum(len(t['steps']) for t in T)}")
        print("First: " + label(T[0]) + (f" | Last: {label(T[-1])}" if len(T) > 1 else ""))
    else:
        print("No test case boundaries were found. Read the file directly, section by section:")
        for s in idx["sections"][:30]:
            print(f"  lines {s['start']}-{s['end']}: {s['title']}")
    for w in idx["warnings"]:
        print("Note: " + w)


def cmd_list(args, root="."):
    idx, _, _ = get_index(args.file, root)
    nums, probs = resolve(idx, args.selection) if args.selection else ([t["n"] for t in idx["tests"]], [])
    for p in probs:
        print("Note: " + p)
    limit = len(nums) if args.all else 60
    for n in nums[:limit]:
        t = idx["tests"][n - 1]
        print(f"{n}. {label(t)}" + (f" [{t['priority']}]" if t.get("priority") else "") + f" ({len(t['steps'])} steps)")
    if len(nums) > limit:
        print(f"... {len(nums) - limit} more (add --all to list them)")


def cmd_shared(args, root="."):
    idx, text, _ = get_index(args.file, root)
    first = idx["tests"][0]["start"] if idx["tests"] else idx["lines"] + 1
    lines = text.splitlines()
    print("\n".join(l for l in lines[:first - 1]).rstrip())


def cmd_combine(args, root="."):
    """Several single test case files (for example qTest copies) as one file, so they run as one batch."""
    parts = []
    for f in args.files:
        body = read_text(f).strip()
        if not re.match(r"^#\s", body):
            body = f"# {os.path.splitext(os.path.basename(f))[0]}\n\n" + body
        parts.append(body)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write("\n\n".join(parts) + "\n")
    idx, _, _ = get_index(args.out, root)
    print(f"{args.out}: {len(idx['tests'])} test cases from {len(args.files)} files.")


def cmd_packet(args, root="."):
    idx, text, _ = get_index(args.file, root)
    print(packet(idx, text, find_one(idx, args.tc), root, args.full_rules))


# ======================================================================== map: vague steps -> the team's knowledge
STOP = set("a an the to of in on at for and or is are be it its this that with as by from into then than when after before "
           "should must can will user users system page screen field button click enter select open check verify ensure see "
           "make sure able there their them they he she his her you your we our any some valid correct proper appropriate "
           "required relevant given and when then also via using use new".split())
VAGUE_DATA = re.compile(r"\b(a|an|any|some|valid|existing|eligible|suitable|appropriate|test|sample|correct)\s+"
                        r"(client|customer|user|account|event|record|order|policy|payment|address|contact|item|product|case|member|profile|document|file)s?\b", re.I)
VAGUE_EXPECTED = re.compile(r"\b(as expected|works( fine| correctly)?|successful(ly)?|correctly|properly|is fine|no (errors?|issues?)|"
                            r"behaves|displayed correctly|should work|appropriate (message|error))\b", re.I)
PLACEHOLDER = re.compile(r"<[^<>]{1,40}>|\[[A-Za-z _-]{2,30}\]|\bTBD\b|\bN/?A\b|\?\?+|_{3,}", re.I)


def toks(s):
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", str(s or ""))
    out = []
    for w in re.findall(r"[A-Za-z][A-Za-z0-9]+", s.lower()):
        if w in STOP or len(w) < 3:
            continue
        for suf in ("ings", "ing", "ed", "es", "s"):
            if w.endswith(suf) and len(w) - len(suf) >= 3:
                w = w[: -len(suf)]
                break
        out.append(w)
    return out


def knowledge_for_map(root="."):
    """Everything the mapper reads, loaded once: rendered keyword knowledge (names, purposes, flow steps),
    the extract (keywords, tests, variables, locators), the app screens and the development screens."""
    k = os.path.join(ai_home(root), "knowledge")
    x = os.path.join(k, ".extract")
    kb = {"kws": {}, "flow_steps": [], "screens": [], "dev_elements": [], "dev_msgs": [], "vars": [], "tests": [], "db": [], "locs": []}
    kdir = os.path.join(k, "keywords")
    for f in sorted(os.listdir(kdir)) if os.path.isdir(kdir) else []:
        text = read_text(os.path.join(kdir, f)) if f.endswith(".md") else ""
        for m in re.finditer(r"(?ms)^### (KW-[A-Z0-9-]+) \| (.+?)$(.*?)(?=^### |^## |\Z)", text):
            g = lambda key, body=m.group(3): (re.search(r"(?m)^- " + key + r": (.*)$", body) or [None, ""])[1].strip()
            purpose = re.sub(r"\s*\(inferred: \w+\)\s*$", "", g("Purpose"))
            kb["kws"][m.group(1)] = {"name": m.group(2).strip(), "purpose": "" if purpose.startswith("(") else purpose,
                                     "args": g("Arguments"), "status": g("Status").lower(), "preferred": g("Preferred").lower()}
        for m in re.finditer(r"(?ms)^### (FLOW-[A-Z0-9-]+) \| (.+?)$(.*?)(?=^### |^## |\Z)", text):
            for n, st, kw in re.findall(r"(?m)^\|\s*(\d+)\s*\|\s*([^|]+?)\s*\|\s*(KW-[A-Z0-9-]+)\s*\|", m.group(3)):
                kb["flow_steps"].append({"flow": m.group(1), "flow_name": m.group(2).strip(), "n": int(n), "step": st, "kw": kw})
    seen = {v["name"].lower() for v in kb["kws"].values()}
    for k_ in load_json(os.path.join(x, "keywords.json"), []):      # knowledge not rendered yet: the extract still has names and docs
        if isinstance(k_, dict) and k_.get("name") and k_["name"].lower() not in seen:
            seen.add(k_["name"].lower())
            kb["kws"]["KW?" + k_["name"]] = {"name": k_["name"], "purpose": (k_.get("documentation") or "").split("\n")[0][:160],
                                              "args": ", ".join(k_.get("arguments") or []), "status": "", "preferred": ""}
    adir = os.path.join(k, "app")
    for f in sorted(os.listdir(adir)) if os.path.isdir(adir) else []:
        text = read_text(os.path.join(adir, f)) if f.endswith(".md") else ""
        for m in re.finditer(r"(?ms)^### (SCREEN-[A-Z0-9-]+) \| (.+?)$(.*?)(?=^### |^## |\Z)", text):
            entry = re.search(r"(?m)^- Entry: (.*)$", m.group(3))
            kb["screens"].append({"id": m.group(1), "name": m.group(2).strip(), "entry": entry.group(1).strip() if entry else "", "src": "QA knowledge"})
    for s in load_json(os.path.join(x, "dev", "dev-screens.json"), []):
        if not isinstance(s, dict):
            continue
        nm = s.get("component") or s.get("id")
        kb["screens"].append({"id": str(s.get("id")), "name": str(nm), "route": s.get("route") or "", "src": "development code"})
        for e in s.get("elements", [])[:400]:
            lab = e.get("label") or e.get("text") or e.get("placeholder") or e.get("name") or e.get("id")
            if lab:
                kb["dev_elements"].append({"screen": str(nm), "route": s.get("route") or "", "kind": e.get("kind", ""), "label": str(lab)[:80],
                                           "id": e.get("id") or "", "testid": e.get("data-testid") or e.get("testid") or ""})
        for v in s.get("validations", [])[:200]:
            for msg in v.get("messages", [])[:4]:
                kb["dev_msgs"].append({"screen": str(nm), "field": v.get("field", ""), "rules": v.get("rules", []), "msg": str(msg)[:160]})
        for t in s.get("texts", [])[:200]:
            if t.get("kind") in ("message", "toast", "alert", "error", "success", "snackbar", "notification"):
                kb["dev_msgs"].append({"screen": str(nm), "field": "", "rules": [], "msg": str(t.get("text"))[:160]})
    for v in load_json(os.path.join(x, "variables.json"), []):
        if isinstance(v, dict) and v.get("name") and not re.search(r"pass|pwd|secret|token|key|credential", v["name"], re.I):
            kb["vars"].append({"name": v["name"], "file": v.get("file", ""), "line": v.get("line")})
    kb["tests"] = [t for t in load_json(os.path.join(x, "tests.json"), []) if isinstance(t, dict)]
    kb["lessons"] = read_lessons(root)
    for k_ in load_json(os.path.join(x, "keywords.json"), []):
        calls = [str(c).lower() for c in (k_.get("calls") or [])] if isinstance(k_, dict) else []
        if any(re.search(r"(query|execute sql|row count|check if exists in database|connect to database)", c) for c in calls):
            kb["db"].append({"name": k_["name"], "file": k_.get("file", ""), "reads": any("query" in c or "row count" in c or "exists" in c for c in calls)})
    for kid, k_ in kb["kws"].items():
        k_["_t"], k_["_id"] = set(toks(k_["name"]) + toks(k_["purpose"])), kid
    kb["args_by_kw"] = {}
    for t in kb["tests"]:                                       # data the team's tests give each keyword, counted once
        for s in t.get("steps", []):
            for a in s.get("args", []) or []:
                for v in re.findall(r"[$@&]\{[^}]+\}", str(a)):
                    kb["args_by_kw"].setdefault(str(s.get("keyword", "")).lower(), {}).setdefault(v, set()).add(t.get("name", ""))
    for group, f in (("flow_steps", lambda x: x["step"]), ("screens", lambda x: x["name"] + " " + str(x.get("route", ""))),
                     ("dev_elements", lambda x: x["label"]), ("dev_msgs", lambda x: x["msg"] + " " + str(x["field"]))):
        for x in kb[group]:
            x["_t"] = set(toks(f(x)))
    return kb


def _score(step_t, cand_t, df, n):
    idf = df.get("__idf__") or {}
    import math
    return sum(idf.get(w) or math.log(1 + n / (1 + df.get(w, 0))) for w in set(step_t) if w in cand_t)


def _candidates(kb, group, st):
    """Only the entries that share a word with the step (inverted index): fast at 50,000 keywords."""
    inv = kb.setdefault("_inv", {}).get(group)
    if inv is None:
        inv = {}
        items = list(kb[group].values()) if isinstance(kb[group], dict) else kb[group]
        for i, x in enumerate(items):
            for w in x["_t"]:
                inv.setdefault(w, []).append(i)
        kb["_inv"][group] = inv
        kb["_inv"][group + "_items"] = items
    items = kb["_inv"][group + "_items"]
    ids = set()
    for w in set(st):
        ids.update(inv.get(w, ()))
    return [items[i] for i in sorted(ids)]


def map_step(kb, step, expected="", df=None, n=1):
    """Best knowledge for one test case step: keywords (flow step mapping first), screen, elements, data, messages."""
    st = toks(step)
    res = {"keywords": [], "screen": None, "elements": [], "data": [], "vague": [], "messages": [],
           "lessons": find_lessons(step + " " + (expected or ""), top=2, lessons=kb.get("lessons", []))}
    cands = []
    for fs in _candidates(kb, "flow_steps", st):                # business step wording the team already mapped: strongest
        sc = _score(st, fs["_t"], df, n) * 1.6
        if sc > 0:
            cands.append((sc, fs["kw"], f"flow step {fs['flow']}:{fs['n']} '{fs['step']}'"))
    for k_ in _candidates(kb, "kws", st):
        kid = k_["_id"]
        if "deprecated" in k_["status"]:
            continue
        sc = _score(st, k_["_t"], df, n) * (1.15 if k_["preferred"].startswith("yes") else 1)
        if sc > 0:
            cands.append((sc, kid, "name and purpose"))
    best = {}
    for sc, kid, why in sorted(cands, key=lambda c: -c[0]):
        if kid not in best and kid in kb["kws"]:
            best[kid] = (sc, why)
    top = sorted(best.items(), key=lambda kv: -kv[1][0])[:3]
    if top:
        hi = top[0][1][0]
        res["keywords"] = [{"id": kid if not kid.startswith("KW?") else "", "name": kb["kws"][kid]["name"], "args": kb["kws"][kid]["args"],
                            "why": why, "strength": "strong" if sc >= max(hi * 0.85, 3.0) and sc == hi else "possible"} for kid, (sc, why) in top
                           if sc >= hi * 0.5]
        if res["keywords"] and res["keywords"][0]["strength"] == "strong":
            res["keywords"] = res["keywords"][:2]
    top_ids = {k["id"] for k in res["keywords"] if k["id"]}
    sst = set(st)

    def screen_score(s):
        nt = s["_t"]
        sc = _score(st, list(nt), df, n)
        if nt and nt <= sst:
            sc += 2                                             # every word of the screen name is in the step
        if s.get("entry") and any(i in s["entry"] for i in top_ids):
            sc += 3                                             # the mapped keyword is how the team enters this screen
        return sc
    entry_screens = [x for x in kb["screens"] if x.get("entry") and any(i in x["entry"] for i in top_ids)]
    pool = {id(x): x for x in _candidates(kb, "screens", st) + entry_screens}.values()
    scr = sorted(((screen_score(s), s) for s in pool), key=lambda c: -c[0])
    if scr and scr[0][0] >= 2.0:
        res["screen"] = scr[0][1]
    quoted = [q.lower() for q in re.findall(r"[\"“`']([^\"”`']{2,60})[\"”`']", step)]
    el = []
    for e in _candidates(kb, "dev_elements", st):
        lab = e["label"].lower()
        lt = e["_t"]
        sc = (5 if any(q == lab or q in lab for q in quoted) else 0) + _score(st, list(lt), df, n) + (2 if lt and lt <= sst else 0)
        if res["screen"] and e["screen"] == res["screen"]["name"]:
            sc *= 1.3
        if sc >= 2.0:
            el.append((sc, e))
    seen_el = set()
    for _, e in sorted(el, key=lambda c: -c[0]):
        if (e["screen"], e["label"].lower()) not in seen_el and len(res["elements"]) < 2:
            seen_el.add((e["screen"], e["label"].lower()))
            res["elements"].append(e)
    if expected or VAGUE_EXPECTED.search(step):
        et = toks(expected) + st
        ms = sorted(((_score(et, m["_t"], df, n), m) for m in _candidates(kb, "dev_msgs", et)), key=lambda c: -c[0])
        res["messages"] = [m for sc, m in ms[:2] if sc > 2.0]
    vd = VAGUE_DATA.search(step)
    if vd or PLACEHOLDER.search(step) or re.search(r":\s*$|=\s*$|\(\s*\)", step):
        noun = vd.group(2).lower() if vd else (toks(PLACEHOLDER.search(step).group(0)) or ["data"])[0] if PLACEHOLDER.search(step) else "data"
        res["vague"].append(f"data not given ({noun})")
        res["data"] = find_data(kb, noun, st, [k["name"] for k in res["keywords"]])
    if VAGUE_EXPECTED.search(expected or "") or (not expected and VAGUE_EXPECTED.search(step)):
        res["vague"].append("expected result not concrete")
    if not res["keywords"] and not res["screen"] and not res["elements"]:
        res["vague"].append("no screen or action found in the knowledge")
    return res


def find_data(kb, noun, step_t, kw_names):
    """Test data the team already uses, best first: (1) arguments that passing team tests give to the mapped keyword,
    (2) variables named after the thing (CLIENT_*, ${EVENT_ID}...), (3) a read-only database lookup through the team's
    own query keyword. Only variable NAMES are shown, never values."""
    out = []
    used = {}
    for k in kw_names:
        for v, ts in kb["args_by_kw"].get(k.lower(), {}).items():
            used.setdefault(v, set()).update(ts)
    for v, ts in sorted(used.items(), key=lambda kv: -len(kv[1]))[:2]:
        out.append({"how": "existing tests", "name": v, "note": f"given to the same keyword by {len(ts)} team test(s), e.g. '{sorted(ts)[0][:60]}'"})
    want = set(toks(noun)) | {w for w in step_t if len(w) > 3}
    nv = []
    for v in kb["vars"]:
        vt = set(toks(v["name"].strip("${}@&").replace("_", " ")))
        hit = len(vt & want)
        if hit and toks(noun) and toks(noun)[0] in vt:
            nv.append((hit, v))
    for _, v in sorted(nv, key=lambda c: -c[0])[:2]:
        nm = v["name"] if v["name"].startswith(("$", "@", "&")) else "${" + v["name"] + "}"
        if not any(o["name"] == nm for o in out):
            out.append({"how": "variables", "name": nm, "note": f"{v['file']}:{v.get('line') or ''}"})
    return out


def map_testcase(kb, t, df, n):
    rows = []
    for s in t["steps"]:
        rows.append((s, map_step(kb, s["text"], s.get("expected", ""), df, n)))
    return rows


def df_of(kb):
    import math
    df, n = {}, 0
    for group in ("kws", "flow_steps", "screens", "dev_elements"):
        for x in (kb[group].values() if isinstance(kb[group], dict) else kb[group]):
            n += 1
            for w in x["_t"]:
                df[w] = df.get(w, 0) + 1
    n = max(n, 1)
    df["__idf__"] = {w: math.log(1 + n / (1 + c)) for w, c in df.items() if w != "__idf__"}
    return df, n


def render_map(t, rows, kb):
    out = [f"# Knowledge map for {label(t)}",
           "Suggestions only: prove each in the live session before use. Marks for the understanding: "
           "+ step added, ~ made concrete from the knowledge (say from where), ! still open."]
    open_n = 0
    for s, r in rows:
        out.append(f"\n{s['no']}. {s['text']}" + (f"  -> Expected: {s['expected']}" if s.get("expected") else ""))
        if r["keywords"]:
            for k in r["keywords"]:
                out.append(f"   keyword ({k['strength']}): {k['name']}" + (f"  [{k['id']}]" if k["id"] else "") +
                           (f"  args: {k['args']}" if k["args"] and k["args"] != "none" else "") + f"  (from {k['why']})")
        if r["screen"]:
            sc = r["screen"]
            out.append(f"   screen: {sc['name']}" + (f" ({sc['id']})" if sc["id"].startswith("SCREEN-") else "") +
                       (f" route {sc['route']}" if sc.get("route") else "") + f"  (from {sc['src']})")
        for e in r["elements"]:
            out.append(f"   element: {e['kind']} '{e['label']}' on {e['screen']}" + (f" id={e['id']}" if e["id"] else "") +
                       (f" data-testid={e['testid']}" if e["testid"] else "") + "  (from development code)")
        for m in r["messages"]:
            out.append(f"   expected text in the code: '{m['msg']}'" + (f" ({m['field']})" if m["field"] else "") + f" on {m['screen']}")
        for d in r["data"]:
            out.append(f"   data, {d['how']}: {d['name']}  ({d['note']})")
        for les in r.get("lessons", []):
            out.append(f"   lesson {les['id']} (apply it): {les['rule']}")
        for v in r["vague"]:
            out.append(f"   ! {v}" + (": fill from the lines above, then mark it ~ on the card" if r["keywords"] or r["data"] or r["messages"] else
                                       ": explore the live application for it (QA knowledge -> development knowledge -> live)"))
        if not (r["keywords"] or r["screen"] or r["elements"]):
            open_n += 1
    if any("data not given" in v for _, r in rows for v in r["vague"]):
        out.append("\nBlank data, in this order: the lines above (proven by team tests) -> the test data files -> "
                   + (f"a read-only database lookup with the team's keyword {next((d for d in kb['db'] if d['reads']), kb['db'][0])['name']} "
                      "(one SELECT with a row limit; check it first: tc_reader.py sql-check \"<query>\") -> " if kb["db"] else "")
                   + "a search in the live application. Record on the card where the data came from; never change shared data without restoring it.")
    out.append(f"\n{len(rows) - open_n} of {len(rows)} steps have a match in the knowledge." +
               (f" {open_n} need live exploration (not a blocker)." if open_n else ""))
    if not kb["kws"] and not kb["screens"]:
        out.append("The QA knowledge is not built in this repo yet: the matches come only from what is there. Build it for better maps.")
    return "\n".join(out)


def draft_understanding(t, rows, kb):
    """A first rewrite of a vague test case in the understanding format, built only from the map's evidence.
    The agent refines it (and proves every step live) before the card is shown; nothing here is final."""
    title = label(t)
    orig = " ".join(f"{s['no']}. {s['text']}" + (f" (expected: {s['expected']})" if s.get("expected") else "") for s, _ in rows)
    out = [f"title: {title}", "goal: <one line: what is tested and which result proves it passed>", f"original: {orig[:600]}"]
    datas = []
    for s, r in rows:
        if any("data not given" in v for v in r["vague"]):
            d = r["data"][0] if r["data"] else None
            datas.append(f"step {s['no']}: {d['name']} ({d['how']})" if d else f"step {s['no']}: to find (test data files, read-only database, live search)")
    out += [f"data: {d}" for d in datas]
    n = 0
    for s, r in rows:
        n += 1
        kw = r["keywords"][0] if r["keywords"] else None
        exp = s.get("expected") or ""
        mark, src = " ", "test case"
        if r["messages"] and (not exp or VAGUE_EXPECTED.search(exp)):
            exp, mark = f"'{r['messages'][0]['msg']}' is shown", "~"
            src = "expected text from the development code"
        if kw:
            src += f"; keyword {kw['name']}" + (" (strong match)" if kw["strength"] == "strong" else " (possible, prove live)")
        elif r["screen"] or r["elements"]:
            src += "; " + (f"screen {r['screen']['name']}" if r["screen"] else f"element '{r['elements'][0]['label']}'")
        else:
            mark, src = "!", "no match in the knowledge: explore live"
        if any("data not given" in v for v in r["vague"]) and mark == " ":
            mark = "~"
        out.append(f"{n} | {mark} | {s['text']} | {exp or '-'} | {src}")
        if "expected result not concrete" in r["vague"] and not r["messages"]:
            out.append(f"check: step {s['no']} expects '{exp or 'nothing concrete'}': write the result that proves it (from the closest test or the live page)")
    return "\n".join(out) + "\n"


def cmd_map(args, root="."):
    idx, text, _ = get_index(args.file, root)
    kb = knowledge_for_map(root)
    df, n = df_of(kb)
    for ref in (args.tc or ["all"]):
        ts = idx["tests"] if ref == "all" else [find_one(idx, ref)]
        for t in ts:
            if not t["steps"]:
                steps = [{"no": 1, "text": " ".join(text.splitlines()[t["start"] - 1:t["end"]])[:600], "expected": ""}]
                t = dict(t, steps=steps)
            rows = map_testcase(kb, t, df, n)
            print(render_map(t, rows, kb))
            if getattr(args, "draft", False):
                tid = re.sub(r"[^\w.-]+", "_", t.get("id") or f"{idx['stem']}-{t['n']}")
                dp = os.path.join(ai_home(root), "session", "understanding", f"{tid}.md")
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                with open(dp, "w", encoding="utf-8") as fh:
                    fh.write(draft_understanding(t, rows, kb))
                print(f"\nDraft rewrite saved: {os.path.relpath(dp, root)}  (fill the goal, refine every row, prove it live, then: tc_reader.py card {os.path.relpath(dp, root)})")
            print()


SQL_WRITE = re.compile(r"\b(insert|update|delete|merge|upsert|replace|drop|alter|create|truncate|rename|grant|revoke|exec|execute|call|"
                       r"commit|rollback|savepoint|lock|copy|load|attach|detach|vacuum|pragma|set|declare|begin|into|for\s+update|nextval|setval)\b", re.I)


def sql_is_read_only(q):
    """(ok, reason). Only one SELECT (or WITH ... SELECT) statement; nothing that writes, locks or changes the session."""
    s = re.sub(r"'(?:[^']|'')*'", "''", str(q or ""))            # string literals cannot hide keywords
    s = re.sub(r"--[^\n]*|/\*.*?\*/", " ", s, flags=re.S).strip().rstrip(";").strip()
    if not s:
        return False, "the query is empty"
    if ";" in s:
        return False, "only one statement is allowed"
    if not re.match(r"(?is)^(select|with)\b", s):
        return False, "only SELECT (or WITH ... SELECT) is allowed"
    w = SQL_WRITE.search(s)
    if w:
        return False, f"'{w.group(0)}' is not allowed in a read-only query"
    if not re.search(r"(?i)\b(fetch\s+first|limit|top|rownum|row_number)\b", s):
        return True, "read-only; add a row limit (FETCH FIRST 5 ROWS ONLY / LIMIT 5 / TOP 5) so a big table never slows the run"
    return True, "read-only"


def cmd_sql_check(args, root="."):
    ok, why = sql_is_read_only(args.query)
    print(("OK    " if ok else "BLOCK ") + why)
    return 0 if ok else 2


# ======================================================================== self-test
SAMPLE = """# Test cases: Client VOC status

| Field | Value |
|---|---|
| Feature | VOC status on the client page |
| Source | Specification v2 |
| Step format | Action -> Expected |
| Status | Draft |

## How to read the steps for automation
1. Names in CAPITALS_WITH_UNDERSCORES are data aliases from the Test data catalog.
2. Names in `backticks` are UI elements from the UI element catalog.
3. "Open the client page for X" means: search for client X and open its page.

## UI element catalog
| Name | Where | Note |
|---|---|---|
| `VOC status text` | Client page header | read-only |
| `VOC popup` | opens from the status text | modal dialog |
| `Subscribe button` | inside the VOC popup | |

## Test data catalog
| Alias | Meaning |
|---|---|
| CLIENT_NO_VID | Client with no VID; eligible; not a sub-account; not synthetic or duplicate |
| CLIENT_WITH_VID | Client holding a VID |
| CLIENT_WITH_VID_EXPIRED | Client whose VID has expired |
| CLIENT_SUB_ACCOUNT | A sub-account client |

## Index
| ID | Title | Priority | Type | Category | Story |
|---|---|---|---|---|---|
| TC-VOC-001 | Not subscribed client shows status and opens popup | High | Functional | Positive | US1 |
| TC-VOC-002 | Subscribed client shows subscribed status | High | Functional | Positive | US1 |
| TC-VOC-003 | Expired VID client shows expired status | Medium | Functional | Negative | US1 |
| TC-VOC-004 | Sub-account client has no subscribe option | Medium | Functional | Negative | US2 |

## US1 - VOC status and entry point
The status text sits in the client page header and is the entry point to the VOC popup.

### Test case 1: Not subscribed client shows status and opens popup
**Priority:** High
**Type:** Functional
**Description:** A client without a VID shows the not-subscribed status.
**Preconditions:** Logged in as a standard user.
**Steps:**
1. Open the client page for CLIENT_NO_VID.
   - Expected: The client page opens.
2. Read `VOC status text`.
   - Expected: It reads "Not subscribed".
3. Click `VOC status text` -> `VOC popup` opens.

### Test case 2: Subscribed client shows subscribed status
**Priority:** High
**Steps:**
1. Open the client page for CLIENT_WITH_VID.
   - Expected: The client page opens.
2. Read `VOC status text`.
   - Expected: It reads "Subscribed".

### Test case 3: Expired VID client shows expired status
**Steps:**
1. Open the client page for CLIENT_WITH_VID_EXPIRED.
2. Read `VOC status text`.
   - Expected: It reads "Expired".

## US2 - Sub-accounts
Sub-accounts inherit the parent's subscription.

### Test case 4: Sub-account client has no subscribe option
**Steps:**
1. Open the client page for CLIENT_SUB_ACCOUNT.
2. Click `VOC status text`.
3. Check `Subscribe button`.
   - Expected: It is not shown.
"""

SAMPLE_TABLE = """# Payments regression
## TC-101 - Create a payment
Priority: P1
| # | Step | Expected result |
|---|---|---|
| 1 | Log in as payer | Home page shows |
| 2 | Create a payment of 100 | Payment is listed |

## TC-102 - Cancel a payment
| # | Step | Expected result |
|---|---|---|
| 1 | Open the payment | Details show |
| 2 | Click Cancel | Status is Cancelled |
"""

SAMPLE_SINGLE = """# TC-1328 Update the preferred address
Description: the user changes the preferred address
## Steps
1. Search the client
2. Open the Addresses tab
3. Tick Preferred
Expected: the address is preferred
"""

SAMPLE_CSV = "Id,Name,Priority,Step Description,Expected Result\nTC-7,Login works,High,Open the login page,Page shows\n,,,Enter the user and password,Home page shows\nTC-8,Logout works,Low,Click Logout,Login page shows\n"

GEN_ROBOT = """*** Settings ***
Resource    voc.resource

*** Test Cases ***
TC-VOC-001 Not subscribed client shows status and opens popup
    [Documentation]    TC-VOC-001 | Not subscribed client shows status and opens popup
    [Tags]    ai-generated    TC-VOC-001
    # Step 1: Open the client page
    Open Client Page    ${CLIENT_NO_VID}
    # Step 2: Read the status
    ${status}=    Read VOC Status Text
    Should Be Equal    ${status}    Not subscribed
    # Step 3: Open the popup
    Click VOC Status Text
"""


def self_test():
    ok = {}
    tmp = tempfile.mkdtemp(prefix="tc_reader_selftest_")
    cwd = os.getcwd()
    import io, contextlib
    try:
        os.makedirs(os.path.join(tmp, "qa-ai-skills"))
        os.chdir(tmp)
        for name, body in (("voc.md", SAMPLE), ("pay.md", SAMPLE_TABLE), ("one.md", SAMPLE_SINGLE), ("q.csv", SAMPLE_CSV), ("gen.robot", GEN_ROBOT),
                           ("notes.md", "# Notes\nSome text.\n## Other\nMore text.\n"),
                           ("voc.resource", "*** Keywords ***\nRead VOC Status Text\n    No Operation\nClick VOC Status Text\n    No Operation\n")):
            with open(name, "w", encoding="utf-8") as fh:
                fh.write(body)
        # stories written as ID headings over test case headings (the "8 of 44" layout), with test cases at mixed levels
        story = ["# Test cases", "", "## Test case index", "", "| ID | Title |", "|---|---|"]
        story += [f"| TC-{k:03d} | Case {k} |" for k in range(1, 45)] + [""]
        k = 0
        for s_i in range(1, 9):
            story += [f"## US-{s_i:03d} Story {s_i}", "Story text.", ""]
            for _ in range(6 if s_i <= 4 else 5):
                k += 1
                if k > 44:
                    break
                lv = "####" if k % 7 == 0 else "###"
                story += [f"{lv} TC-{k:03d}: Case {k}", "**Steps:**", "1. Open the page", "   - Expected: page opens", "2. Click Save", "   - Expected: saved", ""]
        story += ["### TC-099 Missing from index", "Steps:", "1. Do it", "   - Expected: done", ""]
        with open("stories.md", "w", encoding="utf-8") as fh:
            fh.write("\n".join(story))
        si, _, _ = get_index("stories.md")
        ok["story ID headings over test case headings: all 44 found, stories kept as groups"] = \
            len(si["tests"]) == 45 and si["tests"][0]["id"] == "TC-001" and len(si["groups"]) >= 8 and si["tests"][0]["group"].startswith("US-001")
        story2 = [l for l in story if not l.startswith("### TC-005") ]
        with open("stories2.md", "w", encoding="utf-8") as fh:
            fh.write("\n".join(story2).replace("### TC-006: Case 6", "TC-006 Case 6 (plain line)"))
        s2, _, _ = get_index("stories2.md")
        ok["index IDs that were not read are named with their line"] = any("Not read:" in w and "TC-006 (line" in w for w in s2["warnings"])
        gh = ["# Feature: Login", ""] + sum(([f"## Scenario: Login variant {k}", "Given the user is on the login page",
                                            "When they enter valid credentials", "Then the dashboard is shown", ""] for k in range(1, 6)), [])
        with open("gherkin.md", "w", encoding="utf-8") as fh:
            fh.write("\n".join(gh))
        gi_, _, _ = get_index("gherkin.md")
        ok["Gherkin scenarios without IDs: every scenario found, Given/When as steps, Then as the expected result"] = \
            len(gi_["tests"]) == 5 and gi_["tests"][0]["steps"][-1]["expected"] == "the dashboard is shown" and len(gi_["tests"][0]["steps"]) == 2
        idx, text, _ = get_index("voc.md")
        T = idx["tests"]
        ok["AIDLC layout: 4 test cases found by their headings"] = len(T) == 4 and T[0]["title"].startswith("Not subscribed")
        ok["sections recognised by content (details, rules, 2 catalogs, index)"] = \
            [s["kind"] for s in idx["sections"]] == ["metadata", "rules", "catalog", "catalog", "index"] and idx["metadata"].get("Step format") == "Action -> Expected"
        ok["catalog kinds: UI elements and test data"] = sorted(c["kind"] for c in idx["catalogs"]) == ["data", "element"]
        ok["IDs, priority and story taken from the index"] = T[0]["id"] == "TC-VOC-001" and T[2]["priority"] == "Medium" and T[3]["story"] == "US2"
        ok["story groups found (US1 has 3, US2 has 1)"] = [g["title"][:3] for g in idx["groups"]] == ["US1", "US2"] and T[3]["group"].startswith("US2")
        ok["steps and expected results read (sub-bullets and arrows)"] = len(T[0]["steps"]) == 3 and T[0]["steps"][1]["expected"] == 'It reads "Not subscribed".' \
            and T[0]["steps"][2]["expected"] == "`VOC popup` opens."
        ok["aliases used per test case, longest name first (EXPIRED not taken as WITH_VID)"] = \
            T[2]["uses"].get("data") == ["CLIENT_WITH_VID_EXPIRED"] and T[1]["uses"].get("data") == ["CLIENT_WITH_VID"]
        ok["UI element names used per test case"] = T[3]["uses"].get("element") == ["Subscribe button", "VOC status text"] or \
            sorted(T[3]["uses"].get("element", [])) == ["Subscribe button", "VOC status text"]
        p = packet(idx, text, T[0])
        ok["packet: reading rules, section context, test case and only the used catalog rows"] = \
            "## Reading rules of this file" in p and "entry point to the VOC popup" in p and "### Test case 1" in p and \
            "| CLIENT_NO_VID |" in p and "CLIENT_WITH_VID " not in p and "| `VOC status text` |" in p and "Subscribe button" not in p and "| Alias | Meaning |" in p
        ok["unlinked names say what to do"] = "CLIENT_NO_VID -> not linked yet" in p
        sel = lambda *s: resolve(idx, list(s))[0]
        ok["selection: all, first N, range, numbers, IDs, 'test case N', title words"] = \
            sel("all") == [1, 2, 3, 4] and sel("first", "2") == [1, 2] and sel("2-3") == [2, 3] and sel("4", "1") == [4, 1] and \
            sel("TC-VOC-003") == [3] and sel("test case 2") == [2] and sel("expired") == [3]
        ok["selection problems reported, not guessed"] = bool(resolve(idx, ["9"])[1] and resolve(idx, ["status"])[1] and resolve(idx, ["TC-999"])[1])
        # links
        class A: pass
        a = A(); a.file, a.kind, a.name, a.to, a.where = "voc.md", "data", "CLIENT_NO_VID", "keyword Get Client Without VID", "resources/db.resource:40"
        cmd_link(a)
        p2 = packet(idx, text, T[0])
        ok["saved link shown in the next packet"] = "CLIENT_NO_VID -> keyword Get Client Without VID (resources/db.resource:40)" in p2
        a.to = "client 12345678"
        try:
            cmd_link(a)
            ok["links never hold data values"] = False
        except SystemExit:
            ok["links never hold data values"] = True
        changed = SAMPLE.replace("Client with no VID; eligible", "Client with no VID; eligible; active")
        with open("voc2.md", "w", encoding="utf-8") as fh:
            fh.write(changed)
        i2, t2, _ = get_index("voc2.md")
        ok["link flagged when the catalog meaning changed"] = "catalog meaning changed" in packet(i2, t2, i2["tests"][0])
        # step cache
        b = A(); b.file, b.tc, b.robot, b.resource = "voc.md", "1", "gen.robot", ["voc.resource"]
        cmd_learn(b)
        p3 = packet(idx, text, T[1])
        ok["step cache: same step is known; a step seen with only one other client is a hint, not known"] = \
            "Steps already known from earlier passing runs: 1 of 2" in p3 and "2. Read VOC Status Text" in p3 and "AI-created keyword; this same step passed" in p3 and \
            "similar step passed with other data as: Open Client Page    ${CLIENT_NO_VID}" in p3
        g2 = GEN_ROBOT.replace("TC-VOC-001 Not subscribed", "TC-VOC-003 Expired").replace("TC-VOC-001", "TC-VOC-003").replace("${CLIENT_NO_VID}", "${CLIENT_EXPIRED}")
        with open("gen3.robot", "w", encoding="utf-8") as fh:
            fh.write(g2)
        b3 = A(); b3.file, b3.tc, b3.robot, b3.resource = "voc.md", "3", "gen3.robot", ["voc.resource"]
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_learn(b3)
        p4 = packet(idx, text, T[1])
        ok["step cache: proven with two different clients, the keyword takes the client as its argument"] = \
            "Steps already known from earlier passing runs: 2 of 2" in p4 and "Open Client Page  with this step's data or element as its argument" in p4
        cache = load_json(paths()["cache"], {})
        flat = [v for k, v in cache.items() if k.startswith("x:")] + [vv for k, v in cache.items() if k.startswith("g:") for vv in v["variants"].values()]
        ok["step cache: AI-created vs team keywords; no data values stored"] = \
            any(v["source"] == "AI-created" and v["calls"][0].startswith("Read VOC") for v in flat) and \
            any(v["source"] == "team" and v["calls"][0].startswith("Open Client Page") for v in flat) and \
            "Not subscribed" not in json.dumps(cache)
        ext = os.path.join(ai_home("."), "knowledge", ".extract")
        os.makedirs(ext, exist_ok=True)
        save_json(os.path.join(ext, "keywords.json"), [{"name": "Open Client Page"}])
        cmd_learn(b)
        save_json(os.path.join(ext, "keywords.json"), [{"name": "Something Else"}])
        ok["a remembered team keyword that was removed from the repo is not reused"] = "no longer in the repo" in packet(idx, text, T[1])
        save_json(os.path.join(ext, "keywords.json"), [{"name": "Open Client Page"}])
        # batch
        c = A(); c.file, c.selection, c.fresh = "voc.md", ["first", "3"], False
        cmd_plan(c)
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_review(type("X", (), {"file": "voc.md"})())
        ok["review waits until every test case is understood"] = "Not understood yet: 3" in buf.getvalue()
        for n, body in ((1, "title: TC-VOC-001 | Not subscribed client shows status\ngoal: a client without a VID shows Not subscribed\n"
                             "data: CLIENT_NO_VID, found with the team's client query\n1 | + | Log in as the standard user | Home page shows | run-config\n"
                             "2 |   | Open the client page for CLIENT_NO_VID | Client page opens | test case\n"
                             "3 | ~ | Read the VOC status text | It reads \"Not subscribed\" | test case"),
                        (2, "goal: subscribed status\n1 |   | Open the client page for CLIENT_WITH_VID | Client page opens | test case"),
                        (3, "goal: expired status\n1 |   | Open the client page for CLIENT_WITH_VID_EXPIRED | Client page opens | test case\n"
                             "check: the app may show Pending for expired VIDs (status-flows)")):
            up = understanding_path(idx, n)
            os.makedirs(os.path.dirname(up), exist_ok=True)
            with open(up, "w", encoding="utf-8") as fh:
                fh.write(body)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_review(type("X", (), {"file": "voc.md"})())
        rv = buf.getvalue()
        ok["review is an overview for information (1 decided from evidence, 1 added, 1 clear), never a confirmation"] = \
            "1 clear as written, 1 with steps added or made concrete, 1 with points decided from the evidence" in rv and \
            "work continues" in rv and "Cards to show" not in rv
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_card(type("X", (), {"file": "voc.md", "which": "1", "more": []})())
        cd = buf.getvalue()
        ok["card: fixed layout - heading 1 of 2 with ID, title, goal, data, step table with marks, summary line"] = \
            cd.startswith("### Test case 1 of 2 \u00b7 TC-VOC-001") and "**Not subscribed client shows status**" in cd and "**Goal:**" in cd \
            and "**Data:** CLIENT_NO_VID" in cd and "| # | Step | Expected result | From |" in cd and "| 1 | \u2795 Log in as the standard user | Home page shows | run-config |" in cd \
            and "\u2795 1 added from the knowledge \u00b7 \u2248 1 made concrete" in cd
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_card(type("X", (), {"file": "voc.md", "which": "2", "more": []})())
        ok["card: checks shown as decided-from-evidence lines (information)"] = "### Test case 2 of 2" in buf.getvalue() and "\u26a0 **Decided from the evidence:** the app may show Pending" in buf.getvalue()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_card(type("X", (), {"file": understanding_path(idx, 1), "which": None, "more": []})())
        ok["card from an understanding file (single test case run)"] = buf.getvalue().startswith("### Test case 1 of 1 \u00b7 TC-VOC-001")
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_change(type("X", (), {"file": "voc.md", "tc": "1", "step": "3", "was": "an empty results area",
                                      "now": "no result rows", "why": "the page shows no empty area, only no rows"})())
            cmd_card(type("X", (), {"file": "voc.md", "which": "1", "more": []})())
        cc = buf.getvalue()
        ok["changed expected result: recorded on the card as a check line, never quietly"] = \
            "\u26a0 **Changed check, needs your OK:** step 3: the test case expects \"an empty results area\"; the script checks \"no result rows\"" in cc \
            and "\u26a0 1 changed check waiting for your OK" in cc
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_next(type("X", (), {"file": "voc.md"})())
        nx = buf.getvalue()
        ok["batch: next gives the saved understanding, not the whole packet again"] = "[Batch 1 of 3]" in nx and "Your saved understanding" in nx \
            and "Reading rules" not in nx and "CLIENT_NO_VID -> keyword Get Client Without VID" in nx
        d0 = A(); d0.file, d0.tc, d0.state, d0.reason, d0.script, d0.attempts = "voc.md", "3", "ready", "", "", None
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_status(d0)
        bb = load_batch(idx, ".")
        for k in ("1", "2"):
            bb["status"][k]["state"] = "ready"
        save_json(batch_path(idx, "."), bb)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_next(type("X", (), {"file": "voc.md"})())
        ok["batch: when nothing is left to write, next says the ready ones run together"] = "Full run due: 3 test case(s)" in buf.getvalue()
        bb["status"]["3"]["state"] = "waiting"
        save_json(batch_path(idx, "."), bb)
        for tc, stt, why in (("1", "passed", ""), ("2", "failed", "the app shows Pending, the test case expects Subscribed")):
            d = A(); d.file, d.tc, d.state, d.reason, d.script, d.attempts = "voc.md", tc, stt, why, "drafts/voc/test.robot", 1
            d.checked, d.needed = ("the status column after subscribing, twice", "the team to confirm which status is right") if tc == "2" else (None, None)
            with contextlib.redirect_stdout(io.StringIO()):
                cmd_status(d)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_progress(type("X", (), {"file": "voc.md", "all": False})())
        pg = buf.getvalue()
        ok["batch: progress checklist with ticks"] = "1 passed, 1 failed" in pg and "✅ 1." in pg and "❌ 2." in pg and "⬜ 3." in pg
        ok["selection: failed and next N use the batch"] = resolve(idx, ["failed"], load_batch(idx, "."))[0] == [2] and \
            resolve(idx, ["next", "2"], load_batch(idx, "."))[0] == [2, 3]
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cmd_report(type("X", (), {"file": "voc.md"})())
        rp = buf.getvalue()
        rep_file = rp.split("Batch report: ")[1].splitlines()[0]
        ok["batch report written with totals and reasons"] = os.path.isfile(rep_file) and "1 of 3 passed" in rp and "app shows Pending" in open(rep_file).read()
        na_file = rp.split("what is needed: ")[1].splitlines()[0] if "what is needed: " in rp else ""
        na = open(na_file, encoding="utf-8").read() if na_file and os.path.isfile(na_file) else ""
        ok["not-automated report: each test case one by one with reason, what was checked and what is needed"] = \
            "# Test cases not automated: voc.md" in na and "2 of 3 test cases did not become a verified script" in na and \
            "- **Main reason:** the app shows Pending" in na and "- **What was checked:** the status column after subscribing, twice" in na \
            and "- **What is needed to finish it:** the team to confirm which status is right" in na and "It was not run in this batch." in na \
            and "## 1." not in na
        # lessons: every answer becomes a general rule, checked before asking, applied by the map, listed at the end
        def L(action, *text, **kw):
            a_ = type("X", (), dict({"action": action, "text": list(text), "about": None, "source": "user answer", "tc": None, "new": False}, **kw))()
            b_ = io.StringIO()
            try:
                with contextlib.redirect_stdout(b_):
                    cmd_lesson(a_)
            except SystemExit as e:
                return str(e)
            return b_.getvalue()
        l1 = L("add", "'No VID' means the client's VID column is empty; find such clients with the team's Get Client query", about="client VID", tc="TC-9")
        l2 = L("add", "'No VID' means the client's VID column is empty; find such clients with the team's Get Client query")
        l3 = L("add", "Use client 12345678 for VID tests")
        lf = L("find", "Open a client with no VID")
        ln = L("list", new=True)
        ln2 = L("list", new=True)
        ok["lessons: answer saved as a general rule, duplicates and data values refused, found before asking, listed once at the end"] = \
            l1.startswith("Learned L-001") and "Already known as L-001" in l2 and "never a data value" in l3 and \
            "L-001: 'No VID' means" in lf and "- L-001:" in ln and "Nothing new learned" in ln2 and \
            "from: user answer, TC-9" in open(lessons_path("."), encoding="utf-8").read()
        # other layouts
        ip, _, _ = get_index("pay.md")
        ok["IDs in headings with step tables"] = [t["id"] for t in ip["tests"]] == ["TC-101", "TC-102"] and ip["tests"][0]["steps"][1]["expected"] == "Payment is listed" \
            and ip["tests"][0]["priority"] == "P1"
        i1, _, _ = get_index("one.md")
        ok["single test case file (qTest copy style)"] = len(i1["tests"]) == 1 and len(i1["tests"][0]["steps"]) == 3
        ic, tc_, _ = get_index("q.csv")
        ok["CSV export: test cases with their step rows"] = [len(t["steps"]) for t in ic["tests"]] == [2, 1] and ic["tests"][0]["id"] == "TC-7" \
            and "Enter the user and password" in packet(ic, tc_, ic["tests"][0])
        q1 = "# TC-1328: Update the preferred address\n\nSource: qTest\n\n## Steps\n\n| # | Action | Expected result |\n|---|---|---|\n| 1 | Search the client | Found |\n| 2 | Tick Preferred | Saved |\n"
        q2 = "# TC-1329: Remove an address\n\n## Precondition\nAn address exists\n\n## Steps\n\n| # | Action | Expected result |\n|---|---|---|\n| 1 | Click Remove | Gone |\n"
        for nm, body in (("q1.md", q1), ("q2.md", q2)):
            with open(nm, "w", encoding="utf-8") as fh:
                fh.write(body)
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_combine(type("X", (), {"out": "both.md", "files": ["q1.md", "q2.md"]})())
        ib2, _, _ = get_index("both.md")
        ok["several qTest copies combined into one batch (IDs and step tables kept)"] = [t["id"] for t in ib2["tests"]] == ["TC-1328", "TC-1329"] \
            and [len(t["steps"]) for t in ib2["tests"]] == [2, 1]
        iu, _, _ = get_index("notes.md")
        ok["unknown layout: no guessing, the sections are listed instead"] = iu["tests"] == []
        ok["index cached by file content"] = get_index("voc.md")[2] is True
        big = SAMPLE.split("### Test case 1")[0] + "".join(
            f"### Test case {i}: Generated case {i}\n**Steps:**\n1. Open the client page for CLIENT_WITH_VID.\n2. Read `VOC status text`.\n   - Expected: shows {i}\n\n"
            for i in range(1, 501))
        with open("big.md", "w", encoding="utf-8") as fh:
            fh.write(big)
        import time as _t
        t0 = _t.time()
        ib, tb, _ = get_index("big.md")
        pk = packet(ib, tb, ib["tests"][399])
        ok["500 test cases indexed in under 3 seconds; packet of test case 400 stays small"] = len(ib["tests"]) == 500 and _t.time() - t0 < 3 and len(pk) < 4000
        with open("spec.md", "w", encoding="utf-8") as fh:
            fh.write("# Feature Specification: Find owners\n\n## User Scenarios & Testing\n\n### User Story 1 - Find an owner (Priority: P1)\n\n"
                     "A receptionist looks up an owner.\n\n**Acceptance Scenarios**:\n\n"
                     "1. **Given** an owner and a pet named Davis exist, **When** the receptionist searches for \"Davis\", **Then** the owners list shows Davis\n"
                     "2. **Given** one owner matches, **When** the receptionist searches, **Then** the owner page opens, **And** the pets are listed\n\n"
                     "### User Story 2 - Add an owner (Priority: P2)\n\n**Acceptance Scenarios**:\n\n"
                     "1. Given the add owner form, When the telephone is empty and the user saves, Then the error \"must not be blank\" is shown\n\n"
                     "### Edge Cases\n\n- No owner matches.\n\n## Requirements\n\n- **FR-001**: System MUST search owners\n")
        isk, tsk, _ = get_index("spec.md")
        a1, a2, b1 = isk["tests"]
        ok["Spec Kit spec.md: each acceptance scenario is a test case (Given/When/Then, bold or plain)"] = isk["format"] == "speckit" \
            and [t["id"] for t in isk["tests"]] == ["US1-AS1", "US1-AS2", "US2-AS1"] and a1["priority"] == "P1" \
            and a1["steps"][0]["text"] == "Given an owner and a pet named Davis exist" and a1["steps"][1]["expected"] == "the owners list shows Davis" \
            and a2["steps"][-1]["expected"] == "the owner page opens; the pets are listed" \
            and b1["steps"][-1]["text"] == "When the telephone is empty and the user saves" and "must not be blank" in b1["steps"][-1]["expected"] \
            and any("edge case" in w for w in isk["warnings"]) and "A receptionist looks up an owner." in packet(isk, tsk, a2)
        # vague test case -> knowledge map
        kd = os.path.join(ai_home("."), "knowledge")
        os.makedirs(os.path.join(kd, "keywords")); os.makedirs(os.path.join(kd, ".extract", "dev")); os.makedirs(os.path.join(kd, "app"))
        with open(os.path.join(kd, "keywords", "MOD-CLIENT.md"), "w", encoding="utf-8") as fh:
            fh.write("## Flows\n### FLOW-CLIENT-VOC | Subscribe a client to VOC\n| # | Step | Keyword | Name |\n|---|---|---|---|\n"
                     "| 1 | Open the client profile | KW-OPEN-CLIENT-PAGE | Open Client Page |\n| 2 | Subscribe the client to voice of client | KW-SUBSCRIBE-VOC | Subscribe VOC |\n\n"
                     "## Keywords\n### KW-OPEN-CLIENT-PAGE | Open Client Page\n- File: r/client.resource:3\n- Level: page\n- Arguments: ${client}\n"
                     "- Purpose: Searches a client and opens its page (inferred: no)\n- Status: active\n"
                     "### KW-SUBSCRIBE-VOC | Subscribe VOC\n- File: r/voc.resource:9\n- Arguments: none\n- Purpose: Opens the VOC popup and subscribes (inferred: yes)\n"
                     "### KW-OLD-OPEN | Open Client Old\n- Purpose: opens a client page\n- Status: deprecated\n")
        with open(os.path.join(kd, "app", "screens.md"), "w", encoding="utf-8") as fh:
            fh.write("### SCREEN-CLIENT-PAGE | Client page\n- Entry: KW-OPEN-CLIENT-PAGE\n")
        save_json(os.path.join(kd, ".extract", "tests.json"), [{"name": "Existing VOC test", "steps": [{"keyword": "Open Client Page", "args": ["${CLIENT_NO_VID}"]}]}])
        save_json(os.path.join(kd, ".extract", "variables.json"), [{"name": "${CLIENT_NO_VID}", "value": "***NUM***", "file": "data/clients.resource", "line": 4},
                                                                    {"name": "${CLIENT_PASSWORD}", "value": "***MASKED***", "file": "data/x.resource", "line": 1}])
        save_json(os.path.join(kd, ".extract", "keywords.json"), [{"name": "Find Client In Database", "file": "r/db.resource", "calls": ["Query"]}])
        save_json(os.path.join(kd, ".extract", "dev", "dev-screens.json"), [{"id": "client", "component": "ClientPage", "route": "/client/:id",
                   "elements": [{"kind": "button", "label": "Subscribe", "id": "voc-subscribe"}],
                   "validations": [{"field": "voc", "rules": ["required"], "messages": ["Client subscribed to VOC successfully"]}], "texts": []}])
        with open("vague.md", "w", encoding="utf-8") as fh:
            fh.write("# TC-900: VOC subscribe\n## Steps\n1. Open a client profile\n2. Subscribe the client to VOC\n   - Expected: works as expected\n3. Check the reporting batch\n")
        iv, tv, _ = get_index("vague.md")
        kb = knowledge_for_map(".")
        dfv, nv = df_of(kb)
        rows = map_testcase(kb, iv["tests"][0], dfv, nv)
        mp = render_map(iv["tests"][0], rows, kb)
        with open(lessons_path("."), "a", encoding="utf-8") as fh:
            fh.write("- **L-050** To subscribe a client to VOC, open the VOC popup from the client page first _(about: voc subscribe; from: user answer; 2026-11-25)_\n")
        kb = knowledge_for_map(".")
        rows = map_testcase(kb, iv["tests"][0], dfv, nv)
        mp = render_map(iv["tests"][0], rows, kb)
        ok["the map applies saved lessons to the matching steps"] = "lesson L-050 (apply it): To subscribe a client to VOC" in mp
        ok["vague steps mapped: flow step wording -> team keyword, screen, element, data from existing tests"] = \
            rows[0][1]["keywords"][0]["name"] == "Open Client Page" and rows[0][1]["data"][0]["name"] == "${CLIENT_NO_VID}" \
            and rows[1][1]["keywords"][0]["name"] == "Subscribe VOC" and any(e["id"] == "voc-subscribe" for e in rows[1][1]["elements"]) \
            and "Client subscribed to VOC successfully" in mp and "Open Client Old" not in mp
        ok["map: blank data and vague expected flagged, unknown step is live exploration (not a blocker); no secret names"] = \
            "data not given" in mp and "expected result not concrete" in mp and "need live exploration (not a blocker)" in mp \
            and "CLIENT_PASSWORD" not in mp and "read-only database lookup with the team's keyword Find Client In Database" in mp and "***" not in mp
        dr = parse_understanding(draft_understanding(iv["tests"][0], rows, kb))
        card_txt = render_card(dict(dr, goal="a client can subscribe to VOC"), 1, 1)
        ok["vague case: draft rewrite with marks and sources; card shows the original and asks to confirm"] = \
            len(dr["steps"]) == 3 and dr["steps"][1]["mark"] == "\u2248" and "Client subscribed to VOC successfully" in dr["steps"][1]["expected"] \
            and dr["steps"][2]["mark"] == "\u26a0" and "completed from the knowledge" in card_txt and "As written in the test case:" in card_txt \
            and "Open a client profile" in card_txt
        ok["sql-check: only one read-only SELECT passes"] = sql_is_read_only("SELECT id FROM clients WHERE vid IS NULL FETCH FIRST 5 ROWS ONLY")[0] \
            and sql_is_read_only("with c as (select id from t) select * from c limit 3")[0] \
            and not sql_is_read_only("SELECT 1; DELETE FROM clients")[0] and not sql_is_read_only("UPDATE clients SET x=1")[0] \
            and not sql_is_read_only("SELECT * INTO backup FROM clients")[0] and not sql_is_read_only("select * from t for update")[0] \
            and sql_is_read_only("select * from t where note = 'please delete me' limit 1")[0]
    finally:
        os.chdir(cwd)
        shutil.rmtree(tmp, ignore_errors=True)
    width = max(len(k) for k in ok)
    print()
    for k, v in ok.items():
        print(f"  {'OK  ' if v else 'FAIL'}  {k.ljust(width)}")
    passed = all(ok.values())
    print("SELF-TEST PASSED" if passed else "SELF-TEST FAILED", f"({sum(ok.values())} of {len(ok)} OK)")
    return 0 if passed else 1


# ======================================================================== main
def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    if argv is None:
        argv = sys.argv[1:]
    if argv[:1] == ["--self-test"]:
        return self_test()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for c in ("index", "shared"):
        sp = sub.add_parser(c); sp.add_argument("file")
    sp = sub.add_parser("list"); sp.add_argument("file"); sp.add_argument("selection", nargs="*"); sp.add_argument("--all", action="store_true")
    sp = sub.add_parser("packet"); sp.add_argument("file"); sp.add_argument("tc", nargs="+"); sp.add_argument("--full-rules", action="store_true")
    sp = sub.add_parser("plan"); sp.add_argument("file"); sp.add_argument("selection", nargs="*"); sp.add_argument("--fresh", action="store_true")
    sp = sub.add_parser("next"); sp.add_argument("file")
    sp = sub.add_parser("review"); sp.add_argument("file")
    sp = sub.add_parser("card"); sp.add_argument("file"); sp.add_argument("which", nargs="?"); sp.add_argument("more", nargs="*")
    sp = sub.add_parser("combine"); sp.add_argument("out"); sp.add_argument("files", nargs="+")
    sp = sub.add_parser("change"); sp.add_argument("file"); sp.add_argument("tc", nargs="?"); sp.add_argument("--step", required=True)
    sp.add_argument("--was", required=True); sp.add_argument("--now", required=True); sp.add_argument("--why")
    sp = sub.add_parser("status"); sp.add_argument("file"); sp.add_argument("tc")
    sp.add_argument("state", choices=["ready", "passed", "failed", "blocked", "skipped"]); sp.add_argument("--reason"); sp.add_argument("--script"); sp.add_argument("--attempts", type=int)
    sp.add_argument("--checked", help="what was checked before giving up (sources, screens, queries)"); sp.add_argument("--needed", help="what is needed to finish it")
    sp = sub.add_parser("progress"); sp.add_argument("file"); sp.add_argument("--all", action="store_true")
    sp = sub.add_parser("report"); sp.add_argument("file")
    sp = sub.add_parser("link"); sp.add_argument("kind", choices=["data", "element"]); sp.add_argument("file"); sp.add_argument("name")
    sp.add_argument("--to", required=True); sp.add_argument("--where")
    sp = sub.add_parser("map"); sp.add_argument("file"); sp.add_argument("tc", nargs="*"); sp.add_argument("--draft", action="store_true")
    sp = sub.add_parser("sql-check"); sp.add_argument("query")
    sp = sub.add_parser("lesson"); sp.add_argument("action", choices=["add", "find", "list"]); sp.add_argument("text", nargs="*")
    sp.add_argument("--about"); sp.add_argument("--source", default="user answer"); sp.add_argument("--tc"); sp.add_argument("--new", action="store_true")
    sp = sub.add_parser("learn"); sp.add_argument("file"); sp.add_argument("tc"); sp.add_argument("robot"); sp.add_argument("--resource", action="append")
    a = ap.parse_args(argv)
    for f in getattr(a, "files", None) or []:
        if not os.path.isfile(f):
            raise SystemExit(f"File not found: {f}")
    if a.cmd == "sql-check":
        return cmd_sql_check(a)
    if a.cmd == "lesson":
        return cmd_lesson(a)
    if getattr(a, "file", None) and not os.path.isfile(a.file):
        raise SystemExit(f"File not found: {a.file}")
    if a.cmd == "packet":
        a.tc = a.tc if len(a.tc) > 1 else a.tc[0]
    {"index": cmd_index, "list": cmd_list, "shared": cmd_shared, "packet": cmd_packet, "plan": cmd_plan, "next": cmd_next,
     "status": cmd_status, "review": cmd_review, "card": cmd_card, "combine": cmd_combine, "progress": cmd_progress, "report": cmd_report, "link": cmd_link, "learn": cmd_learn, "change": cmd_change, "map": cmd_map}[a.cmd](a)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(0)
