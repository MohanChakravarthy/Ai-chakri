---
name: app-knowledge-builder
description: Builds or incrementally refreshes the application knowledge base of a Robot Framework QA automation repository. Analyses regression suites, resource files and an optional qTest CSV export to map modules, screens, navigation paths, business flows, entities and test data, plus an application map (entry routes, preconditions, proof elements, blocking messages), a glossary and UI patterns, with stable IDs used by keyword-knowledge-builder, locator-knowledge-builder and robot-script-generator. Use when asked to build, create, refresh, update or rebuild application knowledge.
version: 0.1.0
---

# App Knowledge Builder

## 1. Purpose and principles
Produce an accurate, evidence-based map of how the application under test works, derived from the existing automated regression tests. It is the foundation for every downstream skill, so accuracy beats speed.

- **Evidence only.** Every screen, flow and entity must be traceable to at least one source test or qTest case. Never infer features that are not evidenced; record uncertainty under Open questions.
- **Read-only on the codebase.** Never modify, move, format or delete any `.robot`, `.resource`, `.py`, variable or config file. Write only inside `qa-ai-data/knowledge/`.
- **Stable IDs.** IDs, once issued, never change. Downstream skills depend on them.
- **Deterministic output.** Same input produces the same structure: sort modules, screens and flows alphabetically by ID; use the exact templates below.
- **No secrets.** Never copy passwords, tokens, API keys, connection strings, real customer names or personal data into knowledge files. Refer to them by variable name only (e.g. `${PORTAL_PASSWORD}`).

## 2. Inputs
**Primary source of facts: `qa-ai-data/knowledge/.extract/`** (produced by the extractor `extract_repo.py` found under `qa-ai-skills/skills/`, e.g. `qa-ai-skills/skills/qa-knowledge-setup/extract_repo.py`). Use `tests.json` for test names, files, lines, tags, documentation, setup/teardown, templates and ordered steps (with resolved keyword targets); `summary.json` for library per file, test organisation, UI patterns and parse errors; `routes.json` for entry routes and prerequisites; `ui-signals.json` for on-screen messages. Keys in `routes.json` are `<file>::<keyword name>` for user keywords and `lib:<keyword> <first argument>` for library steps written directly in tests; `always_before` lists what every test did before that step. If `.extract/` is missing or older than the current commit, run the extractor first. Do not read raw `.robot` files to collect facts; open a raw file only for a specific line range when a step's business meaning is unclear. Your job here is meaning: modules, screens, flows, business-language steps and IDs.

1. **Config (optional):** `qa-ai-data/knowledge/config.yaml`
   - `project_name` (default: repo folder name)
   - `suites_paths` (default: auto-detect folders containing `.robot` files)
   - `resources_paths` (default: auto-detect `.resource` and keyword `.robot` files)
   - `qtest_export_path` (default: `qtest-export/`)
   - `exclude_paths` (always excluded: `results/`, `output/`, `logs/`, `reports/`, `.venv/`, `venv/`, `node_modules/`, `.git/`, `qa-ai-data/ai_generated_tests/` - AI drafts are never evidence)
   - `module_map` (optional: folder or tag to module name overrides)
2. **Robot Framework sources:** suites, resource files, variable files, and `__init__.robot` files (suite setup and teardown).
3. **qTest export (optional):** `.csv` preferred; `.xlsx` accepted. Expected columns (match case-insensitively and by closest name): Test Case ID, Name, Module or Folder, Description, Precondition, Step, Expected Result, Priority, Status. If the folder is missing or empty, proceed with Robot sources only and record `qtest_export_used: no`.

If the user's request names specific folders, modules or files, limit the run to those.

## 3. Outputs
```
qa-ai-data/knowledge/
  app-knowledge.md          # index, registries, run metadata
  app/
    MOD-<NAME>.md           # one detail file per module
  app-map.md                # application map: screens as states, transitions, preconditions
  glossary.md               # user words -> screen / element / action IDs
  ui-patterns.md            # enterprise UI patterns this app uses and how tests handle them
  run-config.md             # how tests are normally run: command, files, variables, setup chain
  app-knowledge.log.md      # run history (append-only)
```
Create missing folders. Overwrite only the files you are regenerating; never delete a module file, mark it deprecated instead.

## 4. Procedure

### Step 1: Pre-flight
- Confirm the workspace is a git repository and capture `git rev-parse HEAD` and the current branch. If there are uncommitted changes to `.robot` or `.resource` files, warn the user that knowledge will reflect the working copy.
- Load `qa-ai-data/knowledge/config.yaml` if present; validate paths exist and report any that do not.
- Inventory sources: count suite files, test cases, resource files, keywords, and qTest rows. Show this inventory to the user before heavy processing.

### Step 2: Detect framework and conventions
- **Automation library** from `Library` imports and `requirements*.txt` / `pyproject.toml`: `Browser` = Robot Framework Browser (Playwright); `SeleniumLibrary` = Selenium. Record per suite if mixed.
- **Test organisation:** one test per `.robot` file, or many tests per suite file.
- **Test ID convention:** where qTest IDs live (tags such as `TC-1234`, `[Documentation]`, or test names).
- **Environment and login pattern:** how URLs and credentials are supplied (variable files, CLI variables, environment variables).
- **Common setup and teardown** from `__init__.robot` and `Suite Setup` / `Test Setup`.

### Step 3: Choose full or incremental run
- The plan from `split_extract.py` decides (qa-knowledge-setup step 1): build the modules in this stage's `changed` list, keep `unchanged` ones. For `rebuild`, every module is in `changed`. Modules listed in `not_in_this_extract` are outside this run's scope: never delete or change their files.
- Deleted tests: remove their citations; if a flow loses all evidence, mark it `deprecated` (keep its ID).

### Step 4: Build the module list
- The modules are the plan's modules (one per test folder, with `module_map` overrides from `qa-ai-data/knowledge/config.yaml`), so every stage and every sub-agent uses the same names. `MOD-COMMON` (shared keywords and locators) has no app module file.
- Show the module list (name, number of tests, to build or unchanged) and continue. To group modules differently, the user adds `module_map` to `qa-ai-data/knowledge/config.yaml`.

### Step 5: Process one module at a time
**Work from the worksheet.** `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py worksheet app <MODULE>` prints the module compactly: one line per test (file::name, tags, documentation, its steps as keyword names), the shortest real entry route of every keyword with the tests using it and what always runs before, the on-screen messages and the development links. Write the module from it; open the brief below only for a fact the worksheet lacks. qa-knowledge-setup has already run `split_extract.py plan`, which cut the extract into one brief per module (`qa-ai-data/knowledge/.tmp/briefs/<MODULE>/brief.json`: the module's tests, the keywords and locators it owns, the shared keywords it calls by name only, its routes, messages and development links) and listed which modules to build for this stage (`changed`). Build only those; leave the files of `unchanged` modules exactly as they are. Take every fact from the brief; never read the `.robot`, `.resource` or development source files to collect facts again, and never read another module's brief. Open a source file only for one specific line range (at most 300 lines) when the brief lacks a fact. Keep the Notes and learned entries of the module's existing file. When you work as a sub-agent for one module, read only this skill file, your brief and your module's existing file, write only your module's files, and reply with the files written, the counts and any open questions; the main agent records the module and writes the index files.
1. For each module, take its tests from `tests.json`: name, documentation, tags, setup, teardown, template and steps (with file and line).
2. Follow keyword calls through `keywords.json` (`calls` with resolved targets, `steps`, `documentation`) only as deep as needed to understand navigation and business actions (normally 2 levels), and use `routes.json` for entry routes and prerequisites. Do not catalogue keywords or locators here; other skills do that.
3. Expand data-driven tests (`[Template]`, FOR loops) into the business variations they cover, e.g. one flow with several address types.
4. Match qTest rows to tests by ID. Use qTest steps and expected results to describe business meaning. Record unmatched qTest cases as **Not automated**, and Robot tests with no qTest ID as **No qTest link**.
5. Write the module file, then append a progress line to the run log, then move to the next module. If the run is interrupted, resume from the log.

### Step 6: Extract per module
- **Screens:** ID, name, navigation path from login, and UI areas (tabs, grids, dialogs, dropdowns, forms) evidenced by tests.
- **Flows:** ID, name, purpose, preconditions, test data (by variable name), ordered business steps, screens touched, expected results, variations, priority if known, and source tests.
- **Entities:** business objects and their known values or types (e.g. Customer, Address, Address Type).
- **Dependencies:** flows that must run first (e.g. Login, Open Client).

### Step 6b: Build the application map (relations are mandatory)
The map is what makes scripts correct: it says how to reach every screen and what must be true first. **The facts are rendered from the code; you name the screens and write what needs understanding.** For each screen, add one line to `qa-ai-data/knowledge/meaning/app/screens.md`:
```
SCREEN-CLIENT-ADDRESSES | Addresses tab | MOD-CLIENT | KW-OPEN-ADDRESSES-TAB | client selected; logged in | (proof ${VAR} only to override) | Close or Cancel; unsaved-changes dialog
- Blocking messages: MSG-ADDRESSES-NO-CLIENT "No customer selected" | cause: no client open | fix: entry route from Open Client
- Development screen: /clients/:id/addresses "Addresses" (high: 3 IDs, URL)
```
Columns: screen ID | name | module | entry keyword ID (as the keyword worksheet shows it) | preconditions in business words | proof element only when the rendered one is wrong | exit and cleanup. Lines starting with `- ` below a screen (blocking messages, development screen, waits for, fields that depend on a condition) are copied into its entry; a `## Not yet covered by tests` section at the end is copied to the end of the map. Then `knowledge_build.py render app-map` writes `app-map.md`: the entry keyword with file and line, the entry route copied verbatim from the shortest real route with its source test, what always runs before it, the proof element (the last locator the entry keyword waits for or checks, else the first one the source test checks right after it; otherwise an Open question), "probable: single test" when only one test reaches the screen, and the transitions to the other screens. Never write `app-map.md` by hand. The rules below say what each part means and how to choose it:
For every screen:
- **Entry keyword:** the first keyword (or library step) that lands on this screen in the tests.
- **Entry route:** copy the shortest `example_routes` entry for that keyword verbatim, with its `source_test`. This is the only approved way in; never write a shorter path. The one change allowed: replace literal data values (client names, IDs, account numbers, any `***MASKED***` or `***NUM***`) with the variable the test uses or with `<value>`, so no real data reaches the knowledge files.
- **Preconditions:** translate every item in `always_before` into a business condition (e.g. `Open Client` -> `client selected`; `Login To Portal` -> `logged in`). An item present in all tests reaching the screen is a hard precondition. Keep as preconditions only navigation and context-setting steps (open browser, log in, search or open a record, select a client or account, navigate, switch mode); assertions and data entry in `always_before` are not preconditions. If `tests_using` is 1, mark the preconditions `probable (single test)` so the generator verifies them live. Record the context the screen needs (selected client, account, record, role, edit mode, feature flag).
- **Proof element:** a locator variable that the tests wait for or assert right after arriving (from `Wait For Elements State`, `Wait Until Element Is Visible`, `Get Text`, `Should` steps). This is how the generator confirms the screen really loaded. If none exists, write `Proof element: none (generator must find one live)` and add an Open question.
- **Transitions:** every other screen reachable from here, with the keyword that moves there.
- **Blocking messages:** from `ui-signals.json` messages, record each message text, the screen where it appears, its cause (the missing precondition) and the fix (the keyword or route that satisfies it). Example: `"No customer selected"` on Addresses -> cause: no customer open -> fix: run the entry route from `Open Client`.
- **Exit and cleanup:** how tests leave the screen (save, cancel, close, logout) and any unsaved-changes or confirm dialogs.

Transition and message IDs: `TR-<FROM>-TO-<TO>`, `MSG-<SCREEN>-<SHORT>`; same stability rules as other IDs.

**With development knowledge** (`qa-ai-data/knowledge/dev/dev-qa-links.md` exists; it is built in the step before this one): add to every QA screen that has a **high or medium** link:
- `Development screen:` its route and title, with the confidence and evidence in short form ("high: 3 IDs, URL").
- `Waits for:` the data it loads on open and the loading indicator (from `qa-ai-data/knowledge/dev/app-overview.md`). If the screen has no proof element from the tests, name the development proof element as `Proof element (from development code, prove live): <element>`; never mark it as proven.
- `Fields that depend on a condition:` a one-line pointer to `qa-ai-data/knowledge/dev/form-variants.md` when the screen has any.
Low or ambiguous links are not copied into the map; they stay in `dev-qa-links.md` to be confirmed. Development screens with no QA link go into a "Not yet covered by tests" list at the end of the map (route, title), so the generator knows they exist but has no route to them yet. The QA facts always come first: never change an entry route, precondition or transition because of the development code. If the two disagree, keep the QA fact and add an Open question.

### Step 6c: Build the glossary
For every screen, element and action, collect the words a person might use: tab and menu labels (from `text=` and label locators), page titles, test and keyword names split into words, documentation phrases, qTest names, and common abbreviations. Map each term to exactly one ID; if a term maps to several IDs, list all and mark it `ambiguous` so the generator asks the user. With development knowledge, also add for each linked screen its page title, tab names and route words from the development code as synonyms (they are often the words a test case uses), and the screen's aliases from `qa-ai-data/knowledge/dev/dev-qa-links.md`.

### Step 6d: Record UI patterns
From `summary.json` `ui_patterns_detected` and `ui-signals.json`, write `ui-patterns.md`: each pattern this app uses (frames, shadow DOM, modals and alerts, toasts, loading spinners, new tabs or windows, custom or MUI or Lightning dropdowns, date pickers, virtualised or paginated grids, Sleep usage) with 1-2 real examples and the existing keyword that handles it. Patterns with no handling keyword are listed as risks.

### Step 6e: Record the run configuration (mandatory)
The generator and rf-mcp must reproduce a normal run exactly; missing setup was the cause of real failures (vault values not loaded, login typed twice). First run `python qa-ai-skills/skills/qa-knowledge-setup/knowledge_build.py render run-config`: it writes the facts the extract holds (library per suite, init files and their setups, variable files, unresolved imports, secrets loading and the path to it for every suite, import order per suite, suite setup chain) between the `generated` markers, which are rewritten on every render. Then fill only the lines marked `<AI ...>` (command, working folder, command-line variables, environments, how secrets reach the tests, environment variables, headed switch, login retries, open questions) in `qa-ai-data/knowledge/run-config.md` from evidence only (README, `requirements*.txt`, argument files `*.args`/`*.txt` used with `--argumentfile`, CI files, scripts in `scripts/` or `bin/`, `__init__.robot` files, variable files, `summary.json` `init_suite_setups`), never guessing:
```
# Run Configuration: <project_name>
- Normal command: robot <options> <suite path>   (source: <file>; ask the user once if no file shows it)
- Automation library per suite: <from summary.json suite_libraries: SeleniumLibrary, Browser or mixed>; browser used (chrome, edge, firefox, chromium) and where it is set
- Working folder robot is started from (`${EXECDIR}`): <repo root or other>
- Command-line variables and the defaults they override: <e.g. ENV: suite default QA, normal runs pass the test environment> (names and environment names only)
- Argument files: <paths or none>
- Variable files and their arguments: <from summary.json variables_imports, e.g. config/secrets_loader.py with ${ENV}> (paths and argument names, never values)
- Imports the extractor could not follow: <from summary.json unresolved_imports, or none> and the `--variable` that resolves them
- Environment variables required: <names only, e.g. VAULT_ADDR>; `.env` files and what loads them (names only, never values)
- How secrets reach the tests: <one of: a vault loader keyword or library, a variables file reading environment variables, a `.env` file, `--variable` on the command line, or a mix> (names and files only)
- Environments: <every environment name found in variable/config files or loader branches, e.g. QA, UAT> and how one is chosen (<variable>); the generator offers exactly this list at start-up
- Folder init files: <list from summary.json init_files, .robot or .txt>; setups found in them: <keywords, or "none">
- Suite setup chain (runs once per session, in order): <init file> -> <keyword, or none>; <suite> -> <keyword>
- Vault / secrets loading: <keyword and file that load them>, and **how each suite reaches that file** from summary.json `secrets_loaders` (e.g. `<suite> -> resources/global.resource -> common/common_password_handler.resource`). List it for every suite in scope, even when the suite imports it only through another resource. Must run exactly once per session
- Import order per suite: <from qa-ai-data/knowledge/.extract/import-chains.json: the suite's own Library / Resource / Variables lines in file order (depth 0), with any variable a later import needs and the file that defines it>; the generator imports exactly these lines, in this order, and nothing nested on its own
- Browser and headed switch: <library>, <variable or "hard-coded headless in <file>:<line>">
- Login retries inside keywords: <keyword: n attempts, or none>
- Open questions: <anything not evidenced>
```
Names of variables only, never values.

### Step 7: Build the index
Assemble `qa-ai-data/knowledge/app-knowledge.md` from all module files (template in section 6).

### Step 8: Self-validate before finishing
Your output must pass knowledge-reviewer and `knowledge_build.py check` (every test file in a module file, no `<AI ...>` line left, every map screen with an entry route). Never write helper scripts.
- Every flow cites at least one existing source file and test name (verify the files exist).
- Every screen referenced by a flow is defined in a module file.
- Every active screen in app-map.md has an entry route copied from a real test, preconditions, and a proof element (or an Open question).
- Every glossary term maps to an existing ID.
- No duplicate IDs; no previously issued ID is missing (deprecated is fine).
- No secrets or personal data in output (scan for password, token, secret, apikey patterns and email addresses).
- Counts in the index match the module files.
- `run-config.md` exists and every line cites a source file (or is listed under Open questions).
- Every suite in scope with an entry in `summary.json` `secrets_loaders` has its secrets loader and the path to it written in `run-config.md`.
Fix any failure before reporting.

### Step 9: Report to the user
Summarise: full or incremental run, modules processed, counts of screens, flows, entities and tests covered, qTest matched vs not automated vs no qTest link, deprecated items, open questions, and output paths. Do not commit; leave committing to the user.

## 5. ID rules (critical for linking)
- Module: `MOD-<NAME>`, e.g. `MOD-CLIENT`.
- Screen: `SCREEN-<MODULE>-<NAME>`, e.g. `SCREEN-CUSTOMER-ADDRESSES-TAB`.
- Flow: `FLOW-<MODULE>-<ACTION>`, e.g. `FLOW-CUSTOMER-ADD-ADDRESS`.
- Entity: `ENT-<NAME>`, e.g. `ENT-ADDRESS-TYPE`.
- Uppercase, hyphen-separated, ASCII only, max 60 characters, unique across the repo.
- Never rename or reuse an ID. Mark obsolete items `Status: deprecated`. If a name changes, keep the ID and update the name.

## 6. Templates

### Module file: `qa-ai-data/knowledge/app/MOD-<NAME>.md`
```
# Module: <Name> (MOD-<NAME>)
Last updated: <ISO date> | Commit: <hash> | Status: active

## Summary
<2-3 sentences: what this module does for the business>

## Screens
### SCREEN-<...> | <Name>
- Navigation: Login > <Menu> > <Page> > <Tab>
- UI areas: <tabs, grids, dialogs, dropdowns, forms>
- Status: active

## Flows
### FLOW-<...> | <Name>
- Purpose: <one line>
- Depends on: FLOW-<...>
- Preconditions: <state required>
- Test data: ${VARIABLE_NAMES}
- Steps:
  1. <business-language step>
  2. ...
- Screens: SCREEN-<...>, SCREEN-<...>
- Expected results: <observable outcomes>
- Variations: <data-driven cases, e.g. types ABCD, EFGH>
- Priority: <from qTest if known>
- Source tests: <path>::<test name> [<qTest ID>]
- Status: active

## Entities
- ENT-<...> | <Name>: <attributes / known values>

## Not automated (qTest only)
- <qTest ID> | <name> | <one-line summary>

## No qTest link
- <path>::<test name>

## Open questions
- <what is unclear and which test raised it>
```

### Index file: `qa-ai-data/knowledge/app-knowledge.md`
```
# Application Knowledge: <project_name>

## Metadata
- schema_version: 1
- generated_at: <ISO timestamp>
- last_commit: <hash>
- branch: <branch>
- automation_library: Browser | SeleniumLibrary | mixed (see per-suite list)
- test_organisation: one-test-per-file | many-tests-per-suite
- test_id_convention: <e.g. tag TC-####>
- qtest_export_used: yes | no

## Overview
<one paragraph describing the application>

## Modules
| Module ID | Name | File | Screens | Flows | Tests |

## Screen registry
| Screen ID | Name | Module | Navigation |

## Flow registry
| Flow ID | Name | Module | Depends on | Status |

## Common flows
<login, main navigation, global setup and teardown>

## Coverage
- Robot tests analysed / qTest matched / not automated / no qTest link
```

### Application map file: `qa-ai-data/knowledge/app-map.md`
```
# Application Map: <project_name>
Start state: logged out

## SCREEN-<...> | <Name>
- Module: MOD-<...>
- Entry keyword: <keyword name> (<file>:<line>)
- Entry route (from <source test>):
  1. <step as in the test, data replaced by variables>
  2. ...
- Preconditions: logged in; client selected; <other context>
- Proof element: ${VARIABLE} (<what it is>)
- Transitions: TR-<...> -> SCREEN-<...> via <keyword>
- Blocking messages: MSG-<...> "<text>" | cause: <missing precondition> | fix: <keyword / route>
- Exit: <how tests leave; dialogs on exit>
- Development screen: <route> "<title>" (high | medium: <evidence>)   (only with development knowledge)
- Waits for: <data loaded on open>; loading indicator <name>          (only with development knowledge)
- Status: active | learned (needs review)
```

### Glossary file: `qa-ai-data/knowledge/glossary.md`
```
| Term | Synonyms | Maps to | Kind (screen/element/action) | Ambiguous |
```

## 7. Writing rules
- Business language in steps ("Open client", "Go to Addresses tab"), never locators or code.
- Concise bullets; no copied code blocks from the repo.
- Use only the templates above; do not add or rename sections.
- When unsure, ask in Open questions rather than guess.

## 8. Error handling
- Unparseable file: skip it, list it in the report and run log, continue.
- qTest file with unrecognised columns: show the detected headers, map what you can, and ask the user to confirm the mapping before using it.
- Conflicting evidence (e.g. two navigation paths): record both with their sources and add an Open question.
- Context pressure: if a module is too large, split it into sub-modules (`MOD-CUSTOMER-ADDR`) rather than skimming.

## 9. Example requests
- "@app-knowledge-builder build the application knowledge for this repo."
- "@app-knowledge-builder build the application knowledge using the regression suites and the qTest export."
- "@app-knowledge-builder refresh the application knowledge for changes since the last run."
- "@app-knowledge-builder rebuild the knowledge for the Client module only."
