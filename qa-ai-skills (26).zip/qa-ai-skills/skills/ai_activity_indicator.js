// ai_activity_indicator.js - AI status glow and badge, coloured by the tool that is working.
// Loaded by Playwright MCP's --init-script (every page it opens), and injected by
// ai_session.py / ai_activity_indicator.py on pages driven by rf-mcp or the AI's Robot runs.
// It is only ever loaded by the AI skills: a normal Robot run by a person never shows it.
//
// Modes (window.__aiMode):
//   'rf'          blue    - rf-mcp is running the existing keywords (login, navigation, ...)
//   'playwright'  purple  - Playwright MCP is reading a new screen (default for Playwright pages)
//   'robot'       yellow  - the AI's own Robot Framework run is checking the finished test
//
// Safe: ignores the mouse (pointer-events: none), text lives in a closed shadow root (text
// checks and locators never see it), styles are set from script (works with strict CSP),
// all errors swallowed.
// Update from the AI:  window.__aiSetLabel('AI assistant is reviewing this page', 'Search Client', 'playwright')
//   line 1 = what is happening (plain English), line 2 = "Keyword: <name>" (hidden if empty)
(() => {
  try {
    if (window.top !== window.self) return;            // main page only, not inside frames
    const MODES = {
      rf:         { tag: 'ROBOT FRAMEWORK MCP', glow: '37,99,235',  soft: '96,165,250',
                    bg: '#1D4ED8', fg: '#FFFFFF', fg2: '#DBEAFE', tagc: '#BFDBFE', border: '#1E3A8A' },
      playwright: { tag: 'PLAYWRIGHT MCP',      glow: '124,58,237', soft: '167,139,250',
                    bg: '#6D28D9', fg: '#FFFFFF', fg2: '#EDE9FE', tagc: '#DDD6FE', border: '#4C1D95' },
      robot:      { tag: 'ROBOT FRAMEWORK RUN', glow: '245,158,11', soft: '253,224,71',
                    bg: '#FFD60A', fg: '#111111', fg2: '#3F3F46', tagc: '#7C4A03', border: '#B45309' }
    };
    const mode = (m) => (MODES[m] ? m : (MODES[window.__aiMode] ? window.__aiMode : 'playwright'));
    const DEFAULT = window.__aiLabelText || 'AI assistant is reviewing this page';

    const paint = () => {
      try {
        const m = MODES[mode(window.__aiMode)];
        const d = window.__aiFrame, b = window.__aiBadge;
        if (!d || !b) return;
        d.style.boxShadow = 'inset 0 0 0 3px rgba(' + m.glow + ',0.95), inset 0 0 28px 6px rgba(' + m.soft + ',0.55)';
        Object.assign(b.style, { background: m.bg, color: m.fg, border: '1px solid ' + m.border,
          outline: '2px solid rgba(255,255,255,0.85)' });
        window.__aiTag.textContent = m.tag;
        window.__aiTag.style.color = m.tagc;
        window.__aiLine2.style.color = m.fg2;
        if (window.__aiAnim) { try { window.__aiAnim.cancel(); } catch (e) {} }
        if (d.animate) window.__aiAnim = d.animate([
          { boxShadow: 'inset 0 0 0 2px rgba(' + m.glow + ',0.7), inset 0 0 14px 2px rgba(' + m.soft + ',0.35)' },
          { boxShadow: 'inset 0 0 0 4px rgba(' + m.glow + ',1), inset 0 0 40px 10px rgba(' + m.soft + ',0.75)' }
        ], { duration: 1600, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' });
      } catch (e) {}
    };

    window.__aiSetLabel = (text, keyword, newMode) => {
      try {
        if (newMode && MODES[newMode]) window.__aiMode = newMode;
        window.__aiLabelText = String(text || DEFAULT).slice(0, 90);
        window.__aiKeywordText = keyword ? String(keyword).slice(0, 80) : '';
        if (window.__aiLine1) window.__aiLine1.textContent = window.__aiLabelText;
        if (window.__aiLine2) {
          window.__aiLine2.textContent = window.__aiKeywordText ? 'Keyword: ' + window.__aiKeywordText : '';
          window.__aiLine2.style.display = window.__aiKeywordText ? 'block' : 'none';
        }
        paint();
      } catch (e) {}
    };

    const draw = () => {
      try {
        if (document.getElementById('ai-activity-indicator')) return;
        const root = document.documentElement;
        if (!root) return;
        const d = document.createElement('div');
        d.id = 'ai-activity-indicator';
        d.setAttribute('aria-hidden', 'true');
        Object.assign(d.style, { position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
          pointerEvents: 'none', zIndex: '2147483647', borderRadius: '6px' });
        const sr = d.attachShadow({ mode: 'closed' });
        const badge = document.createElement('div');
        Object.assign(badge.style, { position: 'absolute', top: '10px', right: '14px', maxWidth: '60vw',
          borderRadius: '10px', padding: '6px 12px 7px', boxShadow: '0 2px 12px rgba(0,0,0,0.35)',
          font: '13px/1.35 Segoe UI, Arial, sans-serif' });
        const tag = document.createElement('div');
        Object.assign(tag.style, { fontSize: '10px', fontWeight: '700', letterSpacing: '0.08em', marginBottom: '1px' });
        const l1 = document.createElement('div');
        Object.assign(l1.style, { fontWeight: '700', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' });
        const l2 = document.createElement('div');
        Object.assign(l2.style, { fontWeight: '500', fontSize: '12px', whiteSpace: 'nowrap',
          overflow: 'hidden', textOverflow: 'ellipsis', marginTop: '2px' });
        badge.appendChild(tag); badge.appendChild(l1); badge.appendChild(l2);
        sr.appendChild(badge);
        window.__aiFrame = d; window.__aiBadge = badge; window.__aiTag = tag;
        window.__aiLine1 = l1; window.__aiLine2 = l2;
        root.appendChild(d);
        window.__aiSetLabel(window.__aiLabelText || DEFAULT, window.__aiKeywordText || '', mode(window.__aiMode));
      } catch (e) {}
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw, { once: true });
    draw();
    try { new MutationObserver(() => { if (!document.getElementById('ai-activity-indicator')) draw(); })
      .observe(document.documentElement, { childList: true }); } catch (e) {}
  } catch (e) {}
})();
