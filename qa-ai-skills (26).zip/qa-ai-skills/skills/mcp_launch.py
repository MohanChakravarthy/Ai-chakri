#!/usr/bin/env python3
"""
mcp_launch.py - starts a Python MCP server inside the QA repo folder.

Some editors (Devin Desktop, Claude Code) cannot set the folder an MCP server starts in, but rf-mcp
must run in the QA repo so that Robot finds the suites, resources and ${EXECDIR}. The setup script
writes MCP entries that call this launcher:

    python skills/mcp_launch.py --cwd <QA repo> --module robotmcp.server

It changes to that folder and runs the module exactly like `python -m <module>`.
Python 3.8+, standard library only.
"""
import os, runpy, sys


def main():
    args = sys.argv[1:]
    cwd, module = None, None
    while args:
        a = args.pop(0)
        if a == "--cwd" and args:
            cwd = args.pop(0)
        elif a == "--module" and args:
            module = args.pop(0)
            break
    if not module:
        print("usage: mcp_launch.py --cwd <folder> --module <python module> [module arguments]", file=sys.stderr)
        sys.exit(2)
    if cwd:
        os.chdir(cwd)
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
    os.environ.setdefault("PYTHONUTF8", "1")
    sys.argv = [module] + args
    runpy.run_module(module, run_name="__main__", alter_sys=True)


if __name__ == "__main__":
    main()
